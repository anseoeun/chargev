import { MessageBox } from 'element-ui'
import axios from 'axios'
import Cookies from 'js-cookie'
import store from './store'
import qs from 'qs'
/**
 * Error Message setting
 */
const getMessages = (response = {}) => {
  return response.rspStatus
    ? {
      status: 'Error',
      message: response.rspStatus.rspMessage
    }
    : {
      status: 500,
      message: '서버접속불가 또는 잘못된 API'
    }
}

const getBaseUrl = () => {
  let exclusive = ''
  let gateway = ''
  let cscenter = ''
  let eis = ''

  if (process.env.NODE_ENV === 'production') {
    exclusive = process.env.VUE_APP_BASEURL_EXCLUSIVE
    gateway = process.env.VUE_APP_BASEURL_GATEWAY
    cscenter = process.env.VUE_APP_BASEURL_CSENTER
    eis = process.env.VUE_APP_BASEURL_EIS
  } else {
    // 환경설정 파일 분리 적용
    exclusive = 'https://dwcslt.hmc.co.kr'
    gateway = 'https://tepgw.hmc.co.kr/wp'
    eis = 'https://tepgw.hmc.co.kr/eis'
    // cscenter = 'http://dwcs.hmc.co.kr'
    //exclusive = 'http://localhost:8106'
    //gateway = 'http://localhost:8203'
  }

  return { exclusive, gateway, cscenter, eis }
}

const baseUrls = {
  exclusive:
    process.env.NODE_ENV !== 'production'
      ? 'http://tecslt.hmc.co.kr' // local
      : '/exclusive', // local
  //  ? ''
  //  : '',
  //gateway: process.env.NODE_ENV !== 'production'
  //   ? 'http://10.7.137.111/gw' // local
  //   : 'http://10.7.137.111/gw' // local
  //   ? '/gw'
  //   : '/gw'
  gateway:
    process.env.NODE_ENV !== 'production'
      ? '' // local
      : '/exclusive', // local

  cscenter:
    process.env.NODE_ENV !== 'production'
      ? 'http://twcs.hmc.co.kr' // local
      : '/customer-info' // local
}

// Https Module
class Https {
  constructor() {
    this.baseUrls = getBaseUrl()

    const sessionId = Cookies.get('sessionId')

    const defaultHeaders = {
      'api-Key': '54afb4e2-123d-44c2-a24d-43fa7dbfb761',
      'x-b3-sampled': 1,
      //'ep-channel': 'exclusive',
      'ep-channel': 'wexclusive',
      'ep-jsessionid': sessionId
    }

    this.defaultHeaders = defaultHeaders

    const ax = (customOption = {}, customHeaders = {}) =>
      axios.create({
        ...customOption,
        headers: { ...this.defaultHeaders, ...customHeaders }
      })
    this._axios = ax

    // const axBlob = axios.create({
    //   responseType: 'blob',
    //   headers: {
    //     'api-Key': '54afb4e2-123d-44c2-a24d-43fa7dbfb761',
    //     'x-b3-sampled': 1,
    //     'ep-channel': 'exclusive',
    //     'ep-jsessionid': sessionId
    //   },
    // })
    // this._axiosBlob = axBlob

    // const axForm = axios.create({
    //   headers: {
    //     'api-Key': '54afb4e2-123d-44c2-a24d-43fa7dbfb761',
    //     'Content-Type': 'multipart/form-data',
    //     'x-b3-sampled': 1,
    //     'ep-channel': 'exclusive',
    //     'ep-jsessionid': sessionId
    //   },
    // })
    // this._axiosForm = axForm
  }

  // GET
  async get(
    url = '',
    params = {},
    customErr,
    service,
    customOption = {},
    customHeaders = {}
  ) {
    const baseUrl = service ? this.baseUrls[service] : this.baseUrls.exclusive

    const sessionId = Cookies.get('sessionId')
    if (sessionId) {
      customHeaders['ep-jsessionid'] = sessionId
    }

    const currPath = store.state.currPath || '/'
    if (currPath) {
      customHeaders['ep-menu-id'] = currPath
    }

    this.onError = customErr ? customErr : this.onError
    const res = await this._axios(customOption, customHeaders)
      .get(`${baseUrl}${url.startsWith('/') ? '' : '/'}${url}`, {
        params: { ...params },
        paramsSerializer: params => {
          return qs.stringify(params)
        }
      })
      .then(res => this.onResult(res))
      .catch(err => {
        this.onError(err.response)
        return [null, err]
      })
    return res
  }

  // GET
  async getb(
    url = '',
    params = {},
    customErr,
    service,
    customOption = {},
    customHeaders = {}
  ) {
    const baseUrl = service ? this.baseUrls[service] : this.baseUrls.exclusive
    
    customOption['responseType'] = 'blob'
    
    const sessionId = Cookies.get('sessionId')
    if (sessionId) {
      customHeaders['ep-jsessionid'] = sessionId
    }
    
    const currPath = store.state.currPath || '/'
    if (currPath) {
      customHeaders['ep-menu-id'] = currPath
    }
    
    const epChannel = 'wexclusive' 
    customHeaders['ep-channel'] = epChannel

    this.onError = customErr ? customErr : this.onError
    const res = await this._axios(customOption, customHeaders)
      .get(`${baseUrl}${url.startsWith('/') ? '' : '/'}${url}`, {
        params: { ...params },
        paramsSerializer: params => {
          return qs.stringify(params)
        }
      })
      .then(res => this.onResult(res))
      .catch(err => {
        this.onError(err.response)
        return [null, err]
      })
    return res
  }

  // POST
  async post(
    url = '',
    data = {},
    customErr,
    service,
    customOption = {},
    customHeaders = {}
  ) {
    const baseUrl = service ? this.baseUrls[service] : this.baseUrls.exclusive

    // console.log(service)
    // console.log(baseUrl)

    const sessionId = Cookies.get('sessionId')
    if (sessionId) {
      customHeaders['ep-jsessionid'] = sessionId
    }

    const currPath = store.state.currPath || '/'
    if (currPath) {
      customHeaders['ep-menu-id'] = currPath
    }

    this.onError = customErr ? customErr : this.onError
    const res = await this._axios(customOption, customHeaders)
      .post(`${baseUrl}${url.startsWith('/') ? '' : '/'}${url}`, data)
      .then(res => this.onResult(res))
      .catch(err => {
        this.onError(err.response)
        return [null, err]
      })
    return res
  }

  // POST + Qs
  async postQs(
    url = '',
    params = {},
    customErr,
    service,
    customOption = {},
    customHeaders = {}
  ) {
    const baseUrl = service ? this.baseUrls[service] : this.baseUrls.exclusive

    const sessionId = Cookies.get('sessionId')
    if (sessionId) {
      customHeaders['ep-jsessionid'] = sessionId
    }

    const currPath = store.state.currPath || '/'
    if (currPath) {
      customHeaders['ep-menu-id'] = currPath
    }

    const query = qs.stringify({ ...params })
    this.onError = customErr ? customErr : this.onError
    const res = await this._axios(customOption, customHeaders)
      .post(`${baseUrl}${url.startsWith('/') ? '' : '/'}${url}?${query}`, {
        params: { ...params }
      })
      .then(res => this.onResult(res))
      .catch(err => {
        this.onError(err.response)
        return [null, err]
      })
    return res
  }

  // POST
  async postMultiPart(
    url = '',
    data = {},
    customErr,
    service,
    customOption = {},
    customHeaders = {}
  ) {
    const baseUrl = service ? this.baseUrls[service] : this.baseUrls.exclusive
    customHeaders['Content-Type'] = 'multipart/form-data'

    const sessionId = Cookies.get('sessionId')
    if (sessionId) {
      customHeaders['ep-jsessionid'] = sessionId
    }

    const currPath = store.state.currPath || '/'
    if (currPath) {
      customHeaders['ep-menu-id'] = currPath
    }

    this.onError = customErr ? customErr : this.onError
    const res = await this._axios(customOption, customHeaders)
      .post(`${baseUrl}${url.startsWith('/') ? '' : '/'}${url}`, data)
      .then(res => this.onResult(res))
      .catch(err => {
        this.onError(err.response)
        return [null, err]
      })
    return res
  }

  // POST
  async postNoErrMsg(
    url = '',
    data = {},
    customErr,
    service,
    customOption = {},
    customHeaders = {}
  ) {
    const baseUrl = service ? this.baseUrls[service] : this.baseUrls.exclusive

    console.log(service)
    console.log(baseUrl)

    const sessionId = Cookies.get('sessionId')
    if (sessionId) {
      customHeaders['ep-jsessionid'] = sessionId
    }

    const currPath = store.state.currPath || '/'
    if (currPath) {
      customHeaders['ep-menu-id'] = currPath
    }

    const res = await this._axios(customOption, customHeaders)
      .post(`${baseUrl}${url.startsWith('/') ? '' : '/'}${url}`, data)
      .then(res => this.onResultNoMsg(res))
      .catch(err => {
        return [null, err]
      })
    return res
  }

  // PUT (post에 _method=put)
  async put(
    url = '',
    data = {},
    customErr,
    service,
    customOption = {},
    customHeaders = {}
  ) {
    const baseUrl = service ? this.baseUrls[service] : this.baseUrls.exclusive

    const sessionId = Cookies.get('sessionId')
    if (sessionId) {
      customHeaders['ep-jsessionid'] = sessionId
    }

    const currPath = store.state.currPath || '/'
    if (currPath) {
      customHeaders['ep-menu-id'] = currPath
    }

    this.onError = customErr ? customErr : this.onError
    const res = await this._axios(customOption, customHeaders)
      .post(
        `${baseUrl}${url.startsWith('/') ? '' : '/'}${url}${
          url.indexOf('?') > -1 ? '&' : '?'
        }_method=put`,
        data
      )
      .then(res => this.onResult(res))
      .catch(err => {
        this.onError(err.response)
        return [null, err]
      })
    return res
  }

  // DELETE (post에 method=delete)
  async delete(
    url = '',
    data = {},
    params = {},
    customErr,
    service,
    customOption = {},
    customHeaders = {}
  ) {
    const baseUrl = service ? this.baseUrls[service] : this.baseUrls.exclusive

    const sessionId = Cookies.get('sessionId')
    if (sessionId) {
      customHeaders['ep-jsessionid'] = sessionId
    }

    const currPath = store.state.currPath || '/'
    if (currPath) {
      customHeaders['ep-menu-id'] = currPath
    }

    this.onError = customErr ? customErr : this.onError
    const res = await this._axios(customOption, customHeaders)
      .post(
        `${baseUrl}${url.startsWith('/') ? '' : '/'}${url}${
          url.indexOf('?') > -1 ? '&' : '?'
        }_method=delete`,
        data,
        {
          params: { ...params }
        }
      )
      .then(res => this.onResult(res))
      .catch(err => {
        this.onError(err.response)
        return [null, err]
      })
    return res
  }

  onResult(response) {
    const res = response.data
    const rspStatus = res.rspStatus
    const resConfig = response.config

    // 외부 API
    if (rspStatus === undefined) {
      if (response.status !== 200) {
        this.onError(res)
      }
      return response.status === 200 ? [res, null] : [null, null]
    } else {
      const { rspCode } = res.rspStatus
      if (rspCode !== '0000') {
        this.onError(res, resConfig)
      }
      return rspCode === '0000' ? [res, null] : [res, res.rspStatus]
    }
  }

  onResultNoMsg(response) {
    const res = response.data
    const rspStatus = res.rspStatus
    const resConfig = response.config

    // 외부 API
    if (rspStatus === undefined) {
      if (response.status !== 200) {
        this.onError(res)
      }
      return response.status === 200 ? [res, null] : [null, null]
    } else {
      const { rspCode } = res.rspStatus
      if (rspCode !== '0000') {
      }
      return rspCode === '0000' ? [res, null] : [res, res.rspStatus]
    }
  }

  // Client에서 API 호출 시 에러인 경우 message box
  onError(res, resConfig) {
    if (process.server) return
    if (resConfig && resConfig.url.indexOf('logout') > -1) {
      // 로그아웃일 경우
      return
    }
    if (
      res &&
      res.rspStatus &&
      (res.rspStatus.rspCode === 'EXP.1000' || res.rspStatus.rspCode === '1000')
    ) {
      // api호출시 데이터가 없을경우, alert 메시지창 띄우지 않음.
      return
    }
    if (
      res &&
      res.rspStatus &&
      ['EXP.1401', 'EXP.1402', 'EXP.3201', '1401', '1402', '3201'].includes(
        res.rspStatus.rspCode
      )
    ) {
      // 세션이 없을 경우
      Cookies.remove('sessionId')
      store.state.isAuthenticated = false
      location.href = '/#/login'
      //this.$router.push('/login')
      return
    }

    let { status, message } = getMessages(res)
    MessageBox.alert(message, status, {
      confirmButtonText: 'OK'
    })
  }
}

export default Https
