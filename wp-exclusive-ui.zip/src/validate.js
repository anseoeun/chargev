const validate = {
  require: {
    input: {
      required: true,
      message: '필수 입력 항목입니다',
      trigger: 'blur'
    },
    select: {
      required: true,
      message: '필수 선택 항목입니다',
      trigger: 'change'
    }
  }
}

export default {
  require(type = 'input', options = {}) {
    return { ...validate.require[type], ...options }
  }
}
