<template>
  <div>
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />

    <!-- 고객조회 팝업 -->
    <el-dialog title="고객조회" :visible.sync="popVisibleCustomer" class="popMember" width="1100px" @close="popVisibleCustomer = false">
      <!-- Popup Contents -->
      <el-form ref="info" class="detail-form">
        <el-row>
          <el-col :span="8">
            <el-form-item label="조회구분">
              <el-select
              v-model="searchForm.type"
              >
                <el-option 
                v-for="{ type, code } in customerType" 
                :key="code" 
                :value="code" 
                :label="type"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="이메일">
              <el-input v-model.trim="searchForm.email" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="고객관리번호">
              <el-input v-model.trim="searchForm.subjectNumber" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="이름" required>
              <el-input v-model.trim="searchForm.name" placeholder="이름과 생년월일을 조합해주세요" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="생년월일">
              <el-date-picker
                v-model="searchForm.bDay"
                type="date"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="휴대전화">
              <el-input v-model.trim="searchForm.mobile" />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>

      <div class="btn-group">
        <div class="right">
          <el-button type="info" class="btn-small" @click="resetSearchForm">초기화</el-button>
          <el-button type="primary" class="btn-small" @click.native="search">조회</el-button>
        </div>
      </div>

      <div class="article-title">
        <h2>조회결과</h2>
      </div>
      <el-table 
        ref="singleTable"
        :data="customerInfo" 
        empty-text="조회된 결과가 존재하지 않습니다."
        class="box"
        highlight-current-row
        @current-change="handleCurrentChange"
      >
        <el-table-column label="선택" width="50" align="center">
          <template slot-scope="scope">
            <el-radio-group v-model="selectRadio">
            <el-radio :label="scope.row.no" />
             </el-radio-group>
          </template>
        </el-table-column>
        <el-table-column prop="emailAddress" label="이메일" width="200" align="center"></el-table-column>
        <el-table-column prop="memberNumber" label="고객관리번호" width="150" align="center"></el-table-column>
        <el-table-column prop="fullName" label="고객명" width="150" align="center"></el-table-column>
        <el-table-column prop="birthDate" label="생년월일" width="100" align="center"></el-table-column>
        <el-table-column prop="mobile" label="휴대전화" width="100" align="center"></el-table-column>
        <el-table-column prop="employeeYn" label="직원여부" width="100" align="center"></el-table-column>
        <el-table-column prop="belongedTeam" label="소속" width="200" align="center"></el-table-column>
      </el-table>

      <template slot="footer">
        <div>
          <el-button type="info" @click="popVisibleCustomer = false">취소</el-button>
          <el-button type="primary" @click="selectCustomer">선택</el-button>
        </div>
      </template>

      <pop-message
        :pop-visible.sync="alertMessagePop"
        :pop-message.sync="alertMessage"
        @confirm="alertMessagePop = false"
        @close="alertMessagePop = false"
      />
      <loading
        :pop-visible.sync="popVisibleLoading"
        :close-on-click-modal="false"
        @close="popVisibleLoading = false"
      />
    </el-dialog>
  </div>
</template>
<script>
import Loading from '~/components/popup/Loading.vue'
import PopMessage from '~/components/popup/PopMessage.vue'
import moment from 'moment'
export default {
  components: {
    Loading,
    PopMessage
  },
  data() {
    return {
      findCustomerType: '',     // 조회 고객, 배우자용 구분
      alertMessage: '',
      alertMessagePop: false,
      popVisibleLoading: true,
      popVisibleCustomer: false,
      date: '',
      customerUniqNumber: null,
      selectRadio : '',       // radio 제어용
      memberInfo : {
        memberMngNumber: '',
        customerName: null,
        mobile: null,
        birthDate: null,
        emailAddress: null,
      },
      searchYear:[],
      searchForm: {
        year: moment().year(),
        type: 'M', //조회구분(M:회원정보, C:계약자정보)
        name: null, //이름
        email: null, //이메일주소
        subjectNumber: null, //고객관리번호
        mobile: null, //휴대전화
        bDay: null, //생년월일
      },
      customerType: [
        {
          type: '회원정보',
          code: 'M',
        },
        {
          type: '계약자정보',
          code: 'C',
        }
      ],
      customerInfo: []
    }
  },
  computed: {
    changeData() {
      return [
        this.customerUniqNumber,
        this.memberMngNumber,
      ]
    }
  },
  mounted () {
    this.searchYear = {
      first: moment().year(),
      second:moment().add(-1, 'y').year(),
      third: moment().add(-2, 'y').year(),
      fourth: moment().add(-3, 'y').year(),
      fifth: moment().add(-4, 'y').year(),
    }
  },
  methods : { 
    handleCurrentChange(val) {
      if(!val) return
      this.customerUniqNumber = val.customerUniqNumber // 고객 고유번호
      this.memberInfo.memberMngNumber = val.memberNumber  // 고객관리번호
      this.memberInfo.customerName = val.fullName ? val.fullName : ''  // 고객명
      this.memberInfo.mobile = val.mobile  ? val.mobile : ''          // 핸드폰번호
      this.memberInfo.birthDate = val.birthDate ? val.birthDate : ''  // 생일
      this.memberInfo.emailAddress = val.emailAddress ? val.emailAddress : '' // 이메일
    },
    search() {
      if(this.validation()) { return }

      // 초기화
      this.customerInfo = []

      if(this.searchForm.type === 'C') {
        //'계약자정보'로 조회시
        this.getCustomerInfoByContract()
      }else {
        //'회원정보'로 조회시
        this.getCustomerInfo()
      }
    },
    async getCustomerInfo() {

      // '회원정보'를 통해 회원정보조회
      let arr = []

      let mobileNumber = this.searchForm.mobile ? this.searchForm.mobile.replaceAll('-','') : null
      let birthDate = this.searchForm.bDay ? moment(this.searchForm.bDay).format('YYYYMMDD') : null
      let mbrNm = this.searchForm.name ? this.searchForm.name : null
      let csmrMgmtNo = this.searchForm.subjectNumber ? this.searchForm.subjectNumber : null
      let lgiId = this.searchForm.email ? this.searchForm.email : null

      const params = {
        mobile: mobileNumber,
        fullName: mbrNm,
        birthDate: birthDate,
        memberNumber: csmrMgmtNo,
        emailAddress: lgiId,
      }

      Object.keys(params).forEach(k => (
        !params[k] && params[k] !== undefined) && delete params[k]
      )
      const[res, err] = await this.$https.post('/v2/exclusive/total/member/searchMember', params)
 
      if(res && res.data) {
        // arr = [{
        //   no : 0,
        //   emailAddress: res.data.lgiId,
        //   fullName: res.data.mbrNm,
        //   birthDate: res.data.brdyYmd,
        //   mobile: res.data.hpTn,
        //   employeeYn: res.data.employeeYn ? res.data.employeeYn : '-',
        //   belongedTeam: res.data.belongedTeam ? res.data.belongedTeam : '-',
        //   customerUniqNumber: res.data.mbrMbno ? res.data.mbrMbno : '', //고객고유번호
        //   memberNumber: res.data.memberNumber //고객관리번호
        // }]   

        arr = res.data.map((item) => {
          return {
            ...item,
            employeeYn: item.employeeYn ? item.employeeYn : 'N',
            belongedTeam: item.belongedTeam ? item.belongedTeam : '-',
          }
        })

        if(arr.length > 0) {
          this.customerName = arr[0].fullName
          this.customerUniqNumber = arr[0].customerUniqNumber
          this.memberMngNumber = arr[0].memberNumber

          // 임직원 용
          this.memberInfo.customerName = arr[0].mbrNm
          this.memberInfo.memberMngNumber = arr[0].memberNumber
        }
        
        this.$refs.singleTable.setCurrentRow(arr[0]) //첫번째 데이터 선택 활성화
      } else {
        console.log(err)
        this.reset()
      } 
      this.customerInfo = arr

    },
    async getCustomerInfoByContract() {
      // '계약자정보'를 통해 회원정보조회
      let arr = []
      
      let mobileNumber = this.searchForm.mobile ? this.searchForm.mobile.replaceAll('-','') : null
      let birthDate = this.searchForm.bDay ? moment(this.searchForm.bDay).format('YYMMDD') : null
      let mbrNm = this.searchForm.name ? this.searchForm.name : null
      let csmrMgmtNo = this.searchForm.subjectNumber ? this.searchForm.subjectNumber : null
      let lgiId = this.searchForm.email ? this.searchForm.email : null


      const params = {
        mobile: mobileNumber,
        fullName: mbrNm,
        birthDate: birthDate,
        memberNumber: csmrMgmtNo,
        emailAddress: lgiId,
      }

      Object.keys(params).forEach(k => (
        !params[k] && params[k] !== undefined) && delete params[k]
      )

      const [res, err] = await this.$https.post('/v2/exclusive/total/member/searchCustomer', params)
      if(err) return
      if(res && res.data) {

        if(res.data.length > 0) {
          arr = res.data.map((items, idx) => {
            return {
              no : idx+1,
              emailAddress: items.emailAddress,
              fullName: items.fullName,
              birthDate: items.birthDate,
              mobile: items.mobile,
              employeeYn: items.employeeYn ? items.employeeYn : '-',
              belongedTeam: items.belongedTeam ? items.belongedTeam : '-',
              customerUniqNumber: items.customerUniqNumber ? items.customerUniqNumber : '', //고객고유번호
              memberNumber: items.memberNumber //고객관리번호
            }
          })

          if(arr.length > 0) {
            this.customerUniqNumber = arr[0].customerUniqNumber
            this.memberInfo.customerName = arr[0].fullName
            this.memberInfo.memberMngNumber = arr[0].memberNumber
            this.memberInfo.mobile = arr[0].mobile

            this.$refs.singleTable.setCurrentRow(arr[0]) //첫번째 데이터 선택 활성화
          }else {
            this.reset()
          }
        }
        this.customerInfo = arr   
      }

    },
    resetSearchForm() {
      //조회 영역 초기화
      Object.assign(this.searchForm, this.$options.data().searchForm)
      //검색 결과 초기화
      Object.assign(this.customerInfo, this.$options.data().customerInfo)

    },
    reset() {
      Object.assign(this.historyCnt, this.$options.data().historyCnt)
          
      this.$refs.estimate.estimateData = []
      this.$refs.trial.tableData = []
      this.$refs.contract.contractData = []
      this.$refs.coupon.couponData = []
      this.$refs.sms.tableData = []

      this.customerName = null
      this.customerUniqNumber = null
      this.memberMngNumber = null
    },
    validation() {
      let chk = false
      
      if(this.searchForm.name && !this.searchForm.bDay){
        chk = true
      }
      if(this.searchForm.bDay && !this.searchForm.name) {
        chk = true
      }
      if(chk) {
        this.alertMessage = '이름과 생년월일을 조합해주세요.'
        this.alertMessagePop = true
      }
      return chk
    },
    customerPopOpen(type) {
      this.findCustomerType = type
      this.popVisibleCustomer = true
      // 초기화
      this.customerInfo = []
    },
    selectCustomer(){
      this.memberInfo.birthDate = moment(this.memberInfo.birthDate).format('YYYY-MM-DD')
      this.memberInfo.type = this.findCustomerType

      this.$emit('buyCanDtime', this.memberInfo)
      this.popVisibleCustomer = false
    },
    onPopclose() {
      this.$emit('close')
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
