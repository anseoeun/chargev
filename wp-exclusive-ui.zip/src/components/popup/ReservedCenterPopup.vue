<template>
  <v-popup
    popup-type="v2"
    :visible="popShow.reservedCenterPop"
    class="delivery-popup center-pop"
    @close="onClose"
  >
    <template slot="body">
      <div id="reservedCenterPopupTop" class="popup-header">
        <h3>차량보관장소</h3>
        <span>출고센터 방문 예약</span>
      </div>

      <div class="contract-number">
        <p>계약번호 {{ contractNumber }}</p>
      </div>

      <div v-if="isChangeReservation" class="delivery-status">
        <div class="status-title">
          <h3>방문예약 변경</h3>
          <v-btn i-name="btn-refresh" @click="refreshVisitReservationInfo" />
        </div>
      </div>
      <div
        v-else-if="(currentReservationInfo && currentReservationInfo.visitPrearrangementTimeCode ) || info.onlineStatusCode == '0330'"
        class="delivery-status"
      >
        <div class="status-title">
          <h3>방문예약접수가 완료되었습니다.</h3>
          <v-btn i-name="btn-refresh" @click="refreshVisitReservationInfo" />
        </div>
        <p>
          방문예약 날짜는
          {{ (currentReservationInfo && currentReservationInfo.visitPrearrangementDay) && $moment(currentReservationInfo.visitPrearrangementDay, 'YYYYMMDD').format('YYYY.MM.DD') }} {{ currentReservationInfo && (currentReservationInfo.visitPrearrangementTimeCode || '') }} 입니다.
        </p>
      </div>
      <div v-else class="delivery-status">
        <div class="status-title">
          <h3>방문예약접수를 진행해주세요.</h3>
          <v-btn i-name="btn-refresh" @click="refreshVisitReservationInfo" />
        </div>
        <p>방문예약은 근무일 기준 1~2일 내에서 접수가능합니다.</p>
      </div>

      <div class="content-title flex-start">
        <h3>인수자 정보</h3>
        <span class="sub-text">인수자 변경은 방문 예약 당일까지 가능합니다.</span>
      </div>

      <div class="content-detail">
        <ul class="list-information information-dotted-list">
          <li>
            <div class="title">인수자</div>
            <div class="content">
              {{ contractDetail.acceqtorInfo ? contractDetail.acceqtorInfo.acceptorName : '-' }}
              {{
              contractDetail.acceqtorInfo && contractDetail.acceqtorInfo.acquisitionTypeName
              ? `(${contractDetail.acceqtorInfo.acquisitionTypeName})`
              : ''
              }}
            </div>
            <div class="title">연락처</div>
            <div
              class="content"
            >{{ contractDetail.acceqtorInfo ? contractDetail.acceqtorInfo.acceptorTelephonNumber : '-' }}</div>
            <div class="content right-button">
              <v-btn
                type="button"
                class="btn btn-mini btn-gray"
                :disabled="
                  contractDetail.carArrivalPrearrangementDate != null &&
                    contractDetail.carArrivalPrearrangementDate.length > 0 &&
                    $moment(contractDetail.carArrivalPrearrangementDate).diff(new Date(), 'days') <= 0
                "
                @click="isChangeAcceptor = true"
              >변경</v-btn>
            </div>
          </li>
        </ul>

        <div v-if="isChangeAcceptor" class="edit-form">
          <ul class="list-information information-dotted-list">
            <li>
              <div class="title">변경할 인수자</div>
              <div class="content">
                <v-select v-if="!changedAcceptor.isAgent"
                  v-model="changedAcceptor.relationPersonSerialNumber"
                  class="edit-select"
                  :data="relationPersonList"
                  value-key="relationPersonSerialNumber"
                  label-key="relationPersonName"
                  placeholder="선택하세요"
                  @change="onChangeRelationPerson"
                />
                <input v-if="changedAcceptor.isAgent" v-model="changedAcceptor.name" type="text" title="대리인 성명 입력" placeholder="성명을 입력하세요." />
                <v-checkbox
                  class="instead-check"
                  :one-check="true"
                  :checked.sync="changedAcceptor.isAgent"
                >대리인 신청</v-checkbox>
              </div>
            </li>
            <li v-if="changedAcceptor.isAgent === true">
              <div class="title">
                대리인 생년월일
              </div>
              <div class="content">
                <v-select
                  v-model="changedAcceptor.birthYear"
                  class="edit-select"
                  :data="birthYearList"
                  placeholder="년도"
                />
                <v-select
                  v-model="changedAcceptor.birthMonth"
                  class="edit-select"
                  :data="birthMonthList"
                  placeholder="월"
                />
                <v-select
                  v-model="changedAcceptor.birthDay"
                  class="edit-select"
                  :data="birthDayList"
                  placeholder="일"
                />
              </div>
            </li>
            <li v-if="changedAcceptor.isAgent === true">
              <div class="title">대리인 성별</div>
              <div class="content">
                <v-radio
                  v-model="changedAcceptor.gender"
                  :data="[{ value: '1', label: '남자' }, { value: '2', label: '여자' }]"
                />
              </div>
            </li>
            <li>
              <div class="title">변경할 연락처</div>
              <div class="content">
                <v-input v-model="changedAcceptor.phone" class="tel-input" />
              </div>
            </li>
          </ul>
          <div class="edit-button-group">
            <v-btn b-size="btn-md" b-type="btn-gray" @click="isChangeAcceptor = false">변경취소</v-btn>
            <v-btn b-size="btn-md" @click="confirmChangeAcceptor">변경 완료</v-btn>
          </div>
        </div>
      </div>

      <div
        v-if="currentReservationInfo && currentReservationInfo.visitPrearrangementTimeCode"
        class="content-title"
      >
        <h3>방문예약 접수내역</h3>
      </div>

      <div
        v-if="currentReservationInfo && currentReservationInfo.visitPrearrangementTimeCode"
        class="content-detail"
      >
        <div class="table-wrap">
          <table class="table delivery-table">
            <caption>예약신청 및 방문예약 일시 및 접수현황 정보</caption>
            <colgroup>
              <col width="35%" />
              <col width="40%" />
              <col width="25%" />
            </colgroup>
            <thead>
              <tr>
                <th>예약신청일시</th>
                <th>방문예약일시</th>
                <th>접수현황</th>
              </tr>
            </thead>
            <tbody>
              <tr v-if="currentReservationInfo">
                <td>{{ currentReservationInfo.deliveryRequestDate || '-' }}</td>
                <td>{{ currentReservationInfo.visitPrearrangementDay ? $moment(currentReservationInfo.visitPrearrangementDay, 'YYYYMMDD').format('YYYY.MM.DD') : '-' }} {{ currentReservationInfo.visitPrearrangementTimeCode || '' }}</td>
                <td>{{ currentReservationInfo.receiptSituation || '-' }}</td>
              </tr>
              <tr v-if="previousReservationInfo">
                <td>{{ previousReservationInfo.deliveryRequestDate || '-' }}</td>
                <td>{{ previousReservationInfo.visitPrearrangementDay ? $moment(previousReservationInfo.visitPrearrangementDay, 'YYYYMMDD').format('YYYY.MM.DD') : '-' }} {{ previousReservationInfo.visitPrearrangementTimeCode || '' }}</td>
                <td>{{ previousReservationInfo.receiptSituation || '-' }}</td>
              </tr>
              <tr v-if="!currentReservationInfo && !previousReservationInfo">
                <td colspan="3" class="empty-content">신청하신 방문예약 접수내역이 없습니다. 방문예약을 서둘러주세요!</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div
        v-if="!currentReservationInfo || !currentReservationInfo.visitPrearrangementTimeCode || isChangeReservation"
        class="content-title"
      >
        <h3>방문예약일 선택</h3>
      </div>

      <div
        v-if="!currentReservationInfo || !currentReservationInfo.visitPrearrangementTimeCode || isChangeReservation"
        class="before-notice-text"
      >
        <p>
          방문예약은 평일(근무일 기준) 1~2일 내에서만 가능합니다. 날짜를 선택 후, 희망하시는 시간대를 신중히
          선택해주세요.
        </p>
        <p class="point">※ 방문예약 신청 후 별도의 예약변경 없이 미방문 시, 차량배달탁송으로 전환되며 탁송료는 추가결제됩니다.</p>
      </div>

      <div
        v-if="!currentReservationInfo || !currentReservationInfo.visitPrearrangementTimeCode || isChangeReservation"
        class="content-detail"
      >
        <form action>
          <div class="btn-group date-sort-group">
            <v-btn
              b-size="btn-md"
              :b-type="selectedDayType == '1' ? 'btn-skyblue' : 'btn-confirm'"
              @click="selectedDayType = '1'; searchAvailableVisits()"
            >
              {{
              standardYearMonthDay1 ? $moment(standardYearMonthDay1, 'YYYYMMDD').format('M/D') : ''
              }}
              (+1일 후)
            </v-btn>
            <v-btn
              b-size="btn-md"
              :b-type="selectedDayType == '2' ? 'btn-skyblue' : 'btn-confirm'"
              @click="selectedDayType = '2'; searchAvailableVisits()"
            >
              {{
              standardYearMonthDay2 ? $moment(standardYearMonthDay2, 'YYYYMMDD').format('M/D') : ''
              }}
              (+2일 후)
            </v-btn>
          </div>
          <div class="table-wrap date-table">
            <table class="table">
              <colgroup>
                <col width="15%" />
                <col width="25%" />
                <col width="40%" />
                <col width="20%" />
              </colgroup>
              <tbody>
                <tr>
                  <th>선택</th>
                  <th>예약날짜</th>
                  <th>예약시간대</th>
                  <th>가능상태</th>
                </tr>
                <tr v-for="(time, idx) in visitReservationTime" :key="`time-${idx}`">
                  <td>
                    <el-radio
                      v-model="selectedVisitTime"
                      name="selectedVisitTime"
                      :label="time.criterionYearMonthDay + time.visitPrearrangementTimeCode"
                      :disabled="time.possibleStatusYn != 'Y'"
                      :custom-label="true"
                    >
                      <template>&nbsp;</template>
                    </el-radio>
                  </td>
                  <td>{{ time.criterionYearMonthDay && $moment(time.criterionYearMonthDay, 'YYYYMMDD').format('M/D') }}</td>
                  <td>
                    {{
                    time.visitPrearrangementTimeCode &&
                    $moment(time.visitPrearrangementTimeCode, 'HHmm').format('HH:mm')
                    }}
                    ~
                    {{
                    time.visitPrearrangementTimeCode &&
                    $moment(time.visitPrearrangementTimeCode, 'HHmm')
                    .add(30, 'minutes')
                    .format('HH:mm')
                    }}
                  </td>
                  <td>{{ time.possibleStatusYn == 'Y' ? '가능' : '불가능' }}</td>
                </tr>
                <tr v-if="!selectedDayType && !visitReservationTime">
                  <td colspan="4" class="empty-lg-content">방문예약일을 선택 후 조회 바랍니다.</td>
                </tr>
                <tr v-else-if="searching">
                  <td colspan="4" class="empty-lg-content">&nbsp;</td>
                </tr>
                <tr v-else-if="visitReservationTime && visitReservationTime.length == 0">
                  <td colspan="4" class="empty-lg-content">가능한 방문예약일이 없습니다.</td>
                </tr>
              </tbody>
            </table>
          </div>
        </form>
      </div>

      <div class="btn-group form-btn-group">
        <v-btn
          v-if="!currentReservationInfo || !currentReservationInfo.visitPrearrangementTimeCode"
          b-size="btn-md" data-link-area="마이페이지-진행중인계약" data-link-name="방문예약하기" 
          @click="reserveVisit"
        >방문예약하기</v-btn>
        <v-btn
          v-else-if="!isChangeReservation"
          b-size="btn-md"
          :disabled="
            info.onlineStatusCode == '9600' || !currentReservationInfo.visitPrearrangementDay ||
              $moment(currentReservationInfo.visitPrearrangementDay, 'YYYYMMDD').isBefore($moment(new Date()), 'day') 
          "
          @click="isChangeReservation = true"
        >방문예약 변경하기</v-btn>

        <v-btn
          v-if="isChangeReservation"
          b-size="btn-md"
          b-type="btn-gray"
          @click="isChangeReservation = false"
        >변경취소</v-btn>
        <v-btn v-if="isChangeReservation" b-size="btn-md" @click="reserveVisit">변경완료</v-btn>
      </div>

      <div class="content-title">
        <h3>차량보관장소</h3>
        <!-- <span>
          <a class="btn btn-more-blue" @click="howComePopVisible = true">교통편 안내</a>
        </span> -->
      </div>

      <div class="content-detail">
        <div class="center-address">
          <h4>{{ deliveryCenterDetail.data && deliveryCenterDetail.data.deliveryCenterName }}</h4>
          <sub>{{ deliveryCenterDetail.data && deliveryCenterDetail.data.deliveryCenterAddress }}</sub>
        </div>

        <vue-daum-map
          :app-key="kakaomapOptions.appKey"
          :center.sync="kakaomapOptions.center"
          :level.sync="kakaomapOptions.level"
          :map-type-id="kakaomapOptions.mapTypeId"
          :libraries="kakaomapOptions.libraries"
          class="maps"
          @load="onMapLoaded"
        />

        <div class="table-information">
          <ul class="list">
            <li>※약도 이미지를 클릭하시면 상세한 지도를 보실 수 있습니다.</li>
          </ul>
        </div>

        <div class="center-information">
          <ul class="vertical-dotted-list">
            <li>
              <strong>대표전화</strong>
              <span>{{ deliveryCenterDetail.data && deliveryCenterDetail.data.deliveryCenterTel }}</span>
            </li>
            <li>
              <strong>근무시간</strong>
              <span>{{ deliveryCenterDetail.data && deliveryCenterDetail.data.deliveryCenterOpTime }}</span>
            </li>
          </ul>
          <ul class="dotted-list">
            <li>예약 상황에 따라 예약접수일이 연기되거나 탁송으로 변경될 수도 있습니다.</li>
            <li>
              출고증접수 ~ 차량인도까지 약 20~30분 소요됩니다.차량취급설명시기능, 조작법 등 의문사항 문의 시 안내해
              드립니다.
            </li>
          </ul>
        </div>

        <div class="step-number">
          <ul>
            <li>
              <h4>1. 방문</h4>
              <p>신분증 지참 출고센터방문</p>
            </li>
            <li>
              <h4>2. 안내</h4>
              <p>신분증 확인 및 출고안내</p>
            </li>
            <li>
              <h4>3. 처리</h4>
              <p>출고처리(임시운행증발급)</p>
            </li>
            <li>
              <h4>4. 점검</h4>
              <p>세차 및 인도 전 점검</p>
            </li>
            <li>
              <h4>5. 이동</h4>
              <p>고객호명 후 인도장 이동</p>
            </li>
            <li>
              <h4>6. 확인</h4>
              <p>외관점검 및 지급품 확인</p>
            </li>
            <li>
              <h4>7. 인도</h4>
              <p>차량취급 설명 후 차량인도</p>
            </li>
          </ul>
        </div>
      </div>

      <div v-if="faqList && faqList.data" class="content-title">
        <h3>자주하는 질문</h3>
        <router-link to="/customer-center/ask" class="btn btn-more-blue" target="_blank">1:1 문의하기</router-link>
      </div>
      <v-list-group
        v-if="faqList && faqList.data && faqList.data.list"
        :accordion="true"
        :first-select="false"
        class="faq-list"
      >
        <VListItem
          v-for="(faq, idx) in faqList.data.list"
          :key="`faq-${idx}`"
          :data-id="`${idx}`"
          :label="faq.faqQuestion"
        >
          <!-- eslint-disable-next-line vue/no-v-html -->
          <div v-html="faq.faqAnswer"></div>
        </VListItem>
      </v-list-group>

      <div class="page-notice">
        <h4>안내사항</h4>
        <ul class="list-notice">
          <li>차량보관장소 방문예약변경은 기존에 신청한 리스트 취소 후, 재신청 가능합니다.</li>
          <li>차량보관장소 방문예약변경은 예약 당일에는 변경 불가합니다. 당일 예약변경 문의는 고객센터로 연락 바랍니다.</li>
          <li>
            차량보관장소 방문예약 이후 별도의 예약변경 없이 미방문 시, 차량 배달탁송으로 전환되며 탁송료는 추가결제
            됩니다.
          </li>
        </ul>
      </div>

      <how-come-popup
        :delivery-center-detail="deliveryCenterDetail.data"
        :visible.sync="howComePopVisible"
      />
    </template>
  </v-popup>
</template>

<script>
import VueDaumMap from 'vue-daum-map'
import { VListGroup, VListItem, VSelect, VCheckbox, VRadio, VInput, VPopup, VBtn } from '~/components/element'
import HowComePopup from '~/components/popup/HowComePopup'

export default {
  components: {
    VueDaumMap,
    VListGroup,
    VListItem,
    VPopup,
    VInput,
    VCheckbox,
    VRadio,
    VSelect,
    VBtn,
    HowComePopup
  },
  props: {
    popShow: {
      type: Object,
      default: () => {},
      required: true
    },
    contractNumber: {
      type: String,
      default: ''
    },
    info: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  data() {
    return {
      contractDetail: {}, // =info props
      isChangeAcceptor: false, //인수자 변경모드
      relationPersonList: [], //인수 가능자 목록
      changedAcceptor: { isAgent: false , name:'' }, //변경정보
      isChangeReservation: false, //방문예약 변경모드
      selectedDayType: null, //1일후/2일후/전체 선택
      searching :false,
      standardYearMonthDay1: null, //1일후의 근무일
      standardYearMonthDay2: null, //2일후의 근무일
      selectedVisitTime: null, //선택한 방문예약일 시간대
      previousReservationInfo: null, //변경시, 이전 데이터 표시용
      currentReservationInfo: null, //현재 방문예약 신청 정보
      kakaomapOptions: {
        appKey: process.env.KAKAO_MAP_KEY || 'd36c755c60b3595a2790ce2d5f70020a',
        mapTypeId: VueDaumMap.MapTypeId.NORMAL, // 맵 타입
        libraries: [], // 추가로 불러올 라이브러리
        map: null, // 지도 객체. 지도가 로드되면 할당됨.
        center: { lat: '33.450701', lng: '126.570667' }, //중심 좌표
        level: 3 //확대축소정도
      },
      howComePopVisible: false, //교통편안내 팝업 여부
      faqList: [],
      visitReservationTime: null, //방문예약 시간대 정보
      deliveryCenterDetail: {} //출고센터 상세정보
    }
  },
  computed: {
    birthYearList() {
      const thisYear = new Date().getFullYear()
      return Array.from(Array(thisYear - 1899), (x, idx) => {
        return { value: thisYear - idx + '', label: thisYear - idx + '년' }
      })
    },
    birthMonthList() {
      return Array.from(Array(12), (x, idx) => {
        return { value: idx + 1 + '', label: idx + 1 + '월' }
      })
    },
    birthDayList() {
      return Array.from(Array(31), (x, idx) => {
        return { value: idx + 1 + '', label: idx + 1 + '일' }
      })
    },
    markerImagePath() {
      return require('@/assets/images/marker_number_blue.png')
    }
  },
  watch: {
    popShow: {
      async handler(val) {
        if (val.reservedCenterPop === true) {
          this.contractDetail = { ...this.info }

          //API-E-구매서비스-072 (인수정보 조회)
          const [resA, errA] = await this.$https.get('/purchase/v1/purchase/acquisition/info', { contractNumber: this.contractNumber, electronicSignatureTypeCode: 'A' }, null, 'gateway')
          if(!errA && resA && resA.data) {
            this.contractDetail.acceqtorInfo = { ...resA.data }
          }

          //API-E-구매서비스-012 (명의자 정보 조회)
          const [res0, err0] = await this.$https.get('/purchase/v1/purchase/contract/nam/info', { contractNumber: this.contractNumber, electronicSignatureTypeCode: 'A' }, null, 'gateway')
          if(!err0 && res0) {
            this.relationPersonList = res0.data.relationPersonList
          }

          //현재 방문예약 조회
          this.refreshVisitReservationInfo()
          
          //API-E-전담컨설턴트-030 (출고정보 조회)
          const [resWD, errWD] = await this.$https.get(`/v1/exclusive/work/delivery/${this.contractNumber}`)
          if (!errWD && resWD && resWD.data) {
            const deliveryCenterCode = resWD.data.deliveryCenterCode
            //출고센터 상세조회
            const [resD, errD] = await this.$https.get(`/customer-support/v1/purchase-guide/delivery-center/${deliveryCenterCode}`, null, null, 'gateway')
            if (!errD && resD && resD.data) {
              this.deliveryCenterDetail = resD
              this.kakaomapOptions.center = { lat: resD.data.lat, lng: resD.data.lon }
              this.onMapCreateMarker(this.kakaomapOptions.map, this.kakaomapOptions.center.lat, this.kakaomapOptions.center.lng)
            }
          }

          //시작일 휴일여부 조회
          const tomorrowStr = this.$moment(new Date()).add(1, 'days').format('YYYYMMDD')
          const [res1, err1] = await this.$https.get('/common/v1/common/exclusive/consultant/working-day', { checkDate: tomorrowStr }, null, 'gateway')
          if (!err1) {
						this.standardYearMonthDay1 = res1.data && res1.data.standardYearMonthDay
					} else {
						this.standardYearMonthDay1 = tomorrowStr
          }

          //종료일 휴일여부 조회
          const twoDaysLater = this.$moment(this.standardYearMonthDay1 , 'YYYYMMDD').add(1, 'days').format('YYYYMMDD')
          const [res2, err2] = await this.$https.get('/common/v1/common/exclusive/consultant/working-day', { checkDate: twoDaysLater }, null, 'gateway')
					if (!err2) {
						this.standardYearMonthDay2 = res2.data && res2.data.standardYearMonthDay
					} else {
						this.standardYearMonthDay2 = twoDaysLater
					}

          //FAQ 조회
          const [res, err] = await this.$https.get('/customer-support/v1/customer-support/faq/list', {
            siteTypeCode: 'E',
            faqCategoryCode: 10, //TODO: change category code
            pageNo: 1,
            pageSize: 8,
            faqSeq: '',
            searchKeyword: '',
            faqCode: ''
          }, null, 'gateway')
          if (err || !res || !res.data) return
          this.faqList = res.data.list
        }
      },
      deep: true
    },
    'changedAcceptor.isAgent'(isAgent){
      if(isAgent){ // 대리인
        this.changedAcceptor.name = ''   
      }
    },
    visitReservationTime(timeList) {
      this.searching = false 
      if (this.currentReservationInfo) {
        const timeFormatted =
					this.currentReservationInfo.visitPrearrangementDay +
					(this.currentReservationInfo.visitPrearrangementTimeCode &&
						this.currentReservationInfo.visitPrearrangementTimeCode.substring(0, 2) +
							this.currentReservationInfo.visitPrearrangementTimeCode.substring(3, 5))
        const time =
					timeList && timeList.find((el) => timeFormatted == el.criterionYearMonthDay + el.visitPrearrangementTimeCode)
        if (time) {
          this.selectedVisitTime = timeFormatted
        }
      }
    }
  },
  methods: {
    async refreshVisitReservationInfo() {
      const [res, err] = await this.$https.get('/purchase/v1/purchase/visit-reservation/info', { contractNumber: this.contractNumber }, null, 'gateway')
      if (err || !res) return
      this.currentReservationInfo = res.data
    },
    async confirmChangeAcceptor() {
      //인수자변경
      const { name, phone, birthYear, birthMonth, birthDay, gender, isAgent, acceptorZipCode, acceptorCenterAddress, acceptorCenterAddressDetail } = this.changedAcceptor
      console.log(this.changedAcceptor, '****')
      if (!name || !phone || (isAgent && !(birthYear && birthMonth && birthDay && gender))) {
        this.$emit('alertMsg', '변경할 인수자 정보를 모두 입력해주세요')
      } else {
        const [res, err] = await this.$https.put('/purchase/v1/purchase/acquisition/info', {
          contractNumber: this.contractNumber,
          acceptorName: name || '',
          acceptorTelephonNumber: phone || '',
					acceptorZipCode: this.changedAcceptor.acceptorZipCode || '',
					acceptorCenterAddress: this.changedAcceptor.acceptorCenterAddress || '',
					acceptorCenterAddressDetail: this.changedAcceptor.acceptorCenterAddressDetail || '',
          etcContent: '',
          residentRegistrationNumber: (isAgent) ?
            `${birthYear}${(birthMonth>9)?'':'0'}${birthMonth}${(birthDay>9)?'':'0'}${birthDay}${gender}111111`
            : this.changedAcceptor.inhabitantsIdentificationNumber + '111111',
          deputyCounselYn: isAgent ? 'Y' : 'N' 
        }, null, 'gateway')
        if(err) return

        //인수자 변경
        this.contractDetail.acceqtorInfo = {
          acceptorName: this.changedAcceptor.name || '',
          acquisitionTypeName: (isAgent)?'대리인':'본인'   ,
          acceptorTelephonNumber: this.changedAcceptor.phone || ''
        }
        this.changedAcceptor = { isAgent: false , name:''  }
        this.isChangeAcceptor = false
      }
    },
    onChangeRelationPerson(serialNumber) {
      const person =
				this.relationPersonList &&
        this.relationPersonList.find((el) => el.relationPersonSerialNumber === serialNumber)
      if (person) {
        this.changedAcceptor = {
          relationPersonSerialNumber: serialNumber,
          name: person.relationPersonName,
          phone: `${person.mobilePhoneNumber1.trim()}${person.mobilePhoneNumber2.trim()}${person.mobilePhoneNumber3.trim()}`,
          birthYear: null,
          birthMonth: null,
          birthDay: null,
          gender: '1',
          isAgent : false ,
          //isAgent: person.relationPersonRelationCode != '00', //대리인체크해서 이름기입할때만 - 인수유형코드 00 대리인 /드롭박스로 계약자중 1명(ex 공동명의자) 할경우는 본인 01로 한다 (임소정)
          acceptorZipCode: person.zipCode.trim(),
          acceptorCenterAddress: person.addressContents,
          acceptorCenterAddressDetail: person.detailAddressContents,
          acquisitionTypeName: person.acquisitionTypeName,
          inhabitantsIdentificationNumber: person.inhabitantsIdentificationNumber
        }
        console.log(this.changedAcceptor, '*******')
      }
    },
    async reserveVisit() {
      if (!this.selectedVisitTime) return
      //최초예약
      const [res, err] = await this.$https.postQs('/purchase/v1/purchase/visit-reservation/info', {
        contractNumber: this.contractNumber,
        visitPossibleDay: this.selectedVisitTime && this.selectedVisitTime.substring(0, 8),
        visitPossibleTime: this.selectedVisitTime && this.selectedVisitTime.substring(8, 12)
      }, null, 'gateway')
      if(!err && res) {
        console.log('visitReservationResult', res.data)

        if (this.isChangeReservation && this.currentReservationInfo) {
          //예약변경
          this.previousReservationInfo = {
            ...this.currentReservationInfo,
            receiptSituation: '접수취소'
          }
          this.$emit('alertMsg', '방문 예약일이 변경되었습니다.\n기존 예약내역은 자동으로 삭제됩니다.')
        }

        this.currentReservationInfo = {
          deliveryRequestDate: this.$moment(new Date()).format('YYYY-MM-DD HH:mm'),
          visitPrearrangementDay: this.$moment(this.selectedVisitTime, 'YYYYMMDDHHmm').format('YYYY-MM-DD'),
          visitPrearrangementTimeCode:
            this.$moment(this.selectedVisitTime, 'YYYYMMDDHHmm').format('HH:mm') +
            ' ~ ' +
            this.$moment(this.selectedVisitTime, 'YYYYMMDDHHmm')
              .add(30, 'minutes')
              .format('HH:mm'),
          receiptSituation: '접수완료'
        }

        this.isChangeReservation = false
        this.$emit('visitReserved')

        document.querySelector('div.delivery-popup').scrollTo(0, 0)
      }
    },
    async searchAvailableVisits() {
      //방문가능 시간대 정보 조회
      this.selectedVisitTime = null
      this.searching = true 
      const [res, err] = await this.$https.get('/purchase/v1/purchase/visit-reservation/time', {
        contractNumber: this.contractNumber,
        visitPossibleDay: this.selectedDayType === '2' ? this.standardYearMonthDay2 : this.standardYearMonthDay1
      }, null, 'gateway')
      if(!err && res) {
        this.visitReservationTime = res.data
      }
    },
    // 지도가 로드 완료되면 load 이벤트 발생
    onMapLoaded(map) {
      this.kakaomapOptions.map = map
      this.onMapZoomControl(map)
    },
    onMapCreateMarker(map, lat, lon) {
      // 지도 위에 마커 표시
      // eslint-disable-next-line no-undef
      const markerPosition = new kakao.maps.LatLng(lat, lon)
      // eslint-disable-next-line no-undef
      const markerImage = new kakao.maps.MarkerImage(this.markerImagePath, new kakao.maps.Size(36, 37), {
        // eslint-disable-next-line no-undef
        spriteSize: new kakao.maps.Size(36, 691), // 스프라이트 이미지의 크기
        // eslint-disable-next-line no-undef
        spriteOrigin: new kakao.maps.Point(0, 10), // 스프라이트 이미지 중 사용할 영역의 좌상단 좌표
        // eslint-disable-next-line no-undef
        offset: new kakao.maps.Point(13, 37) // 마커 좌표에 일치시킬 이미지 내에서의 좌표
      })
      // eslint-disable-next-line no-undef
      const marker = new kakao.maps.Marker({
        position: markerPosition,
        image: markerImage
      })
      marker.setMap(map)
      //map.relayout()
    },
    onMapZoomControl(map) {
      // 지도 줌 컨트롤 생성
      // eslint-disable-next-line no-undef
      const zoomControl = new kakao.maps.ZoomControl()
      // eslint-disable-next-line no-undef
      map.addControl(zoomControl, kakao.maps.ControlPosition.RIGHT)
    },
    onClose() {
      this.popShow.reservedCenterPop = false
      this.$emit('update:popShow', this.popShow)
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~/assets/style/common/mixin.scss';
@import '~/assets/style/common/var.scss';
@import '~/assets/style/pages/popup/DeliveryTrackingPopup.scss';
</style>
