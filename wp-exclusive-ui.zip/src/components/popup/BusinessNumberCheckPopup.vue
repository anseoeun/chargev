<template>
  <!-- 법인번호입력 팝업 -->
  <el-dialog title="법인번호 입력" :visible.sync="popVisibleCorpNumber.visible">
    <!-- Popup Contents -->
    <div class="board-wrap">
      <el-form ref="info" class="detail-form">
        <el-row>
          <el-col :span="24">
            <el-form-item label="구분">
              <el-radio v-model="corpNumber.radioType" label="1"
                >법인번호</el-radio
              >
              <el-radio v-model="corpNumber.radioType" label="2"
                >주민등록번호</el-radio
              >
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="입력">
              <el-input
                v-model="corpNumber.textNum"
                placeholder="숫자만 입력하세요"
              />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <ul class="note">
      <li>
        * 법인번호가 없는 사업자(단체)의 경우 대표자 주민등록번호를 기입하세요.
      </li>
    </ul>
    <!-- Popup Footer -->
    <template slot="footer">
      <div>
        <el-button type="info" @click="popVisibleCorpNumber.visible = false"
          >취소</el-button
        >
        <el-button type="primary" @click="$emit('setData', corpNumber)"
          >확인</el-button
        >
      </div>
    </template>
  </el-dialog>
</template>
<script>
export default {
  props: {
    popVisibleCorpNumber: {
      type: Object,
      default: () => {},
      required: true
    }
  },
  data() {
    return {
      corpNumber: {
        radioType: "1",
        textNum: ""
      }
    };
  },
  computed: {},
  methods: {}
};
</script>
<style lang="scss" scoped>
@import "~/assets/style/pages/detail.scss";
</style>
