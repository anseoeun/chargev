<template>
    <div>
        <!-- Popup Contents -->
      <div class="board-wrap">
        <el-tabs 
          v-model="activeTab"
          type="card" 
          stretch
          @tab-click="handleTabClick"
        >
          <el-tab-pane label="생산차" name="product">
            <table class="tbl-detail">
              <colgroup>
                <col style="width:20%" />
                <col style="width:80%" />
              </colgroup>
              <tbody>
                <tr>
                  <th>차종구분</th>
                  <td>
                    <el-select 
                      v-model="selectedCarInfo.carType"
                      placeholder="전체"
                      class="full"
                      @change="onChangeTypeCars">
                      <el-option 
                        v-for="{ carTypeCode, carTypeName } in carTypes"
                        :key="carTypeCode"
                        :value="carTypeCode"
                        :label="carTypeName"
                      ></el-option>
                    </el-select>
                    <span class="car-price"></span>
                  </td>
                </tr>
                <tr>
                  <th>대표차</th>
                  <td>
                    <el-select 
                      v-model="selectedCarInfo.repnCar"
                      placeholder="전체"
                      class="full"
                      :disabled="selectedCarInfo.carType === '' || selectedCarInfo.carType === 'all'"
                      @change="onChnageRepnCar">
                      <el-option 
                        v-for="{ repnCarCode, repnCarName, disabled } in estimateCarInfo.selTypeCars"
                        :key="repnCarCode"
                        :value="repnCarCode"
                        :label="repnCarName"
                        :disabled="disabled"
                      ></el-option>
                    </el-select>
                    <span class="car-price"></span>
                  </td>
                </tr>
                <tr>
                  <th>판매모델</th>
                  <td>
                    <el-select 
                      v-model="selectedCarInfo.saleModelCode" 
                      placeholder="전체"
                      class="full"
                      :disabled="selectedCarInfo.repnCar === '' || selectedCarInfo.repnCar === 'all'"
                      @change="onChangeSaleModel">
                      <el-option 
                        v-for="{ saleModelCode, saleModelName, saleModelTrim } in estimateCarInfo.saleModels"
                        :key="saleModelCode"
                        :value="saleModelCode"
                        :label="saleModelName + ' ' + saleModelTrim">
                      </el-option>
                    </el-select>
                    <span class="car-price"> {{ (carPriceInfo.carPrice ? carPriceInfo.carPrice.toLocaleString() : '0')+'원' }}</span>
                  </td>
                </tr>
                <tr>
                  <th>외장색상</th>
                  <td>
                    <el-select v-model="selectedCarInfo.exteriorColorCode" 
                      placeholder="전체"
                      :disabled="selectedCarInfo.saleModelCode === '' || selectedCarInfo.saleModelCode === 'all'"
                      class="full"
                      @change="onChangeExteriorColor">
                      <el-option 
                        v-for="{ colorCode, colorName, disabled } in estimateCarInfo.exteriorColors"
                        :key="colorCode"
                        :value="colorCode"
                        :label="colorName"
                        :disabled="disabled"
                      >
                      </el-option>
                    </el-select>
                    <span class="car-price">{{ (carPriceInfo.exteriorColorPrice ? carPriceInfo.exteriorColorPrice.toLocaleString() : '0')+'원' }}</span>
                  </td>
                </tr>
                <tr>
                  <th>내장색상</th>
                  <td>
                    <el-select 
                      v-model="selectedCarInfo.interiorColorCode" 
                      placeholder="전체"
                      class="full"
                      :disabled="selectedCarInfo.exteriorColorCode === '' || selectedCarInfo.exteriorColorCode === 'all'"
                      @change="onChangeInteriorColor">
                      <el-option
                        v-for="{ colorCode, colorName, disabled } in estimateCarInfo.interiorColors"
                        :key="colorCode"
                        :value="colorCode"
                        :label="colorName"
                        :disabled="disabled">
                      </el-option>
                    </el-select>
                    <span class="car-price">{{ (carPriceInfo.interiorColorPrice ? carPriceInfo.interiorColorPrice.toLocaleString() : '0')+'원' }}</span>
                  </td>
                </tr>
                <tr>
                  <th>선택품목</th>
                  <td>
                    <el-select 
                      v-model="selectedCarInfo.optionMixCode" 
                      placeholder="전체"
                      :disabled="selectedCarInfo.interiorColorCode === '' || selectedCarInfo.interiorColorCode === 'all'"
                      class="multiple-select full"
                      multiple
                      @change="onChangeChoiceOption"
                      >
                      <el-option
                        v-for="{ optionCode, optionName, disabled } in estimateCarInfo.choiceOptions"
                        :key="optionCode"
                        :value="optionCode"
                        :label="optionName"
                        :disabled="disabled"
                      ></el-option>
                    </el-select>
                    <span class="car-price">{{ (carPriceInfo.choiceOptionPrice ? carPriceInfo.choiceOptionPrice.toLocaleString() : '0')+'원' }}</span>
                  </td>
                </tr>
                <tr>
                  <th>파츠</th>
                  <td>
                    <el-select 
                      v-model="selectedCarInfo.tuixOptionCode" 
                      placeholder="전체"
                      :disabled="selectedCarInfo.optionMixCode.length === 0"
                      class="multiple-select full"
                      multiple
                      @change="onChangeTuixOption"
                      >
                      <el-option 
                        v-for="{ optionCode, optionName, disabled } in estimateCarInfo.tuixOptions.filter((el) => el.optionCode !== 'AX0001')"
                        :key="optionCode"
                        :value="optionCode"
                        :label="optionName"
                        :disabled="disabled"
                      ></el-option>
                    </el-select>
                    <span class="car-price">{{ (carPriceInfo.tuixOptionPrice ? carPriceInfo.tuixOptionPrice.toLocaleString() : '0')+'원' }}</span>
                  </td>
                </tr>
                <tr>
                  <th>총 구입비</th>
                  <td align="right"><span class="car-price">{{ (carTotalPrice ? carTotalPrice.toLocaleString() : '0')+'원' }}</span></td>
                </tr>
                <tr>
                  <th>예상 출고일</th>
                  <td align="right"><span class="car-date">{{ selectedCarInfo.exemplificationDateText }}</span></td>
                </tr>
              </tbody>
            </table>
          </el-tab-pane>

          <el-tab-pane label="일반재고" name="general">
            <el-form ref="info" class="detail-form">
              <el-row>
                <el-col :span="24">
                  <el-form-item label="차량구분">
                    <div class="classify-vehicle">
                      <el-select 
                        v-model="selectedCarInfo.carType"
                        placeholder="전체"
                        @change="onChangeTypeCars">
                        <el-option 
                          v-for="{ carTypeCode, carTypeName } in carTypes"
                          :key="carTypeCode"
                          :value="carTypeCode"
                          :label="carTypeName"
                        ></el-option>
                      </el-select>
                      <el-select 
                        v-model="selectedCarInfo.repnCar"
                        placeholder="전체"
                        :disabled="selectedCarInfo.carType === '' || selectedCarInfo.carType === 'all'"
                        @change="onChnageRepnCar">
                        <el-option 
                          v-for="{ repnCarCode, repnCarName, disabled } in estimateCarInfo.selTypeCars"
                          :key="repnCarCode"
                          :value="repnCarCode"
                          :label="repnCarName"
                          :disabled="disabled"
                        ></el-option>
                      </el-select>
                      <el-select 
                        v-model="selectedCarInfo.saleModelCode" 
                        placeholder="전체"
                        :disabled="selectedCarInfo.repnCar === '' || selectedCarInfo.repnCar === 'all'"
                        @change="onChangeSaleModel">
                        <el-option 
                          v-for="{ saleModelCode, saleModelName, saleModelTrim } in estimateCarInfo.saleModels"
                          :key="saleModelCode"
                          :value="saleModelCode"
                          :label="saleModelName + ' ' + saleModelTrim">
                        </el-option>
                      </el-select>
                      <el-select 
                        v-model="selectedCarInfo.exteriorColorCode" 
                        placeholder="전체"
                        :disabled="selectedCarInfo.saleModelCode === '' || selectedCarInfo.saleModelCode === 'all'"
                        @change="onChangeExteriorColor">
                        <el-option 
                          v-for="{ colorCode, colorName, disabled } in estimateCarInfo.exteriorColors"
                          :key="colorCode"
                          :value="colorCode"
                          :label="colorName"
                          :disabled="disabled"
                        >
                        </el-option>
                      </el-select>
                      <el-select 
                        v-model="selectedCarInfo.interiorColorCode" 
                        placeholder="전체"
                        :disabled="selectedCarInfo.exteriorColorCode === '' || selectedCarInfo.exteriorColorCode === 'all'"
                        @change="onChangeInteriorColor">
                        <el-option
                          v-for="{ colorCode, colorName } in estimateCarInfo.interiorColors"
                          :key="colorCode"
                          :value="colorCode"
                          :label="colorName">
                        </el-option>
                      </el-select>
                       <el-select 
                        v-model="selectedCarInfo.optionMixCode" 
                        placeholder="전체"
                        class="multiple-select"
                        :disabled="selectedCarInfo.interiorColorCode === '' || selectedCarInfo.interiorColorCode === 'all'"
                        multiple
                        @change="onChangeChoiceOption"
                        >
                        <el-option
                          v-for="{ optionCode, optionName, disabled } in estimateCarInfo.choiceOptions"
                          :key="optionCode"
                          :value="optionCode"
                          :label="optionName"
                          :disabled="disabled"
                        ></el-option>
                      </el-select>
                    </div>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
            <div class="btn-group">
              <el-button type="primary" @click="resetSelectedData('all')">초기화</el-button>
              <el-button type="primary" @click="getGeneralCarList">조회</el-button>
            </div>
            <el-table 
              :data="generalCarData"
              empty-text="조회된 결과가 존재하지 않습니다."
            >
              <el-table-column label="선택" width="50" align="center">
                 <template slot-scope="scope">
                  <el-checkbox
                    v-model="scope.row.isSelected"
                    @change="checkGeneralCar(scope.row)"
                    />
                 </template>
              </el-table-column>
              <el-table-column prop="saleModelNm" label="차량명" width="330" align="center"></el-table-column>
              <el-table-column prop="optionMixCode" label="옵션조합코드" width="120" align="center"></el-table-column>
              <el-table-column prop="optionDetail" label="옵션" width="400" align="center"></el-table-column>
              <el-table-column prop="deliveryCenter" label="출고센터" width="100" align="center"></el-table-column>
              <el-table-column prop="inventoryCount" label="재고수량" width="80" align="center"></el-table-column>
            </el-table>
            <div class="btn-wrap">
              <div class="side"></div>
              <div class="pagination">
                <v-pagination
                  v-if="generalCarData.length"
                  :page.sync="pageInfo.page"
                  :size="pageInfo.size"
                  :total="pageInfo.total"
                  @page-change="onSearch($event, 'generalCar')"
                />
              </div>
              <div class="main"></div>
            </div>
          </el-tab-pane>

          <el-tab-pane label="기획전" name="exhibition">
            <el-form ref="info" class="detail-form">
              <el-row>
                <el-col :span="24">
                  <el-form-item label="기획전">
                    <el-select
                      v-model="exhibitionInfo.exhibitionNo"
                      placeholder="전체"
                      class="full"
                    >
                      <el-option 
                        v-for="{ exhbNo, exhbNm } in exhibitionInfo.exhibitionList"
                        :key="exhbNo"
                        :value="exhbNo"
                        :label="exhbNm"
                      ></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
            <div class="btn-group">
              <el-button type="primary" @click="exhibitionInfo.exhibitionNo = null">초기화</el-button>
              <el-button type="primary" @click="getExhibitionCar">조회</el-button>
            </div>
            <el-table 
              :data="exhibitionInfo.exhibitionCarData"
              empty-text="조회된 결과가 존재하지 않습니다."
            >
              <el-table-column label="선택" width="50" align="center">
                 <template slot-scope="scope">
                  <el-checkbox
                    v-model="scope.row.isSelected"
                    @change="checkExhibitionCar(scope.row)"
                    />
                 </template>
              </el-table-column>
              <el-table-column prop="saleModelName" label="차량명" width="300" align="center"></el-table-column>
              <el-table-column prop="carProductionNumber" label="생산번호" width="150" align="center"></el-table-column>
              <el-table-column prop="deliveryCenterName" label="출고센터" width="180" align="center"></el-table-column>
              <el-table-column prop="prdnDt" label="생산일" width="150" align="center"></el-table-column>
              <el-table-column prop="discountTypeName" label="차량구분" width="180" align="center"></el-table-column>
              <el-table-column prop="discountPrice" label="차량할인" width="180" align="center"></el-table-column>
              <el-table-column prop="" label="주행거리" width="150" align="center"></el-table-column>
              <el-table-column prop="" label="차량상태(외관)" width="180" align="center"></el-table-column>
              <el-table-column prop="" label="차량상태(내관)" width="180" align="center"></el-table-column>
            </el-table>
            <div class="btn-wrap">
              <div class="side"></div>
              <div class="pagination">
                <v-pagination
                  v-if="exhibitionInfo.exhibitionCarData.length"
                  :page.sync="pageInfo.page"
                  :size="pageInfo.size"
                  :total="pageInfo.total"
                  @page-change="onSearch($event, 'exhibitionCar')"
                />
              </div>
              <div class="main"></div>
            </div>
          </el-tab-pane>

        </el-tabs>
      </div>
    </div>
</template>
<script>
import { mapGetters } from 'vuex'
export default {
  data() {
    return {
      activeTab: 'product',
      estimateCarInfo: {  
        selTypeCars: [],
        saleModels: [],
        exteriorColors: [],
        interiorColors: [],
        choiceOptions:[],
        tuixOptions:[],
      },
      selectedCarInfo:{
        carType: '', //차종
        repnCar: '', //대표차
        saleModelCode: '', //모델
        exteriorColorCode: '', //외장색상코드
        interiorColorCode: '', //내장색상코드
        realityInteriorColorCode: '', 
        optionMixCode: [], //옵션코드
        tuixOptionCode: [], //파츠코드
        tuixOptionData: [], 
        exemplificationDateText: '-',
        preEstimateInfo: null
      },
      generalCarData: [],
      exhibitionInfo: {
        exhibitionNo:null,
        exhibitionList: [],
        exhibitionCarData:[],
      },
      carPriceInfo: {
        carPrice: 0,
        exteriorColorPrice: 0,
        interiorColorPrice: 0,
        choiceOptionPrice: 0,
        tuixOptionPrice: 0,
      },
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      },
    }
  },
  computed: {
    ...mapGetters(['userInfo']),
    carTypes: function() {
      const carTypes = this.$store.state.carTypes
      if(carTypes && carTypes.length > 0) {
        carTypes.shift()
        carTypes.unshift({ 'carTypeCode': 'all', 'carTypeName': '전체' })
      }
      return carTypes
    },
    carTotalPrice() { 
      //차량가격 + 색상가격 + 선택 옵션 가격 + tuix 옵션 가격
      let price = 0

      if (this.carPriceInfo.carPrice) price += Number(this.carPriceInfo.carPrice)

      if (this.carPriceInfo.exteriorColorPrice) {
        price += Number(this.carPriceInfo.exteriorColorPrice)
      }

      if (this.carPriceInfo.interiorColorPrice) {
        price += Number(this.carPriceInfo.interiorColorPrice)
      }

      if(this.carPriceInfo.choiceOptionPrice) {
        price += Number(this.carPriceInfo.choiceOptionPrice)
      }

      if(this.carPriceInfo.tuixOptionPrice) {
        price += Number(this.carPriceInfo.tuixOptionPrice)
      }

      return price
    }
  },
  methods: {
    async onChangeTypeCars(carTypeCode) {
      this.resetSelectedData('carType')

      let arr = []
      const params={
        imageSectionCode: '01',
        siteTypeCode: 'W',
        carTypeCode: carTypeCode,
        carPurposeCode: '',
        menuTypeCode:'',
      }
      const [res, err] = await this.$https.get('/product/v2/product/car/type/purpose', params, null, 'gateway')
      if(!err) {
        if(res.data && res.rspStatus.rspCode === '0000') {
          arr = res.data.map((items) => {
            return {
              repnCarName: items.carName, 
              repnCarCode: items.carCode,
              disabled: items.carAbbreviation === 'AX' ? false : true 
            }
          })
        }
      }else {
        console.error('exclusive :: /product/v2/product/car/type/purpose ERROR !! '+err)
      }

      this.estimateCarInfo.selTypeCars = arr
        
    },
    async onChnageRepnCar(repnCar) {
      /** 대표차 선택시 실행 - 선택한 차종,대표차 하위의 판매모델 차량 조회 */
      this.resetSelectedData('repnCar')

      /**선택한 차종,대표차 하위의 판매모델 차량 조회 API */
      const[res, err] = await this.$https.get('/v2/exclusive/work/car/trim/'+repnCar)
      if(!err) {
        if(res.data) {
          this.estimateCarInfo.saleModels = res.data.map((items) => {
            return { saleModelCode: items.saleModelCode, saleModelName: items.modelBasicInfo, saleModelPrice: items.carModelPrice, saleModelTrim: items.carTrimName}
          })
        }
      }else {
        console.error('exclusive :: /v2/exclusive/work/car/trim ERROR !! '+err)
      }

    },
    async onChangeSaleModel(modelCode) {
      /** 판매모델 선택시 실행 - 선택한 판매모델 차량 하위의 외장컬러, 선택옵션 조회 */
      this.resetSelectedData('saleModel')

      const index = this.estimateCarInfo.saleModels.findIndex(function(item) {
        return item.saleModelCode === modelCode
      })

      this.carPriceInfo.carPrice = Number(this.estimateCarInfo.saleModels[index].saleModelPrice)
    
      /** 선택한 판매모델 차량 하위의 외장컬러 조회 API*/
      const [res, err] = await this.$https.get('/product/v2/product/exterior-color/'+modelCode, null, null, 'gateway')
      if(!err) {
        if(res.data) {
          this.estimateCarInfo.exteriorColors = res.data.map((items) => {
            return { colorCode: items.exteriorColorCode, colorName: items.exteriorColorName, colorPrice: items.exteriorColorPrice, disabled: items.choiceYn === 'Y' ? false : true}
          })
        }
      }else {
        console.error('exclusive :: /product/v2/product/exterior-color ERROR !! '+err)
      }

      /** 선택한 판매모델 차량 하위의 선택옵션 조회 API*/
      const [res1, err1] = await this.$https.get('/product/v2/product/options/choice/'+modelCode, null, null, 'gateway')
      if(!err1) {
        if(res1.data) {
          this.estimateCarInfo.choiceOptions = res1.data.map((items) => {
            return { optionCode: items.choiceOptionCode, optionName: items.choiceOptionName, optionPrice: items.choiceOptionPrice, disabled: items.unityChoiceYn === 'Y' ? false : true, unity: items.unityChoiceYn, optionGroup: items.choiceOptionGroupCodes}
          })
        }
      } else {
        console.error('exclusive :: /product/v2/product/options/choice ERROR !! '+err1)
      }
    },
    async onChangeExteriorColor(colorCode) {
      /** 외장컬러 선택시 실행 - 선택한 판매모델과 외장컬러로 내장컬러 조회 */
      this.resetSelectedData('exColor')

      const index = this.estimateCarInfo.exteriorColors.findIndex(function(item) {
        return item.colorCode === colorCode
      })

      this.carPriceInfo.exteriorColorPrice = Number(this.estimateCarInfo.exteriorColors[index].colorPrice)

      /**택한 판매모델과 외장컬러로 내장컬러 조회API */
      const [res, err] = await this.$https.get('/product/v2/product/interior-color/'+this.selectedCarInfo.saleModelCode, {  
        exteriorColorCode: colorCode
      }, null, 'gateway')
      if(!err) {
        if(res.data) {
          this.estimateCarInfo.interiorColors = res.data.map((items) => {
            return { colorCode: items.interiorColorCode, colorName: items.interiorColorName, colorPrice: items.interiorColorPrice, realityColorCode: items.realityInteriorColorCode, disabled: items.choiceYn === 'Y' ? false : true }
          })
        }
      }else {
        console.error('exclusive :: /product/v2/product/interior-color ERROR !! '+err)
      }
    },
    async onChangeInteriorColor(colorCode) {
      /** 내장 컬러 선택시 실행 - 필수선택옵션 조회 */
      this.resetSelectedData('inColor')

      const index = this.estimateCarInfo.interiorColors.findIndex(function(item) {
        return item.colorCode === colorCode
      })

      this.carPriceInfo.interiorColorPrice = Number(this.estimateCarInfo.interiorColors[index].colorPrice)
      this.selectedCarInfo.realityInteriorColorCode = this.estimateCarInfo.interiorColors[index].realityColorCode

      //컬러에 따른 필수 옵션 조회 API
      const params ={
        saleModelCode: this.selectedCarInfo.saleModelCode,
        saleSpecCode: 'A', //AX차량의 경우 판매스펙코드 'A'로 고정
        exteriorColorCode: this.selectedCarInfo.exteriorColorCode,
        interiorColorCode: colorCode
      }

      let arr = []
      const [res, err] = await this.$https.get('/product/v2/product/option-required-choice', params, null, 'gateway')
      if(!err) {
        if(res.data) {
          arr = res.data.map(el => {
            return {
              optionCode: el.OPTIONCODE
            }
          })

          arr.map(items => {
            const idx = this.estimateCarInfo.choiceOptions.findIndex(function(item) {
              return item.optionCode === items.optionCode
            }) 
            
            if(idx > -1) {
              this.selectedCarInfo.optionMixCode.push(this.estimateCarInfo.choiceOptions[idx].optionCode)
            }
          })
        }
      }else {
        console.error('exclusive :: /product/v2/product/option-required-choice ERROR !! '+err)
      }

      this.onChangeChoiceOption()
      
    },
    async onChangeChoiceOption() {
      //파츠 초기화
      this.resetSelectedData('option')

      let turboChk = this.selectedCarInfo.saleModelCode.substr(5,1) === 'T' ? true : false
      let chkt = this.selectedCarInfo.optionMixCode.findIndex(el => el === 'CA1' || el === 'CA2') > -1

      if(turboChk && !chkt) {
        let turboOpt = this.estimateCarInfo.choiceOptions.find(el => el.optionCode === 'CA1' || el.optionCode === 'CA2')
        if(turboOpt) {
          this.selectedCarInfo.optionMixCode.unshift(turboOpt.optionCode)
        }
      }

      // 선택한 항목에 따른 비활성화 옵션 조회
      this.disabledOptionList()

      let price = 0
      //선택한 선택옵션의 총 가격 계산
      for(let data of this.selectedCarInfo.optionMixCode) {
        const index = this.estimateCarInfo.choiceOptions.findIndex(function(item){
          return item.optionCode === data
        })
        
        price += Number(this.estimateCarInfo.choiceOptions[index].optionPrice)
      }

      this.carPriceInfo.choiceOptionPrice = price

      //파츠옵션 조회
      this.getTuixOption()

      let optionCode = this.selectedCarInfo.optionMixCode.join(',')
      let optionMixCode = await this.getOptionMixCode(this.selectedCarInfo.saleModelCode, optionCode)

      //예삳출고일 조회
      const data = {
        saleModelCode: this.selectedCarInfo.saleModelCode,
        optionMixCode: optionMixCode.code,
        exteriorColorCode : this.selectedCarInfo.exteriorColorCode,
        interiorColorCode : this.selectedCarInfo.interiorColorCode
      }
      this.getExemplification(data)
      let activePlusOpt = this.selectedCarInfo.optionMixCode.findIndex(el => el === 'CAP' ) > -1
      let activePlus = this.selectedCarInfo.tuixOptionData.findIndex(el => el === 'AX0001') === -1

      if(activePlusOpt && activePlus) {
        this.selectedCarInfo.tuixOptionData.push('AX0001')
      }

    },
    async disabledOptionList() {
      this.optionUniqCheck() //단독으로 선택될 수 없는 옵션 체크 해제 처리

      const params = {
        optionCode: this.selectedCarInfo.optionMixCode.join(',')
      }

      if(!params.optionCode) {
        this.estimateCarInfo.choiceOptions.map(items => {
          items.disabled = items.unity === 'Y' ? false : true
        })
        return
      }
      
      let arr = []
      const [res, err] = await this.$https.get('/product/v2/product/disable-option/'+ this.selectedCarInfo.saleModelCode, params, null, 'gateway')
      if(!err) {
        if(res.data) {
          res.data.map(items => {
            const idx = this.estimateCarInfo.choiceOptions.findIndex(function(item) {
              return item.optionCode === items.optionCode
            })
            if(idx !== ''){
              this.estimateCarInfo.choiceOptions[idx].disabled = true
            }
            arr.push(items.optionCode)
          })
          
          this.estimateCarInfo.choiceOptions.map(el => {
            if(arr.indexOf(el.optionCode) === -1) {
              el.disabled = false
            }
          })
        }
      }else {
        console.error('exclusive :: /product/v2/product/disable-option ERROR !! '+err)
      }

      this.possibleOptionList(params)

      // const [res1, err1] = await this.$https.get('/product/v2/product/add-possible-option/'+ this.selectedCarInfo.saleModelCode, params, null, 'gateway')
      // if(!err1) {
      //   if(res1.data) {
      //     res1.data.map(items => {
      //       const idx = this.estimateCarInfo.choiceOptions.findIndex(function(item) {
      //         return item.optionCode === items.optionCode
      //       })
      //       if(idx !== '') this.estimateCarInfo.choiceOptions[idx].disabled = false
      //     })
      //   }
      // }else {
      //   console.error('exclusive :: /product/v2/product/add-possible-option ERROR !! '+err1)
      // }
    },
    async possibleOptionList(params) {
      const [res1, err1] = await this.$https.get('/product/v2/product/add-possible-option/'+ this.selectedCarInfo.saleModelCode, params, null, 'gateway')
      if(!err1) {
        if(res1.data) {
          res1.data.map(items => {
            const idx = this.estimateCarInfo.choiceOptions.findIndex(function(item) {
              return item.optionCode === items.optionCode
            })
            if(idx !== '') this.estimateCarInfo.choiceOptions[idx].disabled = false
          })
        }
      }else {
        console.error('exclusive :: /product/v2/product/add-possible-option ERROR !! '+err1)
      }
    },
    optionUniqCheck() {
      //단독으로 선택될 수 없는 옵션의 경우 체크 해제 처리

      let arr =[]
      this.selectedCarInfo.optionMixCode.map(el => {
        let idx = this.estimateCarInfo.choiceOptions.findIndex(function(item) {
          return item.optionCode === el
        })
        if(idx > -1){
          let unity = this.estimateCarInfo.choiceOptions[idx].unity
          let group = this.estimateCarInfo.choiceOptions[idx].optionGroup

          if(unity === 'N'){
            let chkVal = false
            this.selectedCarInfo.optionMixCode.map(item => {
              if(item !== el) {
                if(group.indexOf(item) > -1){
                  chkVal = true
                }
              }
            })
            if(!chkVal) {
              arr.push(el)
            }
          }
        }
      })
      if(arr.length > 0) {
        arr.map(el => {
          this.selectedCarInfo.optionMixCode.map((item, idx) => {
            if(item === el) this.selectedCarInfo.optionMixCode.splice(idx, 1)
          })
        })
      }
    },
    async onChangeTuixOption() {
      let price = 0
      //선택한 파츠옵션의 총 가격 계산
      for(let data of this.selectedCarInfo.tuixOptionCode) {
        const index = this.estimateCarInfo.tuixOptions.findIndex(function(item){
          return item.optionCode === data
        })
        
        price += Number(this.estimateCarInfo.tuixOptions[index].optionPrice)
      }

      this.carPriceInfo.tuixOptionPrice = price

      let arr = []
      const params = {
        tuixCode: this.selectedCarInfo.tuixOptionCode.join(',')
      }
      const [res, err] = await this.$https.get('/product/v2/product/disable-tuix/'+this.selectedCarInfo.saleModelCode, params, null, 'gateway')
      if(!err) {
        if(res.data) {
          res.data.map(items => {
            const idx = this.estimateCarInfo.tuixOptions.findIndex(function(item) {
              return item.optionCode === items.tuixCode
            })
            if(idx !== '') {
              this.estimateCarInfo.tuixOptions[idx].disabled = true
            }
            arr.push(items.tuixCode)
          })

          this.estimateCarInfo.tuixOptions.map(el => {
            if(arr.indexOf(el.optionCode) === -1) {
              el.disabled = false
            }
          })
        }
      }else {
        console.error('exclusive :: /product/v2/product/disable-tuix ERROR !! '+err)
      }
    },
    async getExemplification(data) {
      //예상 출고일 문구 조회 API
      const [res, err] = await this.$https.get('/purchase/v2/purchase/contract/car/exemplification/info', {
        saleModelCode : data.saleModelCode,
        optionMixCode : data.optionMixCode,
        exteriorColorCode : data.exteriorColorCode,
        interiorColorCode : data.interiorColorCode,
      }, null, 'gateway')
      if(!err) {
        if(res.data) {
          this.selectedCarInfo.exemplificationDateText = res.data.exemplificationDateText
        }
      }else {
        console.error('exclusive :: /purchase/v2/purchase/contract/car/exemplification/info ERROR !! '+err)
      }
    },
    async getTuixOption() {
      let optionCode = this.selectedCarInfo.optionMixCode.length ? this.selectedCarInfo.optionMixCode.join(',') : ''
      
      //파츠옵션 조회API
      const [res, err] = await this.$https.get('/product/v2/product/options/tuix/'+this.selectedCarInfo.saleModelCode, {
        carAbbreviation: this.selectedCarInfo.saleModelCode.substr(0, 2),
        optionCode: optionCode,
        exteriorColorCode: this.selectedCarInfo.exteriorColorCode,
        interiorColorCode: this.selectedCarInfo.interiorColorCode,
        saleSpecCode: '' 
      }, null, 'gateway')
      if(!err) {
        if(res.data){
          this.estimateCarInfo.tuixOptions = res.data.map((items) => {
            // return { optionCode: items.tuixOptionCode, optionName: items.tuixOptionName, optionPrice: items.tuixOptionPrice, unity:items.unityChoiceYn, disabled: items.unityChoiceYn === 'Y' ? false : true} //추 후 주석 풀 예정
            return { optionCode: items.tuixOptionCode, optionName: items.tuixOptionName, optionPrice: items.tuixOptionPrice, unity:items.unityChoiceYn, disabled: false} //임시(추 후 삭제예정 소스)
          })
        }
      }else {
        console.error('exclusive :: /product/v2/product/options/tuix ERROR !! '+err)
      }

      //필수 파츠옵션 조회 API
      const params = {
        saleModelCode: this.selectedCarInfo.saleModelCode,
        optionCode: optionCode,
        saleSpecCode: 'A' 
      }
      let arr =[]
      const [res1, err1] = await this.$https.get('/product/v2/product/tuix-required-choice', params, null, 'gateway')
      if(!err1) {
        if(res1.data) {
          arr = res1.data.map(el => {
            return { tuixCode: el.tuixCode }
          }).filter((items) => items.tuixCode !== 'AX0001')

          arr.map(items => {
            const idx = this.estimateCarInfo.tuixOptions.findIndex(function(item) {
              return item.optionCode === items.tuixCode
            })
            if(idx !== ''){
              this.selectedCarInfo.tuixOptionCode.push(this.estimateCarInfo.tuixOptions[idx].optionCode)
            }
            
          })
        }
      }else {
        console.error('exclusive :: /product/v2/product/tuix-required-choice ERROR !! '+err1)
      }
    },
    async getOptionMixCode(saleModelCode, optionCode) {
      //옵션조합코드 조회
      const params = {
        saleModelCode: saleModelCode,
        optionCode: optionCode,
        saleSpecCode:'',
      }
      const [res, err] = await this.$https.get('/product/v2/product/option-mix-info', params, null, 'gateway')
      if(!err) {
        if(res.data) {
          return {
            code : res.data.optionMixCode
          }
        }
      }else {
        console.error('exclusive :: /product/v2/product/option-mix-info ERROR !! '+err)
      }
    },
    async getGeneralCarList() {
      /** 일반재고차 리스트 조회 */
      this.$emit('loading', true) //로딩 활성화
      //this.popVisibleLoading = true //로딩 활성화

      const { page, size } = this.$data.pageInfo

      let optionCode = this.selectedCarInfo.optionMixCode.length ? this.selectedCarInfo.optionMixCode.join(',') : ''
      let optionMixCode = await this.getOptionMixCode(this.selectedCarInfo.saleModelCode, optionCode)

      const params = {
        pageNo: page,
        pageSize: size,
        carType: this.selectedCarInfo.carType ? this.selectedCarInfo.carType === 'all' ? '' : this.selectedCarInfo.carType : '',
        repnCarCode: this.selectedCarInfo.repnCar,
        saleModelCode: this.selectedCarInfo.saleModelCode,
        exteriorColorCode: this.selectedCarInfo.exteriorColorCode,
        interiorColorCode: this.selectedCarInfo.interiorColorCode,
        mixedOptionCode: optionMixCode !== '' && optionMixCode.code !== 'X01' ? optionMixCode.code : null,
      }
      const [res, err] = await this.$https.post('/v2/exclusive/support/generalCar/inventory', params)
      if(!err) {
        if(res.data && res.data.list) {
          this.generalCarData = res.data.list.map((el, idx) => {
            return{
              ...el,
              no : res.data.total - res.data.endRow + res.data.list.length - idx,
              isSelected: false,
              saleModelNm: el.carNm +' / '+el.carTrimNm + ' / '+el.exrlCtyNm+ ' / '+el.carEngNm,
              optionMixCode: el.optCpndCtyNo,
              optionDetail: el.optDtl,
              deliveryCenter: el.dvcNm,
              inventoryCount: el.ivCrt,
            }
          })
          this.$data.pageInfo = {
            ...this.$data.pageInfo,
            total: res.data.total
          }
        }
      }else {
        console.error('exclusive :: /v2/exclusive/support/generalCar/inventory ERROR !! '+err)
      }
      this.$emit('loading', false) //로딩 비활성화
      //this.popVisibleLoading = false
    },
    async checkGeneralCar(data) {
      this.generalCarData.map(el => {
        if(el.no !== data.no) {
          el.isSelected = false
        }
      })
      
      let price = 0

      const params = {
        saleModelCode: data.saleCarCtyNo,
        optionMixCode:  data.optCpndCtyNo,
        exteriorColorCode: data.xrclCtyNo,
        interiorColorCode: data.ieclCtyNo,
      }
      const [res, err] = await this.$https.get('/product/v2/product/estimation/car/info', params, null, 'gateway')
      if(!err) {
        if(res.data) {
          price = res.data.carPrice
        }
      }else {
        console.error('exclusive :: /product/v2/product/estimation/car/info ERROR !! '+err)
      }
      
      this.selectedCarInfo.preEstimateInfo = {
        carCode: data.repnCarnCd,  //대표차번호
        carPrice: price,  //차량가격
        saleModelCode: data.saleCarCtyNo, //판매모델코드
        optionMixCode: data.optCpndCtyNo, //옵션조합코드
        interiorColorCode: data.ieclCtyNo, //내장컬러코트
        exteriorColorCode: data.xrclCtyNo, //외장컬러코드
        exrsCnstEeno: this.userInfo.eeno, //전담사원번호
        estimationTypeCode:'EX', //견적구분코드
        estimationStoreSectionCode:'10', //견적저장구획코드(10:가견적,20:견적최종저장)
        estimationCarTypeCode:'10', //견적차량유형코드(10:일반재고,20:할인재고,30:전시재고,40:판촉재고,50:생산차량)
        systemTypeCode:'W' //사이트구분코드
      }
    },
    async getExhibitionList() {
      /** 기획전 목록 조회 */
      const [res, err] = await this.$https.get('/v2/exclusive/support/exhition')
      if(!err) {
        if(res.data) {
          this.exhibitionInfo.exhibitionList = res.data.map((items) => {
            return { exhbNo : items.exhbNo, exhbNm : items.exhbNm }
          })
          //this.exhibitionInfo.exhibitionList.unshift({ 'exhbNo': 'all', 'exhbNm': '전체' })
        }
      }else {
        console.error('exclusive :: /v2/exclusive/support/exhition ERROR !! '+err)
      }
    },
    async getExhibitionCar() {
      this.$emit('loading', true) //로딩 활성화

      let exhbList = []
      const { page, size } = this.$data.pageInfo
      const params = {
        sortCode : '20',
        pageNo : page,
        pageSize: size,
        deliveryAreaCode: '',
        deliveryLocalAreaCode: ''
      }
      const [res, err] = await this.$https.get('/product/v2/product/exhibition/cars/'+this.exhibitionInfo.exhibitionNo, params, null, 'gateway')
      if(!err) {
        if(res.data && res.data.discountsearchcars){
          exhbList = res.data.discountsearchcars.map((items, idx) => {
            return { 
              no : idx + 1,
              isSelected: false,
              saleModelName: items.saleModelName, 
              carProductionNumber: items.carProductionNumber, 
              deliveryCenterName: items.deliveryCenterName, 
              prdnDt: items.prdnDt, 
              discountTypeName: items.discountTypeName, 
              discountPrice: items.discountPrice,
              carCode: items.carCode,
              carPrice: items.carPrice,
              saleModelCode: items.saleModelCode,
              optionMixCode: items.optionMixCode,
              interiorColorCode: items.interiorColorCode,
              exteriorColorCode: items.exteriorColorCode,
              carTypeCode: items.discountTypeCode, 
            }
          })
          this.$data.pageInfo = {
            ...this.$data.pageInfo,
            total: res.data.totalCount
          }
        }
      }else {
        console.error('exclusive :: /product/v2/product/exhibition/cars ERROR !! '+err)
      }

      this.exhibitionInfo.exhibitionCarData = exhbList

      this.$emit('loading', false) //로딩 비활성화

    },
    checkExhibitionCar(data) {
      /** 기획전 차량 선택 */
      this.exhibitionInfo.exhibitionCarData.map(el => {
        if(el.no !== data.no) {
          el.isSelected = false
        }
      })

      let carTypeCode = data.discountTypeCode === '01' ? '20' : data.discoutTypeCode === '04' ? '40' : '30'
      let preEstimate = {
        carCode: data.carCode,
        carPrice: data.carPrice,
        saleModelCode: data.saleModelCode,
        optionMixCode: data.optionMixCode,
        interiorColorCode: data.interiorColorCode,
        exteriorColorCode: data.exteriorColorCode,
        exrsCnstEeno: this.userInfo.eeno,
        estimationTypeCode: 'EX',
        estimationCarTypeCode:carTypeCode,
      }
      this.selectedCarInfo.preEstimateInfo= preEstimate
    },
    handleTabClick(tab) {
      this.resetSelectedData('all')

      Object.assign(this.exhibitionInfo, this.$options.data().exhibitionInfo)

      this.generalCarData.splice(0)

      if(tab.name === 'exhibition'){
        Object.assign(this.exhibitionInfo, this.$options.data().exhibitionInfo)
        this.getExhibitionList()
      } 
    },
    onSearch(page, type) {
      this.$data.pageInfo.page = page
      if(type === 'generalCar') {
        this.getGeneralCarList()
      }else{
        this.getExhibitionCar()
      }
    },
    resetSelectedData(type) {
      if(type === 'all') {
        /**선택된 항목들 초기화 */
        Object.assign(this.selectedCarInfo, this.$options.data().selectedCarInfo)
        /**선택된 항목들의 가격정보 초기화 */
        Object.assign(this.carPriceInfo, this.$options.data().carPriceInfo)
      }
      if(type === 'carType') {
        this.selectedCarInfo.repnCar = ''
      }
      if(type === 'carType' || type === 'repnCar') {
        this.selectedCarInfo.saleModelCode = ''
      }
      if(type === 'carType' || type === 'repnCar' || type === 'saleModel') {
        this.selectedCarInfo.exteriorColorCode= ''
        /**선택된 항목들의 가격정보 초기화 */
        Object.assign(this.carPriceInfo, this.$options.data().carPriceInfo)
      }
      if(type === 'carType' || type === 'repnCar' || type === 'saleModel' || type === 'exColor') {
        this.selectedCarInfo.interiorColorCode= '',
        this.selectedCarInfo.realityInteriorColorCode=''

        this.carPriceInfo.interiorColorPrice = 0

      }
      if(type === 'carType' || type === 'repnCar' || type === 'saleModel' || type === 'exColor' || type === 'inColor') {
        this.selectedCarInfo.optionMixCode= []

        this.carPriceInfo.choiceOptionPrice = 0
      }
      if(type === 'carType' || type === 'repnCar' || type === 'saleModel' || type === 'exColor' || type === 'inColor' || type === 'option') {
        this.selectedCarInfo.tuixOptionCode= []

        this.carPriceInfo.tuixOptionPrice = 0
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
