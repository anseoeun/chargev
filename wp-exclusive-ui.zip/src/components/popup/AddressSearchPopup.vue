<template>
  <div>
    <!-- 주소검색 팝업 -->
    <el-dialog title="주소검색" :visible.sync="popVisibleAddress.addressPop">
      <!-- Popup Contents -->
      <div class="board-wrap">
        <el-form
          ref="info"
          class="detail-form"
          @submit.prevent.native="onSearch(1)"
        >
          <el-row>
            <el-col :span="24">
              <el-form-item label="주소검색">
                <el-input
                  v-model="searchTxt"
                  placeholder="예) 헌릉로12, 양재동 231"
                />
                <el-button type="primary" class="btn-small" @click="onSearch(1)"
                  >검색</el-button
                >
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <ul class="note">
          <li>
            * 주민등록 상 주소(법인인 경우 사업자등록 상 주소)로 검색하고 선택해
            주세요.
          </li>
          <li>
            * 주소 미확인으로 출고 후 구매 취소 발생 시 왕복탁송료 이외
            부대비용은 본인 부담이니 이 점 반드시 유의하시기 바랍니다.
          </li>
        </ul>
        <div class="search-count" v-if="addressList.length">
          검색결과 : {{ Number(pageInfo.total).toLocaleString() }}건
        </div>
        <el-table :data="addressList" style="" v-if="addressList.length">
          <el-table-column label="우편번호" width="159" align="center">
            <template slot-scope="props">
              <a class="link" @click="onSelectAddress(props.row)">
                {{ props.row.zipNo }}
              </a>
            </template>
          </el-table-column>
          <el-table-column label="주소" width="560" align="center">
            <template slot-scope="props">
              <a class="link" @click="onSelectAddress(props.row)">
                {{ props.row.roadAddr }}
              </a>
            </template>
          </el-table-column>
        </el-table>
        <div class="pagination">
          <v-pagination
            v-if="addressList.length"
            :page.sync="pageInfo.page"
            :size="pageInfo.size"
            :total="pageInfo.total"
            @page-change="onPage"
          />
        </div>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import VPagination from "~/components/element/VPagination.vue";
export default {
  name: "AddressSearchPopup",
  components: {
    VPagination
  },
  props: {
    popVisibleAddress: {
      type: Object,
      default: () => {},
      required: true
    }
  },
  data() {
    return {
      searchTxt: "",
      addressList: [],
      pageInfo: {
        page: 1,
        size: 5,
        total: 0
      }
    };
  },
  methods: {
    callPaymentRequest() {
      this.$emit("callPaymentRequest");
    },
    openPop() {
      this.popVisible = true;
    },
    onSearch(page) {
      this.pageInfo.page = page;
      if (this.searchTxt !== "") {
        this.searchAddress();
      } else {
        return;
      }
    },
    async searchAddress() {
      const { page, size } = this.pageInfo;
      const [res, err] = await this.$https.get(
        "/common/v2/common/juso/addr",
        {
          currentPage: page,
          countPerPage: size,
          keyword: this.searchTxt
        },
        null,
        "gateway"
      );

      if (!res) return;

      const {
        results: {
          common: { currentPage, countPerPage, totalCount },
          juso
        }
      } = res.data;

      this.pageInfo = {
        page: currentPage,
        size: countPerPage,
        total: totalCount
      };
      this.addressList = juso.length
        ? juso.map(({ jibunAddr, roadAddr, zipNo, siNm, sggNm, bdMgtSn }) => ({
            jibunAddr,
            roadAddr,
            zipNo,
            siNm,
            sggNm,
            bdMgtSn
          }))
        : [];
    },
    onPage(page) {
      this.pageInfo.page = page;
      this.searchAddress();
    },
    onSelectAddress(juso) {
      console.log("juso ::: ", juso);
      juso.addrIdex = this.popVisibleAddress.addrIndex;
      if (this.popVisibleAddress.addrIndex === "release") {
        this.$EventBus.$emit("selectedAddressRelease", juso);
      } else {
        this.$EventBus.$emit("selectedAddress", juso);
      }
      this.popVisibleAddress.addressPop = false;
    }
  }
};
</script>
<style lang="scss" scoped>
@import "~/assets/style/pages/detail.scss";
</style>
