<template>
  <div>
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />

    <!-- 업체조회 팝업 -->
    <el-dialog title="업체조회" :visible.sync="popVisibleCompany" @close="popVisibleCompany = false">
      <!-- Popup Contents -->
      <div class="board-wrap">
        <el-form ref="info" class="detail-form" @submit.prevent.native="onSearchCompany">
          <el-row>
            <el-col :span="24">
              <el-form-item label="업체조회">
                <el-input v-model="searchText" placeholder="검색어를 입력하세요." />
                <el-button type="info" class="btn-small" @click="onReset">초기화</el-button>
                <el-button type="primary" class="btn-small" @click="onSearchCompany">검색</el-button>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>

        <div class="list-company">
          <el-radio-group v-if="companyList && companyList.length > 0" v-model="radioCompany">
            <ul>
              <li v-for="(item, index) in companyList" :key="index">
                <el-radio :label="item">[ {{ item.afcoCd }} ] {{ item.afcoNm }} - {{ item.bzNo }} </el-radio>
              </li> 
            </ul>
          </el-radio-group>
          <div v-else class="no-data">
            조회결과가 없습니다.
          </div>
        </div>
      </div>
      <!-- Popup Footer -->
      <template slot="footer">
        <div>
          <el-button type="info" @click="popVisibleCompany = false">취소</el-button>
          <el-button type="primary" @click="selectCompany">선택</el-button>
        </div>
      </template>
    </el-dialog>

  </div>
</template>
<script>
import Loading from '~/components/popup/Loading.vue'
export default {
  components: {
    Loading
  },
  data() {
    return {
      companyList: [],
      popVisibleCompany: false,
      popVisibleLoading: true,
      searchText: '',
      radioCompany: '',
    }
  },
  mounted () {
    //this.searchCompany()
  },
  methods: {
    async companyPopOpen() {
      this.popVisibleCompany = true
      this.searchText = ''
      this.companyList = []
      //await this.searchCompany()
    },
    selectCompany() {
      // 선택한 업체값을 넘겨준다
      this.$emit('selectCompany', this.radioCompany)
      //this.$emit('close')
      this.popVisibleCompany = false
    },
    onPopclose() {
      this.$emit('close')
    },
    onReset() {
      this.searchText = ''
    },
    async onSearchCompany() {
      await this.searchCompany()
    },
    async searchCompany() {
      // 초기화
      let arr = []

      let searchText =  this.searchText ?  this.searchText : ''
      const [res, err] = await this.$https.get('/v2/exclusive/common/companyCodeList/', { companyName : searchText})
      if (!err && res.data) {
        res.data.map((items => {
          arr.push(
            {
              'afcoNm' : items.AFCO_NM,          // 계열사명
              'afcoCd' : items.AFCO_CD,          // 계열사 코드
              'afcoSncCd' : items.AFCO_SCN_CD,   // 구분 코드
              'bzNo' : items.BZNO                // 사업자번호 
            }
          )
        }))

        this.companyList = arr
        this.popVisibleLoading = false
      } else {
        return
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
