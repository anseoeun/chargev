<template>
  <div>
    <!-- 하이패스 팝업 -->
    <el-dialog title="하이패스 개통 신청 대행을 위한 개인정보 제3자 제공 동의" :visible.sync="showPopup" class="popMember" width="1100px" @close="showPopup = false">
      <!-- Popup Contents -->
        <div class="agree-highpass">
            <ul>
                <li>
                    <strong>제공대상</strong>
                    <p>한국도로공사</p>
                </li>
                <li>
                    <strong>개인정보 이용 목적</strong>
                    <p>하이패스 등록 서비스 제공<br />(하이패스 단말기 장착 차량 및 신청 고객에 한함)</p>
                </li>
                <li>
                    <strong>제공하는 개인정보 항목</strong>
                    <p>성명, 상호, 연락처, 휴대폰번호, 차량정보</p>
                </li>
                <li>
                    <strong>개인정보 보유 및 이용기간</strong> 
                    <ol>
                        <li>1. 단말기 해지 또는 명의 변경 시 까지</li>
                        <li>2. 등록 또는 해지일로부터 6개월 (미납업무 처리)</li>
                    </ol>
                </li>
                <li>
                    <strong>개인정보 제공 미동의에 따른 불이익 사항</strong>
                    <p>하이패스 서비스 제공을 할 수 없습니다.<br />(단, 하이패스 미등록 상태에서 사용 시에는 고객정보를 한국도로공사에 제공할 수 있습니다.)</p>
                </li>
            </ul>

            <p>※ 한국도로공사로부터 하이패스 개통 신청 업무를 위탁 받아 대행 처리하며, 개인정보 제3자 제공 동의해 주셔야 하이패스 서비스 이용이 가능합니다.</p>
            <p>※ 하이패스 신청에 따른 이용약관 및 기타 관련 정보는 하이패스 홈페이지(www.excard.co.kr)를 참고하시기 바랍니다.</p>
            <p>※ 현대자동차는 하이패스가 적용된 차량 계약건의 경우에만 고객의 개인정보를 한국도로공사로 제공합니다.</p>
          
            <div class="info-text">
                <!-- case 1 -->
                <p v-if="!hipassEnabled">하이패스 장착 차량에서 하이패스 미장착 차량으로 변경합니다. 아래 동의를 해제해 주세요.</p>
                <!-- case 2 -->
                <p v-else>하이패스 미장착 차량에서 하이패스 장착 차량으로 변경합니다. 아래 동의를 선택해 주세요.</p>

                <el-checkbox
                  v-model="hipassChecked"
                  label="개인정보 제3자 제공 동의"
                />
                
            </div>

            <div class="btn-wrap"><el-button type="primary" @click.native="validation"> 확인 </el-button></div>

        </div>
      <pop-message
        :pop-visible.sync="alertMessagePop"
        :pop-message.sync="alertMessage"
        @confirm="alertMessagePop = false"
        @close="alertMessagePop = false"
      />
    </el-dialog>
  </div>
</template>
<script>
import PopMessage from '~/components/popup/PopMessage.vue'
export default {
  components: {
    PopMessage
  },
  props: {
    hipassPopVisible: {
      type: Boolean,
      default: false
    },
    hipassEnabled: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      showPopup : false,
      alertMessage: '',
      alertMessagePop: false,
      /* [#10426/2022.01.12/A936506] 하이패스 동의 여부 체크, 최종 통과 여부 체크 */
      hipassChecked: false, 
      hipassAgreeCompleted: false
    }
  },
  computed: {
  },
  watch: {
    hipassPopVisible(newVal) {
      this.showPopup = newVal
      this.hipassChecked = !this.hipassEnabled
    },
    showPopup(newVal) {
      if(!newVal) {
        this.onClose()
      }
    }
  },
  methods : { 
    reset() {
    },
    validation() {
      if(this.hipassEnabled !== this.hipassChecked) {  
        if(this.hipassChecked) {
          this.alertMessage = '아래 동의를 해제해 주세요.'
          this.alertMessagePop = true
          return
        } else {
          this.alertMessage = '아래 동의를 선택해 주세요.'
          this.alertMessagePop = true
          return
        }
      } else {
        this.hipassAgreeCompleted = true
        this.onClose()
      }
    },
    onClose() {
      this.$emit('close', this.hipassAgreeCompleted)
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
.agree-highpass {
    > ul {
        margin-bottom: 30px;
        > li {
            & > strong {
                display: block;
                margin-bottom: 10px;
                font-weight: bold;
                font-size: 17px;
                & + * {
                    line-height: 1.6;
                }
            }
            & + li {
                margin-top: 30px;
            }
        }
    }
    p + p {
        margin-top: 10px;
    }
    .info-text {
        margin: 30px 0;
        .el-checkbox {
            margin-top: 30px;
        }
    }
    .btn-wrap {
        justify-content: center;
    }
}
</style>
