<template>
  <v-popup
    popup-type="v2"
    :visible="visible"
    class="delivery-popup center-pop"
    @close="$emit('update:visible', false)"
  >
    <template slot="body">
      <div style="overflow: hidden;">
        <article class="message-box">
          <h4>
            {{ deliveryCenterDetail.deliveryCenterName }}
            <span>({{ deliveryCenterDetail.deliveryCenterTel }})</span>
          </h4>
          <p>{{ deliveryCenterDetail.deliveryCenterAddress }}</p>
        </article>

        <section class="popup-tab-wrap">
          <div class="content">
            <!-- 지도영역 -->
            <section class="map-box">
              <!-- 임시 지도 API 영역 -->
              <vue-daum-map
                :app-key="kakaomapOptions.appKey"
                :center.sync="mapCenter"
                :level.sync="kakaomapOptions.level"
                :map-type-id="kakaomapOptions.mapTypeId"
                :libraries="kakaomapOptions.libraries"
                class="maps"
                @load="onMapLoaded"
              />
            </section>
            <section class="location-guide">
              <strong>찾아오시는 길</strong>
              <ul class="list-dot">
                <li>
                  <p v-html="deliveryCenterDetail.deliveryCenterVisitWay1"></p>
                </li>
                <li>
                  <p v-html="deliveryCenterDetail.deliveryCenterVisitWay2"></p>
                </li>
              </ul>
            </section>
          </div>
        </section>
      </div>
    </template>
  </v-popup>
</template>
<script>
import VueDaumMap from 'vue-daum-map'
import { VPopup } from '~/components/element'

export default {
  components: {
    VueDaumMap,
    VPopup
  },
  props: {
    deliveryCenterDetail: {
      type: Object,
      default: () => {
        return {}
      }
    },
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      kakaomapOptions: {
        appKey: process.env.KAKAO_MAP_KEY,
        mapTypeId: VueDaumMap.MapTypeId.NORMAL, // 맵 타입
        libraries: [], // 추가로 불러올 라이브러리
        map: null, // 지도 객체. 지도가 로드되면 할당됨.
        level: 3 //확대축소정도
      }
    }
  },
  computed: {
    mapCenter: {
      get: function() {
        return { lat: this.deliveryCenterDetail.lat || 33.450701, lng: this.deliveryCenterDetail.lon || 126.570667 }
      },
      set: function() {}
    }
  },
  methods: {
    // 지도가 로드 완료되면 load 이벤트 발생
    onMapLoaded(map) {
      this.kakaomapOptions.map = map
      this.onMapZoomControl(map)
      this.onMapCreateMarker(map, this.mapCenter.lat, this.mapCenter.lng)
    },
    onMapCreateMarker(map, lat, lon) {
      // 지도 위에 마커 표시
      // eslint-disable-next-line no-undef
      const markerPosition = new kakao.maps.LatLng(lat, lon)
      // eslint-disable-next-line no-undef
      const marker = new kakao.maps.Marker({
        position: markerPosition
      })
      marker.setMap(map)
    },
    onMapZoomControl(map) {
      // 지도 줌 컨트롤 생성
      // eslint-disable-next-line no-undef
      const zoomControl = new kakao.maps.ZoomControl()
      // eslint-disable-next-line no-undef
      map.addControl(zoomControl, kakao.maps.ControlPosition.RIGHT)
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/common/mixin.scss';
@import '~/assets/style/common/var.scss';
@import '~/assets/style/pages/popup/DeliveryTrackingPopup.scss';
</style>
