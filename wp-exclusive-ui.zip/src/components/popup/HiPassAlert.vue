<template>
  <!-- message Popup -->
  <v-popup
    popup-type="message"
    :visible.sync="popVisible"
    :is-close="isClose"
    :width="popWidth"
    @confirm="$emit('confirm')"
    @close="$emit('close')"
  >
    <template
      v-if="popMessage.split('\n').length > 1"
      slot="body"
    >
      <p
        v-for="(items, idx) in popMessage.split('\n')"
        :key="`message-${idx}`"
        :class="popAlign"
      >
        {{ items }}
      </p>
      <p
        v-if="popSubMessage"
        :style="subMessageStyle"
      >
        {{ popSubMessage }}
      </p>
    </template>
    <template
      v-else
      slot="body"
    >
      <p>
        {{ popMessage }}
      </p>
      <p
        v-if="popSubMessage"
        :style="subMessageStyle"
      >
        {{ popSubMessage }}
      </p>
    </template>
    <template slot="footer">
      <el-button
        type="primary"
        @click="agreeClick"
      >
        확인
      </el-button>
    </template>
  </v-popup>  
</template>

<script>
import VPopup from '~/components/element/VPopup.vue'
export default {
  components: {
    VPopup
  },
  props: {
    isClose: {
      type: Boolean,
      default: false
    },
    popVisible: {
      type: Boolean,
      default: false
    },
    popMessage: {
      type: String,
      default: ''
    },
    popSubMessage: {
      type: String,
      default: ''
    },
    subMessageStyle: {
      type: String,
      default: ''
    },
    popAlign: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      popWidth: '600px'
    }
  },
  methods: {
    agreeClick(){
      this.$emit('click')
      this.closePop()
    },
    closePop() {
      this.$emit('close')
    }
  }
}
</script>

<style lang="scss" scoped>
</style>