<template>
  <div>
    <el-dialog
      custom-class="message"
      :visible.sync="agreePop"
      class="agreePop"
      width="960px"
    >
      <!-- Message -->
      <el-table :data="agreeTable" max-height="650">
        <el-table-column
          label="구분"
          align="center"
          prop="informationGatheringName"
        />
        <el-table-column
          label="동의여부"
          align="center"
          prop="informationGatheringYn"
        >
          <template slot-scope="scope">
            <div>
              <el-radio
                v-model="scope.row.informationGatheringYn"
                label="Y"
                @click.native.prevent
                >동의</el-radio
              >
              <el-radio
                v-model="scope.row.informationGatheringYn"
                label="N"
                @click.native.prevent
                >미동의</el-radio
              >
            </div>
            <div v-if="scope.row.checkList === 'Y'" class="checkList">
              <el-checkbox label="sms" />
              <el-checkbox label="e-mail" />
              <el-checkbox label="우편" />
            </div>
          </template>
        </el-table-column>
      </el-table>
      <!-- Popup Footer -->
      <template slot="footer">
        <el-button type="primary" @click="agreePop = false">확인</el-button>
      </template>
    </el-dialog>
  </div>
</template>
<script>
export default {
  name: "AgreePopup",
  props: {
    popAgreeDatas: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      agreePop: false,
      agreeTable: [] // 정보제공 동의 정보
    };
  },
  methods: {
    agreePopOpen() {
      // 활용 동의 팝업 활성화
      const agreePopData = this.popAgreeDatas.data;
      const ccT017 = this.popAgreeDatas.codes || [];
      if (ccT017 && ccT017.length) {
        // 공통코드 데이터가 있을경우
        this.agreeTable = ccT017.map(items => {
          const findIdx = agreePopData.informationGatheringInfo.findIndex(
            items2 => items2.informationGatheringCode === items.value
          );
          return {
            informationGatheringCode: items.value,
            informationGatheringName: items.label,
            informationGatheringYn:
              findIdx > -1
                ? agreePopData.informationGatheringInfo[findIdx]
                    .informationGatheringYn
                : "N"
          };
        });
      } else {
        this.agreeTable = agreePopData.informationGatheringInfo;
      }
      // this.agreePopOpen = row
      this.agreePop = true;
    }
  }
};
</script>
<style lang="scss" scoped>
@import "~/assets/style/pages/detail.scss";
</style>
