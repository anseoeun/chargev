<template>
  <v-popup
    :visible="popVisible"
    :width="popWidth"
    popup-text-align="center"
    popup-type="wait"
    pop-height="40vh"
    :close-on-click-modal="closeOnClickModal"
    :is-show-close="false"
    @close="$emit('close')"
  >
    <template slot="body">
      <div class="image">
        <img 
          src="~@/assets/images/Loading_Car.gif"
          alt
        />
      </div>
      <div 
        class="loading-contents" 
        style="overflow:hidden;"
      >
        <p class="loading-title">
          잠시만 기다려 주세요.
        </p>
      </div>
    </template>
  </v-popup>
</template>

<script>
import VPopup from '~/components/element/VPopup.vue'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Boolean,
      default: false
    },
    closeOnClickModal: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      popWidth: '443px'
    }
  }
  // created() {
  //   console.log('popVisible: ', this.popVisible)
  //   console.log('payment: ', this.payment)
  // }
}
</script>

<style lang="scss" scoped>
@import '~/assets/style/pages/loading.scss';
</style>
