<template>
  <div>
    <!-- 빠른결제요청 팝업 -->
    <el-dialog title="빠른 결제요청" :visible.sync="popVisible">
      <!-- Popup Contents -->
      <div class="board-wrap">
        <el-form class="detail-form">
          <el-row>
            <el-col :span="24">
              <el-form-item label="변경 후">결제대기</el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <div class="box">
          <el-table :data="popPaymentDatas">
            <el-table-column
              prop="contractNumber"
              label="계약번호"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="onlineStatusName"
              label="변경 전 상태"
              align="center"
            ></el-table-column>
          </el-table>
        </div>
      </div>
      <!-- Popup Footer -->
      <template slot="footer">
        <div>
          <el-button type="info" @click="popVisible = false">취소</el-button>
          <el-button type="primary" @click="callPaymentRequest">확인</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>
<script>
export default {
  name: "PayRequestPopup",
  props: {
    popPaymentDatas: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      popVisible: false
    };
  },
  methods: {
    callPaymentRequest() {
      this.$emit("callPaymentRequest");
    },
    openPop() {
      this.popVisible = true;
    },
    closePop() {
      this.popVisible = false;
    }
  }
};
</script>
<style lang="scss" scoped>
@import "~/assets/style/pages/detail.scss";
</style>
