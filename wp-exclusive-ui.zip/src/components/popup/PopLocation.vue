<template>
  <v-popup
    :visible="visible"
    popup-type="v2"
    popup-text-align="center"
    @close="$emit('close')"
  >
    <h3
      slot="header"
      class="popup-title"
    >
      {{ type === 'loc' ? '위치 수정' : '우편번호 검색' }}
    </h3>
    <div slot="body">
      <div v-if="type === 'loc'">
        <p class="popup-sub-title">
          현재 접속중인 지역은 <span class="now-position">"{{ value }}"</span>가 아닌가요?<br>
          아래에서 원하시는 지역을 선택하시면 위치정보가 재설정됩니다.
        </p>
      </div>
      <div class="popup-search-wrap">
        <!-- 검색창 -->
        <el-form
          ref="form"
          :model="items"
          :status-icon="true"
          @submit.prevent.native="onSearch(1)"
        >
          <el-form-item
            prop="searchText"
            :rules="[{ required: true, message: '검색어를 입력해 주세요' }]"
          >
            <el-input
              v-model="items.searchText"
              input-type="sch"
              placeholder="예) 헌릉로 12, 현대자동차연구소, 양재동 231"
            />
          </el-form-item>
        </el-form>
        <!-- 검색버튼 -->
        <el-button
          type="primary"
          @click="onSearch(1)"
        >
          검색
        </el-button>
      </div>

      <section class="ex-box">
        <p class="ex-box-title">
          검색어 예 :
        </p>
        <p class="dot-head">
          도로명(반포대로 58), 건물명(독립기념관), 지번(삼성동 25)
        </p>
      </section>

      <!-- 주소 검색 결과 -->
      <section
        v-if="isSearch"
        class="result-table"
      >
        <strong>검색결과:<span class="point">{{ pageInfo.total }}</span>건</strong>
        <div class="table-wrap">
          <table class="table">
            <caption>
              위치수정 버튼을 누르면 나오는 표로 도로명주소, 우편주소를 제공
            </caption>
            <colgroup>
              <col style="width:80%">
              <col style="width:20%">
            </colgroup>
            <thead>
              <tr>
                <th scope="col">
                  도로명 주소
                </th>
                <th scope="col">
                  우편주소
                </th>
              </tr>
            </thead>
            <tbody v-if="list.length">
              <tr
                v-for="(juso, index) in list"
                :key="index"
              >
                <td>
                  <el-button
                    type="text"
                    class="address"
                    @click="onSelectAddress(juso)"
                  >
                    {{ juso.roadAddr }}
                    <span class="old">{{ juso.jibunAddr }}</span>
                  </el-button>
                </td>
                <td>{{ juso.zipNo }}</td>
              </tr>
            </tbody>
            <tbody v-else>
              <tr>
                <td
                  colspan="2"
                  class="no-data"
                >
                  검색결과가 없습니다.
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <!-- TODO 컴포넌트로 변경해야함 -->
        <v-pagination
          v-if="list.length"
          :page.sync="pageInfo.page"
          :size="pageInfo.size"
          :total="pageInfo.total"
          @page-change="onPage"
        />
      </section>
    </div>
  </v-popup>
</template>

<script>
import VPopup from '~/components/element/VPopup.vue'
import VPagination from '~/components/element/VPagination.vue'

export default {
  components: {
    VPopup,
    VPagination
  },

  props: {
    visible: {
      type: Boolean,
      default: false
    },
    value: {
      type: String,
      default: null
    },
    type: {
      type: String,
      default: 'loc'
    }
  },

  data() {
    return {
      items: {
        searchText: ''
      },
      list: [],
      pageInfo: {
        page: 1,
        size: 5,
        total: 0
      },
      isSearch: false
    }
  },

  methods: {
    /**
     * 주소 검색(www.juso.go.kr)
     */
    async fetchAddress() {
      const { page, size } = this.pageInfo

      const [res] = await this.$https.get('eis/juso/addrlink/addrLinkApiJsonp.do', {
        confmKey: 'U01TX0FVVEgyMDE3MDgxODE2NTExMTIzODcy',
        currentPage: page,
        countPerPage: size,
        keyword: this.items.searchText,
        resultType: 'json'
      }, null, 'gateway')

      if (!res) return
      const {
        results: {
          common: { currentPage, countPerPage, totalCount },
          juso
        }
      } = JSON.parse(res.replace(/^\(/, '').replace(/\)$/, ''))

      this.pageInfo = {
        page: currentPage,
        size: countPerPage,
        total: totalCount
      }
      this.list = juso.length
        ? juso.map(({ jibunAddr, roadAddr, zipNo, siNm, sggNm }) => ({
          jibunAddr,
          roadAddr,
          zipNo,
          siNm,
          sggNm
        }))
        : []
    },

    onSearch(page) {
      this.pageInfo.page = page
      this.$refs.form.validate((valid) => {
        if (valid) {
          this.isSearch = true
          this.fetchAddress()
        } else {
          return false
        }
      })
    },

    onPage(page) {
      this.pageInfo.page = page
      this.fetchAddress()
    },

    onSelectAddress(juso) {
      this.$emit('input', juso.roadAddr)
      this.$emit('select', juso)
      this.$emit('close')
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~/assets/style/common/mixin.scss';
@import '~/assets/style/common/var.scss';
@import '~/assets/style/pages/popLocation.scss';
</style>
