<template>
  <div 
    class="el-image"
    :class="{ 'border' : border }"
    :style="getStyle"
  >
    <div 
      v-if="loading" 
      class="placeholder" 
      name="placeholder"
    >
      <i class="el-icon-loading" />
    </div>
    <div 
      v-else-if="error" 
      class="error" 
      name="error"
    >
      <i class="el-icon-picture-outline" />
    </div>
    <div v-else>
      <img
        class="el-image__inner"
        :src="src"
        :alt="alt"
        :style="getFit"
      >
    </div>
  </div>
</template> 

<script>
export default {
  props: {
    src: {
      type: String,
      default: ''
    },
    border: {
      type: Boolean,
      default: false
    },
    fit: {
      type: String,
      default: 'contain'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '100%'
    },
    imgType: {
      type: String,
      default: null
    },
    alt: {
      type: String,
      default: ''
    }
  },

  data() {
    return {
      loading: true,
      error: false,
      show: true
    }
  },

  computed: {
    getStyle() {
      let size = { width: this.width, height: this.height }
      let sizeType = {
        table: { width: '126px', height: '68px' }
      }
      if (sizeType[this.imgType]) {
        size = { ...size, ...sizeType[this.imgType] }
      }
      return `width: ${size.width}; height: ${size.height}`
    },

    getFit() {
      if (this.fit === 'fill') {
        return 'width: 100%; height: 100%;'
      } else if (this.fit === 'none') {
        return ''
      } else {
        return 'width: 100%; height: auto;'
      }
    }
  },
  /*
  watch: {
    src: {
      handler(val) {
        this.show && this.loadImage(val)
      },
      immediate: true
    },
    show(val) {
      val && this.loadImage(this.src)
    }
  },*/

  mounted() {
    this.loadImage(this.src)
  },

  methods: {
    loadImage(val) {
      // reset status
      this.loading = true
      this.error = false
      const img = new window.Image()
      img.onload = this.handleLoad.bind(this)
      img.onerror = this.handleError.bind(this)
      img.src = val
    },
    handleLoad(e) {
      this.loading = false
      this.$emit('load', e)
    },
    handleError(e) {
      this.loading = false
      this.error = true
      this.$emit('error', e)
    }
  }
}
</script>

<style lang="scss" scope>
.el-image {
  display: inline-block;
  text-align: center;
  box-sizing: border-box;
  overflow: hidden;

  &.border {
    border: 1px solid #ddd;
  }

  > div {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 100%;
    background: #e5e5e5;
    text-align: center;
    vertical-align: middle;

    > i {
      font-size: 28px;
    }
  }
}
</style>
