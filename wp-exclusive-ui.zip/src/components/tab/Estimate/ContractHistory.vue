<template>
  <div>
    
    <div class="box">
      <el-table :data="contractHistory">
        <el-table-column prop="carCode" label="차명" width="150" align="center"></el-table-column>
        <el-table-column prop="contractNumber" label="계약번호" width="200" align="center">
          <template slot-scope="props">
            <a
              class="link"
              :href="`/#/wp/contract/${props.row.contractType}/release-detail`"
              target="_blank"
              @click="$utils.setLocalStorage({ contractNumber: props.row.contractNumber })"
            >
              {{ props.row.contractNumber }}
            </a>
          </template>
        </el-table-column>
        <el-table-column prop="contractStartDate" label="계약시작일" width="120" align="center"></el-table-column>
        <el-table-column prop="contractEndDate" label="계약완료일" width="120" align="center"></el-table-column>
        <el-table-column prop="releaseDate" label="출고일" width="120" align="center"></el-table-column>
        <el-table-column prop="consultantName" label="계약담당자" width="150" align="center"></el-table-column>
        <el-table-column prop="legacyStatusName" label="판매진행상태" width="100" align="center"></el-table-column>
        <el-table-column prop="onlineStatusName" label="온라인진행상태" width="100" align="center"></el-table-column>
        <el-table-column prop="vehicleIdentificationNumber" label="차대번호" width="200" align="center"></el-table-column>
        <el-table-column prop="prebookYn" label="사전계약여부" width="100" align="center"></el-table-column>
        <el-table-column prop="consultantId" label="사번" width="150" align="center"></el-table-column>
        <el-table-column prop="cancelReason" label="취소사유" width="200" align="center"></el-table-column>
      </el-table>
      <div class="btn-wrap">
          <div class="side"></div>
          <div class="pagination">
            <v-pagination
              v-if="contractHistory.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch"
            />
          </div>
          <div class="main"></div>
        </div>
    </div>   

  </div>
</template>
<script>
export default {
  props: {
    estimateNumber: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      contractHistory:[],
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      },
    }
  },
  watch: {
    'estimateNumber': function() {
      this.getContractHistory()
    }
  },
  methods: {
    async getContractHistory() {
      if(!this.estimateNumber) return

      const { page, size } = this.$data.pageInfo
      const params = {
        pageNo: page,
        pageSize: size,
        estimateNumber: this.estimateNumber
      }

      const [res, err] = await this.$https.post('/v2/exclusive/support/estimate/contract-history',params)
      if(!err) {
        if(res.data && res.data.list) {
          this.contractHistory = res.data.list.map((items) => {
            return {
              ...items,
              isSelected: false,
              carCode: items.carCode ? items.carCode : '-',
              contractNumber: items.contractNumber ? items.contractNumber : '',
              contractStartDate: items.contractStartDate ? items.contractStartDate : '-',
              contractEndDate: items.contractEndDate ? items.contractEndDate : '-',
              releaseDate: items.releaseDate ? items.releaseDate : '-',
              consultantName: items.consultantName ? items.consultantName : '-',
              legacyStatusName: items.legacyStatusName ? items.legacyStatusName : '-',
              onlineStatusName: items.onlineStatusName ? items.onlineStatusName : '-',
              vehicleIdentificationNumber: items.vehicleIdentificationNumber ? items.vehicleIdentificationNumber : '-',
              prebookYn: items.prebookYn ? items.prebookYn : '-',
              consultantId: items.consultantId ? items.consultantId : '-',
              cancelReason: items.cancelReason ? items.cancelReason : '-',
              contractType: items.corpYn === 'Y' ? 'corporation' : 'customer'
            }
          })
          this.$data.pageInfo = {
            ...this.$data.pageInfo,
            total: res.data.total
          }
        }
      }else {
        console.error('exclusive :: /v2/exclusive/support/estimate/contract-history ERROR !! '+err)
      }
    },
    onSearch(page) {
      this.$data.pageInfo.page = page
      this.getContractHistory()
    },
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>