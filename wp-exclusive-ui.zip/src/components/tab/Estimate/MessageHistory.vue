<template>
  <div>
    
    <div class="box">
      <el-table :data="messageHistory">
        <el-table-column prop="msgType" label="발송유형" width="100" align="center"></el-table-column>
        <el-table-column prop="sendDate" label="발송일시" width="150" align="center"></el-table-column>
        <el-table-column prop="msgTitle" label="제목" width="300" align="center"></el-table-column>
        <el-table-column prop="" label="내용" width="150" align="center">
          <template slot-scope="props">
              <a
                class="link"
                href="#"
                @click="getContents(props.row.serialNumber, props.row.msgType)"
              >
                상세보기
              </a>
            </template>
        </el-table-column>
        <el-table-column prop="adresseeName" label="이름" width="150" align="center"></el-table-column>
        <el-table-column prop="adresseeMobile" label="휴대전화번호" width="150" align="center"></el-table-column>
        <el-table-column prop="adresseeEmail" label="이메일" width="240" align="center"></el-table-column>
        <el-table-column prop="dispatcherName" label="보낸사람" width="100" align="center"></el-table-column>
        <el-table-column prop="sendMobile" label="발신번호" width="150" align="center"></el-table-column>
        <el-table-column prop="sendState" label="발송상태" width="100" align="center"></el-table-column>
        <el-table-column prop="" label="비고" width="100" align="center">
          <template slot-scope="props">
            <el-button type="primary" class="btn-small" @click="resend(props.row)">재발송</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div> 

    <div v-if="messageDetail.msgType" class="detail-view">
      <el-form ref="info" class="detail-form table-wrap">
        <el-row>
          <el-col :span="24">
            <el-form-item label="제목">
              <el-input 
                v-model="messageDetail.msgTitle"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="발송유형">{{ messageDetail.msgType }}</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="발송일시">{{ messageDetail.msgTime }}</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="수신정보">{{ messageDetail.receiverInfo }}</el-form-item>
          </el-col>
        </el-row>
        <el-row v-show="messageDetail.msgType === 'EML'">
          <el-col :span="24">
            <el-form-item label="내용">
              <el-input type="textarea" class="textarea" v-html="messageDetail.msgContents" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row v-show="messageDetail.msgType !== 'EML'">
          <el-col :span="24">
            <el-form-item label="내용">
              <el-input v-model="messageDetail.msgContents" type="textarea" class="textarea" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="URL">
              <el-link type="primary">{{ estimateUrl }}</el-link>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="btn-group">
        <el-button type="primary" @click="resend(messageDetail)">발송</el-button>
      </div>
      <pop-message
        :pop-visible.sync="alertMessagePop"
        :pop-message.sync="alertMessage"
        @confirm="alertMessagePop = false"
        @close="alertMessagePop = false"
      />
      <loading
        :pop-visible.sync="popVisibleLoading"
        :close-on-click-modal="false"
        @close="popVisibleLoading = false"
      />
      
    </div>


  </div>
</template>
<script>
import PopMessage from '~/components/popup/PopMessage.vue'
import Loading from '~/components/popup/Loading.vue'
export default {
  components: {
    PopMessage,
    Loading
  },
  props: {
    estimateNumber: {
      type: String,
      default: '',
    },
    estimateUrl: {
      type: String,
      default: '',
    }
  }, 
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      popVisibleLoading: false, // 로딩 활성화 여부
      messageHistory: [],
      messageDetail : {
        msgTitle:'',
        msgContents:'',
        msgType:'',
        msgTime: '',
        receiverInfo:'',
        serialNumber:'',
      },
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      },
    }
  },
  methods: {
    async getMessageHistory() {
      if(!this.estimateNumber) return
      const { page, size } = this.$data.pageInfo
      const params = {
        pageNo: page,
        pageSize: size,
        estimateNumber: this.estimateNumber
      }
      const [res, err] = await this.$https.post('/v2/exclusive/support/estimate/message-history', params)
      if(!err) {
        if(res.data && res.data.list) {
          this.messageHistory = res.data.list.map((items) => {
            return {
              ...items,
              isSelected: false,
              serialNumber: items.msgIntegrationSendSerialNumber,
              msgType: items.messageTypeCode ? items.messageTypeCode : '-',
              sendDate: items.sendDate ? items.sendDate : '-',
              adresseeName: items.adresseeName ? items.adresseeName : '-',
              adresseeMobile: items.adresseeMobile ? items.adresseeMobile : '-',
              adresseeEmail: items.adresseeEmail ? items.adresseeEmail : '-',
              sendMobile: items.sendMobile ? items.sendMobile : '-',
              dispatcherName: items.dispatcherName ? items.dispatcherName : '-',
              msgTitle: items.messageTitle ? items.messageTitle : '-',
              sendState: items.sendState ? items.sendState : '-',
            }
          })
          this.$data.pageInfo = {
            ...this.$data.pageInfo,
            total: res.data.total
          }
        }
      }else {
        console.error('exclusive :: /v2/exclusive/support/estimate/message-history ERROR !! '+err)
      }
    },
    async getContents(msgSerialNumber, sndTypeCd) {
      if(sndTypeCd === 'EML') {
        let param = {
          workEmailSendSerialNumber: msgSerialNumber,
          messageTypeCode: sndTypeCd,
        }
        this.popVisibleLoading = true
        const [res, err] = await this.$https.post('/v2/exclusive/common/email-content', param)
        if(!err) {
          if(res.data) {
            this.messageDetail = {
              msgTitle: res.data.mailTitle,
              msgContents: res.data.messageContent,
              msgType: res.data.sndTypeCd,
              msgTime: res.data.sendDateTime,
              receiverInfo:res.data.receiverEmailAddress,
              serialNumber:res.data.mailSendSerialNumber,
            }
          }
        }else {
          console.error('exclusive :: /v2/exclusive/common/email-content ERROR !! '+err)
        }
        this.popVisibleLoading = false

      }else {
        let param = {
          workSmsSendSerialNumber: msgSerialNumber,
          messageTypeCode: sndTypeCd,
        }
        this.popVisibleLoading = true
        const [res, err] = await this.$https.post('/v2/exclusive/common/sms-content', param)
        if(!err) {
          if(res.data) {
            this.messageDetail = {
              msgTitle: res.data.smsTitle,
              msgContents: res.data.smsContent,
              msgType: res.data.sndTypeCd,
              msgTime: res.data.sendDateTime,
              receiverInfo:res.data.mobileNumber,
              serialNumber:res.data.smsSendSerialNumber,
            }
          }
        }else {
          console.error('exclusive :: /v2/exclusive/common/sms-content ERROR !! '+err)
        }
        this.popVisibleLoading = false
      }
    },
    async resend(data) {
      if(!data.serialNumber) return 

      let msgDetail = data.msgType === 'EML' ? '' : data.msgContents

      const params = {
        msgIntegrationSendSerialNumber: data.serialNumber,
        messageTypeCode: data.msgType,
        estimateNumber: this.estimateNumber,
        messageTitle: data.msgTitle,
        messageContents: msgDetail,
      }
      this.popVisibleLoading = true
      const [res, err] = await this.$https.post('/v2/exclusive/support/estimate/sendMessage', params)
      if(!err) {
        if(res.rspStatus && res.rspStatus.rspCode === '0000'){
          this.alertMessage = '전송되었습니다.'
          this.alertMessagePop = true

          Object.assign(this.$data.messageDetail, this.$options.data().messageDetail)
          this.$emit('reloadData', this.estimateNumber) // reload
        }
      }else {
        console.error('exclusive ::/v2/exclusive/support/estimate/sendMessage ERROR !! '+err)
      }
      this.popVisibleLoading = false
    },
  }

}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>