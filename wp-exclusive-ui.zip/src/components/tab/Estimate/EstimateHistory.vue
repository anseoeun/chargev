<template>
  <div>
    <div class="box">
      <el-table :data="estimateHistory">
        <el-table-column prop="estimateNumber" label="견적번호" width="200" align="center">
          <template slot-scope="props">
            <a
              class="link"
              href="#"
              @click="estimatePopup(props.row.estShareUrl)"
            >
              {{ props.row.estimateNumber }}
            </a>
          </template>
        </el-table-column>
        <el-table-column prop="exrsCnstEeno" label="사번" width="200" align="center"></el-table-column>
        <el-table-column prop="saleMdlNm" label="모델" width="639" align="center"></el-table-column>
        <el-table-column prop="estDtm" label="견적일시" width="150" align="center"></el-table-column>
        <el-table-column prop="finMdfyDtm" label="최종수정일시" width="150" align="center"></el-table-column>
        <el-table-column prop="contractNumber" label="계약번호" width="200" align="center">
          <template slot-scope="props">
            <a
              class="link"
              :href="`/#/wp/contract/${props.row.contractType}/release-detail`"
              target="_blank"
              @click="$utils.setLocalStorage({ contractNumber: props.row.contractNumber })"
            >
              {{ props.row.contractNumber }}
            </a>
          </template>
        </el-table-column>
      </el-table>
      <div class="btn-wrap">
          <div class="side"></div>
          <div class="pagination">
            <v-pagination
              v-if="estimateHistory.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch($event,'1')"
            />
          </div>
          <div class="main"></div>
        </div>
    </div>   

  </div>
</template>
<script>
export default {
  props: {
    estimateNumber: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      estimateHistory: [],
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      },
    }
  },
  watch: {
    'estimateNumber': function() {
      this.getEstimateHistory()
    }
  },
  methods: {
    async getEstimateHistory() {
      if(!this.estimateNumber) return

      const { page, size } = this.$data.pageInfo
      const params = {
        pageNo: page,
        pageSize: size,
        estimateNumber: this.estimateNumber
      }

      const [res, err] = await this.$https.post('/v2/exclusive/support/estimate/estimate-history', params)
      if(!err) {
        if(res.data && res.data.list) {
          this.estimateHistory =  res.data.list.map((items) => {
            return {
              ...items,
              isSelected: false,
              estimateNumber: items.carEstNo ? items.carEstNo : '-',
              estShareUrl: items.estShareUrl ? items.estShareUrl : '-',
              exrsCnstEeno: items.exrsCnstEeno ? items.exrsCnstEeno : '-',
              saleMdlNm: items.saleMdlNm ? items.saleMdlNm : '-',
              estDtm: items.estDtm ? items.estDtm : '-',
              finMdfyDtm: items.finMdfyDtm ? items.finMdfyDtm : '-',
              contractNumber: items.saleCnttNo ? items.saleCnttNo : '',
              contractType: items.corpYn === 'Y' ? 'corporation' : 'customer'
            }
          })
          this.$data.pageInfo = {
            ...this.$data.pageInfo,
            total: res.data.total
          }
        }
      }else {
        console.error('exclusive :: /v2/exclusive/support/estimate/estimate-history ERROR !! '+err)
      }
      console.log('VUE_APP_PROFILE :: '+process.env.VUE_APP_PROFILE)
    },
    estimatePopup(url) {
      let preffixUrl = 'http://10.7.137.110/dev/casper'
      if (['stg', 'dev', 'prod'].includes(process.env.VUE_APP_PROFILE)) {
        preffixUrl = process.env.VUE_APP_BASEURL_FRONT
      }

      let fullUrl = preffixUrl + '/estimation/detail?estimationUrl='

      let width = 1400
      let height = 1000
      let clientWidth = document.body.clientWidth
      let clientHeight = document.body.clientHeight
      let winX = window.screenX || window.screenLeft || 0
      let winY = window.screenY || window.screenTop || 0
      let left = winX + (clientWidth - width) / 2
      let top = winY + (clientHeight - height) / 2

      //window 팝업 오픈
      window.open(fullUrl+url, 'popup', 'top='+top+ ',left='+left+ ',width='+width+ ',height='+height+ ', status=no, menubar=no, toolbar=no')
    },
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>