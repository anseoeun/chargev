<template>
  <div>
    <!-- 컴포넌트 루프 테스트  (field, index) in tableHeader-->
    <component
      v-bind:is="currentComponent(item)"
      :ref="currentComponentRef(item)"
      v-for="(item, index) in componentSortList"
      :key="index"
      :contract-number.sync="contractNumber"
      :contract-data.sync="contractData"
      :contract-info-data.sync="contractInfoData"
      :contractor-installment-yn="contractorInstallmentYn"
      :user-info-data.sync="userInfoData"
      :active-user-flag.sync="activeUserFlag"
      @agreePopOpen="agreePopOpen($event)"
      @searchAddressPopOpen="searchAddressPopOpen()"
      @refresh="refresh()"
    ></component>
    <!-- <span v-for="(field, index) in componuntTest" :key="index">{{
      field.comp | to_uppercase
    }}</span> 
    <contractor-info
      :contract-number.sync="contractNumber"
      :contract-data.sync="contractData"
      :contract-info-data.sync="contractInfoData"
      :user-info-data.sync="userInfoData"
      :active-user-flag.sync="activeUserFlag"
      @agreePopOpen="agreePopOpen($event)"
    />
    <service-info
      :contract-number.sync="contractNumber"
      :contract-data.sync="contractData"
      :contract-info-data.sync="contractInfoData"
      :user-info-data.sync="userInfoData"
      :active-user-flag.sync="activeUserFlag"
    />
    <payment-info
      :contract-number.sync="contractNumber"
      :contract-data.sync="contractData"
      :user-info-data.sync="userInfoData"
      :active-user-flag.sync="activeUserFlag"
    />
    <signature-info
      ref="signatureInfo"
      :contract-number.sync="contractNumber"
      :contract-data.sync="contractData"
      :user-info-data.sync="userInfoData"
      :active-user-flag.sync="activeUserFlag"
    />
    <status-info
      ref="statusInfo"
      :contract-number.sync="contractNumber"
      :contract-data.sync="contractData"
      :user-info-data.sync="userInfoData"
      :active-user-flag.sync="activeUserFlag"
    />
    <paper-review-info
      ref="paperInfo"
      :contract-number.sync="contractNumber"
      :user-info-data.sync="userInfoData"
      :active-user-flag.sync="activeUserFlag"
    />
    <recommend-info
      :contract-number.sync="contractNumber"
      :user-info-data.sync="userInfoData"
      :active-user-flag.sync="activeUserFlag"
    />-->

    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />

    <!-- agree Popup -->
    <agree-popup
      ref="agrPop"
      :pop-visible.sync="agreePop"
      :pop-agree-datas.sync="popAgreeDatas"
      :common-codes.sync="commonCodes"
      @close="agreePop = false"
    />
  </div>
</template>
<script>
import HTableList from "~/components/common/HTableList.vue";
import HTable from "~/components/common/HTable.vue";
import HTitle from "~/components/common/HTitle.vue";
import PopMessage from "~/components/popup/PopMessage.vue";
import ContractorInfo from "~/components/tab/contract/ContractorInfo.vue";
import ServiceInfo from "~/components/tab/contract/ServiceInfo.vue";
import PaymentInfo from "~/components/tab/contract/PaymentInfo.vue";
import SignatureInfo from "~/components/tab/contract/SignatureInfo.vue";
import StatusInfo from "~/components/tab/contract/StatusInfo.vue";
import PaperReviewInfo from "~/components/tab/contract/PaperReviewInfo.vue";
import RecommendInfo from "~/components/tab/contract/RecommendInfo.vue";
import AgreePopup from "~/components/popup/AgreePopup.vue";

export default {
  name: "ContractInfo",
  components: {
    HTitle,
    HTableList,
    HTable,
    PopMessage,
    ContractorInfo,
    ServiceInfo,
    PaymentInfo,
    SignatureInfo,
    StatusInfo,
    PaperReviewInfo,
    RecommendInfo,
    AgreePopup
  },
  props: {
    contractNumber: {
      type: String,
      default: ""
    },
    contractData: {
      type: Object,
      default: () => {}
    },
    contractorInstallmentYn: {
      type: Boolean,
      default: false
    },
    userInfoData: {
      // 로그인 사용자 정보
      type: Object,
      default: () => {}
    },
    activeUserFlag: {
      type: Boolean,
      default: false
    },
    contractInfoData: {
      type: Object,
      default: () => {}
    },
    componentSortList: {
      type: Array,
      default: () => [
        "contractor-info",
        "service-info",
        "payment-info",
        "signature-info",
        "status-info",
        "paper-review-info",
        "recommend-info"
      ]
    }
  },
  data() {
    return {
      isAuth: process.env.VUE_APP_AUTH === "true", // 권한 패스용
      alertMessage: "",
      alertMessagePop: false,
      agreePop: false, // 활용 동의 팝업
      popAgreeDatas: {}, // 정보제공 동의 정보
      commonCodes: {}
    };
  },
  async created() {
    await this.loadCommonCode();
  },
  methods: {
    fetchCommonCodeData(systemType = "", codeType = "") {
      let res = null;
      switch (systemType) {
        case "E":
          res = this.$store.dispatch("loadCommonCodesE", {
            vm: this,
            codeTypeCode: codeType
          });
          break;
        case "C":
          res = this.$store.dispatch("loadLegacyCommonCodesC", {
            vm: this,
            codeTypeCode: codeType
          });
          break;
      }
      return res;
    },
    async loadCommonCode() {
      const [ccT017] = await Promise.all([
        this.fetchCommonCodeData("E", "T017")
      ]);
      this.commonCodes = { ...ccT017 };
    },
    onCheck(value) {
      console.log(value);
    },
    isValidAuthBtn(authId) {
      // 버튼별 권한 체크
      let bResult = false; // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || [];
      if (currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some(items => {
          if (items.btnId === authId) {
            bResult = true;
            return true;
          }
        });
      }
      return bResult;
    },
    getAllData() {
      console.log("this.$refs");
      console.log(this.$refs);
      this.getStatusInfo();
      this.getSignatureInfo();
      this.getPaperReviewData();
      this.getRecommenderData();
      this.getServiceData();
    },
    getSignatureInfo() {
      this.$refs.signatureInfo[0].getElectronSignData();
    },
    getStatusInfo() {
      this.$refs.statusInfo[0].getStatusData();
    },
    getPaperReviewData() {
      this.$refs.paperReviewInfo[0].getPaperReviewData();
    },
    getRecommenderData() {
      this.$refs.recommendInfo[0].getRecommenderData();
    },
    getServiceData() {
      this.$refs.serviceInfo[0].getServiceData();
    },
    agreePopOpen(data) {
      // 활용 동의 팝업 활성화
      this.popAgreeDatas.data = data;
      this.popAgreeDatas.codes = this.commonCodes.T017;
      this.$refs.agrPop.agreePopOpen();
    },
    currentComponent(compo) {
      return compo;
    },
    currentComponentRef(value) {
      return value
        .split("-")
        .map((el, idx) =>
          idx !== 0 ? el.charAt(0).toUpperCase() + el.slice(1) : el
        )
        .join("");
    },
    searchAddressPopOpen() {
      $emit("searchAddressPopOpen");
    },
    refresh() {
      this.$emit("refresh", true);
    }
  }
};
</script>
