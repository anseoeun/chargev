<template>
  <div>
    <div class="article-title">
      <h2>출고정보</h2>
    </div>
    <div class="box">
      <table class="tbl-detail">
        <colgroup>
          <col style="width:13%" />
          <col style="width:20%" />
          <col style="width:13%" />
          <col style="width:20%" />
          <col style="width:13%" />
          <col style="width:20%" />
        </colgroup>
        <tbody>
          <tr>
            <th>출고센터</th>
            <td>
              <!-- v-if="contractInfoData.legacyStatusCode === '20'" -->
              <span>{{ releaseInfoData.deliveryCenterName }}</span>
              <el-button
                type="primary"
                class="btn-small space"
                v-if="isValidAuthBtn('authExclusive')&&
                  activeUserFlag && (contractInfoData.legacyStatusCode === '10'||contractInfoData.legacyStatusCode === '20')
                "
				:disabled=" !activeUserFlag  "
                @click="popVisibleRelease = true"
                >변경</el-button
              >
            </td>
            <th>출고일 / 출고예정일</th>
            <td>{{ releaseInfoData.deliveryPrearrangedDate|| "없음"  }}</td>
            <th>상태</th>
            <td>{{ releaseInfoData.deliveryStateName|| "없음" }}</td>
          </tr>
        </tbody>
      </table>
    </div>
    <!-- <div class="tableBox">
      <table class="two-th-table">
        <tbody>
          <tr class="table-list">
            <th>출고정보</th>
            <th>출고센터</th>
            <td>
              <div class="table-content">
                <el-tooltip
                  placement="bottom"
                  effect="light"
                >
                  <div slot="content">
                    <el-row>
                      <el-col :span="24">
                        위치 : <span>{{ releaseInfoData.deliveryCenterAddress }}</span>
                      </el-col>
                      <el-col :span="24">
                        전화번호 : <span>{{ releaseInfoData.deliveryCenterTelNo }}</span>
                      </el-col>
                    </el-row>
                  </div>
                  <el-button type="text">
                    {{ releaseInfoData.deliveryCenterName || '' + formatPhone(releaseInfoData.deliveryCenterTelNo) || '' }}
                  </el-button>
                </el-tooltip>
              </div>
            </td>
            <th>출고일 / 출고예정일</th>
            <td>
              <div class="table-content">
                {{ releaseInfoData.deliveryPrearrangedDate }}
              </div>
            </td>
            <th>상태</th>
            <td>
              <div class="table-content">
                {{ releaseInfoData.deliveryStateName }}
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div> -->
    <div class="article-title">
      <h2>인수정보</h2>
      <el-button
        type="primary"
        v-if="
          isValidAuthBtn('authExclusive') &&
            activeUserFlag 
        "
        @click="oneClickDisable($event, onChangeAcquisition)"
        :disabled ="!activeUserFlag || !(
              contractInfoData.onlineStatusCode === '0200' ||
              contractInfoData.onlineStatusCode === '9108' ||
              contractInfoData.onlineStatusCode === '9123' ||
              contractInfoData.onlineStatusCode === '9124' ||
              contractInfoData.onlineStatusCode === '0130' ||
              contractInfoData.onlineStatusCode === '9131')"
        >변경</el-button
      >
    </div>
    <div class="box">
      <table class="tbl-detail">
        <colgroup>
          <col style="width:13%" />
          <col style="width:20%" />
          <col style="width:13%" />
          <col style="width:20%" />
          <col style="width:13%" />
          <col style="width:20%" />
        </colgroup>
        <tbody>
          <tr>
            <th>인수유형</th>
            <td>{{ releaseTakeoverData.acquisitionTypeName || "없음" }}</td>
            <th>탁송지역</th>
            <td>{{ releaseTakeoverData.deliveryPlace || "없음" }}</td>
            <th>인수확정여부</th>
            <td>{{ releaseTakeoverData.acquisitionDecisionYn || "없음" }}</td>
          </tr>
          <!-- <tr>
            <th>등록대행 동의여부</th>
            <td>
              {{
                releaseRegistAgencyData &&
                  releaseRegistAgencyData.personalInformationPossessionAgreement
              }}
            </td>
            <th>등록 진행상황</th>
            <td>
              {{
                releaseRegistAgencyData &&
                  releaseRegistAgencyData.registAgencyRegistState
              }}
            </td>
            <th>번호판 끝자리 수</th>
            <td>
              {{
                releaseRegistAgencyData &&
                  releaseRegistAgencyData.registAgencyPlatesEndNumber
              }}
            </td>
          </tr> -->
          <tr>
            <th>표준서비스 물품</th>
            <td>
              <div>
                <el-radio
                  v-model="releaseTakeoverData.standardServiceCode"
                  label="S"
                  >썬팅무료시공</el-radio
                >
                <el-radio
                  v-model="releaseTakeoverData.standardServiceCode"
                  label="K"
                  >브랜드KIT</el-radio
                >
              </div>
            </td>
            <th>등록대행 서비스</th>
            <td colspan="3">
              <!-- :disabled="
                  releaseTakeoverData.standardServiceCode === 'K' &&
                    releaseRegistAgencyData.registAgencyApplyYn === '미신청'
                " -->
              <el-radio v-model="registAgencyApplyYn" label="Y"
              :disabled="releaseTakeoverData.acquisitionTypeCode==='04'"
                >등록대행</el-radio
              >
              <!-- :disabled="
                  releaseTakeoverData.standardServiceCode === 'K' &&
                    releaseRegistAgencyData.registAgencyApplyYn === '미신청'
                " -->
              <el-radio v-model="registAgencyApplyYn" label="N"
                >직접등록</el-radio
              >
            </td>
            <!-- <th>차량검수 패키지</th>
            <td>
              <el-radio v-model="rdo3" :label="1">신청</el-radio>
              <el-radio v-model="rdo3" :label="2">미신청</el-radio>
            </td> -->
          </tr>
          <tr>
            <th>인수자명</th>
            <td>
              <!-- <el-select v-model="customerNumber">
                <el-option
                  v-for="item in releaseConsigneeData"
                  :key="item.customerNumber"
                  :value="item.customerNumber"
                  :label="item.customerName"
                />
              </el-select> -->
              {{releaseTakeoverData.acquisitionPersonName}}
              <!-- <div>{{ releaseTakeoverData.acquisitionPersonName }}</div> -->
            </td>
            <th>인수자 연락처</th>
            <td>
              {{ releaseTakeoverData.acquisitionPersonMobile || "없음" }}
            </td>
            <th>인수자 연락처2</th>
            <td>
              {{ releaseTakeoverData.hopeAcquisitionPersonMobile || "없음" }}
            </td>
          </tr>
          <tr>
            <th>탁송지 주소</th>
            <td colspan="5">
              <el-button
                type="info"
                class="btn-small"
                v-if="isValidAuthBtn('authExclusive')"
                :disabled=" !activeUserFlag || releaseTakeoverData.acquisitionTypeCode==='04'"
                @click="popVisibleSearch = true"
                >공식지정 인수점</el-button
              >
              <!-- <el-button type="info" class="btn-small">블루핸즈 선택</el-button> -->
              <el-button
                v-if="isValidAuthBtn('authExclusive')&&registAgencyApplyYn === 'N'"
                type="info"
                class="btn-small"
				      :disabled=" !activeUserFlag || releaseTakeoverData.acquisitionTypeCode==='04'"
                @click="popVisibleConsignment = true"
                >주소변경</el-button
              >
              <!-- <div>{{ releaseTakeoverData.acquisitionPersonAddress }}</div> -->
              <!-- [#9948/2021.11/24/A936505] 상호지점 표기 START -->
              <div><template v-if="releaseTakeoverData.firmId">[공식지정 인수점] </template>{{ releaseTakeoverData.acquisitionFirmName ? releaseTakeoverData.acquisitionFirmName : releaseTakeoverData.firmNm
                }} </div>
              <!-- [#9948/2021.11/24/A936505] 상호지점 표기 END -->
              <div>{{
                  releaseTakeoverData.acquisitionZipCode
                    ? "(" + releaseTakeoverData.acquisitionZipCode + ")"
                    : ""
                }}</div>
              <div>{{ releaseTakeoverData.acquisitionAddressContents }}</div>
              <template v-if="!detailAddressInput">
                <div>
                  {{ releaseTakeoverData.acquisitionDetailAddressContents }}
                </div>
              </template>
              <template v-if="detailAddressInput">
                <el-input
                  v-model="releaseTakeoverData.acquisitionDetailAddressContents"
                  class="inp-addr"
                  maxlength="100"
                />
              </template>
              <div>{{ takeoverForm.firmTn }} / {{ takeoverForm.firmHpNo }}</div>
            </td>
          </tr>
          <tr>
            <th>기타 요청사항</th>
            <td colspan="5">
                  <el-input                  
                  v-model="releaseTakeoverData.etcContent" 
                  maxlength="100" 
                />              
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- 전자서명 component -->
    <signature-info
      ref="signatureInfo"
      :contract-number.sync="contractInfoData.contractNumber"
      :contract-data.sync="contractData"
      :contract-info-data.sync="contractInfoData"
      :active-user-flag.sync="activeUserFlag"/>

    <!-- 인수유형이 본인, 전시일경우를 제외한 나머지 케이스 -->
    <div
      v-if="
        releaseTakeoverData.acquisitionTypeCode !== '01' &&
          releaseTakeoverData.acquisitionTypeCode !== '04'
      "
      class="article-title"
    >
      <h2>탁송정보</h2>
    </div>
    <div
      v-if="
        releaseTakeoverData.acquisitionTypeCode !== '01' &&
          releaseTakeoverData.acquisitionTypeCode !== '04'
      "
      class="box"
    >
      <table class="tbl-detail">
        <colgroup>
          <col style="width:15%" />
          <col style="width:35%" />
          <col style="width:15%" />
          <col style="width:35%" />
        </colgroup>
        <tbody>
          <tr>
            <th>탁송사</th>
            <td>
              <div>
                {{ releaseConsignData.consignableCompanyName }}
              </div>
            </td>
            <th>탁송기사</th>
            <td>
              <div>
                {{ releaseConsignData.consignablePersonName }}
                <span class="difference">{{
                  releaseConsignData.consignablePersonPhoneNumber
                    ? "(" + releaseConsignData.consignablePersonPhoneNumber +")"
                    : ""
                }}</span>                
              </div>
              <el-button type="primary" :disabled=" !activeUserFlag  " @click="locationViewPop = true">
                위치보기
              </el-button>
            </td>
          </tr>
          <tr>
            <th>탁송경로 (1차)</th>
            <td colspan="5">
              <div>
                {{ releaseConsignData.consignableRegionName }}
              </div>
            </td>
          </tr>
          <tr>
            <th>출발일시</th>
            <td>
              <div>
                {{ releaseConsignData.startingDate }}
              </div>
            </td>
            <th>도착예정일시</th>
            <td>
              <div>
                {{ releaseConsignData.arrivalPrearrangementDate }}
              </div>
            </td>
          </tr>
          <tr>
            <th>도착일시</th>
            <td>
              <div>
                {{ releaseConsignData.arrivalDate }}
              </div>
            </td>
            <th>인수일시</th>
            <td>
              <div>
                {{ releaseConsignData.acquisitionDate }}
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <el-dialog
        custom-class="message"
        :visible.sync="locationViewPop"
        class="locationViewPop"
        width="960px"
      >
        <!-- src=" -->
        <vue-friendly-iframe
          style="width: 604px; height: 404px; margin: auto;"
          :src="
            `https://smartwap.glovis.net/mgr/popup/kakaoMap.jsp?pCustCd=S009&pRequestNo=` +
              contractInfoData.contractNumber
          "
        />
      </el-dialog>
    </div>

    <div
      class="article-title"
      v-if="
        releaseRegistAgencyData &&
          releaseRegistAgencyData.registAgencyApplyYn === '신청'
      "
    >
      <h2>등록대행</h2>
    </div>
    <div
      v-if="
        releaseRegistAgencyData &&
          releaseRegistAgencyData.registAgencyApplyYn === '신청'
      "
      class="box"
    >
      <table class="tbl-detail">
        <colgroup>
          <col style="width:20%" />
          <col style="width:30%" />
          <col style="width:20%" />
          <col style="width:30%" />
        </colgroup>
        <tbody>
          <tr>
            <th>등록 진행상황</th>
            <td>
              <div>
                {{
                  releaseRegistAgencyData &&
                    releaseRegistAgencyData.registAgencyRegistState
                }}
              </div>
            </td>
            <!-- <th>번호판 끝자리수</th>
            <td>
              <div>
                {{
                  releaseRegistAgencyData &&
                    releaseRegistAgencyData.registAgencyPlatesEndNumber
                }}
              </div>
            </td> -->
            <th>용품점</th>
            <td colspan="7">
              <div>
                {{
                  releaseRegistAgencyData &&
                    releaseRegistAgencyData.registAgencyName
                }}
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div
      class="article-title"
      v-if="registAgencyApplyYn === 'N' && releaseEresistData"
    >
      <h2>E-등록</h2>
    </div>
    <div class="box" v-if="registAgencyApplyYn === 'N' && releaseEresistData">
      <el-table :data="releaseEresistData">
        <el-table-column
          prop="no"
          label="번호"
          width="100"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="vbgInpDt"
          label="신청일"
          width="250"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="eregProgStatNm"
          label="진행 상태"
          width="200"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="eregResultNm"
          label="등록 결과"
          width="200"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="failRsonSbcNm"
          label="비고"
          width="450"
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="trtmPhbStItmzSbc"
          label="비용납부 취소"
          width="335"
          align="center"
        >
          <template slot-scope="props">
            <span
              v-if="
                  props.row.cvcplPttStCd === '23'
              "
            >
              <a class="link" @click="alertVisibleCancelEregist = true">
                취소
              </a>
            </span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="article-title">
      <h2>탁송료 변동이력</h2>
    </div>
    <div class="box">
      <el-table :data="releaseDeliveryPriceHistory">
        <el-table-column
          prop="onlineStatusName"
          label="온라인 진행상태"
          width="300"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="deliveryPlace"
          label="탁송지"
          width="235"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="deliveryCenterName"
          label="출고센터"
          width="250"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="deliveryPrice"
          label="탁송료"
          width="250"
          align="center"
        >
          <template slot-scope="props">
            {{
              props.row.deliveryPrice &&
                props.row.deliveryPrice.toLocaleString() + "원"
            }}
          </template>
        </el-table-column>
        <el-table-column
          prop="updDate"
          label="처리일시"
          width="250"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="disposerName"
          label="처리자"
          width="250"
          align="center"
        ></el-table-column>
      </el-table>
    </div>

    <!-- <div class="tableBox">
      <table class="two-th-table">
        <tbody>
          <tr class="table-list">
            <th rowspan="2">
              출고센터<br />
              진행정보
            </th>
            <th>PDI 수배지시</th>
            <td>
              <div class="table-content">
                {{ releaseCenterData.preDeliveryInspectionDate }}
              </div>
            </td>
            <th>탁송사인수</th>
            <td colspan="3">
              <div class="table-content">
                {{ releaseCenterData.consignableCompanyAcquisitionDate }}
              </div>
            </td>
          </tr>
          <tr class="table-list">
            <th>TUIX 장착중</th>
            <td>
              <div class="table-content">
                {{ releaseCenterData.tuixMountStartDate }}
              </div>
            </td>
            <th>TUIX 장착완료</th>
            <td>
              <div class="table-content">
                {{ releaseCenterData.tuixMountCompleteDate }}
              </div>
            </td>
            <th>출문</th>
            <td>
              <div class="table-content">
                {{ releaseCenterData.outOfGateDate }}
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="tableBox">
      <table class="two-th-table">
        <tbody>
          <tr class="table-list">
            <th rowspan="4">
              인수정보
            </th>
            <th>인수유형</th>
            <td>
              <div class="table-content">
                {{ releaseTakeoverData.acquisitionTypeName }}
              </div>
            </td>
            <th>배달탁송지</th>
            <td>
              <div class="table-content">
                {{ releaseTakeoverData.deliveryPlace }}
              </div>
            </td>
            <th>인수확정여부</th>
            <td>
              <div class="table-content">
                {{ releaseTakeoverData.acquisitionDecisionYn }}
              </div>
            </td>
          </tr>
          <tr class="table-list">
            <th>인수자명</th>
            <td>
              <div class="table-content">
                {{ releaseTakeoverData.acquisitionPersonName }}
              </div>
            </td>
            <th class="non" />
            <td />
            <th>인수자 연락처</th>
            <td>
              <div class="table-content">
                {{ releaseTakeoverData.acquisitionPersonMobile }}
              </div>
            </td>
          </tr> -->
    <!-- 인수유형이 본인일 경우(01) -->
    <!-- <template v-if="releaseTakeoverData.acquisitionTypeCode === '01'">
            <tr class="table-list">
              <th>출고예약시간</th>
              <td colspan="5">
                <div class="table-content">
                  {{ releaseTakeoverData.deliveryReservationDate }}
                </div>
              </td>
            </tr>
          </template> -->
    <!-- 인수유형이 전시차량일 경우(04) -->
    <!-- <template
            v-else-if="releaseTakeoverData.acquisitionTypeCode === '04'"
          >
            <tr class="table-list">
              <th>전시차보유거점</th>
              <td colspan="5">
                <div class="table-content">
                  {{ releaseTakeoverData.agencyName }}
                </div>
              </td>
            </tr>
          </template> -->
    <!-- 인수유형 (01, 04)를 제외한 나머지 항목 유형 -->
    <!-- <template v-else>
            <tr class="table-list">
              <th>인수지 주소</th>
              <td colspan="5">
                <div class="table-content">
                  {{ releaseTakeoverData.acquisitionPersonAddress }}
                </div>
              </td>
            </tr>
            <tr class="table-list">
              <th>기타 요청사항</th>
              <td colspan="5">
                <div class="table-content">
                  {{ releaseTakeoverData.etcContent }}
                </div>
              </td>
            </tr>
          </template>
        </tbody>
      </table>
    </div> -->
    <!-- 인수유형이 본인, 전시일경우를 제외한 나머지 케이스 -->
    <!-- <div
      v-if="
        releaseTakeoverData.acquisitionTypeCode !== '01' &&
          releaseTakeoverData.acquisitionTypeCode !== '04'
      "
      class="tableBox"
    >
      <table class="two-th-table">
        <tbody>
          <tr class="table-list">
            <th rowspan="4">
              탁송정보
            </th>
            <th>탁송사</th>
            <td>
              <div class="table-content">
                {{ releaseConsignData.consignableCompanyName }}
              </div>
            </td>
            <th>탁송기사</th>
            <td>
              <div class="table-content">
                {{ releaseConsignData.consignablePersonName }}
              </div>
              <el-button type="primary" @click="locationViewPop = true">
                위치보기
              </el-button>
            </td>
            <th class="non" />
            <td>
              <div class="table-content" />
            </td>
          </tr>
          <tr class="table-list">
            <th>탁송경로 (1차)</th>
            <td colspan="5">
              <div class="table-content">
                {{ releaseConsignData.consignableRegionName }}
              </div>
            </td>
          </tr>
          <tr class="table-list">
            <th>출발일시</th>
            <td>
              <div class="table-content">
                {{ releaseConsignData.startingDate }}
              </div>
            </td>
            <th>도착예정일시</th>
            <td colspan="3">
              <div class="table-content">
                {{ releaseConsignData.arrivalPrearrangementDate }}
              </div>
            </td>
          </tr>
          <tr class="table-list">
            <th>도착일시</th>
            <td>
              <div class="table-content">
                {{ releaseConsignData.arrivalDate }}
              </div>
            </td>
            <th>인수일시</th>
            <td colspan="3">
              <div class="table-content">
                {{ releaseConsignData.acquisitionDate }}
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <el-dialog
        custom-class="message"
        :visible.sync="locationViewPop"
        class="locationViewPop"
        width="960px"
      > -->
    <!-- src=" -->
    <!-- <vue-friendly-iframe
          style="width: 604px; height: 404px; margin: auto;"
          :src="
            `https://smartwap.glovis.net/mgr/popup/kakaoMap.jsp?pCustCd=S009&pRequestNo=` +
              contractInfoData.contractNumber
          "
        />
      </el-dialog>
    </div>
    <div class="tableBox">
      <table class="two-th-table">
        <tbody>
          <tr class="table-list">
            <th rowspan="2">
              등록정보
            </th>
            <th>
              등록/썬팅서비스<br />
              신청 여부
            </th>
            <td>
              <div class="table-content">
                {{
                  releaseRegistAgencyData &&
                    releaseRegistAgencyData.registAgencyApplyYn
                }}
              </div>
            </td>
            <th>등록 진행상황</th>
            <td>
              <div class="table-content">
                {{
                  releaseRegistAgencyData &&
                    releaseRegistAgencyData.registAgencyRegistState
                }}
              </div>
            </td>
            <th>등록대행 동의 여부</th>
            <td>
              <div class="table-content">
                {{
                  releaseRegistAgencyData &&
                    releaseRegistAgencyData.personalInformationPossessionAgreement
                }}
              </div>
            </td>
          </tr>
          <tr class="table-list">
            <th>번호판 끝자리수</th>
            <td>
              <div class="table-content">
                {{
                  releaseRegistAgencyData &&
                    releaseRegistAgencyData.registAgencyPlatesEndNumber
                }}
              </div>
            </td>
            <th>용품점</th>
            <td>
              <div class="table-content">
                <el-tooltip placement="bottom" effect="light">
                  <div slot="content">
                    <el-row>
                      <el-col :span="24">
                        주소 :
                        <span>{{
                          releaseRegistAgencyData &&
                            releaseRegistAgencyData.registAgencyAddress
                        }}</span>
                      </el-col>
                      <el-col :span="24">
                        전화번호 :
                        <span>{{
                          releaseRegistAgencyData &&
                            releaseRegistAgencyData.registAgencyTelephoneNumber
                        }}</span>
                      </el-col>
                    </el-row>
                  </div>
                  <el-button type="text">
                    {{
                      releaseRegistAgencyData &&
                        releaseRegistAgencyData.registAgencyName
                    }}
                  </el-button>
                </el-tooltip>
              </div>
            </td>
            <th class="non" />
            <td>
              <div class="table-content" />
            </td>
          </tr>
        </tbody>
      </table>
    </div> -->

    <el-dialog title="출고센터 변경" :visible.sync="popVisibleRelease">
      <!-- Popup Contents -->
      <div class="board-wrap">
        <table class="tbl-detail">
          <colgroup>
            <col style="width:20%;" />
            <col style="width:40%;" />
            <col style="width:40%;" />
          </colgroup>
          <thead>
            <tr>
              <th>구분</th>
              <th>변경 전</th>
              <th>변경 후</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th>출고센터</th>
              <td align="center">{{ releaseInfoData.deliveryCenterName }}</td>
              <td align="center">
                <el-select
                  v-model="releaseDeliveryCenter"
                  @change="changeDeliveryCenter"
                >
                  <el-option label="선택하세요" value=""></el-option>
                  <el-option
                    v-for="item in releaseDeliveryCenterList"
                    :key="item.deliveryCenterCode"
                    :value="item.deliveryCenterCode"
                    :label="item.deliveryCenterName"
                  ></el-option>
                </el-select>
              </td>
            </tr>
            <tr>
              <th>탁송지역</th>
              <td align="center" colspan="2">
                {{ releaseTakeoverData.deliveryPlace }}
                <!-- {{
                  releaseTakeoverData.acquisitionZipCode
                    ? "(" + releaseTakeoverData.acquisitionZipCode + ")"
                    : ""
                }}
                {{ releaseTakeoverData.acquisitionAddressContents }}
                {{ releaseTakeoverData.acquisitionDetailAddressContents }} -->
              </td>
            </tr>
            <tr>
              <th>탁송료</th>
              <td align="center">
                {{
                  releaseTakeoverData.deliveryPrice
                    ? releaseTakeoverData.deliveryPrice.toLocaleString() + "원"
                    : ""
                }}
              </td>
              <td align="center">
                {{
                  deleveryCenterForm.afterDeliveryPrict
                    ? Number(
                        deleveryCenterForm.afterDeliveryPrict
                      ).toLocaleString() + "원"
                    : ""
                }}
              </td>
            </tr>
            <!-- <tr>
              <th>차액</th>
              <td align="center"></td>
              <td align="center">
                <span class="difference">{{
                  deleveryCenterForm.diffDeliveryPrice
                    ? deleveryCenterForm.diffDeliveryPrice.toLocaleString() +
                      "원"
                    : ""
                }}</span>
              </td>
            </tr> -->
          </tbody>
        </table>
      </div>
      <!-- Popup Footer -->
      <template slot="footer">
        <div>
          <el-button type="info" @click="popVisibleRelease = false"
            >취소</el-button
          >
          <el-button type="primary" @click="oneClickDisable($event, onSaveDeliveryCenter)"
            >확인</el-button
          >
        </div>
      </template>
    </el-dialog>

    <el-dialog title="탁송지 변경" :visible.sync="popVisibleConsignment">
      <!-- Popup Contents -->
      <div class="board-wrap">
        <table class="tbl-detail">
          <colgroup>
            <col style="width:20%;" />
            <col style="width:40%;" />
            <col style="width:40%;" />
          </colgroup>
          <thead>
            <tr>
              <th>구분</th>
              <th>변경 전</th>
              <th>변경 후</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th>출고센터</th>
              <td colspan="2">{{ releaseInfoData.deliveryCenterName }}</td>
            </tr>
            <tr>
              <th>탁송지</th>
              <td colspan="2">
                <div>
                  {{
                    releaseTakeoverData.acquisitionZipCode
                      ? "(" + releaseTakeoverData.acquisitionZipCode + ")"
                      : ""
                  }}
                  {{ releaseTakeoverData.acquisitionAddressContents }}
                  {{ releaseTakeoverData.acquisitionDetailAddressContents }}
                </div>
                <div class="zip-code">
                  <el-input
                    v-model="jusoForm.zipCode"
                    :readonly="true"
                  ></el-input>
                  <el-button
                    type="info"
                    class="btn-small"
                    @click="searchAddressPopOpen('release')"
                    >주소검색</el-button
                  >
                </div>
                <el-input
                  v-model="jusoForm.address"
                  :readonly="true"
                ></el-input>
                <el-input v-model="jusoForm.detailAddress"></el-input>
              </td>
            </tr>
            <!-- <tr>
              <th>탁송료</th>
              <td align="center">
                {{
                  releaseTakeoverData.deliveryPrice
                    ? releaseTakeoverData.deliveryPrice.toLocaleString() + "원"
                    : ""
                }}
              </td>
              <td align="center">
                {{
                  deleveryCenterForm.afterDeliveryPrict
                    ? Number(
                        deleveryCenterForm.afterDeliveryPrict
                      ).toLocaleString() + "원"
                    : ""
                }}
              </td>
            </tr>
            <tr>
              <th>차액</th>
              <td align="center"></td>
              <td align="center">
                <span class="difference">{{
                  deleveryCenterForm.diffDeliveryPrice
                    ? deleveryCenterForm.diffDeliveryPrice.toLocaleString() +
                      "원"
                    : ""
                }}</span>
              </td>
            </tr> -->
          </tbody>
        </table>
      </div>
      <!-- Popup Footer -->
      <template slot="footer">
        <div>
          <el-button type="info" @click="popVisibleConsignment = false"
            >취소</el-button
          >
          <el-button type="primary" @click="setAddress">확인</el-button>
        </div>
      </template>
    </el-dialog>

    <!-- 공식 지정 인수점 조회 팝업 -->
    <el-dialog
      title="공식 지정 인수점 조회"
      :visible.sync="popVisibleSearch"
      width="1270px"
    >
      <!-- Popup Contents -->
      <div class="map-search">
        <el-form>
          <div class="search-top">
            <el-select
              v-model="searchSido"
              placeholder="시/도 선택"
              @change="onChangeSido($event)"
            >
              <el-option
                v-for="{ value, label } in commonCodes.Z028 &&
                  commonCodes.Z028.slice(1, commonCodes.Z028.length)"
                :key="value"
                :value="value"
                :label="label"
              />
            </el-select>
            <el-select v-model="searchGungu" placeholder="시/군/구 선택">
              <el-option
                v-for="{ key, value } in gunguList"
                :key="key"
                :value="key"
                :label="value"
              />
            </el-select>
            <el-button
              type="primary"
              class="btn-small"
              @click="getFormalTakeOver()"
              >검색</el-button
            >
          </div>
        </el-form>

        <div class="search-result">
          <div class="search-list">
            <ul v-if="releaseTakeoverList.length > 0">
              <li
                v-for="(items, index) in releaseTakeoverList"
                :key="items.firmId"
								@mouseenter="onCenterClick(index)"
								@mouseleave="onMapPopClose"
              >
                <div class="search-info">
                  <div class="title">
                    <span class="num">{{ index + 1 }}</span>
                    <strong class="name">{{ items.firmNm }}</strong>
                  </div>
                  <p>{{ items.rdnaSbc }} {{ items.rdnaDtlSbc }}</p>
                  <p>{{ items.firmTn }} / {{ items.hpTn }}</p>
                </div>
                <el-button type="text" @click="getTakeoverList($event, items)"
                  >선택</el-button
                >
              </li>
            </ul>

            <div v-if="releaseTakeoverList.length <= 0" class="no-result">
              검색 결과가 없습니다.
            </div>
          </div>
          <div ref="mapBox" class="map-area"></div>
					<div v-show="tooltipActive" ref="mountCenterClickPop" class="map-tooltip" style=" top: -180px;left: -180px;">
						<div class="search-info">
							<div class="title">
								<span class="num">{{ clickIdx + 1 }}</span>
								<strong class="name">
									[{{ centerData ? (centerData.firmTypeNm ? centerData.firmTypeNm : '') : '' }}]
									{{ centerData ? (centerData.firmNm ? centerData.firmNm : '') : '' }}
								</strong>
							</div>
							<p>
								{{ centerData ? (centerData.rdnaSbc ? centerData.rdnaSbc : '') : '' }}
								<br />
								{{ centerData ? (centerData.rdnaDtlSbc ? centerData.rdnaDtlSbc : '') : '' }}
							</p>
							<p>
								{{ centerData ? (centerData.firmTn ? centerData.firmTn : '') : '' }} / {{ centerData ? (centerData.hpTn ? centerData.hpTn : '') : '' }}
							</p>
						</div>
					</div>
        </div>
      </div>
    </el-dialog>

    <!-- 결제 취소 팝업 -->
    <el-dialog custom-class="message" :visible.sync="alertVisibleCancelEregist">
      <!-- Message -->
      온라인 차량등록을 취소 하시겠습니까?

      <!-- Popup Footer -->
      <template slot="footer">
        <el-button type="info" @click="alertVisibleCancelEregist = false">
          아니요
        </el-button>
        <el-button type="primary" @click="oneClickDisable($event, cancelEregist)">
          예
        </el-button>
      </template>
    </el-dialog>

    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
    <!-- ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## -->    
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />
    <!-- ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## -->    
  </div>
</template>
<script>
import SignatureInfo from "~/components/tab/contract/SignatureInfo.vue"
import VueFriendlyIframe from "vue-friendly-iframe";
import PopMessage from "~/components/popup/PopMessage.vue";
import moment from "moment";
import loadScriptOnce from 'load-script-once'
import lMapKeys from 'lodash/mapKeys'
import * as addrData from '~/plugins/utils/data'
/* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
import Loading from "~/components/popup/Loading.vue";
/* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
let kakao = global.kakao

export default {
  name: "ReleaseInfo",
  components: {
    SignatureInfo,
    VueFriendlyIframe,
    PopMessage,
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
    Loading
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */    
  },
  props: {
    contractNumber: {
      type: String,
      default: ""
    },
    contractInfoData: {
      type: Object,
      default: () => {}
    },
    contractData: {
      type: Object,
      default: () => {}
    },
    activeUserFlag: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      alertMessage: "",
      alertMessagePop: false,
      locationViewPop: false,
      popVisibleSearch: false,
      popVisibleConsignment: false,
      commonCodes: {},
      releaseInfoData: {},
      releaseCenterData: {},
      releaseTakeoverData: {},
      releaseConsignData: {},
      releaseRegistAgencyData: {},
      releaseConsigneeData: [],
      releaseDeliveryCenterList: [],
      releaseDeliveryPriceHistory: [],
      releaseEresistData: [],
      popVisibleRelease: false,
      detailAddressInput: false,
      alertVisibleCancelEregist: false,
      registAgencyApplyYn: "",
      customerNumber: "",
      releaseDeliveryCenter: "",
      searchSido: "",
      searchGungu: "",
      gunguList: [],
      releaseTakeoverList: [],
      priReleaseTakeoverList: [],
      takeoverForm: {},
      deleveryCenterForm: {},
      jusoForm: {
        zipCode: '',
        address: '',
        detailAddress: ''
      },
      currentReleaseTakeoverData:{},
      officialTakeOver: false,

      address: {
				sido: null,
				sidoName: null,
				sigungu: null
			},
      geocoder: null,
      agencyZoomDefaultLv: 3,
			map: {},
			marker: [],
			markerOverlay: [], // 마커 커스텀오버레이
			// 커스텀 오버레이: 마우스 클릭시 사용
			customOverlay2: null,

			// 현재 위치에 따른 좌표 - 초기값: 양재지점
			addrPos: {
				latitude: 37.486267,
				longitude: 127.033671
			},

			// 위치 검색에 따른 좌표
			searchPos: {
				latitude: null,
				longitude: null,
				radius: 5
			},
      locationResult: false, //검색결과
			mountCenters: [], //장착점 리스트
      tooltipActive: false,
			centerData: null,
			clickIdx: 0,
      kakaomapAppKey: process.env.KAKAO_MAP_NATIVE_KEY || 'f3b6fbfa5dd5685e7ad0f8c68ee2d600',
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      popVisibleLoading: false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
    }
  },
  async created() {
    await this.loadCommonCode();

    this.$EventBus.$on("selectedAddressRelease", juso => {
      if (juso) {
        this.jusoForm.zipCode = juso.zipNo;
        this.jusoForm.address = juso.roadAddr;
        this.jusoForm.detailAddress = "";
        //this.callChangeDeliveryCenter(juso.zipNo);

        /* this.releaseTakeoverData.acquisitionZipCode = juso.zipNo;
        this.releaseTakeoverData.acquisitionAddressContents = juso.roadAddr;
        this.releaseTakeoverData.acquisitionDetailAddressContents = "";
        this.detailAddressInput = true;
        this.takeoverForm = {
          firmName: "",
          firmTn: "",
          firmHpNo: ""
        }; */
      }
    });
  },
	async mounted() {
		await loadScriptOnce(`https://dapi.kakao.com/v2/maps/sdk.js?autoload=false&appkey=${this.kakaomapAppKey}&libraries=services`)
			.then(async () => {
				if (window.kakao.maps && window.kakao.maps.services) {
					kakao = window.kakao
					this.geocoder = new kakao.maps.services.Geocoder()
				} else {
					await window.kakao.maps.load(() => {
						kakao = window.kakao
						this.geocoder = new kakao.maps.services.Geocoder()
						// this.marker = new kakao.maps.Marker()
					})
				}
			})
			.catch((err) => {
				console.error(err)

        window.kakao=window.kakao||{},window.kakao.maps=window.kakao.maps||{},window.daum&&window.daum.maps?window.kakao.maps=window.daum.maps:(window.daum=window.daum||{},window.daum.maps=window.kakao.maps),
        function(){
          var o=window.kakao.maps=window.kakao.maps||{};
          
          if(void 0===o.readyState)o.onloadcallbacks=[],o.readyState=0;
          else if(2===o.readyState)return;
            
          o.VERSION={
            ROADMAP:"2111ydg",
            ROADMAP_SUFFIX:"",
            HYBRID:"2111ydg",
            SR:"3.00",
            ROADVIEW:"7.00",
            ROADVIEW_FLASH:"200402",
            BICYCLE:"6.00",
            USE_DISTRICT:"2111ydg",
            SKYVIEW_VERSION:"160114",
            SKYVIEW_HD_VERSION:"160107"
          },
          o.RESOURCE_PATH={
            ROADVIEW_AJAX:"//t1.daumcdn.net/roadviewjscore/core/css3d/200204/standard/1580795088957/roadview.js",
            ROADVIEW_CSS:"//t1.daumcdn.net/roadviewjscore/core/openapi/standard/211122/roadview.js"
          };
          
          for(var n,r="https:"==location.protocol?"https:":"http:",s="",i=document.getElementsByTagName("script"),d=i.length;n=i[--d];)if(/\/(beta-)?dapi\.kakao\.com\/v2\/maps\/sdk\.js\b/.test(n.src)){s=n.src;break}i=null;
          
          var c=o.onloadcallbacks,
            E=["v3"],
            S="",
            I={
              v3:r+"//t1.daumcdn.net/mapjsapi/js/main/4.4.3/kakao.js",
              services:r+"//t1.daumcdn.net/mapjsapi/js/libs/services/1.0.2/services.js",
              drawing:r+"//t1.daumcdn.net/mapjsapi/js/libs/drawing/1.2.6/drawing.js",
              clusterer:r+"//t1.daumcdn.net/mapjsapi/js/libs/clusterer/1.0.9/clusterer.js"
            },
            _=function(a){var t={};return a.replace(/[?&]+([^=&]+)=([^&]*)/gi,function(a,e,o){t[e]=o}),t}(s);
            S=_.appkey,S&&(o.apikey=S),
            o.version="4.4.3";
          
          var R=_.libraries;
          
          if(R&&(E=E.concat(R.split(","))),"false"!==_.autoload){
            for(var dd=0,l=E.length;dd<l;dd++) {
              !function(a){
                if(a) document.write('<script charset="UTF-8" src="'+a+'" />')
              }(I[E[dd]]);
            }
            o.readyState=2
          }
          
          o.load=
            function(t){
              switch(c.push(t),o.readyState){
                case 0:
                  o.readyState=1,a();
                  break;
                case 2:
                  e()
              }
            }
          
          function a(){if(E.length){t(I[E.shift()],a).start()}else e()}
          
          function t(a,t){var e=document.createElement("script");return e.charset="utf-8",e.onload=t,e.onreadystatechange=function(){/loaded|complete/.test(this.readyState)&&t()},{start:function(){e.src=a||"",document.getElementsByTagName("head")[0].appendChild(e),e=null}}}
          
          function e(){for(;c[0];)c.shift()();o.readyState=2}
        }();

        if (window.kakao.maps && window.kakao.maps.services) {
					kakao = window.kakao
					this.geocoder = new kakao.maps.services.Geocoder()
				} else {
					window.kakao.maps.load(() => {
						kakao = window.kakao
						this.geocoder = new kakao.maps.services.Geocoder()
						// this.marker = new kakao.maps.Marker()
					})
				}
			})
	},
  watch: {
    contractData: function() {
      this.registAgencyApplyYn = this.contractData
        ? this.contractData.registAgencyApplyYn
        : "";
    },

    releaseTakeoverList: {
			deep: true,
			handler(newVal) {
				if (newVal) {
					this.mountCenters = newVal

					if (Object.keys(this.mountCenters).length > 0) {
							if (newVal.length > 0) this.locationResult = true
							else this.locationResult = false

							lMapKeys(this.mountCenters, (obj, key) => {
								if (obj.firmType === 'A') {
									obj.firmTypeNm = '썬팅장착점'
								} else {
									obj.firmTypeNm = '블루핸즈'
								}

								obj.kakaomapOptions = {
									center: { lat: obj.laeCnVal, lng: obj.loeCnVal }, // 지도의 중심 좌표
									level: 3, // 지도의 레벨(확대, 축소 정도),
									libraries: [], // 추가로 불러올 라이브러리
									isMapView: false
								}
							})
					} else {
						this.locationResult = false
					}

					this.onViewMap()
				}
			}
		},

    popVisibleSearch(val) {
      if(val && this.searchSido && this.searchGungu) {
        if(this.priReleaseTakeoverList) this.releaseTakeoverList = this.priReleaseTakeoverList
        else this.getFormalTakeOver()
      }
    }
  },
  methods: {
    fetchCommonCodeData(systemType = "", codeType = "") {
      let res = null;
      switch (systemType) {
        case "E":
          res = this.$store.dispatch("loadCommonCodesE", {
            vm: this,
            codeTypeCode: codeType
          });
          break;
        case "C":
          res = this.$store.dispatch("loadLegacyCommonCodesC", {
            vm: this,
            codeTypeCode: codeType
          });
          break;
      }
      return res;
    },
    async loadCommonCode() {
      const [ccZ028, ccT064, ccT065, ccT066] = await Promise.all([
        this.fetchCommonCodeData("E", "Z028"), // 결제항목
        this.fetchCommonCodeData("E", "T064"), // E등록진행상태
        this.fetchCommonCodeData("E", "T065"), // E등록등록상태
        this.fetchCommonCodeData("E", "T066") // E등록결재정보
      ]);

      this.commonCodes = { ...ccZ028, ...ccT064, ...ccT065, ...ccT066 };
    },
    formatPhone(tel) {
      return tel ? "(" + tel + ")" : "";
    },
    isValidAuthBtn(authId) {
      // 버튼별 권한 체크
      // console.log("authId:::" + authId);
      let bResult = false; // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || [];

      // console.log("currAuthBtnList:::", currAuthBtnList);
      if (currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some(items => {
          if (items.btnId === authId) {
            bResult = true;
            return true;
          }
        });
      }
      return bResult;
    },
    async getAllData() {
      if (!this.contractInfoData.contractNumber) return;

      //출고정보
      this.getReleaseInfoData()

      //출고센터진행정보
      this.getReleaseCenterData()

      // API-E-업무담당자-032 (인수정보 조회)
      this.getReleaseTakeoverData()

      //탁송정보
      this.getReleaseConsignData()

      //등록대행정보 조회 (API-E-전담컨설턴트-034)
      // ########## [2021.10.08/A936506] 더 이상 사용하지 않아 주석처리, 운영에서 에러 로그 계속 찍혀 수정 요청.
      this.getReleaseRegistAgencyData()

      //인수자명 리스트 조회
      this.getReleaseConsignee()

      //출고센터 리스트 조회
      this.getReleaseDeliveryCenterList()

      //탁송료변경이력 조회
      this.getReleaseDeliveryPriceHistory()

      //E등록 이력 조회
      this.getReleaseEresistHistory()

      //전자 서명 조회
      this.getSignatureInfo();
    },
    async getReleaseInfoData() {
      //출고정보
      const [res1, err1] = await this.$https.get(
        "/v2/exclusive/work/delivery/" + this.contractInfoData.contractNumber
      );
      if (!err1) {
        console.log("/work/delivery/", res1.data);
        this.releaseInfoData = res1.data;
        //this.releaseDeliveryCenter = this.releaseInfoData.deliveryCenterCode;
      } else {
        console.error(err1);
      }
    },
    async getReleaseCenterData() {
      //출고센터진행정보
      const [res2, err2] = await this.$https.get(
        "/v2/exclusive/work/delivery-state/" +
          this.contractInfoData.contractNumber
      );
      if (!err2) {
        console.log("/work/delivery-state/", res2.data);
        this.releaseCenterData = res2.data;
      } else {
        console.error(err2);
      }
    },
    async getReleaseTakeoverData() {
      //인수정보 조회
      const [res3, err3] = await this.$https.post(
        "/v2/exclusive/work/take-over",
        { contractNumber: this.contractInfoData.contractNumber }
      );
      if (!err3) {
        console.log('/work/take-over/', res3.data)
        this.releaseTakeoverData = res3.data
        this.currentReleaseTakeoverData = res3.data
        if(this.contractInfoData.contractPersonalCorporationCode !== '3'){
          this.customerNumber = this.contractData.contractorInfo
          .filter(
            el =>
              el.customerName === this.releaseTakeoverData.acquisitionPersonName
          )
          .map(el => el.customerManagementNumber)[0];

          this.customerNumber = this.customerNumber
            ? this.customerNumber
            : "";
        }else{
          this.customerNumber = this.contractData.contractorInfo
          .filter(
            el =>
              el.businessName === this.releaseTakeoverData.acquisitionPersonName
          )
          .map(el => el.customerManagementNumber)[0];

          this.customerNumber = this.customerNumber
            ? this.customerNumber
            : "";
        }

        this.takeoverForm = {      
          firmName: res3.data.firmNm,
          firmTn: res3.data.firmTn,
          firmHpNo: res3.data.firmHpNo,
          firmId: res3.data.firmId        
         };

        if(this.releaseTakeoverData && this.releaseTakeoverData.acquisitionAddressContents){
          const sidoList = this.commonCodes.Z028
          let searchAddr = ''
          sidoList.some((ele) => {
            if(this.releaseTakeoverData.acquisitionAddressContents.indexOf(ele.label) > -1) {
              this.searchSido = ele.value
              searchAddr = ele.label
            }
          })

          await this.onChangeSido(this.searchSido)

          // API-WE-구매서비스-015 (인수 업체 조회)
          const [res, err] = await this.$https.post(
            "/v1/tbtech/formalTakeOver",
            this.searchSido === '17' ? {req_type:'C'} : {req_type:'C', wpa_scn_cd: this.searchSido},
            null,
            "eis"
          );
          if (!err) {
            const resList = res.ds_List ? res.ds_List.map((ele) => ({
              admzNm:    ele.admz_nm,
              admzScnCd: ele.admz_scn_cd,
              firmId:    ele.firm_id,
              firmNm:    ele.firm_nm,
              firmTn:    ele.firm_tn,
              firmType:  ele.firm_type,
              hpTn:      ele.hp_tn,
              laeCnVal:  ele.lae_cn_val,
              loeCnVal:  ele.loe_cn_val,
              rdnaDtlSbc:ele.rdna_dtl_sbc,
              rdnaSbc:   ele.rdna_sbc,
              rdwNmZip:  ele.rdw_nm_zip,
              wpaNm:     ele.wpa_nm,
              wpaScnCd:  ele.wpa_scn_cd
            })) : []
            const takeOverInfo = resList.find((ele) => ele.firmId === this.releaseTakeoverData.firmId);
            if(takeOverInfo && takeOverInfo.admzScnCd){
              this.searchGungu = takeOverInfo.admzScnCd

              let takeOverList = resList.map((ele) => {
                let dist
                if ((ele.laeCnVal === takeOverInfo.laeCnVal) && (ele.loeCnVal === takeOverInfo.loeCnVal)) {
                  dist = 0
                } else {
                  let radLat1 = Math.PI * ele.laeCnVal / 180;
                  let radLat2 = Math.PI * takeOverInfo.laeCnVal / 180;
                  let theta = ele.loeCnVal - takeOverInfo.loeCnVal;
                  let radTheta = Math.PI * theta / 180;
                  dist = Math.sin(radLat1) * Math.sin(radLat2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.cos(radTheta);
                  if (dist > 1) dist = 1;
                      

                  dist = Math.acos(dist);
                  dist = dist * 180 / Math.PI;
                  dist = dist * 60 * 1.1515 * 1.609344 * 1000;
                  if (dist < 100) dist = Math.round(dist / 10) * 10;
                  else dist = Math.round(dist / 100) * 100;
                }

                return {...ele, dist}
              }).sort((a, b) => { return a.dist < b.dist ? -1 : 1 })
              
              this.priReleaseTakeoverList = takeOverList.filter((ele, idx) => idx < 5)
            } else {
              let gunguNm = '';
              await this.gunguList.some((ele) => {
                if(this.releaseTakeoverData.acquisitionAddressContents.indexOf(ele.value) > -1 && ele.value.length > gunguNm.length) {
                  gunguNm = ele.value
                  searchAddr += ' ' + ele.value
                  this.searchGungu = ele.key
                }
              })

              await this.geocoder.addressSearch(searchAddr, (result, status) => {
                // 정상적으로 검색이 완료됐으면 
                if (status === kakao.maps.services.Status.OK) {
                  let takeOverList = resList.map((ele) => {
                    let dist
                    if ((ele.laeCnVal === result[0].y) && (ele.loeCnVal === result[0].x)) {
                      dist = 0
                    } else {
                      let radLat1 = Math.PI * ele.laeCnVal / 180;
                      let radLat2 = Math.PI * result[0].y / 180;
                      let theta = ele.loeCnVal - result[0].x;
                      let radTheta = Math.PI * theta / 180;
                      dist = Math.sin(radLat1) * Math.sin(radLat2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.cos(radTheta);
                      if (dist > 1) dist = 1;
                          

                      dist = Math.acos(dist);
                      dist = dist * 180 / Math.PI;
                      dist = dist * 60 * 1.1515 * 1.609344 * 1000;
                      if (dist < 100) dist = Math.round(dist / 10) * 10;
                      else dist = Math.round(dist / 100) * 100;
                    }

                    return {...ele, dist}
                  }).sort((a, b) => { return a.dist < b.dist ? -1 : 1 })
                  
                  this.priReleaseTakeoverList = takeOverList.filter((ele, idx) => idx < 5)
                }
              });
            }
          } else {
            console.error(err);
          }
        }

      } else {
        console.error(err3);
      }
    },
    async getReleaseConsignData() {
      //탁송정보
      const [res4, err4] = await this.$https.get(
        "/v2/exclusive/work/consign/" + this.contractInfoData.contractNumber
      );
      if (!err4) {
        console.log("/work/consign/", res4.data)
        this.releaseConsignData = res4.data
      } else {
        console.error(err4)
      }
    },
    async getReleaseRegistAgencyData() {
      //등록대행정보 조회 (API-E-전담컨설턴트-034)
      const [res5, err5] = await this.$https.get(
        "/v2/exclusive/work/regist-agency/" +
          this.contractInfoData.contractNumber
      )
      if (!err5) {
        console.log("/work/regist-agency/", res5.data);
        this.releaseRegistAgencyData = res5.data;
      } else {
        console.error(err5);
      }
    },
    async getReleaseConsignee() {
      //인수자 정보 조회 (API-WX-전담컨설턴트-012)
      const [res6, err6] = await this.$https.get(
        "/v2/exclusive/work/consignee/" + this.contractInfoData.contractNumber
      );
      if (!err6) {
        console.log("/work/consignee/", res6.data);
        this.releaseConsigneeData = res6.data;
        this.releaseConsigneeData.unshift({ customerName: "선택", customerNumber: "" });
      } else {
        console.error(err6);
      }
    },
    async getReleaseDeliveryCenterList() {
      //API-WX-전담컨설턴트-018 (출고센터 목록 조회)
      const [res7, err7] = await this.$https.get(
        "/v2/exclusive/work/deliveryCenter"
      );
      if (!err7) {
        console.log("/work/consignee/", res7.data);
        this.releaseDeliveryCenterList = res7.data;
      } else {
        console.error(err7);
      }
    },
    async getReleaseDeliveryPriceHistory() {
      //API-WX-전담컨설턴트-029 (탁송료변경이력 조회)
      const [res8, err8] = await this.$https.get(
        "/v2/exclusive/work/deliveryPriceHistory/" +
          this.contractInfoData.contractNumber
      );
      if (!err8) {
        console.log("/work/deliveryPriceHistory/", res8.data);
        this.releaseDeliveryPriceHistory = res8.data;
      } else {
        console.error(err8);
      }
    },
    async getReleaseEresistHistory() {
      //E등록 이력 조회
      const data = {
        saleCnttNo: this.contractInfoData.contractNumber
      };
      const [res1, err1] = await this.$https.post(
        "/purchase/v2/purchase/contract/e-reg/regList",
        data,
        null,
        "gateway"
      );
      if (!err1) {
        console.log("/work/delivery/", res1.data);
        this.releaseEresistData = res1.data.map((el, idx) => {
          return {
            ...el,
            no: res1.data.length - idx,
            vbgInpDt: moment(el.vbgInpDt).format("YYYY-MM-DD")
          };
        });
      } else {
        console.error(err1);
      }
    },
    getSignatureInfo() {
      //전자 서명 이력 조회
      const elecSignKcd = 'C' //인수확정
      this.$refs.signatureInfo.getElectronSignData(elecSignKcd);
    },
    searchAddressPopOpen(index) {
      this.$EventBus.$emit("searchAddressPopOpen", index);
    },
    async callChangeDeliveryCenter(zipNo) {
      await this.changeDeliveryCenter(
        this.releaseInfoData.deliveryCenterCode,
        zipNo
      );
    },
    async changeDeliveryCenter(val) {
      // zipNum
      if (!val) {
        this.alertMessage = '출고센터를 선택하세요.'
        this.alertMessagePop = true
        return
      }

      const param = {
        saleContractNo: this.contractInfoData.contractNumber,
        saleModelCode: this.contractInfoData.saleModelCode,
        optionCode: this.contractInfoData.optionCode,
        deliveryAreaCode: this.releaseTakeoverData.deliveryAreaCode,
        deliveryLocalAreaCode: this.releaseTakeoverData.deliveryLocalAreaCode,
        deliveryCenterCode: val
      };
      console.log("===", param);
      // API-WX-전담컨설턴트-037 (변경 후 출고센터 탁송료 조회)
      const [res, err] = await this.$https.post(
        "/v2/exclusive/work/getConsignmentInfo",
        param
      );

      // API-E-업무담당자-120 (등록대행업체 등록)
      if (!err) {
        console.log("/v2/exclusive/work/getConsignmentInfo", res.data);

        this.deleveryCenterForm = {
          afterDeliveryPrict: res.data.totalDeiveryPrice,
          diffDeliveryPrice:
            res.data.totalDeiveryPrice - this.releaseTakeoverData.deliveryPrice
        };
        console.log("==============", this.deleveryCenterForm);
      } else {
        this.alertMessage = err.rspMessage;
        this.alertMessagePop = true;
        console.error(err);
      }
    },
    async onSaveDeliveryCenter() {
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      if (this.releaseDeliveryCenter === "") {
        this.alertMessage = "출고센터를 선택하세요.";
        this.alertMessagePop = true;
        return;
      }
      // API-WX-공통서비스-004 (휴폐업 조회)
      const [res, err] = await this.$https.get(
        "purchase/v2/purchase/contract/delivery-center/change?contractNumber=" +
          this.contractInfoData.contractNumber +
          "&deliveryCenterCode=" +
          this.releaseDeliveryCenter,
        null,
        null,
        "gateway"
      ); // API-E-업무담당자-120 (등록대행업체 등록)
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
        this.popVisibleLoading = false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      if (!err) {
        console.log("purchase/contract/delivery-center/change", res.data);
        if (res.data.resultYn === "Y") {
          this.alertMessage = "출고센터를 변경했습니다.";
          this.alertMessagePop = true;
          this.popVisibleRelease = false;
          this.getAllData();
        } else {
          this.alertMessage = res.data.resultMessage;
          this.alertMessagePop = true;
          this.popVisibleRelease = false;
        }
      } else {
        console.error(err);
      }
    },
    async onChangeSido(sido) {
      // API-WH-공통서비스-023 (시군 코드조회)
      const [res, err] = await this.$https.get(
        "common/v2/common/support/code/gulist/" + sido,
        null,
        null,
        "gateway"
      );
      if (!err) {
        console.log("common/v2/common/support/code/gulist/", res.data);
        this.gunguList = res.data;
        this.searchGungu = "";
      } else {
        console.error(err);
      }
    },
    async getFormalTakeOver() {
      // API-WE-구매서비스-015 (인수 업체 조회)
      const [res, err] = await this.$https.post(
          "/v1/tbtech/formalTakeOver",
          this.searchSido === '17' ? {req_type:'C'} : {req_type:'C', wpa_scn_cd: this.searchSido},
          null,
          "eis"
        );
      if (!err) {
        console.log("/v1/tbtech/formalTakeOver", res.ds_list);
        const resList = res.ds_List ? res.ds_List.map((ele) => ({
              admzNm:    ele.admz_nm,
              admzScnCd: ele.admz_scn_cd,
              firmId:    ele.firm_id,
              firmNm:    ele.firm_nm,
              firmTn:    ele.firm_tn,
              firmType:  ele.firm_type,
              hpTn:      ele.hp_tn,
              laeCnVal:  ele.lae_cn_val,
              loeCnVal:  ele.loe_cn_val,
              rdnaDtlSbc:ele.rdna_dtl_sbc,
              rdnaSbc:   ele.rdna_sbc,
              rdwNmZip:  ele.rdw_nm_zip,
              wpaNm:     ele.wpa_nm,
              wpaScnCd:  ele.wpa_scn_cd
            })) : []
        
        const resTakeOverList = resList.filter((ele) => ele.admzScnCd === this.searchGungu)

        if(resTakeOverList.length < 5) {
          const sidoList = this.commonCodes.Z028
          let searchAddr = ''
          sidoList.some((ele) => {
            if(ele.value === this.searchSido) searchAddr = ele.label
          })
          
          await this.gunguList.some((ele) => {
            if(ele.key=== this.searchGungu) searchAddr += ' ' + ele.value
          })

          await this.geocoder.addressSearch(searchAddr, (result, status) => {
            // 정상적으로 검색이 완료됐으면 
            if (status === kakao.maps.services.Status.OK) {
              let takeOverList = resList.map((ele) => {
                let dist
                if ((ele.laeCnVal === result[0].y) && (ele.loeCnVal === result[0].x)) {
                  dist = 0
                } else {
                  let radLat1 = Math.PI * ele.laeCnVal / 180;
                  let radLat2 = Math.PI * result[0].y / 180;
                  let theta = ele.loeCnVal - result[0].x;
                  let radTheta = Math.PI * theta / 180;
                  dist = Math.sin(radLat1) * Math.sin(radLat2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.cos(radTheta);
                  if (dist > 1) dist = 1;
                      

                  dist = Math.acos(dist);
                  dist = dist * 180 / Math.PI;
                  dist = dist * 60 * 1.1515 * 1.609344 * 1000;
                  if (dist < 100) dist = Math.round(dist / 10) * 10;
                  else dist = Math.round(dist / 100) * 100;
                }

                return {...ele, dist}
              }).sort((a, b) => { return a.dist < b.dist ? -1 : 1 })
              
              this.releaseTakeoverList = takeOverList.filter((ele, idx) => idx < 5)
            }
          });
        } else {
          this.releaseTakeoverList = resTakeOverList
        }

        
      } else {
        console.error(err);
      }
    },
    getTakeoverList($event, item) {
      this.releaseTakeoverData.acquisitionZipCode = item.rdwNmZip
      this.releaseTakeoverData.acquisitionAddressContents = item.rdnaSbc
      this.releaseTakeoverData.acquisitionDetailAddressContents = item.rdnaDtlSbc
      /* [#9948/2021.11/24/A936505] 상호지점 표기 */
      this.releaseTakeoverData.acquisitionFirmName = item.firmNm
      this.popVisibleSearch = false

      /*[#13772 / 2022.06.02 / A934120] 기타 요청사항에 인수점정보 표기 Start */ 
      let etcCont = this.releaseTakeoverData.etcContent
      let first = etcCont.indexOf('[')
      let memoOrigin =''
      let splitCont= []
      
      if(first !== -1){        
        splitCont = etcCont.split('[')        
        memoOrigin = splitCont[0]
      }else{
        memoOrigin = etcCont
      }
      let etcContResult = memoOrigin + ' ['+item.firmNm+']' + '[' + item.hpTn+ ']'
      this.releaseTakeoverData.etcContent = etcContResult;
      /*[#13772 / 2022.06.02 / A934120] 기타 요청사항에 인수점정보 표기 End */ 


      this.takeoverForm = {      
        firmName: item.firmNm,
        firmTn: item.firmTn,
        firmHpNo: item.hpTn,
        firmId: item.firmId
        
      };
      this.officialTakeOver = true
      console.log('firmId >> '+this.takeoverForm.firmId );
    },
    async onChangeAcquisition() {
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
      if(this.releaseTakeoverData.depositYn==="N"&&this.releaseTakeoverData.qSignYn!=="Y"){
        this.alertMessage = "Q싸인전 무통장 미입금 상태에서는 인수지 변경을 처리할 수 없습니다.";
        this.alertMessagePop = true;
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
        this.popVisibleLoading = false
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */        
        return;
      }
      /* ############################# [W Project/#13152/2022.04.10/A934118] START ###################################### */
      // #13152[전담] 인수정보 변경 - '할부'가 포함된 경우 등록대행만 가능합니다 제한 제거
      //등록대행 서비스 결제수단 '할부' 여부 체크용 ////////////////////////////////////////
      /*const [response, error] = await this.$https.get(
        "payment/v2/payment/payment-amount/info?saleContractNo=" + this.contractInfoData.contractNumber,
        null,
        null,
        "gateway"
      )

      if(!error){
        if(response.data.installmentDetail && this.registAgencyApplyYn === 'N'){
          this.alertMessage = "결제수단에 '할부'가 포함된 경우 등록대행만 가능합니다(직접등록 불가)"
          this.alertMessagePop = true
          return
        }
      }*/
      ///////////////////////////////////////////////////////////////////////////////////
      /* ############################# [W Project/#13152/2022.04.10/A934118] END ###################################### */

      let registAgencyNoRqScnCd = "2";

      if (
        this.releaseConsigneeData.filter(
          el => el.customerNumber === this.customerNumber
        ).length > 0
      ) {
        this.takeoverForm.acceptorName = this.releaseConsigneeData
          .filter(el => el.customerNumber === this.customerNumber)
          .map(el => el.customerName)[0];
        this.takeoverForm.acceptorMobile = this.releaseConsigneeData
          .filter(el => el.customerNumber === this.customerNumber)
          .map(el => el.mobilePhone)[0];
        this.takeoverForm.acceptorBirthDay = this.releaseConsigneeData
          .filter(el => el.customerNumber === this.customerNumber)
          .map(el => el.birthday)[0];
      } else {
        this.takeoverForm.acceptorName = "";
        this.takeoverForm.acceptorMobile = "";
        this.takeoverForm.acceptorBirthDay = "";
      }

      /* if (this.contractInfoData.customerNumber === this.customerNumber) {
        this.takeoverForm.acquisitionTypeCode = "01";
      } else if (this.contractInfoData.customerNumber !== this.customerNumber) {
        this.takeoverForm.acquisitionTypeCode = "00";
      } */

      this.takeoverForm.acceptorMobile = this.takeoverForm.acceptorMobile
        ? this.takeoverForm.acceptorMobile.replace(/-/gi, "")
        : "";

      if(this.officialTakeOver === false){
        this.takeoverForm.acceptorMobile2 = this.releaseTakeoverData.hopeAcquisitionPersonMobile
        ? this.releaseTakeoverData.hopeAcquisitionPersonMobile.replace(/-/gi, "")
        : ""
      }else{
        this.takeoverForm.acceptorMobile2 = ""
      }
      

      var firmChangeYn = 'N' //공식지정 인수점 변경 여부 
      if(( !this.currentReleaseTakeoverData.firmId && this.takeoverForm.firmId )
       || (this.currentReleaseTakeoverData.firmId && this.takeoverForm.firmId && this.currentReleaseTakeoverData.firmId !== this.takeoverForm.firmId) ){
        firmChangeYn = 'Y'
      }
      this.takeoverForm = {
        ...this.takeoverForm,
        contractNumber: this.contractInfoData.contractNumber,
        choiceItemTypeCode: this.releaseTakeoverData.standardServiceCode,
        acceptorGender: '',
        acceptorZipCode: this.releaseTakeoverData.acquisitionZipCode,
        acceptorCenterAddress: this.releaseTakeoverData
          .acquisitionAddressContents,
        acceptorCenterAddressDetail: this.releaseTakeoverData
          .acquisitionDetailAddressContents, 
        etcContent: this.releaseTakeoverData.etcContent.replaceAll('@','').replaceAll('#','').replaceAll('%','').replaceAll('$','').replaceAll('~','').replaceAll("'",'').replaceAll("&",''),
        registAgencyApplyYn: this.registAgencyApplyYn,
        registAgencyNoRqScnCd: registAgencyNoRqScnCd,
        acquisitionTypeCode : this.releaseTakeoverData.acquisitionTypeCode,
        firmChangeYn : firmChangeYn
      }

      console.log('>>>>>>>>>>>>>>>>>>', this.takeoverForm)
      
      const [res, err] = await this.$https.post(
        '/v2/exclusive/work/take-over/change',
        this.takeoverForm
      )
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */  
      if (!err) {
        console.log(res);
        if (res.rspStatus && res.rspStatus.rspCode === "0000") {
          this.alertMessage = "변경되었습니다.";
          this.alertMessagePop = true;
          this.$emit("refresh", true);
          this.takeoverForm = {};
          this.deleveryCenterForm = {};
          this.jusoForm = {
            zipCode: "",
            address: "",
            detailAddress: ""
          };
        }
      } else {
        console.error(err)
      }
    },
    async cancelEregist() {
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      // API-WX-구매서비스-032 (e등록 비용납부 취소)
      this.alertVisibleCancelEregist = false;
      const param = {
        saleCnttNo: this.contractNumber
      };

      const [res, err] = await this.$https.post(
        "purchase/v2/purchase/contract/e-reg/cancelVehRegPay",
        param,
        null,
        "gateway"
      );
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
        this.popVisibleLoading = false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      if (!err) {
        if (res.rspStatus.rspCode === "0000") {
          this.alertMessage = "온라인 차량등록이 취소 되었습니다.";
          this.alertMessagePop = true;
          this.getReleaseEresistHistory();
        }
      } else {
        console.error(err);
      }
    },
    setAddress() {
      this.releaseTakeoverData.acquisitionZipCode = this.jusoForm.zipCode;
      this.releaseTakeoverData.acquisitionAddressContents = this.jusoForm.address;
      this.releaseTakeoverData.acquisitionDetailAddressContents = this.jusoForm.detailAddress;
      this.detailAddressInput = true;
      this.takeoverForm = {
        firmName: "",
        firmTn: "",
        firmHpNo: "",
        firmId: "",
      };
      this.popVisibleConsignment = false;

      this.officialTakeOver = false;
    },

    async onViewMap() {
			await loadScriptOnce(`https://dapi.kakao.com/v2/maps/sdk.js?autoload=false&appkey=${this.kakaomapAppKey}&libraries=services`)
				.then(async () => {
					if (window && window.kakao && window.kakao.maps) {
						kakao = window.kakao
						this.geocoder = new kakao.maps.services.Geocoder()
						// this.marker = new kakao.maps.Marker()
						if (this.$refs.mapBox === undefined) return
						this.initMap()
					} else {
						await window.kakao.maps.load(() => {
							kakao = window.kakao
							this.geocoder = new kakao.maps.services.Geocoder()
							// this.marker = new kakao.maps.Marker()
							if (this.$refs.mapBox === undefined) return
							this.initMap()
						})
					}
				})
				.catch((err) => {
					console.error(err)

          window.kakao=window.kakao||{},window.kakao.maps=window.kakao.maps||{},window.daum&&window.daum.maps?window.kakao.maps=window.daum.maps:(window.daum=window.daum||{},window.daum.maps=window.kakao.maps),
          function(){
            var o=window.kakao.maps=window.kakao.maps||{};
            
            if(void 0===o.readyState)o.onloadcallbacks=[],o.readyState=0;
            else if(2===o.readyState)return;
              
            o.VERSION={
              ROADMAP:"2111ydg",
              ROADMAP_SUFFIX:"",
              HYBRID:"2111ydg",
              SR:"3.00",
              ROADVIEW:"7.00",
              ROADVIEW_FLASH:"200402",
              BICYCLE:"6.00",
              USE_DISTRICT:"2111ydg",
              SKYVIEW_VERSION:"160114",
              SKYVIEW_HD_VERSION:"160107"
            },
            o.RESOURCE_PATH={
              ROADVIEW_AJAX:"//t1.daumcdn.net/roadviewjscore/core/css3d/200204/standard/1580795088957/roadview.js",
              ROADVIEW_CSS:"//t1.daumcdn.net/roadviewjscore/core/openapi/standard/211122/roadview.js"
            };
            
            for(var n,r="https:"==location.protocol?"https:":"http:",s="",i=document.getElementsByTagName("script"),d=i.length;n=i[--d];)if(/\/(beta-)?dapi\.kakao\.com\/v2\/maps\/sdk\.js\b/.test(n.src)){s=n.src;break}i=null;
            
            var c=o.onloadcallbacks,
              E=["v3"],
              S="",
              I={
                v3:r+"//t1.daumcdn.net/mapjsapi/js/main/4.4.3/kakao.js",
                services:r+"//t1.daumcdn.net/mapjsapi/js/libs/services/1.0.2/services.js",
                drawing:r+"//t1.daumcdn.net/mapjsapi/js/libs/drawing/1.2.6/drawing.js",
                clusterer:r+"//t1.daumcdn.net/mapjsapi/js/libs/clusterer/1.0.9/clusterer.js"
              },
              _=function(a){var t={};return a.replace(/[?&]+([^=&]+)=([^&]*)/gi,function(a,e,o){t[e]=o}),t}(s);
              S=_.appkey,S&&(o.apikey=S),
              o.version="4.4.3";
            
            var R=_.libraries;
            
            if(R&&(E=E.concat(R.split(","))),"false"!==_.autoload){
              for(var dd=0,l=E.length;dd<l;dd++) {
                !function(a){
                  if(a) document.write('<script charset="UTF-8" src="'+a+'" />')
                }(I[E[dd]]);
              }
              o.readyState=2
            }
            
            o.load=
              function(t){
                switch(c.push(t),o.readyState){
                  case 0:
                    o.readyState=1,a();
                    break;
                  case 2:
                    e()
                }
              }
            
            function a(){if(E.length){t(I[E.shift()],a).start()}else e()}
            
            function t(a,t){var e=document.createElement("script");return e.charset="utf-8",e.onload=t,e.onreadystatechange=function(){/loaded|complete/.test(this.readyState)&&t()},{start:function(){e.src=a||"",document.getElementsByTagName("head")[0].appendChild(e),e=null}}}
            
            function e(){for(;c[0];)c.shift()();o.readyState=2}
          }();

          if (window && window.kakao && window.kakao.maps) {
						kakao = window.kakao
						this.geocoder = new kakao.maps.services.Geocoder()
						// this.marker = new kakao.maps.Marker()
						if (this.$refs.mapBox === undefined) return
						this.initMap()
					} else {
						window.kakao.maps.load(() => {
							kakao = window.kakao
							this.geocoder = new kakao.maps.services.Geocoder()
							// this.marker = new kakao.maps.Marker()
							if (this.$refs.mapBox === undefined) return
							this.initMap()
						})
					}
				})
		},

    async initMapDetail() {
			// kakao map 초기 셋팅
			if (this.$refs.mapBox === undefined) return
			this.map = await new kakao.maps.Map(this.$refs.mapBox, {
				// 권한 요청 여부 판단 이전 default map view setting
				center: new kakao.maps.LatLng(37.486219, 127.033676),
				level: this.agencyZoomDefaultLv, // 지도의 확대 레벨
				disableDoubleClick: true
			})

			// 브라우저 현재위치 가져오는 부분
			const { latitude, longitude } = await this.getPosition()

			this.addrPos = { latitude, longitude }
			const nowPos = { latitude, longitude }
      const zoomControl = new kakao.maps.ZoomControl()
			// Map 생성
			this.map = new kakao.maps.Map(this.$refs.mapBox, {
        center: new kakao.maps.LatLng(this.addrPos.latitude, this.addrPos.longitude), // 지도의 중심좌표
				level: this.agencyZoomDefaultLv, // 지도의 확대 레벨
				disableDoubleClick: true
			})


      this.map.removeControl(zoomControl, kakao.maps.ControlPosition.RIGHT)
      this.map.addControl(zoomControl, kakao.maps.ControlPosition.RIGHT)
      this.map.setZoomable(true)

			// 브라우저 현재위치 좌표--> 주소로 변환 하는 부분
			this.setAddressByPos()

			return nowPos
		},
    
		async initMap() {
			this.initMapDetail().then((res) => {
				const { latitude, longitude } = res
				this.searchPos = { latitude, longitude }
				// 초기 위치 값에 따른 조회
				const initRadius = this.getDistance(new kakao.maps.LatLng(latitude, longitude), this.map.getBounds().getSouthWest())
				this.searchPos.radius = Math.floor(initRadius / 1000)
				this.displayMarker()

				// this.displayMarker()
			})
		},

    displayMarker() {
			let vm = this
			this.marker.map((items) => {
				items.setMap(null)
			}) // 마커초기화
			this.marker = []
			const bounds = new kakao.maps.LatLngBounds()

			if (this.mountCenters && this.mountCenters.length > 0) {
				this.mountCenters.map((item, i) => {
					const imgOptions = {
						spriteSize: new kakao.maps.Size(36, 691), // 스프라이트 이미지의 크기
						spriteOrigin: new kakao.maps.Point(0, i * 46 + 10), // 스프라이트 이미지 중 사용할 영역의 좌상단 좌표
						offset: new kakao.maps.Point(13, 37) // 마커 좌표에 일치시킬 이미지 내에서의 좌표
					}
					const imageSrc = require('@/assets/images/marker_number_blue.png') // 마커 이미지 url, 스프라이트 이미지를 씁니다
					// 마커 이미지의 이미지 크기 입니다
					let imageSize = new kakao.maps.Size(36, 37)
					// 마커 이미지를 생성합니다
					let markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize, imgOptions)
					// 마커를 표시할 위치
					let position = new kakao.maps.LatLng(item.laeCnVal, item.loeCnVal)
					//let position = new kakao.maps.LatLng(37.486219, 127.033676) //위치정보가 없어 임의 데이터
					// 마커를 생성합니다
					let markerShape = new kakao.maps.Marker({
						map: vm.map, // 마커를 표시할 지도
						position: position, // 마커를 표시할 위치
						title: item.title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
						image: markerImage, // 마커 이미지
						clickable: true // 마커를 클릭했을 때 지도의 클릭 이벤트가 발생하지 않도록 설정합니다
					})
					// 마커에 클릭이벤트를 등록합니다
					kakao.maps.event.addListener(markerShape, 'click', () => {
						this.onCenterClick(i)
					})
					this.marker.push(markerShape)
					bounds.extend(position)
				})
				// 마커설정
				this.marker.map((items) => {
					items.setMap(this.map)
				})

				if (!this.mapSearch) {
					this.map.setBounds(bounds)
				}
			} else {
				this.marker.map((items) => {
					items.setMap(null)
				}) // 마커초기화
				this.marker = []
			}
		},
		// 마커 클릭
		async onCenterClick(index, flag) {
			if (this.customOverlay2) {
        try {
          this.customOverlay2.setMap(null)
        } catch(e){}
			}
			this.tooltipActive = true

			this.centerData = this.mountCenters[index]
			this.centerData.clickIdx = index + 1
			this.clickIdx = index
			if (this.$refs.mountCenterClickPop === undefined) return
			if (this.$refs.mapBox === undefined) return
			if (kakao === undefined) return
			if (this.centerData) {
				const customOverlayPos = new kakao.maps.LatLng(this.mountCenters[index].laeCnVal, this.mountCenters[index].loeCnVal)
				//const customOverlayPos = new kakao.maps.LatLng(37.486267, 127.033671)
				const contents = await this.$refs.mountCenterClickPop
				this.customOverlay2 = new kakao.maps.CustomOverlay({
					position: customOverlayPos,
					content: contents,
					xAnchor: 0.5,
					yAnchor: 1.4
				})
				this.customOverlay2.setMap(this.map)

				this.map.panTo(customOverlayPos)
			}
		},

		async onMapPopClose() {
			if (this.customOverlay2) {
        try {
          await this.customOverlay2.setMap(null)
        } catch(e){}
			}
			this.tooltipActive = await false
			this.customOverlay2 = await null
		},

    // 현재 사용자 위치 가지고 오기
		async getPosition() {
			const [res, err] = await this.getLocation()
			return err ? { latitude: 37.486219, longitude: 127.033676 } : res
		},

    async getLocation() {
        const isIE11 = !!window.MSInputMethodContext && !!document.documentMode // check browser ie 11
        const location = (options = {}) => {
            options = isIE11 ? { enableHighAccuracy: false, ...options } : options

            if (navigator.geolocation) {
                return new Promise((resolve, reject) => {
                    navigator.geolocation.getCurrentPosition(resolve, reject, options)
                })
            } else {
                alert('GPS를 지원하지 않습니다')
            }
        }
        try {
            const { coords } = await location()
            const { latitude, longitude } = coords
            return [{ latitude, longitude }, null]
        } catch (error) {
            // Handle error
            console.log(error)
            return [null, error]
        }
    },

    
		// 내위치에서 거리 구하기 (센터좌표)
		getDistance(lat, lng) {
			if (kakao && kakao.maps) {
				const distanceLine = new kakao.maps.Polyline({
					path: [new kakao.maps.LatLng(this.addrPos.latitude, this.addrPos.longitude), new kakao.maps.LatLng(lat, lng)]
				})
				let distanceMeter = 0
				distanceMeter = Math.round(distanceLine.getLength() / 1000)
				return distanceMeter
			}
		},
		// 좌표로 주소셋팅
		setAddressByPos() {
			const { latitude, longitude } = this.addrPos
			// 시,도
			this.geocoder.coord2RegionCode(longitude, latitude, (result, status) => {
				if (status === kakao.maps.services.Status.OK) {
					// eslint-disable-next-line camelcase
					const res = result.find(({ region_type }) => region_type === 'H')
					this.address.siNm = this.get1DepthMapping(res.region_1depth_name)
				}
			})

			// 상세주소
			this.geocoder.coord2Address(longitude, latitude, (result, status) => {
				if (status === kakao.maps.services.Status.OK) {
					// eslint-disable-next-line camelcase
					const { road_address, address } = result[0]
					// eslint-disable-next-line camelcase
					this.address.roadAddr = road_address ? road_address.address_name : address.address_name
				}
			})
		},
		// 주소 1Depth매핑
		get1DepthMapping(val) {
			for (let i = 0; i < addrData.default.address1.length; i++) {
				if (addrData.default.address1[i].value === val) {
					return addrData.default.address1[i].label
				} else {
					return val
				}
			}
    },
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
    oneClickDisable(event, clickEvent, ...args) {
      if(event.target.disabled === true){
        retrun
      }

      event.target.disabled = true

      try {
        clickEvent(...args)
      } catch {}
      setTimeout(() => {
        event.target.disabled = false
      }, 2000)
    }
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */    
  }
};
</script>
<style lang="scss" scoped>
@import "~/assets/style/pages/detail.scss";
@import "~/assets/style/pages/tab/ReleaseInfo.scss";
</style>
