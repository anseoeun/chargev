<template>
  <div>
    <el-table
      :data="messageData"
      max-height="450"
      empty-text="조회된 결과가 존재하지 않습니다."
      @selection-change="onCheck"
      @row-click="onRowClick"
    >
      <el-table-column
        label="No."
        prop="no"
        width="50"
        align="center"
      />
      <el-table-column
        label="계약번호"
        prop="contractNumber"
        width="150"
        align="center"
      />
      <el-table-column
        label="수신자명"
        prop="adresseeName"
        width="100"
        align="center"
      />
      <el-table-column
        label="전화번호"
        prop="adresseeMobile"
        width="140"
        align="center"
      />
      <el-table-column
        label="발송일시"
        prop="sendDate"
        width="140"
        align="center"
      >
        <template slot-scope="scope">
          <el-button
            type="text"
            @click="popContentVisible = true"
          >
            {{ scope.row.sendDate }}
          </el-button>
        </template>
      </el-table-column>
      <el-table-column
        label="구분"
        prop="sendSectionalName"
        width="116"
        align="center"
      />
      <el-table-column
        label="제목"
        prop="messageTitle"
        width="170"
        align="center"
      />
      <el-table-column
        label="본문"
        prop="messageContents"
        align="center"
      />
      <el-table-column
        label="보낸사람"
        prop="dispatcherName"
        width="80"
        align="center"
      />
      <el-table-column
        label="발신전화번호"
        prop="sendMobile"
        width="120"
        align="center"
      />
      <el-table-column
        label="발송상태"
        prop="sendState"
        width="70"
        align="center"
      />
      <el-table-column
        prop="col12"
        label="비고"
        align="center"
        width="100"
      >
        <template slot-scope="props">
          <el-button 
            v-if="props.row.messageTypeCode === 'KAT'"
            type="primary"
            @click="oneClickDisable($event, reSend(props.row.messageTypeCode))"
          >
            재전송
          </el-button>
        </template>
      </el-table-column>
          
    </el-table>
    <!-- 내용보기 팝업 -->
    <el-dialog
      title="내용보기"
      :visible.sync="popContentVisible"
      width="1100px"
    >
      <!-- Popup Contents -->
      <h-title :title="'수신자 정보'" />
      <el-form
        ref="smsInfo"
        :model="smsInfo"
        class="detail-form message-content-pop"
      >
        <el-row>
          <el-col :span="8">
            <el-form-item label="수신자명">
              {{ smsInfo.contractName }}
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="휴대번호전화">
              {{ smsInfo.mobileNumber }}
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="발송일시">
              {{ smsInfo.sendDateTime }}
            </el-form-item>
          </el-col>
        </el-row>
      </el-form><h-title :title="'발신내용'" />

      <el-form
        ref="smsInfo"
        :model="smsInfo"
        class="detail-form message-content-pop"
      >
        <el-row>
          <el-col :span="24">
            <el-form-item label="제목">
              <el-input
                v-model="smsInfo.smsTitle"
                class="mms-title"
                :readonly="!['SMS', 'MMS', 'LMS'].includes(smsInfo.sndTypeCd)"
                @blur="smsInfo.smsTitle = $event.target.value"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="내용">
              <el-input
                v-model="smsInfo.smsContent"
                type="textarea"
                :readonly="!['SMS', 'MMS', 'LMS'].includes(smsInfo.sndTypeCd)"
                @blur="smsInfo.smsContent = $event.target.value"
              />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>

      <!-- Popup Footer -->
      <template slot="footer">
        <el-button
          v-if="['KAT','SMS', 'MMS', 'LMS'].includes(smsInfo.sndTypeCd)"
          type="primary"
          @click="oneClickDisable($event, reSend(smsInfo.sndTypeCd))"
        >
          재전송
        </el-button>
      </template>
    </el-dialog>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
    <!-- ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## -->    
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />
    <!-- ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## -->    
  </div>
</template>
<script>
import HTitle from '~/components/common/HTitle.vue'
import PopMessage from '~/components/popup/PopMessage.vue'
/* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
import Loading from '~/components/popup/Loading.vue'
/* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */

export default {
  name: 'SmsHistory',
  components: {
    HTitle,
    PopMessage,
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
    Loading
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */    
  },
  props: {
    data: {
      type: Array,
      default: null
    },
    contractNumber: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      popContentVisible: false,
      messageData:[],
      smsInfo: {
        contractName: '',
        mobileNumber: '',
        sendDateTime: '',
        smsTitle: '',
        smsContent: ''
      }, // 상세보기 (문자 이력)
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      popVisibleLoading: false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */        
    }
  },
  methods: {
    onCheck(value) {
      console.log(value)
    },
    async getSmsHistoryData() {
      const [res, err] = await this.$https.post('/v2/exclusive/work/history/sms', { contractNumber: this.contractNumber, pageNo : '1', pageSize: '100' })
      if(!err) {
        console.log('/work/history/sms/', res.data)
        this.messageData = res.data.list && res.data.list.map((el, idx) => {
          return {
            ...el,
            no : idx+1,
          }
        })
      } else {
        console.error(err)
      }
    },
    async onRowClick(row, column) {
      if(column.property === 'col12') return 

      this.popContentVisible = true
      const { workSmsSendSerialNumber = '' } = row

      if(!workSmsSendSerialNumber) return

      // API-E-업무담당자-108 (문자발송 상세 조회)
      const [res, err] = await this.$https.post('/v2/exclusive/common/sms-content', { workSmsSendSerialNumber })

      if(!err) {

        console.log(res)
        this.smsInfo = res.data
      } else {
        console.error(err)
      }
    },
    async reSend(sndTypeCd) { // 재전송
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */    
      this.popContentVisible = false
      const { smsSendSerialNumber = '', smsTitle = '', smsContent = '' } = this.smsInfo

      const params = {
        msgItgSndSn: smsSendSerialNumber, // 메시지통합발송일련번호
        sndTypeCd: sndTypeCd !== 'KAT' ? 'MMS' : sndTypeCd, // 발송유형코드
        messageTitle: smsTitle, // 메시지제목
        messageContents: smsContent // 메시지내용
      }

      const [res, err] = await this.$https.post('/v2/exclusive/common/sms-resend', params) // API-E-업무담당자-109 (문자 재전송 API)
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
      if(!err) {
        if(res.rspStatus && res.rspStatus.rspCode === '0000') {
          
          if(sndTypeCd === 'KAT'){
            this.alertMessage = '카카오톡이 재전송되었습니다'
          }else{
            this.alertMessage = '문자가 재전송되었습니다.'
          }
          
          this.alertMessagePop = true
          this.$emit('refresh', true)
        }
        console.log(res)
      } else {
        console.error(err)
      }
    },
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
    oneClickDisable(event, clickEvent, ...args) {
      if(event.target.disabled === true){
        retrun
      }

      event.target.disabled = true

      try {
        clickEvent(...args)
      } catch {}
      setTimeout(() => {
        event.target.disabled = false
      }, 2000)
    }
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */    
  }
}
</script>
