<template>
    <div>
     <!-- 진행상태 : 완료인 경우에만 작성가능한 곳, 그 외의 경우는 readonly. -->
      <div class="article-title">
        <h2>직원 인증 정보</h2>
      </div>
      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="8">
              <el-form-item label="소속" required>
                <el-select
                  v-model="data.wExsfCtfnCndSn"
                  placeholder="접수"
                  :disabled="baseDocListNone || alreadySelectedCoCd"
                >
                <el-option
                  v-for="(item, index) in subjectConditionList"
                  :key="index"
                  :value="item.conditionSerialNumber"
                  :label="item.cndSbc"
                  @click.native="conditonSetting(item)"
                />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="고객/손실구분" required>
                <span v-if="data.csmrTypeCd && data.csmrLossCd">
                {{ data.csmrTypeCd }} / {{ data.csmrLossCd }}
                </span>
              </el-form-item>
            </el-col>
            <!-- 직원인증 완료 된 건만 할인율 정보가 출력된다 -->
            <el-col :span="8">
              <el-form-item label="할인조건">
                <span v-show="data.pgsStCd === '03' && data.alreadyAuthCompleteFlag">
                  <span v-if="data.dcSbc">
                    {{ data.dcSbc }}
                  </span>
                  <span v-else>
                    DC {{ data.dcRate ? data.dcRate : 0 }} % , 
                    무이자 {{ data.foiYn === 'Y' ? '가능' : '불가' }} , 일시불 할인 {{ data.lspDcYn === 'Y' ? '가능' : '불가' }} 
                  </span>
                </span>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <!-- 업체정보 & 사번은 진행상태가 완료인 경우에만 입력 가능 -->
            <el-col :span="8">
              <el-form-item label="업체" required>
                <el-input v-model.trim="data.firmNm" style="width:200px;" :disabled="data.pgsStCd !== '03'" :readonly="true" />
                <el-button type="info" class="btn-small" :disabled="data.pgsStCd !== '03'" @click="openCompanyPopup">조회</el-button>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="사번" required>
                <el-input v-if="data.pgsStCd === '03'" v-model.trim="data.wExsfNo" />
                <el-input v-else disabled />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="사업자등록번호">
                <el-input v-if="data.pgsStCd === '03'" v-model.trim="data.bzNo" :readonly="true" />
                <el-input v-else disabled />
              </el-form-item>
            </el-col>
            <!-- <el-col :span="8">
              <el-form-item label="입사일" required>
                <el-date-picker type="date" v-model="data.etcpDt" />
              </el-form-item>
            </el-col> -->
          </el-row>
        </el-form>
      </div>
      
      <div class="article-title gap">
        <h2>서류 심사 목록</h2>
      </div> 
      <div class="box">     
        <el-table
          v-if="documentList"
          :data="documentList"
          class="box append-box"
          >
          <el-table-column prop="no" label="NO." width="60" align="center">
            <template slot-scope="props">
              <span v-if="!props.row.isAdd">{{ props.row.no }}</span>
              <el-button
                v-else
                type="info"
                icon="el-icon-minus"
                class="btn-small"
                @click="deleteDocumentRow(props.row.addRowKey)"
              >
              </el-button>
            </template>
          </el-table-column>
          <el-table-column
            label="구분"
            prop="neceDocTargNm"
            align="center"
            width="310"
            placeholder="선택하세요"
          >
            <template slot-scope="props">
              <span
                v-if="!props.row.isAdd"
              >
                {{ props.row.neceDocTargNm }}
              </span>
              <el-select
                v-else
                v-model="props.row.neceDocTargNo"
                @change="changeDocCtgList($event, props.row)"
              >
                <el-option
                  v-for="{ neceDocTargNo, neceDocTargNm } in documentTargets && documentTargets.slice(1, documentTargets.length)"
                  :key="neceDocTargNo"
                  :value="neceDocTargNo"
                  :label="neceDocTargNm"
                />
              </el-select>
            </template>
          </el-table-column>
          <el-table-column
            label="소분류"
            prop="neceDocNm"
            align="center"
            width="319"
          >
            <template slot-scope="props">
              <span v-if="!props.row.isAdd">{{ props.row.neceDocNm }}</span>
              <el-select
                v-else
                v-model="props.row.neceDocNo"
                placeholder="선택하세요"
                @change="changeDocSubCtgList($event, props.row)"
              >
                <el-option
                  v-for="{ neceDocNo, neceDocNm } in neceDocSubCategoryList[''+props.row.addRowKey]"
                  :key="neceDocNo"
                  :value="neceDocNo"
                  :label="neceDocNm"
                />
              </el-select>
            </template>
          </el-table-column>
          <el-table-column
            label="스크래핑 결과"
            prop="scrapingCompleteYn"
            align="center"
            width="100"
          >
            <template slot-scope="scope">
              <span v-if="scope.row.scrapingCompleteYn">
                {{ scope.row.scrapingCompleteYn }}
              </span>
              <span v-else>
                -
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="추가서류여부"
            prop="additionPapersYn"
            align="center"
            width="100"
          />
          <el-table-column
            label="제출서류"
            prop="fileGroupSerialNumber"
            align="center"
            width="150"
          >
            <template slot-scope="scope">
              <span
               v-if="!scope.row.fileGroupSerialNumber"
               style="cursor: pointer; color: #1a0dab;"
              >
              <el-upload
                ref="upload"
                name="file"
                accept=".jpg, .jpeg, .gif, .pdf"
                action=""
                :auto-upload="false"
                :multiple="false"
                :limit="1"
                :file-list="fileList"
                :on-change="handleChange"
              >
                <el-button
                  v-if="isValidAuthBtn('authManage')"
                  slot="trigger"
                  type="info"
                  class="btn-small"
                  @click="rememberIdex(scope.row.no)"
                >
                  등록
                </el-button>
              </el-upload>
              </span>
              <span
                v-else
                style="cursor: pointer; color: #1a0dab;"
                @click="getFileData(scope.row)"
              >
                <i class="file_img"></i>{{ scope.row.attcFilNm }}<br />
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="요청일시"
            prop="papersRequestDate"
            align="center"
            width="200"
          >
            <template slot-scope="scope">
              <span v-if="scope.row.papersRequestDate">
                {{ scope.row.papersRequestDate }}
              </span>
              <span v-else>
                -
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="등록일시"
            prop="uploadDate"
            align="center"
            width="200"
          >
            <template slot-scope="scope">
              <span v-if="scope.row.uploadDate">
                {{ scope.row.uploadDate }}
              </span>
              <span v-else>
                -
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="처리일시"
            prop="workProcessDate"
            align="center"
            width="200"
          >
            <template slot-scope="scope">
              <span v-if="scope.row.workProcessDate">
                {{ scope.row.workProcessDate }}
              </span>
              <span v-else>
                -
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="처리결과"
            prop="workProcessDetailResultCode"
            align="center"
            width="150"
          >
            <template slot-scope="scope">
              <el-select
                v-if="!scope.row.isAdd"
                v-model="scope.row.workProcessDetailResultCode"
                :disabled="!scope.row.fileGroupSerialNumber || ['40', '50'].includes(scope.row.copyWorkProcessDetailResultCode)"
                @change="changeDocStatus($event, scope.row)"
              >
                <el-option
                  v-for="{ value, label } in commonCodes.T002 && commonCodes.T002.slice(1, commonCodes.T002.length)"
                  :key="value"
                  :value="value"
                  :label="label"
                  :disabled="isValidStatusCode(scope.row.copyWorkProcessDetailResultCode, value)"
                />
              </el-select>
              <el-select
                v-else
                v-model="scope.row.workProcessDetailResultCode"
              >
                <el-option
                  v-for="{ value, label } in commonCodes.T002 && commonCodes.T002.slice(1, 2)"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </template>
          </el-table-column>
          <el-table-column
            label="진행 상황 메모"
            prop="ppExamSbc"
            align="center"
            width="450"
          >
            <template slot-scope="scope">
              <el-input
                v-model="scope.row.ppExamSbc"
                :disabled="!scope.row.isAdd && !scope.row.fileGroupSerialNumber || ['40', '50'].includes(scope.row.copyWorkProcessDetailResultCode)"
                @change="changeDocContent($event, scope.row)"
                @blur="scope.row.ppExamSbc = $event.target.value"
              />
            </template>
          </el-table-column>
        </el-table>
      </div>

      <!-- 업체조회 팝업 (진행상태 완료일때만 조회 가능) -->
      <company-search-popup
        ref="companyPop"
        :pop-visible-company.sync="popVisibleCompany"
        @selectCompany="settingCompany"
        @close="popVisibleCompany = false"
      />

 
      <!-- 심사 대상 서류 목록 -->
      <paper-review-info
        v-if="data.workAssignNumber"
        ref="paperInfo"
        :work-assign-number.sync="data.workAssignNumber"
        :user-info-data.sync="userInfo"
        @setPaperReviewData="setPaperReviewData"
      /> 


      
    </div>
    
</template>

<script>
import PaperReviewInfo from '~/components/tab/contract/EmployeePaperReviewInfo.vue'
import CompanySearchPopup from '~/components/popup/CompanySearchPopup.vue'

export default {
  name: 'EmployeeAuthInfo',
  components: {
    PaperReviewInfo,
    CompanySearchPopup
  },
  props: {
    userInfo: {
      type: Object,
      default: null
    },
    commonCodes: {
      type: Object,
      default: null
    }
  },
  data() {
    return {
      data: {},
      fileList: [],
      uploadDocumentIndex: 0, // 파일 업로드한 문서 index
      popVisibleCompany: false,   // 업체조회
      alertMessage: '',
      fileData: {},
      documentList: [],
      settingDocumentList: [],  // 임직원 서류 심사 목록
      subjectConditionList: [],
      paperReviewData: [], // 서류심사 목록 (팝업)
      reviewFilter: { neceDocTargNo: 'all', neceDocNo: 'all', workProcessDetailResultCode: 'all'},
      paperTypes: [{ neceDocNo: 'all', neceDocNm: '전체' }],
      neceDocCategoryList: null, // 필수 서류 카테고리(구분) === 서류심사 목록 ===
      neceDocSubCategoryList: {}, // 필수 서류 카테고리(소분류) === 서류심사 목록 ===
      neceDocSubCategoryReview: [{ neceDocNo: 'all', neceDocNm: '전체' }], // 필수 서류 카테고리(소분류) === 서류심사 이력 ===
      alreadySelectedCoCd: false,     // 이미 소속을 선택한 건
      baseDocListNone: false,       // 기본서류 완료여부
      firmCd: '',
      conditionMsgType : ['AH1', 'AD1', 'AD2', 'AZ2']
    }
  },
  watch: {
    reviewFilter: {
      handler(obj) {
        this.changeFilter(obj)
      },
      deep: true
    }
  },
  async mounted() {

  },
  methods: {
    async setSaveDocumentList() {
      // 임직원 진행상태 저장 버튼 click 시 넘길 Document setting

      // 심사대상 서류목록 setting 
      await this.$refs.paperInfo.setPaperReviewData()

    },
    /* [#10593/2021.12.24/A936506] 버튼 권한 체크 메소드 누락되어 추가 */
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    async reset() {
      this.baseDocListNone = false
      this.documnetList = []
      this.paperReviewData = []
      this.settingDocumentList = []
      this.subjectConditionList = []
    },
    async getInfoData(data) {

      this.data = data

      if(!this.data.workAssignNumber) {
        return
      }

      await this.reset()

      this.alreadySelectedCoCd = this.data.wExsfCtfnCndSn ? true : false

      // 1. 서류조회
      const [res,err] = await this.$https.get('/v2/exclusive/employeeAuth/document/'+ this.data.workAssignNumber) // 서류 심사 목록 조회

      if(!err) {
        // 기본서류는 2개 고정(현재는)
        var bascDocCnt = 0
        this.settingDocumentList = res.data.map((el, idx) => {
          // 기본 서류 심사 완료 상태 check
          if(el.attcScnCd === '01') {
            if(el.workProcessDetailResultCode === '50'){
              bascDocCnt++
            }
          }
          return {
            ...el,
            no : idx+1,
            copyWorkProcessDetailResultCode: el.workProcessDetailResultCode,
            isEdit: false
          }
        })

        // 2. 기본 서류 완료여부 check
        // 기본서류로 설정된 서류 개수와 기본 서류 심사 완료 개수가 일치 시 기본서류 완료 
        const [res2] = await this.$https.get('/v2/exclusive/employeeAuth/request/papers', { neceDocTargNo : '10040'})

        let employeeBascDocCnt = (res2.data && res2.data.length > 0) ? res2.data.length : 0

        if (bascDocCnt === employeeBascDocCnt) { this.baseDocListNone = false }
        else this.baseDocListNone = true
        
        this.documentList = this.settingDocumentList.slice()
      } else {
        console.error(err)
      }

      // 3. 조견표
      const [res3, err3] = await this.$https.get('/v2/exclusive/employeeAuth/subjectCondition')
      
      if(!err3) {
        this.subjectConditionList = res3.data.map((el, idx) => {
          el.no = idx+1
          return el
        })
      } else {
        console.error(err3)
      }

    },
    // 행추가
    addDocumentRow() {
      this.documentList.push({isAdd: true, no: this.documentList.length + 1, addRowKey: ''+this.addKeyIdx++, workProcessDetailResultCode: '10', neceDocNo: '', file: 'add', fileData: '', fileGroupSerialNumber: null })
    },
    // 서류심사 목록 setting
    setPaperReviewData(reviewData) {
      // paperReviewData
      this.paperReviewData = reviewData
      
    },
    async changeDocCtgList(e, rowData) { // 서류 심사 목록 - 구분 컬럼 변경시 이벤트

      this.documentList.some((items) => {
        if(items.addRowKey === ''+rowData.addRowKey) {
          items.neceDocNo = null
          return true
        }
      })

      if(e && e !== 'all') { // 구분 select value중에서 전체가 아닐 경우에만
        const [res, err] = await this.$https.get('/v2/exclusive/contract/papers?neceDocTargNo='+ e) //API-E-업무담당자-047 (필요서류목록 조회)
        if(!err) {
          // res.data.unshift({'neceDocNo': 'all', 'neceDocNm': '전체' })
          let obj = {}
          obj[rowData.addRowKey] = res.data

          this.neceDocSubCategoryList = { ...this.neceDocSubCategoryList, ...obj }
        
          
        } else {
          this.alertMessage = err
          this.alertMessagePop = true
        }
      }
    },
    // eslint-disable-next-line no-unused-vars
    changeDocSubCtgList(e, row) { // 서류 심사 목록 - 소분류 컬럼 변경시 이벤트
      row.isEdit = true
    },
    // eslint-disable-next-line no-unused-vars
    changeDocStatus(e, row) { // 서류 심사 목록 - 상태
      row.isEdit = true
    },
    // eslint-disable-next-line no-unused-vars
    changeDocContent(e, row) { // 서류 심사 목록 - 처리내용
      row.isEdit = true
    },
    // 임직원 서류 조회로 변경 필요
    async changeCategory(e) {
      this.reviewFilter.neceDocNo = 'all'
      if(e && e !== 'all') { // 구분 select value중에서 전체가 아닐 경우에만
        const [res, err] = await this.$https.get('/v2/exclusive/contract/papers?neceDocTargNo='+ e) //API-E-업무담당자-047 (필요서류목록 조회)
        if(!err) {
          res.data.unshift({'neceDocNo': 'all', 'neceDocNm': '전체' })
          this.neceDocSubCategoryReview = res.data
        } else {
          console.error(err)
        }
      }
    },
    changeSubCategory(e) {
      console.log(e)
    },
    tableRowClassName({row}) {
      if (row.background === 'red') {
        return 'warning-row'
      }
      else if (row.border === 'red') {
        return 'warning-row1'
      }
      return ''
    },
    // 서류심사 행추가로 생성된 행 삭제
    deleteDocumentRow(key) {
      const idx = this.documentList.findIndex(item => item.addRowKey === key)
      if (idx > -1) this.documentList.splice(idx, 1) // 일치하는 row 삭제
    },
    async documentTargetChanged(val, row) {
      const [res,err] = await this.$https.get('/v2/exclusive/contract/papers', { neceDocTargNo: val }) //API-E-업무담당자-047 (필요서류목록 조회)
      if (!err) {
        console.log(row)
        this.paperTypes = [{'neceDocNo': 'all', 'neceDocNm': '전체'}, ...res.data]
      }
    },
    isValidStatusCode(originStatusCode = '', targetCode = '') {
      if(originStatusCode === '30' && ['10', '20'].includes(targetCode)) {
        return true
      } else if(originStatusCode === '20' && targetCode === '10') {
        return true
      }
      return false
    },
    openCompanyPopup() {
      // 진행상태 완료인지 check
      if(this.data.pgsStCd !== '03') {
        this.alertMessage = '진행 상태를 완료한 후 진행해주세요.'
        this.alertMessagePop = true
        return
      } else {
        this.popVisibleCompany = true
        this.$refs.companyPop.companyPopOpen()
      }
    },
    settingCompany(companyData) {

      this.data.firmCd = companyData.afcoCd
      this.data.firmNm = companyData.afcoNm
      this.data.aplScnCd = companyData.afcoSncCd
      this.data.bzNo = companyData.bzNo

    },
    changeFilter(obj) {
      const { neceDocTargNo, neceDocNo, workProcessDetailResultCode } = obj
      if(neceDocTargNo === 'all' && neceDocNo === 'all' && workProcessDetailResultCode === 'all') {
        this.documentList = this.settingDocumentList
      } else {
        this.documentList = this.settingDocumentList.filter((items) => {
          return (neceDocTargNo !== 'all' ? items.neceDocTargNo === neceDocTargNo : true) &&
                 (neceDocNo !== 'all' ? items.neceDocNo === neceDocNo : true) &&
                 (workProcessDetailResultCode !== 'all' ? items.workProcessDetailResultCode === workProcessDetailResultCode : true)
        })
      }
    },
    // 파일업로드
    async handleChange(file) {
      if (file) {
        const allowedTypes = [
          'image/jpg',
          'image/jpeg',
          'image/gif',
          'application/pdf'
        ] // 허용 가능한 파일
        let formData = new FormData()
        if (allowedTypes.includes(file.raw.type)) {
          formData.append('file', file.raw)
          formData.append('fileBizTypeCode', '015')
          formData.append('privateYn', 'Y')
          formData.append('customerNumber', this.userInfo.eeno)

          // 파일 크기 체크 (3MB)
          const size = 10485760
          if (file.size > size) {
            this.alertMessagePop = true
            this.alertMessage = '파일당 10MB 를 넘지 않아야 합니다'
            return
          }

          const [res, err] = await this.$https.postMultiPart(
            '/common/v2/common/file/upload/files',
            formData,
            null,
            'gateway'
          ) // API-WE-공통서비스-004_파일 업로드

          if (!err) {
            let idx = Number(this.uploadDocumentIndex) - 1
            // upload된 file Group sn 문서 목록에 setting
            this.documentList[idx].fileGroupSerialNumber = res.data.fileGroupSn || ''
            this.documentList[idx].attcFilNm = file.name
          } 
          // 전담이 대신 등록해준 파일의 경우
          // 처리결과+진행사항메모 입력은 필수.
          // 저장시 요청/등록/처리일시 모두 동일하게 처리.
        } else {
          this.$refs.upload.clearFiles() // 파일 초기화
          this.alertMessage = '허용되지 않는 확장자입니다.'
          this.alertMessagePop = true
        }
      }
    },
    async rememberIdex(no){
      this.uploadDocumentIndex = no
    },
    async getFileData(row) {
      const { fileGroupSerialNumber: fileGroupSn = ''} = row
      const [res, err] = await this.$https.get('/common/v2/common/file/inquiry/' + fileGroupSn , null, null, 'gateway')

      if(!err) {
        // screenUseTypeCode (01:열람,02:수정,03:삭제,04:인쇄,05:입력,06:업로드,07:다운로드)
        this.$store.dispatch('commonSupportLog', { vm: this, params: { screenUseTypeCode: '07', useInfo: JSON.stringify({ workAssignNumber: this.data.workAssignNumber }), fileName: res.data[0].fileName, fileSize: res.data[0].fileCapa } })
        this.fileData = res.data[0]
        this.downloadLink()
      }
    },
    async downloadLink() {
      const { fileSn, fileGroupSn, fileName, fileExtentions } = this.fileData
      const [res, err] = await this.$https.getb('/common/v2/common/file/download/'+ fileGroupSn  + '/' + fileSn, null, null, 'gateway')

      if(!err) {
        const blob = new Blob([res], {type : fileExtentions })
        if(window.navigator.msSaveOrOpenBlob) {
          // IE11
          window.navigator.msSaveOrOpenBlob(blob, fileName)
        } else {
          // IE11 외 브라우저
          const blobURL = window.URL.createObjectURL(blob)
          const tempLink = document.createElement('a')

          tempLink.href = blobURL

          tempLink.setAttribute('download', fileName)
          document.body.appendChild(tempLink)
          tempLink.click()
          document.body.removeChild(tempLink)
          window.URL.revokeObjectURL(blobURL)
        }
      }
    },
    conditonSetting(target){
      this.data.csmrLossCd = target.csmrLossCd
      this.data.csmrTypeCd = target.csmrTypeCd
      this.data.coCd = target.csmrTypeCd/* 회사(소속) code setting */
      /* [#9840/2021.12.17/A936506] 재구매 제한여부 컬럼 추가 Start */
      let rePurchaseRestrictYn = target.rePurchaseRestrictYn  

      if(rePurchaseRestrictYn === 'N') {
        this.$emit('setRePurchaseRestrict', rePurchaseRestrictYn)
      }
      /* [#9840/2021.12.17/A936506] 재구매 제한여부 컬럼 추가 End */

      // 조견표에 업체코드가 있는 경우 해당 데이터는 국판에 넘기지 않는다
      if(target.firmCd) {
        this.data.firmCd = target.firmCd
        this.data.dsDataTargetYn = 'N'
      } else {
        this.data.firmCd = ''
        this.data.dsDataTargetYn = 'Y'
      }

      // 팝업 Messeag 안내문구가 나가야하는 유형
      for(var type of this.conditionMsgType) {
        if(this.data.coCd === type) {
          this.alertMessage = '해당 직원은 계약 시 『일반개인』으로 진행 후, 차량대금 『결제당일』 직원 인증 요청하여 할인 적용이 필요한 대상입니다.\r\n→사유 : 국판시스템內 직원 등록 시 당일만 적용이 유효한 직원으로 결제당일 인증 진행 필요\r\n\r\n※ 판매대리점 인원의 경우 - 소속이동에 따른 기간인정 및 실적반영 미대상은 해당 없음'
          this.alertMessagePop = true 
        }
      }
      // 기본서류 + 추가서류 둘다 조회
      // 소속에 따른 추가 서류 setting method 
      this.settingAddConditionDocumnet(target)
    },
    async settingAddConditionDocumnet(target) {
      let bascPpSubjNo = target.bascPpSubjNo // 기본서류 대상번호
      let addPpSubjNo = target.addPpSubjNo   // 추가서류 대상번호

      let addDocList = []
      this.paperReviewData = []

      addDocList.push(
        {
          neceDocTargNo :bascPpSubjNo, 
          attcScnCd : '01',
          additionPapersYn: 'N'
        }
      )
      if(addPpSubjNo) { 
        addDocList.push(
          {
            neceDocTargNo :addPpSubjNo, 
            attcScnCd : '02',
            additionPapersYn: 'Y'
          }
        )
      }

      for(var doc of addDocList) {
        const [res1, err1] = await this.$https.get('/v2/exclusive/employeeAuth/request/papers', { neceDocTargNo : doc.neceDocTargNo})
        if(!err1) {
          this.paperReviewData = res1.data.map((el, idx) => {
            return {
              ...el,
              scrapingResult: el.scrapingResult ? el.scrapingResult : 'N',
              papersSectionalName: el.neceDocTargNm,
              papersTypeName: el.neceDocNm,
              isAdd: true,
              isEdit:true,
              addRowKey: idx++,
              workProcessDetailResultCode: '10',  // 추가서류(대기)
              attcScnCd: doc.attcScnCd,
              additionPapersYn: doc.additionPapersYn
            }
          })
        
          this.$refs.paperInfo.addReviewPaperRow(this.paperReviewData)
          this.paperReviewData = [] // 초기화
                  
        } else {
          console.log('request/papers err : ', err1) 
        }

      }

    },
    // process.vue 파일에 정제된 DocumentList 넘기기
    async setDocumentList() {
      // reviewData setting
      await this.setSaveDocumentList()

      let paramDocList = {
        documentList : this.documentList,
        paperReviewData : this.paperReviewData
      }

      this.$emit('setDocumentList', paramDocList, this.data)
    }
  }
        
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
.btn-md{
  min-width: 40px;
  height: 40px;
}
.append-box {
  .el-input, .el-select {
    margin:2px 0;
  }
}
</style>