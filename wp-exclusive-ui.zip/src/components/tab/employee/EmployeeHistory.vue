<template>
    <div>
        <div class="article-title">
            <h2>직원인증 이력</h2>
        </div>
        <div class="box">
            <el-table
            :data="authHistoryList"
            >
            <el-table-column prop="rowNo" label="NO." width="60" align="center"></el-table-column>
            <el-table-column prop="vbgInpDtm" label="요청일시" width="200" align="center"></el-table-column>
            <el-table-column prop="csetDtm" label="처리일시" width="200" align="center"></el-table-column>
            <el-table-column prop="coCdNm" label="소속" width="360"></el-table-column>
            <el-table-column prop="dcSbc" label="할인률" width="319"></el-table-column>
            <el-table-column prop="managerName" label="업무처리자" width="150" align="center"></el-table-column>
            <el-table-column prop="progressState" label="진행상태" width="150" align="center"></el-table-column>
            <el-table-column prop="employeeYn" label="직원여부" width="100" align="center"></el-table-column>
            </el-table>
        </div>

        <div class="article-title">
            <h2>문자 이력</h2>
        </div>
        <div class="box">
          <el-table 
            :data="messageData"
            max-height="450"
            empty-text="조회된 결과가 존재하지 않습니다."
            @row-click="onRowClick"
            >
            <el-table-column
                label="No."
                prop="no"
                width="50"
                align="center"
            />
            <el-table-column
                label="계약번호"
                prop="contractNumber"
                width="150"
                align="center"
            />
            <el-table-column
                label="수신자명"
                prop="adresseeName"
                width="100"
                align="center"
            />
            <el-table-column
                label="전화번호"
                prop="adresseeMobile"
                width="140"
                align="center"
            />
            <el-table-column
                label="발송일시"
                prop="sendDate"
                width="140"
                align="center"
            >
                <template slot-scope="scope">
                <el-button
                    type="text"
                    @click="popContentVisible = true"
                >
                    {{ scope.row.sendDate }}
                </el-button>
                </template>
            </el-table-column>
            <el-table-column
                label="구분"
                prop="sendSectionalName"
                width="116"
                align="center"
            />
            <el-table-column
                label="제목"
                prop="messageTitle"
                width="170"
                align="center"
            />
            <el-table-column
                label="본문"
                prop="messageContents"
                align="center"
            />
            <el-table-column
                label="보낸사람"
                prop="dispatcherName"
                width="80"
                align="center"
            />
            <el-table-column
                label="발신전화번호"
                prop="sendMobile"
                width="120"
                align="center"
            />
            <el-table-column
                label="발송상태"
                prop="sendState"
                width="70"
                align="center"
            />
            <el-table-column
              prop="col12"
              label="비고"
              align="center"
              width="100"
            >
              <template slot-scope="props">
                <el-button 
                  v-if="props.row.messageTypeCode === 'KAT'"
                  type="primary"
                  @click="reSend(props.row.messageTypeCode)"
                >
                  재전송
                </el-button>
              </template>
            </el-table-column>
            </el-table>
            <!-- 내용보기 팝업 -->
            <el-dialog
            title="내용보기"
            :visible.sync="popContentVisible"
            width="1100px"
            >
            <!-- Popup Contents -->
            <h-title :title="'수신자 정보'" />
            <el-form
                ref="smsInfo"
                :model="smsInfo"
                class="detail-form message-content-pop"
            >
                <el-row>
                <el-col :span="8">
                    <el-form-item label="수신자명">
                    {{ smsInfo.contractName }}
                    </el-form-item>
                </el-col>
                <el-col :span="8">
                    <el-form-item label="휴대번호전화">
                    {{ smsInfo.mobileNumber }}
                    </el-form-item>
                </el-col>
                <el-col :span="8">
                    <el-form-item label="발송일시">
                    {{ smsInfo.sendDateTime }}
                    </el-form-item>
                </el-col>
                </el-row>
            </el-form><h-title :title="'발신내용'" />

            <el-form
                ref="smsInfo"
                :model="smsInfo"
                class="detail-form message-content-pop"
            >
                <el-row>
                <el-col :span="24">
                    <el-form-item label="제목">
                    <el-input
                        v-model="smsInfo.smsTitle"
                        class="mms-title"
                        :readonly="!['SMS', 'MMS', 'LMS'].includes(smsInfo.sndTypeCd)"
                        @blur="smsInfo.smsTitle = $event.target.value"
                    />
                    </el-form-item>
                </el-col>
                </el-row>
                <el-row>
                <el-col :span="24">
                    <el-form-item label="내용">
                    <el-input
                        v-model="smsInfo.smsContent"
                        type="textarea"
                        :readonly="!['SMS', 'MMS', 'LMS'].includes(smsInfo.sndTypeCd)"
                        @blur="smsInfo.smsContent = $event.target.value"
                    />
                    </el-form-item>
                </el-col>
                </el-row>
            </el-form>

            <!-- Popup Footer -->
            <template slot="footer">
                <el-button
                v-if="['KAT', 'SMS', 'MMS', 'LMS'].includes(smsInfo.sndTypeCd)"
                type="primary"
                @click="reSend(smsInfo.sndTypeCd)"
                >
                재전송
                </el-button>
            </template>
            </el-dialog>
            <!-- message Popup -->
            <pop-message
            :pop-visible.sync="alertMessagePop"
            :pop-message.sync="alertMessage"
            @confirm="alertMessagePop = false"
            @close="alertMessagePop = false"
            />
        </div>
    </div>
</template>

<script>
import HTitle from '~/components/common/HTitle.vue'
import PopMessage from '~/components/popup/PopMessage.vue'

export default {
  name: 'EmployeeHistory',
  components: {
    HTitle,
    PopMessage
  },
  props: {
    data: {
      type: Object,
      default: null
    }
  },
  data() {
    return {
      workAssignNumber: '',
      authHistoryList : [],
      alertMessage: '',
      alertMessagePop: false,
      popContentVisible: false,
      messageData:[],
      smsInfo: {
        contractName: '',
        mobileNumber: '',
        sendDateTime: '',
        smsTitle: '',
        smsContent: ''
      }
    }
  },
  async created() {
    await this.getSmsHistoryData()
    await this.getEmployeeAuthHistoryData()
  },
  methods: {
    // 문자 이력 조회
    async getSmsHistoryData() {

      const [res, err] = await this.$https.post('/v2/exclusive/employeeAuth/history/sms', { workAssignNumber: this.data.workAssignNumber, pageNo : '1', pageSize: '100' })
      if(!err && res.data) {
        this.messageData = res.data.list && res.data.list.map((el, idx) => {
          return {
            ...el,
            no : idx+1,
          }
        })
      } else {
        console.error(err)
      }
    },
    async getEmployeeAuthHistoryData() {
      const [res,err] = await this.$https.post('/v2/exclusive/employeeAuth/history/auth', { customerManagementNumber : this.data.customerManagementNumber })

      if(!err && res.data) {
        this.authHistoryList = res.data
      }
    },
    async onRowClick(row, column) {
      if(column.property === 'col12') return 

      this.popContentVisible = true
      const { workSmsSendSerialNumber = '' } = row

      if(!workSmsSendSerialNumber) return

      // API-E-업무담당자-108 (문자발송 상세 조회)
      const [res, err] = await this.$https.post('/v2/exclusive/common/sms-content', { workSmsSendSerialNumber })

      if(!err) {

        console.log(res)
        this.smsInfo = res.data
      } else {
        console.error(err)
      }
    },
    async reSend(sndTypeCd) { // 재전송
      this.popContentVisible = false
      const { smsSendSerialNumber = '', smsTitle = '', smsContent = '' } = this.smsInfo

      const params = {
        msgItgSndSn: smsSendSerialNumber, // 메시지통합발송일련번호
        sndTypeCd: sndTypeCd !== 'KAT' ? 'MMS' : sndTypeCd, // 발송유형코드
        messageTitle: smsTitle, // 메시지제목
        messageContents: smsContent, // 메시지내용
        workAssignNumber: this.data.workAssignNumber 	// 업무번호
      }
      const [res, err] = await this.$https.post('/v2/exclusive/common/sms-resend', params) // API-E-업무담당자-109 (문자 재전송 API)

      if(!err) {
        if(res.rspStatus && res.rspStatus.rspCode === '0000') {
          if(sndTypeCd === 'KAT'){
            this.alertMessage = '카카오톡이 재전송되었습니다'
          }else{
            this.alertMessage = '문자가 재전송되었습니다.'
          }
          this.alertMessagePop = true
          this.$emit('refresh', true)
        }
        console.log(res)
      } else {
        console.error(err)
      }
    }
  }
}
</script>