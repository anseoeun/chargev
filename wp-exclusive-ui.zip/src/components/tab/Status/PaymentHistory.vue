<template>
    <div>
        <h-title :title="'결제 처리 변경 이력'" />
        <h-table
        :table-type="'DefultTable'"
        :table-header="conditions"
        :table-datas="paymentData"
        />
    </div>
</template>

<script>
import HTitle from '~/components/common/HTitle.vue'
import HTable from '~/components/common/HTable.vue'
export default {
  name: 'PaymentHistory',
  components: {
    HTable,
    HTitle,
  },
  props: {
    contractNumber: {
      type: String,
      default: ''
    },
  },
  data() {
      return {
          paymentData: [],
          conditions:[
            {
                label: '회차',
                prop: 'paymentOrder',
                type: '',
                width: '50',
                align: 'center'
            },
            {
                label: '결제내역',
                prop: 'paymentTypeName',
                type: '',
                align: 'center',
                width: '80'
            },
            {
                label: '결제방법',
                prop: 'paymentContents',
                type: '',
                width: '210'
            },
            {
                label: '결제자/입금자',
                prop: 'paymentPersonName',
                type: '',
                align: 'center'
            },
            {
                label: '진행상태',
                prop: 'paymentStateName',
                type: '',
                align: 'center',
                width: '80'
            },
            {
                label: '결제금액',
                prop: 'paymentPrice',
                type: '',
                align: 'center'
            },
            {
                label: '결제입력일시',
                prop: 'paymentRequestDate',
                type: '',
                align: 'center'
            },
            {
                label: '결제처리일시',
                prop: 'paymentDate',
                type: '',
                align: 'center'
            },
            {
                label: '환불금액',
                prop: 'refundPrice',
                type: '',
                align: 'center'
            },
            {
                label: '환불요청일시',
                prop: 'refundRequestDate',
                type: '',
                align: 'center'
            },
            {
                label: '환불처리일시',
                prop: 'refundDate',
                type: '',
                align: 'center'
            },
            {
                label: '환불 처리결제상태',
                prop: 'refundStateName',
                type: '',
                align: 'center',
                width: '120'
            },
            {
                label: '처리자',
                prop: 'processPersonName',
                type: '',
                align: 'center'
            }
        ],
      }
  },
  created() {
  },
  mounted() {

  },
  methods: {
      async getPaymentHistoryData() {
        const [res, err] = await this.$https.post('/v2/exclusive/work/history/payment', { contractNumber: this.contractNumber })
        if(!err) {
            console.log('SUCCESS :: /work/history/payment/', res.data)
            this.paymentData = res.data.map((el) => {
            return {
                ...el,
                paymentPrice: el.paymentPrice ? (el.paymentPrice*1).toLocaleString()+'원' : '',
                paymentContents: el.paymentTypeCode !== '30' ? el.paymentContents : (el.virtualAccount ? el.paymentContents + '\n - 계좌번호: ' + el.virtualAccount : el.paymentContents),
                refundPrice: el.refundPrice ? (el.refundPrice*1).toLocaleString()+'원' : ''
            }
            })
        } else {
            console.error(err)
        }
      }
  }
}
</script>