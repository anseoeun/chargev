<template>
  <div>
    <h-title :title="'포인트 처리 변경 이력'" />
    <h-table
      :table-type="'DefultTable'"
      :table-header="conditions"
      :table-datas="pointData"
    />
  </div>
</template>

<script>
import HTitle from '~/components/common/HTitle.vue'
import HTable from '~/components/common/HTable.vue'
export default {
    name:'PointHistory',
    components: {
      HTable,
      HTitle,
    },
    props: {
      contractNumber: {
        type: String,
        default: ""
      },
    },
    data() {
        return {
          pointData:[],
          conditions:[ // 포인트 처리 결제
            {
                label: 'No.',
                prop: 'no',
                type: '',
                width: '80',
                align: 'center'
            },
            {
                label: '포인트종류',
                prop: 'pointName',
                type: '',
                align: 'center'
            },
            {
                label: '결제자',
                prop: 'pointUsePersonName',
                type: '',
                align: 'center'
            },
            {
                label: '진행상태',
                prop: 'pointUseState',
                type: '',
                align: 'center'
            },
            {
                label: '결제금액',
                prop: 'pointUsePrice',
                type: '',
                align: 'center'
            },
            {
                label: '제휴사분담금액',
                prop: 'partnerAssignmentPrice',
                type: '',
                align: 'center'
            },
            {
                label: '당사분담금액',
                prop: 'companyAssignmentPrice',
                type: '',
                align: 'center'
            },
            {
                label: '처리요청일시',
                prop: 'pointProcessRequestDate',
                type: '',
                align: 'center'
            },
            {
                label: '처리일시',
                prop: 'pointProcessDate',
                type: '',
                align: 'center'
            },
            {
                label: '처리자',
                prop: 'processPersonName',
                type: '',
                align: 'center'
            }
          ],
        }
    },
    created() {

    },
    mounted() {

    },
    methods: {
        async getPointHistoryData() {
            const [res, err] = await this.$https.post('/v2/exclusive/work/history/point', { contractNumber: this.contractNumber })
            if(!err) {
                console.log('SUCCESS : /work/history/point/', res.data)
                this.pointData= res.data.map((items, idx) => {
                return {
                    ...items,
                    no: idx + 1,
                    pointUsePrice: items.pointUsePrice.toLocaleString() + '원', // 포인트 사용금액
                    partnerAssignmentPrice: items.partnerAssignmentPrice.toLocaleString() + '원', // 제휴사분담금액
                    companyAssignmentPrice: items.companyAssignmentPrice.toLocaleString() + '원' // 당사분담금액
                }
                })
            } else {
                console.error(err)
            }
        }
    },


}
</script>