<template>
  <div>
    <h-title :title="'국판 호출 로그 이력'" />
    <h-table
      :table-type="'DefultTable'"
      :table-header="conditions"
      :table-datas="apiLogData"
      :handle-row-click="handleRowClick"
    />
    <!-- 로그 상세보기 팝업 -->
    <el-dialog
      title="로그 상세보기"
      :visible.sync="popLogDetail"
      width="1000px"
    >
      <!-- Popup Contents -->
      <el-form
        ref="logInfo"
        :model="logInfo"
        class="detail-form"
      >
        <el-row>
          <el-col :span="24">
            <el-form-item label="일시">
              {{ logInfo.siteConnectTime }}
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item
              label="로그내용">
              <el-input
                v-model="logInfo.logDetail"
                type="textarea"
                :readonly="true"
              />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </el-dialog>  
  </div>
</template>

<script>
import HTitle from '~/components/common/HTitle.vue'
import HTable from '~/components/common/HTable.vue'
export default {
  name: 'ApiHistory',
  components: {
      HTitle,
      HTable
  },
  props: {
    contractNumber: {
      type: String,
      default: ""
    },
  },
  data() {
    return {
      apiLogData: [],
      conditions: [
        {
          label: 'NO.',
          prop: 'no',
          type: '',
          width: '80',
          align: 'center'
        },
        {
          label: '시간',
          prop: 'siteConnectTime',
          type: '',
          width: '200',
          align: 'center'
        },
        {
          label: '내용',
          prop: 'logHead',
          type: '',
          align: 'center'
        }
      ],
      popLogDetail:false,
      logInfo: {
        siteConnectTime:'',
        logDetail:''
      }
    }
  },
  created() {

  },
  mounted() {

  },
  methods: {
    async getApiLogHistoryData() {
      const [res, err] = await this.$https.get('/v2/exclusive/work/history/apilog/'+this.contractNumber)
      if(!err) {
        //console.log('/work/history/apilog/', res.data)
        this.apiLogData = res.data && res.data.map((el, idx) => {
          return {
            ...el,
            no : res.data.length - idx,
            siteConnectTime: el.siteConnectTime? el.siteConnectTime.split('.')[0]:null
          }
        })

        console.log('SUCCESS :: /work/history/apilog/', this.apiLogData)
      } else {
        console.error(err)
      }
    },
      
    handleRowClick(row){
        this.popLogDetail=true
        this.logInfo=row
    },
  }

}
</script>

<style>

</style>