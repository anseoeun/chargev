<template>
  <div>
    <h-title :title="'매출 변경 이력'" />
    <h-table
      :table-type="'DefultTable'"
      :table-header="conditions"
      :table-datas="salesData"
    />
  </div>
</template>

<script>
import HTitle from '~/components/common/HTitle.vue'
import HTable from '~/components/common/HTable.vue'
export default {
  name: 'SalesHistory',
  components: {
    HTable,
    HTitle,
  },
  props: {
    contractNumber: {
      type: String,
      default: ''
    },
  },
  data() {
    return {
      salesData: [],
      conditions:[
        {
          label: '변경내역',
          width: '200',
          prop: 'changeContents',
          type: '',
          align: 'center',
          fixed: 'fixed'
        },
        {
          label: '계약자명',
          width: '200',
          prop: 'contractorName',
          type: '',
          align: 'center',
          fixed: 'fixed'
        },
        {
          label: '과세구분',
          width: '200',
          prop: 'taxationSectionalName',
          type: '',
          align: 'center'
        },
        {
          label: '차량가격',
          width: '200',
          prop: 'carPrice',
          type: '',
          align: 'center'
        },
        {
          label: '할인금액',
          width: '200',
          prop: 'discountPrice',
          type: '',
          align: 'center'
        },
        {
          label: '포인트',
          width: '200',
          prop: 'usePoint',
          type: '',
          align: 'center'
        },
        {
          label: '판매가격',
          width: '200',
          prop: 'salePrice',
          type: '',
          align: 'center'
        },
        {
          label: '계약/인도금',
          width: '200',
          prop: 'contractPrice',
          type: '',
          align: 'center'
        },
        {
          label: '판매유형',
          width: '200',
          prop: 'saleTypeName',
          type: '',
          align: 'center'
        },
        {
          label: '할부원금',
          width: '200',
          prop: 'installmentPrincipal',
          type: '',
          align: 'center'
        },
        {
          label: '신용카드계',
          width: '200',
          prop: 'cardPaymentPrice',
          type: '',
          align: 'center'
        },
        {
          label: '세금계산서',
          width: '200',
          prop: 'tax',
          type: '',
          align: 'center'
        },
        {
          label: '처리일시',
          width: '200',
          prop: 'processDate',
          type: '',
          align: 'center'
        },
        {
          label: '처리자',
          width: '200',
          prop: 'processPersonName',
          type: '',
          align: 'center'
        }
      ],
    }
  },
  methods: {
    async getSalesHistoryData() {
      const [res, err] = await this.$https.get('/v2/exclusive/work/history/sales/' + this.contractNumber)
      if(!err) {
        console.log('SUCCESS :: /work/history/sales/', res.data)
        this.salesData = res.data.map((el) => {
          return {
            ...el,
            carPrice: el.carPrice && (el.carPrice*1).toLocaleString()+' 원',
            discountPrice: el.discountPrice && (el.discountPrice*1).toLocaleString()+' 원',
            usePoint: el.usePoint && (el.usePoint*1).toLocaleString(),
            salePrice: el.salePrice && (el.salePrice*1).toLocaleString()+' 원',
            contractPrice: el.contractPrice && (el.contractPrice*1).toLocaleString()+' 원',
            installmentPrincipal: el.installmentPrincipal && (el.installmentPrincipal*1).toLocaleString()+' 원',
            cardPaymentPrice: el.cardPaymentPrice && (el.cardPaymentPrice*1).toLocaleString()+' 원',
            tax: el.tax && (el.tax*1).toLocaleString()+' 원',
          }
        })
      } else {
        console.error(err)
      }
    }
  }
}
</script>