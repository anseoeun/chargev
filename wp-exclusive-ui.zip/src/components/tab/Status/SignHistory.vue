<template>
  <div>
    <h-title :title="'전자 서명 이력'" />
    <h-table
      :table-type="'DefultTable'"
      :table-header="conditions"
      :table-datas="signData"
    />
  </div>
</template>

<script>
import HTitle from '~/components/common/HTitle.vue'
import HTable from '~/components/common/HTable.vue'
export default {
  name: 'SignHistory',
  components: {
    HTable,
    HTitle,
  },
  props: {
    contractNumber: {
      type: String,
      default: ""
    },
  },
  data() {
    return {
        signData: [],
        conditions:[
        {
          label: '차수',
          prop: 'electronSignOrder',
          type: '',
          width: '80',
          align: 'center'
        },
        {
          label: '이름',
          prop: 'customerName',
          type: '',
          align: 'center'
        },
        {
          label: '구분',
          prop: 'contractorSectionalName',
          type: '',
          align: 'center'
        },
        {
          label: '계약변경시간',
          prop: 'contractAlterationDate',
          type: '',
          align: 'center'
        },
        {
          label: '전자서명 요청시간',
          prop: 'electronSignRequestDate',
          type: '',
          align: 'center'
        },
        {
          label: '전자서명 완료시간',
          prop: 'electronSignCompleteDate',
          type: '',
          align: 'center'
        }
      ],

    }
  },
  created() {

  },
  mounted() {

  },
  methods: {
      async getSignHistoryData() {
        const [res, err] = await this.$https.get('/v2/exclusive/work/history/electron/'+this.contractNumber)
        if(!err) {
          console.log('SUCCESS :: /work/history/electron/', res.data)
          this.signData = res.data
        } else {
          console.error(err)
        }
      }

  }

}
</script>