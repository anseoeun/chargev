<template>
  <div>
      <h-title :title="'서류심사 이력'" />
        <el-form
        ref="ruleForm"
        :model="ruleForm"
        class="detail-form"
        style="margin-top:10px;"
        >
        <el-row>
            <el-col :span="6">
            <el-form-item label="분류">
                <el-select
                  v-model="ruleForm.documentType"
                  placeholder="선택"
                  @change="onChangeDocumentType"
                >
                    <el-option
                      v-for="{ value, label } in documentTypeList"
                      :key="value"
                      :value="value"
                      :label="label"
                    />
                </el-select>
            </el-form-item>
            </el-col>
            <el-col :span="6">
            <el-form-item label="용도">
                <el-select
                v-model="ruleForm.neceDocTargNo"
                @change="documentTargetChanged"
                >
                <el-option
                    v-for="{ neceDocTargNo, neceDocTargNm } in documentTargets"
                    :key="neceDocTargNo"
                    :value="neceDocTargNo"
                    :label="neceDocTargNm"
                />
                </el-select>
            </el-form-item>
            </el-col>
            <el-col :span="6">
            <el-form-item label="서류">
                <el-select
                v-model="ruleForm.neceDocNo"
                >
                <el-option
                    v-for="{ neceDocNo, neceDocNm } in paperTypes"
                    :key="neceDocNo"
                    :value="neceDocNo"
                    :label="neceDocNm"
                />
                </el-select>
            </el-form-item>
            </el-col>
            <el-col :span="6">
            <el-form-item label="상태">
                <el-select
                v-model="ruleForm.workProcessDetailResultCode"
                >
                <el-option
                    v-for="{ value, label } in commonCodes.T002"
                    :key="value"
                    :value="value"
                    :label="label"
                />
                </el-select>
            </el-form-item>
            </el-col>
        </el-row>
        </el-form>
        <h-table
        :table-type="'DefultTable'"
        :table-header="conditions"
        :table-datas="filterReviewList || paperList"
        class="pdt20"
        />
  </div>
</template>

<script>
import HTitle from '~/components/common/HTitle.vue'
import HTable from '~/components/common/HTable.vue'
import { mapState, mapGetters } from 'vuex'
export default {
  name: 'PaperHistory',
  components: {
    HTitle,
    HTable,
  },
  props: {
    contractNumber: {
      type: String,
      default: ''
    },
  },
  data() {
    return {
      paperData: [],
      documentTargets : [{ neceDocTargNo: 'all', neceDocTargNm: '전체' }],
      documentTypeList: [{ value: 'all', label: '전체' }],
      ruleForm: { documentType: 'all', neceDocTargNo: 'all', neceDocNo: 'all', workProcessDetailResultCode: 'all'},
      paperTypes: [{ neceDocNo: 'all', neceDocNm: '전체' }],
      conditions: [
        {
          label: 'No.',
          prop: 'no',
          type: '',
          width: '60',
          align: 'center'
        },
        {
          label: '분류',
          prop: 'papersName',
          type: '',
          width: '90',
          align: 'center'
        },
        {
          label: '용도',
          prop: 'papersSectionalName',
          type: '',
          width: '260',
          align: 'center'
        },
        {
          label: '서류',
          prop: 'papersTypeName',
          type: '',
          width: '200',
          align: 'center'
        },
        {
          label: '스크래핑 여부',
          prop: 'scrapingTargetYn',
          type: '',
          width: '90',
          align: 'center'
        },
        {
          label: '스크래핑 결과',
          prop: 'scrapingResult',
          type: '',
          width: '90',
          align: 'center'
        },
        {
          label: '추가서류여부',
          prop: 'additionPapersYn',
          type: '',
          align: 'center'
        },
        {
          label: '제출서류',
          prop: 'papersNameListStr',
          type: '',
          align: 'center'
        },
        {
          label: '서류요청일시',
          prop: 'papersRequestDate',
          type: '',
          width: '140',
          align: 'center'
        },
        {
          label: '상태변경일시',
          prop: 'papersExaminationDate',
          type: '',
          width: '140',
          align: 'center'
        },
        {
          label: '상태',
          prop: 'papersExaminationState',
          type: '',
          width: '60',
          align: 'center'
        },
        {
          label: '처리내용',
          prop: 'papersExaminationContents',
          type: '',
          align: 'center'
        },
        {
          label: '처리자',
          prop: 'processPersonName',
          type: '',
          width: '120',
          align: 'center'
        }
      ],
      filterReviewList: null,
      commonCodes: {},
    }
  },
  computed: {
    ...mapState({
      // documentTargets: state => state.documentTargets.filter((items) => { return items.neceDocTargNm !== '전체'}), // 전체 항목 제외
    }),
    paperList: function () {
      return this.paperData
    }
  },
  watch: {
    ruleForm: {
      handler(obj) {
        this.changeFilter(obj)
      },
      deep: true
    }
  },
  async created() {
    await this.loadCommonCode()
  },
  mounted() {

  },
  methods: {
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null
      switch(systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {vm: this, codeTypeCode: codeType})
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {vm: this, codeTypeCode: codeType})
        break
      }
      return res
    },
    async loadCommonCode() {
      const [ccT002, ccT072] = await Promise.all([
        this.fetchCommonCodeData('E', 'T002'), //상태
        this.fetchCommonCodeData('E', 'T072')
      ])

      this.commonCodes = { ...ccT002, ...ccT072 }
      this.documentTypeList = this.commonCodes.T072.filter((items) => {
        if (items.value !== '005') {
          return items
        }
      })
    },
    async getPaperHistoryData() {
      const [res, err] = await this.$https.get('/v2/exclusive/work/history/papers/'+this.contractNumber)
      if(!err) {
        console.log('/work/history/papers/', res.data)
        let arr = res.data.filter((items) => {
          if(items.papersCode !== '005') {
            return items
          }
        })
        this.paperData = arr.map((el, idx) => {
          return {
            ...el,
            no : idx+1,
            papersNameListStr : el.papersNameList.join(', ')
          }
        })
      } else {
        console.error(err)
      }
    },
    async documentTargetChanged(val) {
      const [res,err] = await this.$https.get('/v2/exclusive/contract/papers', { neceDocTargNo: val }) //API-E-업무담당자-047 (필요서류목록 조회)
      if (!err) {
        this.paperTypes = [{'neceDocNo': 'all', 'neceDocNm': '전체'}, ...res.data]
        this.ruleForm.neceDocNo = 'all'
      }
    },
    async onChangeDocumentType(data) {
      const [res, err] = await this.$https.get(
        '/v2/exclusive/mypage/document/target/' + data
      )
      if (!err) {
        console.log(res)
        this.documentTargets = [{'neceDocTargNo': 'all', 'neceDocTargNm': '전체'}, ...res.data]
        
        this.ruleForm.neceDocTargNo = 'all'
        this.ruleForm.neceDocNo = 'all'
      } else {
        console.error(err)
      }
    },
    changeFilter(obj) {
      const { documentType, neceDocTargNo, neceDocNo, workProcessDetailResultCode } = obj
      if(documentType === 'all' && neceDocTargNo === 'all' && neceDocNo === 'all' && workProcessDetailResultCode === 'all') {
        return this.filterReviewList = this.paperList
      } else {
        this.filterReviewList = this.paperList.filter((items) => {

          console.log('items :: '+items.papersExaminationStateCode)
          console.log('neceDocNo :: '+neceDocNo)

          return (documentType !== 'all' ? items.papersCode === documentType : true) &&
        (neceDocTargNo !== 'all' ? items.papersSectionalCode === neceDocTargNo : true) &&
        (neceDocNo !== 'all' ? items.papersTypeCode === neceDocNo : true) &&
        (workProcessDetailResultCode !== 'all' ? items.papersExaminationStateCode === workProcessDetailResultCode : true)
        })

        if(this.filterReviewList) {
          this.filterReviewList = this.filterReviewList.map((el, idx) => {
            return {
              ...el,
              no: idx + 1
            }
          })
        }
      }
    },
  }

}
</script>
<style lang="scss" scoped>
.pdt20{
  padding-top: 20px;
}
</style>