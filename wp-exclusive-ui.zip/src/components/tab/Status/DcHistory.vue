<template>
  <div>
    <h-title :title="'전담DC 품의 이력'" />
    <el-table :data="dcHistoryData">
      <el-table-column prop="pecSaleCnsuNo" label="품의번호" width="166" align="center"></el-table-column>
      <el-table-column prop="acpcEenm" label="요청자" width="166" align="center"></el-table-column>
      <el-table-column prop="cnsuPrvsDtl" label="사유" width="194" align="center"></el-table-column>
      <el-table-column prop="rqDtm" label="요청일시" width="170" align="center"></el-table-column>
      <el-table-column prop="rqAmt" label="요청금액" width="166" align="center"></el-table-column>
      <el-table-column prop="trtmDtm" label="처리일" width="170" align="center"></el-table-column>
      <el-table-column prop="addDcAmt" label="승인금액" width="170" align="center"></el-table-column>
      <el-table-column prop="csetStCd" label="승인여부" width="166" align="center"></el-table-column>
      <el-table-column prop="dcAplDtm" label="할인적용일시" width="170" align="center"></el-table-column>
    </el-table>
  </div>
</template>
<script>
import HTitle from '~/components/common/HTitle.vue'

export default {
  components: {
    HTitle,
  },
  props: {
    contractNumber: {
      type: String,
      default: ''
    },
  },
  data() {
    return {
      dcHistoryData: [],
    }
  },
  methods: {
    async getDcHistory() {
      let arr = []
      const [res, err] = await this.$https.get('/v2/exclusive/contract/exrsDcHistory/'+this.contractNumber)
      if(!err) {
        if(res.data) {
          arr = res.data.map(el => {
            return {
              pecSaleCnsuNo: el.pecSaleCnsuNo, //품의번호
              acpcEenm: el.acpcEenm ? el.acpcEenm : '-', //요청자
              cnsuPrvsDtl: el.cnsuPrvsDtl, //사유
              rqDtm: el.rqDtm, //요청일시
              rqAmt: el.rqAmt ? el.rqAmt.toLocaleString()+'원' : '', //요청금액
              trtmDtm: el.trtmDtm, //처리일,
              addDcAmt: el.addDcAmt ? el.addDcAmt.toLocaleString()+'원' : '', //승인금액
              csetStCd: el.csetStCd, //승인여부
              dcAplDtm: el.dcAplDtm ? el.dcAplDtm : '', //할인적용일시
            }
          })
        }
      }else {
        console.error('/contract/exrsDcHistory ERROR ::: '+err)
      }
      this.dcHistoryData = arr
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>