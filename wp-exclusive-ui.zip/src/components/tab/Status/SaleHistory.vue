<template>
    <div>
        <h-title :title="'판매 처리 이력'" />
        <h-table
        :table-type="'DefultTable'"
        :table-header="conditions"
        :table-datas="saleData"
        />
    </div>
  
</template>

<script>
import HTitle from '~/components/common/HTitle.vue'
import HTable from '~/components/common/HTable.vue'
import moment from 'moment'
export default {
  name: 'SaleHistory',
  components: {
    HTable,
    HTitle,
  },
  props: {
    contractNumber: {
      type: String,
      default: ''
    },
  },
  data() {
    return {
      saleData: [],
      conditions:[
        {
          label: '판매진행상태(온라인)',
          prop: 'processStatusName',
          type: '',
          align: 'center'
        },
        {
          label: '레거시 진행상태',
          prop: 'legacyStatusName',
          type: '',
          align: 'center'
        },
        {
          label: '출고예정일',
          prop: 'deliveryPrearrangedDate',
          type: '',
          align: 'center'
        },
        {
          label: '출고일',
          prop: 'deliveryDate',
          type: '',
          align: 'center'
        },
        {
          label: '처리일시',
          prop: 'processDate',
          type: '',
          align: 'center'
        },
        {
          label: '처리자',
          prop: 'processPersonName',
          type: '',
          align: 'center'
        }
      ],
    }
  },
  created() {
  //    await this.getSaleHistoryData();

  },
  mounted() {

  },
  methods: {
    async getSaleHistoryData() {
      const [res, err] = await this.$https.post('/v2/exclusive/work/history/sale', { contractNumber: this.contractNumber })
      if(!err) {
        console.log('SUCCESS :: /work/history/sale/', res.data)
        this.saleData = res.data.map((el) => {
          return {
            ...el,
            deliveryPrearrangedDate: el.deliveryPrearrangedDate ? moment(el.deliveryPrearrangedDate).format('YYYY-MM-DD') : '',          }
        })
      } else {
        console.error(err)
      }
    }

  }

}
</script>
