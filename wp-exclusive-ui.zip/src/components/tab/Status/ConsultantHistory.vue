<template>
  <div>
    <h-title :title="'업무담당자 처리 이력'" />
    <h-table
      :table-type="'DefultTable'"
      :table-header="conditions"
      :table-datas="consultantData"
    />
  </div>
</template>

<script>
import HTitle from '~/components/common/HTitle.vue'
import HTable from '~/components/common/HTable.vue'
export default {
  name: 'ConsultantHistory',
  components: {
    HTable,
    HTitle,
  },
  props: {
    contractNumber: {
      type: String,
      default: ""
    },
  },
  data() {
      return {
          consultantData: [],
          conditions:[
            {
                label: '업무일련번호',
                prop: 'workSerialNumber',
                type: '',
                align: 'center'
            },
            {
                label: '업무유형',
                prop: 'workTypeName',
                type: '',
                align: 'center'
            },
            {
                label: '세부유형',
                prop: 'workDetailTypeName',
                type: '',
                align: 'center'
            },
            {
                label: '처리결과',
                prop: 'workProcessResultName',
                type: '',
                align: 'center'
            },
            {
                label: '차수',
                prop: 'workProcessOrder',
                type: '',
                width: '80',
                align: 'center'
            },
            {
                label: '업무처리 상세',
                prop: 'workProcessDetailResultName',
                type: '',
                align: 'center'
            },
            {
                label: '처리메모 상세',
                prop: 'workProcessDetailContents',
                type: '',
                align: 'center'
            },
            {
                label: '처리메모',
                prop: 'workProcessContents',
                type: '',
                align: 'center'
            },
            {
                label: '처리일시',
                prop: 'processDate',
                type: '',
                align: 'center'
            },
            {
                label: '처리자',
                prop: 'processPersonName',
                type: '',
                align: 'center'
            }
        ],
      }
  },
  created() {

  },
  mounted() {

  },
  methods: {
      async getConsultantHistoryData() {
        const [res, err] = await this.$https.get('/v2/exclusive/work/history/consultant/'+this.contractNumber)
        if(!err) {
            console.log('SUCCESS :: /work/history/consultant/', res.data)
            this.consultantData = res.data
        } else {
            console.error(err)
        }
      }
  }
}
</script>