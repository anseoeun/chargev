<template>
    <div>
        <h-title :title="'계약 변경 이력'" />
        <el-table :data="changeData">
          <el-table-column prop="serviceTypeName" label="구분"  align="center">

          </el-table-column>
          <el-table-column prop="attributeName" label="항목"  align="center">
              <template slot-scope="props" >                
                <el-tooltip
                  placement="bottom"
                  effect="light"
                  v-if="props.row.attributeCode==='05002'"
                >
                  <div slot="content">
                    <el-row>
                      <el-col :span="8">
                        판매할인구분코드
                      </el-col>
                      <el-col :span="16">
                        {{ props.row.etcCont.discountTypeCode}} 
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="8">
                        타겟코드
                      </el-col>
                      <el-col :span="16">
                        {{ props.row.etcCont.discountTargetCode}} 
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="8">
                        쿠폰코드
                      </el-col>
                      <el-col :span="16">
                        {{ props.row.etcCont.couponCode}} 
                      </el-col>
                    </el-row>
                   
                  </div>
                  <el-button type="text">
                    {{ props.row.attributeName }} 
                  </el-button> 
                  
                </el-tooltip>                       
                <el-col v-else>
                  {{ props.row.attributeName }} 
                </el-col>                
              </template>         
          </el-table-column>
          <el-table-column prop="previousContents" label="변경전"  align="center">
              <template slot-scope="props" >                
                <el-tooltip
                  placement="bottom"
                  effect="light"
                  v-if="props.row.serviceTypeCode==='01'"
                >
                  <div slot="content">
                    <el-row>
                      <el-col :span="6">
                        차종
                      </el-col>
                      <el-col :span="18">
                        {{ props.row.etcCont.preCarEnginName }} 
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="6">
                        옵션
                      </el-col>
                      <el-col :span="18">
                        {{ props.row.etcCont.preOptionList}} 
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="6">
                        외장컬러
                      </el-col>
                      <el-col :span="18">
                        {{ props.row.etcCont.preExteriorColorName}} 
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="6">
                        내장컬러
                      </el-col>
                      <el-col :span="18">
                        {{ props.row.etcCont.preInteriorColorName}} 
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="6">
                        파츠
                      </el-col>
                      <el-col :span="18">
                        {{ props.row.etcCont.preTuixList}} 
                      </el-col>
                    </el-row>
                  </div>
                  <el-button type="text">
                    {{ props.row.previousContents }} 
                  </el-button> 
                  
                </el-tooltip>
                <el-col v-else>
                  {{ props.row.previousContents }}
                </el-col>                
              </template>              
          </el-table-column>
          <el-table-column prop="afterContents" label="변경후"  align="center">
              <template slot-scope="props" >                
                <el-tooltip
                  placement="bottom"
                  effect="light"
                  v-if="props.row.serviceTypeCode==='01'"
                >
                  <div slot="content">
                    <el-row>
                      <el-col :span="6">
                        차종
                      </el-col>
                      <el-col :span="18">
                        {{ props.row.etcCont.carEnginName}} 
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="6">
                        옵션
                      </el-col>
                      <el-col :span="18">
                        {{ props.row.etcCont.optionList}} 
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="6">
                        외장컬러
                      </el-col>
                      <el-col :span="18">
                        {{ props.row.etcCont.exteriorColorName}} 
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="6">
                        내장컬러
                      </el-col>
                      <el-col :span="18">
                        {{ props.row.etcCont.interiorColorName}} 
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="6">
                        파츠
                      </el-col>
                      <el-col :span="18">
                        {{ props.row.etcCont.tuixList}} 
                      </el-col>
                    </el-row>
                  </div>
                  <el-button type="text">
                    {{ props.row.afterContents }} 
                  </el-button> 
                  
                </el-tooltip>
                <el-col v-else>
                  {{ props.row.afterContents }}
                </el-col>                
              </template>
          </el-table-column>
          <el-table-column prop="changeDate" label="변경일"  align="center">

          </el-table-column>
          <el-table-column prop="processPersonName" label="처리자"  align="center">
            </el-table-column>      
        </el-table>
        
    </div>
  
</template>

<script>
import HTitle from '~/components/common/HTitle.vue'
//import HTable from '~/components/common/HTable.vue'
import moment from 'moment'
export default {
  name: 'ChangeHistory',
  components: {
    //HTable,
    HTitle,
  },
  props: {
    contractNumber: {
      type: String,
      default: ''
    },
  },
  data() {
    return {
      changeData: []
    }
  },
  created() {
      //await this.getChangeHistoryData();

  },
  mounted() {

  },
  methods: {
    async getChangeHistoryData() {
      
      const [res, err] = await this.$https.post('/v2/exclusive/work/history/change-list', { contractNumber: this.contractNumber })
      if(!err) {
        console.log('SUCCESS :: /work/history/change-list/', res.data)
        this.changeData = res.data.map((el) => {
          return {
            ...el,            
            
            etcCont : el.serviceTypeCode === '01' || '05' ? ( el.etcContents = el.etcContents !==null ? JSON.parse(el.etcContents) : {} ) : el.etcContents,
            previousContents : el.previousContents === null || '' ? '없음' : el.previousContents,
            afterContents : el.afterContents === null || '' ? '없음' : el.afterContents

          }
        })
                
      } else {
        console.error(err)
      }
    }

  }

}
</script>
