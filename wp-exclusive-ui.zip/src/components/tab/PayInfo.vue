<template>
  <div>
    <div class="box">
      <el-table :data="payStateList" class="box" v-if="payStateList">
        <el-table-column
          prop="contractCarTypeName"
          label="차량구분"
          width="229"
          align="center"
        ></el-table-column>
        <el-table-column label="과세구분(유형)" width="200" align="center">
          <template slot-scope="scope">
            {{ scope.row.taxationSectionalName }}
            {{
              scope.row.taxationTypeName !== "" &&
              scope.row.taxationTypeName !== null
                ? `(${scope.row.taxationTypeName})`
                : ""
            }}</template
          >
        </el-table-column>
        <el-table-column
          label="출고증발급요청(IP+P2)"
          width="200"
          align="center"
        >
          <template slot-scope="scope">
            {{ scope.row.qSignYn }}
            <el-button
              v-if="
                isValidAuthBtn('authExclusive') &&
                  (activeUserFlag || isAuth) &&
                  payInfoData.qSignYn !== 'Y' &&
                  (isEmployee && !isEmployeeDc)
              "
              type="info"
              class="btn-qsign"
              :disabled=" (!activeUserFlag) "
              @click="isEmployeeDcPop = true"
            >
              요청
            </el-button>
            <el-button
              v-else-if="
                isValidAuthBtn('authExclusive') &&
                  (activeUserFlag || isAuth) &&
                  payInfoData.qSignYn !== 'Y'
              "
              type="info"
              class="btn-qsign"
              :disabled=" (!activeUserFlag) "
              @click="updateContractAssignPop = true"
            >
              요청
            </el-button>
          </template>
        </el-table-column>
        <el-table-column
          prop="paymentStartDate"
          label="결제시작일"
          width="170"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="paymentTimeLimitDate"
          label="결제기한"
          width="170"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="paymentDate"
          label="결제일"
          width="170"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="afterApproveDate"
          label="직원2차인증기한"
          width="200"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="paymentStateName"
          label="결제진행상태"
          width="200"
          align="center"
        ></el-table-column>
      </el-table>
    </div>

    <div class="pay-info">
      <div class="total-price">
        <span class="price"
          >총 결제금액 :
          {{
            payInfoData.totalPrice
              ? payInfoData.totalPrice.toLocaleString() + "원"
              : ""
          }}</span
        >
        <el-button
          type="primary"
          v-if="isValidAuthBtn('authExclusive') && (activeUserFlag || isAuth)"
          :disabled=" !activeUserFlag  "
          @click="activePayBtn('point')"
          >결제변경</el-button
        >
      </div>
      <div class="pay-step">
        <div class="item-step">
          <div class="title-step">
            <strong class="tit">총 판매금액</strong>
            <div class="price">
              {{
                payInfoData.totalSalePrice
                  ? payInfoData.totalSalePrice.toLocaleString() + "원"
                  : ""
              }}
            </div>
          </div>
          <ul class="data-step">
            <li v-for="(item, index) in saleAmountList" :key="index">
              <strong class="tit">{{ item.name }}</strong>
              <div class="price">
                {{ item.price ? item.price.toLocaleString() : "" }}
              </div>
            </li>
            <!-- <li>
              <strong class="tit">탁송료</strong>
              <div class="price">10,000원</div>
            </li>
            <li>
              <strong class="tit">단기의무보험료</strong>
              <div class="price">8,000원</div>
            </li>
            <li>
              <strong class="tit">할부인지대</strong>
              <div class="price">100,000원</div>
            </li> -->
          </ul>
        </div>

        <div class="item-step" v-if="payInfoData.totalDiscount">
          <i class="el-icon-remove"></i>
          <div class="title-step">
            <strong class="tit">총 할인금액</strong>
            <div class="price">
              {{
                payInfoData.totalDiscount
                  ? payInfoData.totalDiscount.toLocaleString() + "원"
                  : ""
              }}
            </div>
          </div>
          <ul class="data-step">
            <li v-for="(item, index) in discountAmountList" :key="index">
              <strong class="tit">{{ item.name }}</strong>
              <div class="price">{{ item.price }}</div>
              <div class="vw-detail" v-if="item.detail">
                <dl
                  class="vw"
                  v-for="(detailItem, detailIndex) in item.detail"
                  :key="detailIndex"
                >
                  <dt class="vw-title">{{ detailItem.content }}</dt>
                  <dd class="vw-price">{{ detailItem.price }}</dd>
                </dl>
                <!-- <dl class="vw">
                  <dt class="vw-title">직원할인</dt>
                  <dd class="vw-price">1,100원</dd>
                </dl>
                <dl class="vw">
                  <dt class="vw-title">생산월할인</dt>
                  <dd class="vw-price">3,100원</dd>
                </dl>
                <dl class="vw">
                  <dt class="vw-title">기본조건</dt>
                  <dd class="vw-price">2,100원</dd>
                </dl> -->
              </div>
            </li>
            <!-- <li>
              <strong class="tit">쿠폰할인</strong>
              <div class="price">120,000원</div>
              <div class="vw-detail">
                <dl class="vw">
                  <dt class="vw-title">첫 구매할인</dt>
                  <dd class="vw-price">10,000원</dd>
                </dl>
                <dl class="vw">
                  <dt class="vw-title">쿠폰1</dt>
                  <dd class="vw-price">10,000원</dd>
                </dl>
                <dl class="vw">
                  <dt class="vw-title">쿠폰2</dt>
                  <dd class="vw-price">10,000원</dd>
                </dl>
              </div>
            </li>
            <li>
              <strong class="tit">추가할인(전담DC)</strong>
              <div class="price">120,000원</div>
            </li> -->
          </ul>
        </div>

        <div class="item-step" v-if="pointAmountList.length > 0">
          <i class="el-icon-remove"></i>
          <div class="title-step">
            <strong class="tit">포인트 결제</strong>
            <div class="price">
              {{
                payInfoData.totalPoint
                  ? payInfoData.totalPoint.toLocaleString() + "원"
                  : ""
              }}
            </div>
          </div>
          <ul class="data-step">
            <li v-for="(item, index) in pointAmountList" :key="index">
              <strong class="tit">{{ item.content }}</strong>
              <div class="price">
                <span>{{ item.price }}</span>
                <button
                  type="primary"
                  v-if="
                    item.type === 'button' &&
                      (isValidAuthBtn('authExclusive') &&
                        (activeUserFlag || isAuth))
                  "
                  :disabled="!visiblePointBtn"
                  @click="cancelPay(item)"
                >
                  <i class="el-icon-error"></i>
                </button>
              </div>
            </li>
            <!-- <li>
              <strong class="tit">블루멤버스</strong>
              <div class="price">
                <span>80,000원</span>
                <button type="button" class="btn-del">
                  <i class="el-icon-error"></i>
                </button>
              </div>
            </li>
            <li>
              <strong class="tit">세이브 오토</strong>
              <div class="price">
                <span>80,000원</span>
                <button type="button" class="btn-del">
                  <i class="el-icon-error"></i>
                </button>
              </div>
            </li>
            <li>
              <strong class="tit">블루멤버스 포인트 선사용</strong>
              <div class="price">
                <span>80,000원</span>
                <button type="button" class="btn-del">
                  <i class="el-icon-error"></i>
                </button>
              </div>
            </li>
            <li>
              <strong class="tit">한도상향</strong>
              <div class="price">
                <span>신청</span>
              </div>
            </li>
             -->
          </ul>
        </div>

        <div class="item-step" v-if="payInfoData.totalTaxReduction">
          <i class="el-icon-remove"></i>
          <div class="title-step">
            <strong class="tit">감면세액</strong>
            <span class="price">{{ payInfoData.totalTaxReduction }}</span>
          </div>
          <ul class="data-step">
            <li v-for="(item, index) in taxReductionAmountList" :key="index">
              <strong class="tit">{{ item.name }}</strong>
              <div class="price">
                <span>{{ item.price }}</span>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>

    <div class="article-title gap">
      <h2>결제내역</h2>
      <div class="right">
        <el-button
          type="primary"
          v-if="isValidAuthBtn('authExclusive') && (activeUserFlag || isAuth)"
          :disabled=" !activeUserFlag  "
          @click="activePayBtn('cash')"
          >결제변경</el-button
        >
      </div>
    </div>

    <div class="box">
      <table class="tbl-list">
        <colgroup>
          <col style="width:33.333333%" />
          <col style="width:33.333333%" />
          <col style="width:33.333333%" />
        </colgroup>
        <!-- <colgroup v-else>
          <col style="width:25%" />
          <col style="width:25%" />
          <col style="width:25%" />
          <col style="width:25%" />
        </colgroup> -->
        <thead>
          <tr>
            <th>요청금액(A)<i class="el-icon-remove"></i></th>
            <th>처리금액(B)<i class="el-icon-equal"></i></th>
            <th>미처리금액(C)</th>
          <!--   <th v-if="penaltyPriceTotal">위약금</th> -->
          </tr>
        </thead>
        <tbody>
          <tr>
            <td align="center">
              {{
                requestPriceTotal
                  ? requestPriceTotal.toLocaleString() + "원"
                  : "0원"
              }}
            </td>
            <td align="center">
              {{
                payDetail.paymentCompletePriceTotal
                  ? ((payDetail.paymentCompletePriceTotal||0)-(payDetail.refundCompletePriceTotal||0)).toLocaleString() + "원"
                  : "0원"
              }}
            </td>
            <td align="center">
              {{
                requestPriceTotal && payDetail.paymentCompletePriceTotal
                  ? (
                      requestPriceTotal - payDetail.paymentCompletePriceTotal + (payDetail.refundCompletePriceTotal||0)
                    ).toLocaleString() + "원"
                  : (requestPriceTotal || "0").toLocaleString() + "원"
              }}
            </td>
           <!--  <td align="center" v-if="penaltyPriceTotal">
              <span>{{ penaltyPriceTotal.toLocaleString() + "원" }}</span>
              <el-button type="info" class="btn-small space"
                >왕복 탁송료 계산</el-button
              >
            </td> -->
          </tr>
        </tbody>
      </table>
    </div>

    <!--   <div class="box">
      <table class="tbl-list">
        <colgroup>
          <col style="width:25%" />
          <col style="width:25%" />
          <col style="width:25%" />
          <col style="width:25%" />
        </colgroup>
        <thead>
          <tr>
            <th>요청금액(A)<i class="el-icon-remove"></i></th>
            <th>처리금액(B)<i class="el-icon-equal"></i></th>
            <th>미처리금액(C)</th>
            <th>위약금</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td align="center">33,666,111원</td>
            <td align="center">33,666,111원</td>
            <td align="center">0원</td>
            <td align="center">
              <span>340,000원</span>
              <!-- <el-button type="info" class="btn-small space"
                >왕복 탁송료 계산</el-button
              > -->
    <!--       </td>
          </tr>
        </tbody>
      </table>
    </div>  -->

    <div class="box">
      <table class="tbl-list">
        <colgroup>
          <col style="width:7%" />
          <col style="width:7%" />
          <col style="width:6%" />
          <col style="width:14%" />
          <col style="width:6%" />
          <col style="width:7%" />
          <col style="width:7%" />
          <col style="width:6%" />
          <col style="width:6%" />
          <col style="width:7%" />
          <col style="width:7%" />
          <col style="width:6%" />
          <col style="width:6%" />
          <col style="width:6%" />
        </colgroup>
        <thead>
          <tr>
            <th rowspan="2" colspan="2">구분</th>
            <th colspan="4">결제방법</th>
            <th colspan="4">결제상태</th>
            <th colspan="4">취소상태(C)</th>
            <th rowspan="2">비고</th>
          </tr>
          <tr>
            <th>결제수단</th>
            <th>금융사</th>
            <th>명의자</th>
            <th>카드종류</th>
            <th>금액</th>
            <th>상태</th>
            <th>시작일시</th>
            <th>처리일시</th>
            <th>금액</th>
            <th>상태</th>
            <th>시작일시</th>
            <th>처리일시</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="(item, idx) in payDetail.prepaymentInfo"
            :key="`pre-${idx}`"
          >
            <td
              align="center"
              v-if="idx === 0"
              :rowspan="payDetail.prepaymentInfo.length"
            >
              선지급내역
            </td>
            <td align="center">
              {{
                item.paymentSectionName === "계약금" &&
                contractData.penaltyYn === "Y"
                  ? "위약금"
                  : item.paymentSectionName
              }}
            </td>
            <td align="center">{{ item.paymentTypeName }}</td>
            <td align="center">
              {{ item.paymentContents }}
              {{ item.paymentTypeCode === "30" ? item.virtualAccount : "" }}
            </td>
            <td align="center">
              {{ item.paymentPersonName }}
            </td>
            <td align="center">
              {{ item.cardType }}
            </td>
            <td align="center">
              {{ formatCash(item.paymentPrice) }}
            </td>
            <td align="center">
              {{ !item.refundRequestDate && (contractData.contractCancellationDate||contractInfoData.legacyStatusCode==='90') && item.paymentTypeCode==="30" && item.paymentStateCode==="21"? "취소" : item.paymentStateName }}
            </td>
            <td align="center">{{ item.paymentRequestDate }}</td>
            <td align="center">{{ item.paymentDate }}</td>
            <td align="center">{{ formatCash(item.refundPrice) }}</td>
            <td align="center">
              <div class="table-content" v-if="item.refundStateCode === '14' || item.refundStateCode === '34'">
                <el-tooltip

                  placement="bottom" 
                  effect="light" 
                >
                  <div slot="content">
                    <el-row>
                      <el-col :span="24">
                        {{item.refundFailReason}}
                      </el-col>
                    </el-row>
                  </div>
                  <el-button type="text">
                    {{ item.refundStateName }}
                  </el-button>
                </el-tooltip>
              </div>
              <div class="table-content" v-if="item.refundStateCode !== '14' && item.refundStateCode !== '34'">
                {{ item.refundStateName }}
              </div>
            </td>
            <td align="center">{{ item.refundRequestDate }}</td>
            <td align="center">{{ item.refundDate }}</td>
            <td align="center">
              <el-button
                type="primary"
                class="btn-small"
                v-if="
                  isValidAuthBtn('authExclusive') &&
                    (activeUserFlag || isAuth) &&
                    item.refundPossibleYn === 'Y' && item.paymentTypeCode !== '30'
                "
                :disabled="
                  !visibleCashBtn ||
                    (item.paymentSectionName === '계약금' &&
                      contractData.penaltyYn === 'Y') ||
                  contractData.specialCarYn === 'Y'
                "
                @click="beforePrepaymentCardProcessFunc(item, 'prepayment')"
                >변경</el-button
              >
              <el-button
                type="primary"
                class="btn-small"
                v-if="
                  isValidAuthBtn('authExclusive') &&
                    (activeUserFlag || isAuth) && item.paymentTypeCode === '30'
                "
                :disabled="
                  !visibleCashBtn ||
                    (item.paymentSectionName === '계약금' &&
                      contractData.penaltyYn === 'Y') ||
                  contractData.specialCarYn === 'Y'
                "
                @click="cancelPrepaymentCashPop(item)"
                >변경</el-button
              >
            </td>
          </tr>
          <tr v-for="(item, idx) in payDetail.paymentInfo" :key="`paid-${idx}`">
            <td
              align="center"
              v-if="idx === 0"
              :rowspan="payDetail.paymentInfo.length"
            >
              결제 내역
            </td>
            <td align="center">{{ item.paymentSectionName }}</td>
            <td align="center">{{ item.paymentTypeName }}</td>
            <td
              align="center"
              v-if="item.paymentContents && item.paymentTypeCode === '10'"
            >
              {{ item.paymentContents.split("|")[0] }}
              {{ item.paymentContents.split("|")[1] }}
            </td>
            <td
              v-else-if="item.paymentContents && item.paymentTypeCode === 'fakeExamine'"
              align="center"
            >
              {{ item.paymentContents.split("|")[0] }}
              {{ item.paymentContents.split("|")[1] }}
            </td>
            <td
              v-else-if="item.paymentContents && item.paymentTypeCode === '30'"
              align="center"
            >
              {{ item.paymentContents }} {{ item.virtualAccount }}
            </td>
            <td v-else align="center">
              {{ item.paymentContents }}
            </td>
            <td align="center">
              {{ item.paymentPersonName }}
            </td>            
            <td align="center">
              {{ item.cardType }}
            </td>
            <td align="center">
              {{ formatCash(item.paymentPrice) }}
            </td>
            <td align="center">
              <div class="table-content" v-if="item.paymentStateCode === '14' ">
                <el-tooltip
                  placement="bottom" 
                  effect="light" 
                >
                  <div slot="content">
                    <el-row>
                      <el-col :span="24">
                        {{item.paymentFailReason}}
                      </el-col>
                    </el-row>
                  </div>
                  <el-button type="text">
                    {{ item.paymentStateName }}
                  </el-button>
                </el-tooltip>
              </div>
              <div class="table-content" v-if="item.paymentStateCode !== '14'">
                {{ item.paymentStateName }}
              </div>              
            </td>
            <td align="center">
              {{ item.paymentRequestDate }}
            </td>
            <td align="center">
              {{ item.paymentDate }}
            </td>
            <td align="center">
              {{ formatCash(item.refundPrice) }}
            </td>
            <td align="center">
              <div class="table-content" v-if="item.refundStateCode === '14' || item.refundStateCode === '34'">
                <el-tooltip

                  placement="bottom" 
                  effect="light" 
                >
                  <div slot="content">
                    <el-row>
                      <el-col :span="24">
                        {{item.refundFailReason}}
                      </el-col>
                    </el-row>
                  </div>
                  <el-button type="text">
                    {{ item.refundStateName }}
                  </el-button>
                </el-tooltip>
              </div>
              <div class="table-content" v-if="item.refundStateCode !== '14' && item.refundStateCode !== '34'">
                {{ item.refundStateName }}
              </div>
            </td>
            <td align="center">
              {{ item.refundRequestDate }}
            </td>
            <td align="center">
              {{ item.refundDate }}
            </td>
            <td align="center">
              <template
                v-if="
                  isValidAuthBtn('authExclusive') &&
                    (activeUserFlag || isAuth) &&
                    item.paymentTypeCode &&
                    item.refundPossibleYn === 'Y' &&
                    item.paymentStateCode !== '21'
                "
              >
                <!-- 결제타입이 현금이면서 결제상태가 '입금 대기' 상태가 아닐 경우 -->
                <el-button
                  type="primary"
                  class="btn-small"
                  v-if="item.paymentTypeCode === '30'"
                  :disabled="!visibleCashBtn"
                  @click="changePayCashPreProcess(item, 'normal')"
                >
                  변경
                </el-button>
                <!-- 결제타입이 카드인 케이스 -->
                <el-button
                  type="primary"
                  class="btn-small"
                  v-else-if="item.paymentTypeCode === '20'"
                  :disabled="!visibleCashBtn"
                  @click="changePayCard(item)"
                >
                  변경
                </el-button>
                <!-- 결제타입이 현금이외인 모든 케이스 -->
                <el-button
                  type="primary"
                  class="btn-small"
                  v-else
                  :disabled="!visibleCashBtn"
                  @click="cancelPay(item)"
                >
                  변경
                </el-button>
              </template>
              <!-- 입금 대기(21) -->
              <template
                v-if="
                  isValidAuthBtn('authExclusive') &&
                    (activeUserFlag || isAuth) &&
                    item.paymentTypeCode &&
                    item.paymentStateCode === '21'
                "
              >
                <!-- 결제타입이 '현금' 이면서 결제상태가 '입금 대기' 상태일 경우 -->
                <el-button
                  type="primary"
                  class="btn-small"
                  v-if="
                    item.paymentTypeCode === '30' &&
                      item.paymentStateCode === '21'
                  "
                  :disabled="!visibleCashBtn"
                  @click="cancelPay(item)"
                >
                  취소
                </el-button>
              </template>
              <!-- <el-button type="primary" class="btn-small">변경</el-button> -->
            </td>
          </tr>
          <tr
            v-for="(item, idx) in payDetail.additionPaymentInfo"
            :key="`addPay-${idx}`"
          >
            <td
              align="center"
              v-if="idx === 0"
              :rowspan="payDetail.additionPaymentInfo.length"
            >
              추가결제
            </td>
            <td align="center">{{ item.paymentSectionName }}</td>
            <td align="center">{{ item.paymentTypeName }}</td>
            <td
              align="center"
              v-if="item.paymentContents && item.paymentTypeCode === '10'"
            >
              {{ item.paymentContents.split("|")[0] }}
              {{ item.paymentContents.split("|")[1] }}
            </td>
            <td
              align="center"
              v-else-if="item.paymentContents && item.paymentTypeCode === '30'"
            >
              {{ item.paymentContents }} {{ item.virtualAccount }}
            </td>
            <td v-else align="center">
              {{ item.paymentContents }}
            </td>
            <td align="center">
              {{ item.paymentPersonName }}
            </td>
            <td align="center">
              -
            </td>
            <td align="center">
              {{ formatCash(item.paymentPrice) }}
            </td>
            <td align="center">
              <div class="table-content" v-if="item.paymentStateCode === '14'">
                <el-tooltip
                  placement="bottom" 
                  effect="light" 
                >
                  <div slot="content">
                    <el-row>
                      <el-col :span="24">
                        {{item.paymentFailReason}}
                      </el-col>
                    </el-row>
                  </div>
                  <el-button type="text">
                    {{ item.paymentStateName }}
                  </el-button>
                </el-tooltip>
              </div>
              <div class="table-content" v-if="item.paymentStateCode !== '14'">
                {{ item.paymentStateName }}
              </div>              
            </td>
            <td align="center">{{ item.paymentRequestDate }}</td>
            <td align="center">{{ item.paymentDate }}</td>
            <td align="center">{{ formatCash(item.refundPrice) }}</td>
            <td align="center">
              <div class="table-content" v-if="item.refundStateCode === '14' || item.refundStateCode === '34'">
                <el-tooltip

                  placement="bottom" 
                  effect="light" 
                >
                  <div slot="content">
                    <el-row>
                      <el-col :span="24">
                        {{item.refundFailReason}}
                      </el-col>
                    </el-row>
                  </div>
                  <el-button type="text">
                    {{ item.refundStateName }}
                  </el-button>
                </el-tooltip>
              </div>
              <div class="table-content" v-if="item.refundStateCode !== '14' && item.refundStateCode !== '34'">
                {{ item.refundStateName }}
              </div>              
            </td>
            <td align="center">{{ item.refundRequestDate }}</td>
            <td align="center">{{ item.refundDate }}</td>
            <td align="center">
              <template
                v-if="
                  isValidAuthBtn('authExclusive') &&
                    (activeUserFlag || isAuth) &&
                    item.paymentTypeCode &&
                    item.refundPossibleYn === 'Y' &&
                    item.paymentStateCode !== '21' &&
                    item.paymentSectionCode !== '05'
                "
              >
                <!-- 결제타입이 현금이면서 결제상태가 '입금 대기' 상태가 아닐 경우 -->
                <el-button
                  type="primary"
                  class="btn-small"
                  v-if="item.paymentTypeCode === '30'"
                  :disabled="
                    !visibleCashBtn || item.paymentSectionCode === '05'
                  "
                  @click="changePayCashPreProcess(item, 'addpay')"
                >
                  변경
                </el-button>
                <!-- 결제타입이 카드인 케이스 -->
                <el-button
                  type="primary"
                  class="btn-small"
                  v-else-if="item.paymentTypeCode === '20'"
                  :disabled="
                    !visibleCashBtn || item.paymentSectionCode === '05'
                  "
                  @click="changePayCard(item)"
                >
                  변경
                </el-button>
                <!-- 결제타입이 현금이외인 모든 케이스 -->
                <el-button
                  type="primary"
                  class="btn-small"
                  v-else
                  :disabled="
                    !visibleCashBtn || item.paymentSectionCode === '05'
                  "
                  @click="cancelPay(item)"
                >
                  변경
                </el-button>
              </template>
              <!-- 입금 대기(21) -->
              <template
                v-if="
                  isValidAuthBtn('authExclusive') &&
                    (activeUserFlag || isAuth) &&
                    item.paymentTypeCode &&
                    item.paymentStateCode === '21'
                "
              >
                <!-- 결제타입이 '현금' 이면서 결제상태가 '입금 대기' 상태일 경우 -->
                <el-button
                  type="primary"
                  class="btn-small"
                  v-if="
                    item.paymentTypeCode === '30' &&
                      item.paymentStateCode === '21'
                  "
                  :disabled="
                    !visibleCashBtn || item.paymentSectionCode === '05'
                  "
                  @click="cancelPay(item)"
                >
                  취소
                </el-button>
              </template>
            </td>
          </tr>
        </tbody>
        <tfoot>
          <tr>
            <td align="center" colspan="6">소계</td>
            <td align="center" colspan="4">
              {{ formatCash(payDetail.paymentCompletePriceTotal) }}
            </td>
            <td align="center" colspan="4">
              {{
                payDetail.refundCompletePriceTotal
                  ? formatCash(payDetail.refundCompletePriceTotal)
                  : "0원"
              }}
            </td>
            <td></td>
          </tr>
        </tfoot>
      </table>
      <ul class="note">
        <li>
          · 특별주문차량 계약을 취소하는 경우 계약금 전액을 위약금으로
          처리합니다.
        </li>
        <li>
          · 차량 출고 이후 단순 변심에 의한 인수 거부 시
          <strong
            >왕복 탁송료({{
              payInfoData
                ? Number(payInfoData.roundTripDeliveryPrice).toLocaleString()
                : "0"
            }}원)</strong
          >을 징수합니다.
        </li>
      </ul>
    </div>

    <h-title :title="'적립 예정 블루멤버스 포인트'" />
    <h-table
      :table-type="'DefultTable'"
      :table-header="tableHeader06"
      :table-datas="payDetail.blueInfo"
    />

    <!-- <el-row>
      <el-col :span="6" class="info-left">
        <el-form
          v-if="payInfoData"
          ref="payPrice"
          :model="payInfoData"
          class="detail-form"
        >
          <el-row>
            <el-col :span="24">
              <el-form-item label="과세구분">
                {{ payInfoData.taxationSectionalName }}
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="과세유형">
                {{ payInfoData.taxationTypeName }}
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="Q싸인">
                <td>
                  {{ payInfoData.qSignYn || "N" }}
                </td>
                <td class="align-right">
                  <el-button
                    v-if="
                      isValidAuthBtn('authExclusive') &&
                        (activeUserFlag || isAuth) &&
                        payInfoData.qSignYn !== 'Y'
                    "
                    type="info"
                    class="btn-qsign"
                    @click="updateContractAssignPop = true"
                  >
                    결제승인
                  </el-button>
                </td>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="결제시작일">
                {{ payInfoData.paymentStartDate }}
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="결제기한">
                {{ payInfoData.paymentTimeLimitDate }}
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="결제일">
                {{ payInfoData.paymentDate }}
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="진행상태">
                {{ payInfoData.paymentStateName }}
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </el-col>
      <el-col :span="18" class="list-right">
        <div>
          <article class="article">
            <div class="article-title">
              <h2>결제금액</h2>
              <div class="right">
                <p>총 결제금액(포인트 포함)</p>
                <p>
                  {{
                    payInfoData.totalPrice4Mypage
                      ? payInfoData.totalPrice4Mypage.toLocaleString() + "원"
                      : ""
                  }}
                </p>
                <p>|</p>
                <p>총 결제금액</p>
                <p>
                  {{
                    payInfoData.totalPrice
                      ? payInfoData.totalPrice.toLocaleString() + "원"
                      : ""
                  }}
                </p>
                <el-button
                  v-if="
                    isValidAuthBtn('authExclusive') &&
                      (activeUserFlag || isAuth)
                  "
                  type="primary"
                  @click="activePayBtn('point')"
                >
                  결제변경
                </el-button>
              </div>
            </div>
            <div class="accordion-table">
              <el-table
                :data="payAmountList"
                :show-header="false"
                :row-class-name="tableRowClassName"
              >
                <el-table-column prop="name" label="name" />
                <el-table-column prop="content" label="content" width="240" />
                <el-table-column prop="percent" label="percent" align="right" />
                <el-table-column
                  prop="pointState"
                  label="pointState"
                  width="360"
                />
                <el-table-column prop="price" label="price" align="right" />
                <el-table-column prop="type" label="type">
                  <template slot-scope="props">
                    <el-button
                      v-if="
                        props.row.type === 'button' &&
                          (isValidAuthBtn('authExclusive') &&
                            (activeUserFlag || isAuth)) &&
                          props.row.useCompleteYn === 'Y'
                      "
                      :type="`${!visiblePointBtn ? 'info' : 'primary'}`"
                      :disabled="!visiblePointBtn"
                      @click="cancelPay(props.row)"
                    >
                      취소
                    </el-button>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </article>
        </div>
      </el-col>
    </el-row> -->

    <!-- 현금 결제 변경(선지급내역용) -->
    <el-dialog title="현금 결제 변경" :visible.sync="popVisiblePrepaymentCancelCash">
      <!-- Popup Contents -->
      <div class="board-wrap">
        <el-form
          ref="cashPaymentPop"
          class="detail-form"
          :model="selCancelPrePayInfo"
        >
          <el-row>
            <el-col :span="24">
              <el-form-item label="결제자">{{
                selCancelPrePayInfo.paymentPersonName
              }}</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="요청자">{{
                userInfoData.eeNm
              }}</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="결제금액">{{
                selCancelPrePayInfo.paymentCompletePrice.toLocaleString() + "원"
              }}</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="환불계좌">
                <el-select v-model="refundPreInfo.bank">
                  <el-option
                    v-for="{ value, label } in commonCodes.P037 &&
                      commonCodes.P037"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
                <el-input
                  placeholder="계좌번호"
                  v-model="refundPreInfo.guja"
                />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="취소금액">
                <el-input
                  v-model="refundInfo.stlRqAmt"
                  :placeholder="
                    selCancelPrePayInfo.paymentCompletePrice.toLocaleString()
                  "
                  :disabled.sync="disabledPrepaymentRefundAmt"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <!-- <ul class="note">
          <li>
            ※ 왕복탁송료 :
            {{
              payInfoData
                ? Number(payInfoData.roundTripDeliveryPrice).toLocaleString()
                : "0"
            }}원
          </li>
          <li>
            ※ 차감 시 취소금액 :
            {{
              refundInfo && payInfoData
                ? (
                    refundInfo.stlRqAmt - payInfoData.roundTripDeliveryPrice
                  ).toLocaleString()
                : "0"
            }}원
          </li>
        </ul> -->
      </div>
      <!-- Popup Footer -->
      <template slot="footer">
        <div>
          <el-button type="info" @click="popVisiblePrepaymentCancelCash = false"
            >취소</el-button
          >
          <el-button type="primary" @click="oneClickDisable($event, cancelPrepaymentCash)">확인</el-button>
        </div>
      </template>
    </el-dialog>
    <!-- 현금 결제 변경(전체 취소용) -->
    <el-dialog title="현금 결제 변경" :visible.sync="popVisibleChangeCashAll">
      <!-- Popup Contents -->
      <div class="board-wrap">
        <el-form
          ref="cashPaymentPop"
          class="detail-form"
          :model="selChangePayAllInfo"
        >
          <el-row>
            <el-col :span="24">
              <el-form-item label="결제자">
                {{ selChangePayAllInfo.depositor }}
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="요청자">{{
                userInfoData.eeNm
              }}</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="결제금액">
                {{ selChangePayAllInfo.payAmount }}
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="환불계좌">
                <el-select v-model="refundInfo.bankCode">
                  <el-option
                    v-for="{ value, label } in commonCodes.P037 &&
                      commonCodes.P037"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
                <el-input
                  placeholder="계좌번호"
                  v-model="refundInfo.bankAccount"
                />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="취소금액">
                {{ selChangePayAllInfo.cancelAmount }}
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <!-- Popup Footer -->
      <template slot="footer">
        <div>
          <el-button type="info" @click="popVisibleChangeCashAll = false"
            >취소</el-button
          >
          <el-button type="primary" @click="alertVisibleChangeCashAllValidCheck()">확인</el-button>
        </div>
      </template>
    </el-dialog>

    <!-- 현금 결제 변경 -->
    <el-dialog title="현금 결제 변경" :visible.sync="popVisibleChangeCash">
      <!-- Popup Contents -->
      <div class="board-wrap">
        <el-form
          ref="cashPaymentPop"
          class="detail-form"
          :model="selChangePayInfo"
        >
          <el-row>
            <el-col :span="24">
              <el-form-item label="결제자">{{
                selChangePayInfo.depositor
              }}</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="요청자">{{
                userInfoData.eeNm
              }}</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="결제금액">{{
                selChangePayInfo.paymentCompletePrice.toLocaleString() + "원"
              }}</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="환불계좌">
                <el-select v-model="refundInfo.bankCode">
                  <el-option
                    v-for="{ value, label } in commonCodes.P037 &&
                      commonCodes.P037"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
                <el-input
                  placeholder="계좌번호"
                  v-model="refundInfo.bankAccount"
                />
               <!--  <el-input
                  placeholder="예금주"
                  v-model="refundInfo.bankAccountOwner"
                />
                <el-button type="info" class="btn-small">확인</el-button> -->
              </el-form-item>
            </el-col>
          </el-row>
          <!--  <el-row>
            <el-col :span="24">
              <el-form-item label="취소사유">
                <el-select v-model="refundInfo.cancleReason">
                  <el-option
                    v-for="{ value, label } in commonCodes.T046 &&
                      commonCodes.T046"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row> -->
          <el-row>
            <el-col :span="24">
              <el-form-item label="취소금액">
                <el-radio
                  v-model="checkedRefundAllType"
                  label="전액환불"
                  @change="refundCheck($event, selChangePayInfo, 'all')"
                  >전체취소</el-radio
                >
                <el-radio
                  v-model="checkedRefundPartType"
                  label="부분환불"
                  :disabled="selChangePayInfo.payType === 'addPay'"
                  @change="refundCheck($event, selChangePayInfo, 'part')"
                  >부분취소</el-radio
                >
                <!-- <el-radio
                  v-model="checkedRefundPartType"
                  label="부분환불"
                  :disabled="true"
                  @change="refundCheck($event, selChangePayInfo, 'part')"
                  >부분취소</el-radio
                > -->
                <el-input
                  v-model="refundInfo.stlRqAmt"
                  :placeholder="
                    selChangePayInfo.paymentCompletePrice.toLocaleString()
                  "
                  :disabled.sync="disabledRefundAmt"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <!-- <ul class="note">
          <li>
            ※ 왕복탁송료 :
            {{
              payInfoData
                ? Number(payInfoData.roundTripDeliveryPrice).toLocaleString()
                : "0"
            }}원
          </li>
          <li>
            ※ 차감 시 취소금액 :
            {{
              refundInfo && payInfoData
                ? (
                    refundInfo.stlRqAmt - payInfoData.roundTripDeliveryPrice
                  ).toLocaleString()
                : "0"
            }}원
          </li>
        </ul> -->
      </div>
      <!-- Popup Footer -->
      <template slot="footer">
        <div>
          <el-button type="info" @click="popVisibleChangeCash = false"
            >취소</el-button
          >
          <el-button type="primary" @click="changePayCashPop">확인</el-button>
        </div>
      </template>
    </el-dialog>

    <!-- 카드 결제 변경 -->
    <el-dialog title="카드 결제 변경" :visible.sync="popVisibleCard">
      <!-- Popup Contents -->
      <div class="board-wrap">
        <el-form
          ref="cardPaymentPop"
          class="detail-form"
          :model="selCancelPayInfo"
        >
          <el-row>
            <el-col :span="24">
              <el-form-item label="결제자">{{
                selCancelPayInfo.paymentPersonName
              }}</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="요청자">{{
                userInfoData.eeNm
              }}</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="결제금액">{{
                selCancelPayInfo.paymentCompletePrice &&
                  selCancelPayInfo.paymentCompletePrice.toLocaleString() + "원"
              }}</el-form-item>
            </el-col>
          </el-row>
          <!-- <el-row>
            <el-col :span="24">
              <el-form-item label="취소사유">
                <el-select>
                  <el-option label="선택하세요"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row> -->
          <el-row>
            <el-col :span="24">
              <el-form-item label="취소금액">
                <el-radio
                  v-model="checkedRefundAllType"
                  label="전액환불"
                  @change="refundCheck($event, selCancelPayInfo, 'all')"
                  :disabled="selCancelPayInfo.refurndCompletePrice > 0"
                  >전체취소</el-radio
                >
                <el-radio
                  v-model="checkedRefundPartType"
                  label="부분환불"
                  :disabled="
                    selCancelPayInfo.payType === 'addPay' ||
                      selCancelPayInfo.refurndCompletePrice > 0
                  "
                  @change="refundCheck($event, selCancelPayInfo, 'part')"
                  >부분취소</el-radio
                >
                <el-input
                  v-model="refundInfo.stlRqAmt"
                  :placeholder="
                    selCancelPayInfo.paymentCompletePrice &&
                      selCancelPayInfo.paymentCompletePrice.toLocaleString()
                  "
                  :disabled.sync="disabledRefundAmt"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <!-- <ul class="note">
          <li>
            ※ 왕복탁송료 :
            {{
              payInfoData
                ? Number(payInfoData.roundTripDeliveryPrice).toLocaleString()
                : "0"
            }}원
          </li>
          <li>
            ※ 차감 시 취소금액 :
            {{
              refundInfo && payInfoData
                ? (
                    refundInfo.stlRqAmt - payInfoData.roundTripDeliveryPrice
                  ).toLocaleString()
                : "0"
            }}원
          </li>
        </ul> -->
      </div>
      <!-- Popup Footer -->
      <template slot="footer">
        <div>
          <el-button type="info" @click="popVisibleCard = false"
            >취소</el-button
          >
          <el-button type="primary" @click="alertVisibleCancelCash = true"
            >확인</el-button
          >
        </div>
      </template>
    </el-dialog>

    <!--    <el-dialog
      title="현금 결제 변경"
      :visible.sync="popVisibleChangeCash"
      width="1200px"
    >
      <div class="board-wrap" style="padding-top: 10px;">
        <el-table
          ref="cashPaymentPop"
          :data="[selChangePayInfo]"
          @selection-change="onCheck"
        >
          <el-table-column label="은행" prop="paymentContents" align="center" />
          <el-table-column
            label="계좌번호"
            prop="virtualAccount"
            align="center"
          />
          <el-table-column label="예금주 명" prop="depositor" align="center" />
          <el-table-column label="결제일" prop="paymentDate" align="center" />
          <el-table-column
            label="결제 완료 금액"
            prop="paymentCompletePrice"
            :formatter="tableFormatterCash"
            align="center"
          />
          <el-table-column label="환불금액" width="300">
            <template slot-scope="props">
              <div class="refund-td">
                <div>
                  <el-checkbox
                    v-model="checkedRefundPartType"
                    label="부분환불"
                    :disabled="props.row.payType === 'addPay'"
                    @change="refundCheck($event, props, 'part')"
                  />
                  <el-input
                    v-model="refundInfo.stlRqAmt"
                    style="width: 170px"
                    placeholder="금액을 입력하세요."
                    :disabled.sync="disabledRefundAmt"
                  />
                </div>
                <div>
                  <el-checkbox
                    v-model="checkedRefundAllType"
                    label="전액환불"
                    @change="refundCheck($event, props, 'all')"
                  />
                </div>
              </div>
            </template>
          </el-table-column>
        </el-table>
      </div> -->
    <!-- Popup Footer -->
    <!-- <template slot="footer">
        <el-button type="info" @click="popVisibleChangeCash = false">
          취소
        </el-button>
        <el-button type="primary" @click="changePayCashPop">
          적용
        </el-button>
      </template>
    </el-dialog> -->

    <!-- 결제 취소 팝업 -->
    <el-dialog custom-class="message" :visible.sync="alertVisibleCancelCash">
      <!-- Message -->
      결제취소를 진행하시겠습니까?
      <br />
      <span class="text-red">적용 후 이전 상태로 복귀가 불가능 합니다.</span>

      <!-- Popup Footer -->
      <template slot="footer">
        <el-button type="info" @click="alertVisibleCancelCash = false">
          아니요
        </el-button>
        <el-button type="primary" @click="oneClickDisable($event, cancelPayProcess)">
          예
        </el-button>
      </template>
    </el-dialog>

    <!-- 현금 결제 전체 취소 여부 팝업(최초) -->
    <el-dialog custom-class="message" :visible.sync="visibleChangeCashAll.visible">
      <!-- Message -->
      현금으로 결제된 항목 모두를 취소 하시겠습니까?
      <!-- Popup Footer -->
      <template slot="footer">
        <el-button type="info" @click="changePayCash(visibleChangeCashAll.item, visibleChangeCashAll.flag)">
          아니오
        </el-button>
        <el-button type="primary" @click="changePayCashAll()">
          예
        </el-button>
      </template>
    </el-dialog>

    <!-- 결제 변경 팝업 -->
    <el-dialog custom-class="message" :visible.sync="alertVisibleChangeCash">
      <!-- Message -->
      결제변경을 진행하시겠습니까?
      <br />
      <span class="text-red">적용 후 이전 상태로 복귀가 불가능 합니다.</span>

      <!-- Popup Footer -->
      <template slot="footer">
        <el-button type="info" @click="alertVisibleChangeCash = false">
          취소
        </el-button>
        <el-button type="primary" @click="oneClickDisable($event, changePayCashProcess)">
          확인
        </el-button>
      </template>
    </el-dialog>

    <!-- 현금 결제 전체 취소 팝업(최종) -->
    <el-dialog custom-class="message" :visible.sync="alertVisibleChangeCashAll">
      <!-- Message -->
      현금으로 결제된 항목 모두를 취소 하시겠습니까?
      <!-- Popup Footer -->
      <template slot="footer">
        <el-button type="info" @click="alertVisibleChangeCashAll = false">
          아니오
        </el-button>
        <el-button type="primary" @click="changePayAllCashProcess()">
          예
        </el-button>
      </template>
    </el-dialog>

    <el-dialog custom-class="message" :visible.sync="isEmployeeDcPop">
      <!-- Message -->
      직원할인이 적용되지 않았습니다. 계속 진행하시겠습니까?

      <!-- Popup Footer -->
      <template slot="footer">
        <el-button type="info" @click="isEmployeeDcPop = false">
          아니요
        </el-button>
        <el-button type="primary" @click="updateContractAssignPopFunc()">
          예
        </el-button>
      </template>
    </el-dialog>

    <el-dialog custom-class="message" :visible.sync="updateContractAssignPop">
      <!-- Message -->
      출고증발급요청을 진행하시겠습니까?

      <!-- Popup Footer -->
      <template slot="footer">
        <el-button type="info" @click="updateContractAssignPop = false">
          아니요
        </el-button>
        <el-button type="primary" @click="oneClickDisable($event, updateContractAssign)">
          예
        </el-button>
      </template>
    </el-dialog>
    <el-dialog custom-class="message" :visible.sync="beforePrepaymentCardProcessCheckFlag">
      <!-- Message -->
      카드 승인 후 4개월이 경과했습니다.<br>
      판매금융시스템에서 카드정보 복원 후 변경하실 수 있습니다.<br>
      계속 진행하시겠습니까?

      <!-- Popup Footer -->
      <template slot="footer">
        <el-button type="info" @click="beforePrepaymentCardProcessCheckFlag = false">
          아니요
        </el-button>
        <el-button type="primary" @click="cancelPay(preObj, 'prepayment')">
          예
        </el-button>
      </template>
    </el-dialog>
    
    <el-dialog custom-class="message" :visible.sync="partialCancellationInfoPop">
      <!-- Message -->
      ■ 카드 부분취소 가능(6개사) : 현대, 비씨, 롯데, NH농협, 씨티, 하나
      <br><br>
      ※ 신차할부금융 및 캐쉬백 프로모션 등으로 부분취소 불가할수 있으니,
      <br>
      사전에 부분취소 가능여부 카드사 확인후 진행바랍니다.
      <br><br>
      ※ 카드사 청구 후 카드대금 입금 건에 한하여 취소 처리 가능
      <br>
      (당일 승인 당일 부분취소 불가)

      <!-- Popup Footer -->
      <template slot="footer">
        <el-button type="primary" @click="partialCancellationInfoPop = false">
          확인
        </el-button>
      </template>
    </el-dialog>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />

    <loading
      :pop-visible.sync="popVisibleLoading"
      :close-on-click-modal="false"
      @close="popVisibleLoading = false"
    />
  </div>
</template>
<script>
import HTitle from "~/components/common/HTitle.vue";
import HTable from "~/components/common/HTable.vue";
import PopMessage from "~/components/popup/PopMessage.vue";
import Loading from "~/components/popup/Loading.vue";
import moment from "moment";

export default {
  name: "PayInfo",
  components: {
    HTable,
    HTitle,
    PopMessage,
    Loading
  },
  props: {
    contractNumber: {
      type: String,
      default: ""
    },
    userInfoData: {
      // 로그인 사용자 정보
      type: Object,
      default: () => {}
    },
    contractData: {
      type: Object,
      default: () => {}
    },
    contractInfoData: {
      // 계약 정보
      type: Object,
      default: () => {}
    },
    commonCodes: {
      // 공통 코드
      type: Object,
      default: () => {}
    },
    activeUserFlag: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      isAuth: process.env.VUE_APP_AUTH === "true", // 권한 패스용
      popVisibleLoading: false, // 로딩 활성화 여부
      alertMessage: "",
      alertMessagePop: false,
      payInfoData: {},
      saleAmountList: [],
      discountAmountList: [],
      pointAmountList: [],
      taxReductionAmountList: [],
      payAmountList: [],
      payStateList: [],
      payDetail: {},
      visiblePointBtn: false, // 결제금액 - 포인트 - 버튼
      visibleCashBtn: false, // 결제내역 - 카드 or 할부 - 버튼
      selCancelPrePayInfo:{
        depositor: '',
        paymentCompletePrice: ''
      },
      selCancelPayInfo: {
        paymentContents: "",
        paymentPersonName: "",
        paymentDate: "",
        paymentCompletePrice: ""
      }, // 결제취소 팝업 - 취소하려는 결제정보
      selChangePayInfo: {
        paymentContents: "",
        virtualAccount: "",
        depositor: "",
        paymentDate: "",
        paymentCompletePrice: ""
      }, // 결제변경 팝업 - 변경하려는 현금결제정보
      selChangePayAllInfo: {
        depositor: '',
        payAmount: '',
        cancelAmount: 0
      },
      popVisiblePrepaymentCancelCash: false,
      popVisibleCard: false,
      popVisibleChangeCash: false,
      popVisibleChangeCashAll: false,
      alertVisibleCancelCash: false,
      alertVisibleChangeCash: false,
      alertVisibleChangeCashAll: false,
      beforePrepaymentCardProcessCheckFlag: false,
      partialCancellationInfoPop: false,
      visibleChangeCashAll: {
        visible:false,
        item:{},
        flag:'',
      },
      updateContractAssignPop: false,
      checkedRefundPrepayment: true, // 선지급 내역 현금 결제 변경 팝업 - 전체취소 체크 박스
      checkedRefundPartType: false, // 현금 결제 변경 팝업 - 부분환불 체크 박스
      checkedRefundAllType: false, // 현금 결제 변경 팝업 - 전액환불 체크 박스
      disabledPrepaymentRefundAmt: true,
      disabledRefundAmt: true, // 현금 결제 변경 팝업 - 부분환불 input box 활성화/비활성화
      isEmployee: false,
      isEmployeeDc: false,
      isEmployeeDcPop: false,
      blueMembersPreUsePoint: "",
      penaltyPriceTotal: 0, // 위약금
      requestPriceTotal: 0, // 위약금
      refundPreInfo: {
        //선지급 현금 환불 정보
        bank: '',
        guja: ''
      },
      refundInfo: {
        // 현금 환불 정보
        stlRqAmt: "", // 결제 요청 금액
        bankCode: "", // 환불 은행 코드
        bankAccount: "", // 환불 계좌번호
        bankAccountOwner: "", // 환불 계좌 예금주
        cancleReason: "" // 취소사유
      },
      payCompleteDetail: [
        {
          key: "total",
          label: "총 결제금액 (A)",
          payCash: 0,
          refundCash: 0
        },
        {
          key: "completeTotal",
          label: "결제완료금액 (B)",
          payCash: 0,
          refundCash: 0
        },
        {
          key: "unCompleteTotal",
          label: "결제미완료금액 (A-B)",
          payCash: 0,
          refundCash: 0
        }
      ], // 결제내역 - 결제금액 obj
      tableHeader03: [
        {
          label: "상품",
          type: "",
          prop: "",
          align: "center",
          children: [
            {
              label: "상품명",
              type: "",
              prop: "installmentGoodsName",
              align: "center"
            },
            {
              label: "선수금",
              type: "",
              prop: "advancePayment",
              align: "center"
            },
            {
              label: "할부원금",
              type: "",
              prop: "installmentPrincipal",
              align: "center"
            },
            {
              label: "기간",
              type: "",
              width: "90",
              prop: "installmentPeriod",
              align: "center"
            },
            {
              label: "월 납입금",
              type: "",
              prop: "monthlyPaymentTotal",
              align: "center"
            },
            {
              label: "이율",
              type: "",
              prop: "installmentInterest",
              align: "center"
            }
          ]
        },
        {
          label: "진행상태",
          type: "",
          prop: "",
          align: "center",
          children: [
            {
              label: "승인 요청일",
              type: "",
              prop: "installmentRequestDate",
              align: "center"
            },
            {
              label: "결제일",
              type: "",
              prop: "installmentPaymentDate",
              align: "center"
            },
            {
              label: "비고",
              type: "",
              prop: "installmentPaymentStateName",
              align: "center"
            }
          ]
        }
      ],
      tableHeader04: [
        {
          label: "요청",
          type: "",
          prop: "",
          align: "center",
          children: [
            {
              label: "결제자",
              type: "",
              prop: "paymentPersonName",
              align: "center"
            },
            {
              label: "구분",
              type: "",
              prop: "cardRequestSectionalName",
              align: "center"
            },
            {
              label: "요청일",
              type: "",
              prop: "cardRequestDate",
              align: "center"
            }
          ]
        }
      ],
      tableHeader06: [
        {
          label: "포인트 적립 대상",
          prop: "blueMembersPoint",
          type: "",
          align: "center"
        },
        {
          label: "적립율",
          prop: "blueMembersRate",
          type: "",
          align: "center"
        },
        {
          label: "이번 구매로 인한 적립 예정 포인트",
          prop: "blueMembersPrearrangementPoint",
          type: "",
          align: "center"
        },
        {
          label: "포인트 선사용",
          prop: "blueMembersContents",
          type: "",
          align: "center"
        }
      ],
      /*
        [#9598/2021.11.09/A936506]
        출고 결제버튼 비활성화 추가
        단 출고 & 추가할인 전담DC인 경우 결제버튼 활성화 (A001)
        !! 추가할인 여부 구분용 데이터 컬럼 추가 !!
      */
      exclusiveDc: false,
      QsignFlag : false,
      preObj: {},
    }
  },
  computed: {
    transDetail: function() {
      const transMap = this.payCompleteDetail.slice();
      transMap.map(items => {
        switch (items.key) {
        case "total":
          items.payCash = this.payDetail.paymentPriceTotal || 0;
          items.refundCash = this.payDetail.refundPriceTotal || 0;
          break;
        case "completeTotal":
          items.payCash = this.payDetail.paymentCompletePriceTotal || 0;
          items.refundCash = this.payDetail.refundCompletePriceTotal || 0;
          break;
        case "unCompleteTotal":
          items.payCash = this.payDetail.paymentNotCompletedPriceTotal || 0;
          items.refundCash = this.payDetail.refundNotCompletedPriceTotal || 0;
          break
        }
      })
      return transMap
    }
  },
  watch: {
    contractInfoData: function() {
      Object.assign(this.$data, this.$options.data());
      this.isEmployee =
        this.contractInfoData.contractPersonalCorporationCode !== "3" &&
        (this.contractInfoData.customerTypeCode !== "AA1" &&
          this.contractInfoData.customerTypeCode !== "BA1" &&
          this.contractInfoData.customerTypeCode !== "BL1")
          ? true
          : false;
    }
    // payDetail(newVal) {
    //   console.log(newVal)
    //   this.payCompleteDetail.map((items) => {
    //     switch(items.key) {
    //     case 'total':
    //       items.payCash = newVal.paymentPriceTotal || 0
    //       items.refundCash = newVal.refundPriceTotal || 0
    //       break
    //     case 'completeTotal':
    //       items.payCash = newVal.paymentCompletePriceTotal || 0
    //       items.refundCash = newVal.refundCompletePriceTotal || 0
    //       break
    //     case 'unCompleteTotal':
    //       items.payCash = newVal.paymentNotCompletedPriceTotal || 0
    //       items.refundCash = newVal.refundNotCompletedPriceTotal || 0
    //       break
    //     }
    //   })
    // }
  },
  async created() {
      
  },
  methods: {
    async getAllData() {
      // API-E-업무담당자-020 (결제정보 조회)
      // if(Object.keys(this.payInfoData).length===0) {

      const [res1, err1] = await this.$https.post(
        "/v2/exclusive/work/payment",
        { contractNumber: this.contractNumber }
      );
      if (!err1) {
        console.log("/work/payment/", res1.data);
        this.payInfoData = res1.data;
      } else {
        console.error(err1);
      }
      // }

      // API-E-업무담당자-021 (결제금액 조회)
      // if(this.payAmountList.length===0) {
      const [res2, err2] = await this.$https.post(
        "/v2/exclusive/work/payment-amount",
        { contractNumber: this.contractNumber }
      );
      if (!err2) {
        console.log("/work/payment-amount/", res2.data);
        this.payInfoData.totalPrice = 0;
        let totalDiscount = 0,
          totalPoint = 0,
          totalDiscountRate = 0,
          totalPointRate = 0;

        this.payAmountList = [];
        this.saleAmountList = []; // 총 판매금액 리스트
        this.discountAmountList = []; // 총 할인금액 리스트
        this.pointAmountList = []; // 총 포인트 사용 리스트
        this.taxReductionAmountList = []; // 총 감면세액 리스트

        if (res2.data) {
          this.saleAmountList.push({
            name: "차량대금",
            content: "",
            price: res2.data.carPrice
              ? res2.data.carPrice.toLocaleString() + "원"
              : "0원",
            pointState: "",
            background: "",
            type: ""
          });
          this.saleAmountList.push({
            name: "탁송료",
            content: "",
            price: res2.data.deliveryPrice
              ? res2.data.deliveryPrice.toLocaleString() + "원"
              : "0원",
            pointState: "",
            background: "",
            type: ""
          });
          this.saleAmountList.push({
            name: "임시운행 의무보험료",
            content: "",
            price: res2.data.insurancePayment
              ? res2.data.insurancePayment.toLocaleString() + "원"
              : "0원",
            pointState: "",
            background: "",
            type: ""
          });

          if (res2.data.certificateStamp > 0) {
            this.saleAmountList.push({
              name: "할부인지대",
              content: "",
              price: res2.data.certificateStamp
                ? res2.data.certificateStamp.toLocaleString() + "원"
                : "0원",
              pointState: "",
              background: "",
              type: ""
            });
          }

          this.payAmountList.push({
            name: "차량금액",
            content: "",
            price: res2.data.carPrice
              ? res2.data.carPrice.toLocaleString() + "원"
              : "0원",
            pointState: "",
            background: "",
            type: ""
          });
          this.payAmountList.push({
            name: "탁송료",
            content: "",
            price: res2.data.deliveryPrice
              ? res2.data.deliveryPrice.toLocaleString() + "원"
              : "0원",
            pointState: "",
            background: "",
            type: ""
          });
          this.payAmountList.push({
            name: "단기의무보험료",
            content: "",
            price: res2.data.insurancePayment
              ? res2.data.insurancePayment.toLocaleString() + "원"
              : "0원",
            pointState: "",
            background: "",
            type: ""
          });

          this.payInfoData.totalTaxReduction = 0;
          if (res2.data.greenTaxFreePrice) {
            //2020.03.03 친환경면세 => 개소세면세
            this.payAmountList.push({
              name: "개소세면세",
              content: "",
              price: res2.data.greenTaxFreePrice
                ? res2.data.greenTaxFreePrice.toLocaleString() + "원"
                : "0원",
              pointState: "",
              background: "",
              type: ""
            });
            this.taxReductionAmountList.push({
              name: "개별소비세 면세",
              content: "",
              price: res2.data.greenTaxFreePrice
                ? res2.data.greenTaxFreePrice.toLocaleString() + "원"
                : "0원",
              pointState: "",
              background: "",
              type: ""
            });

            this.payInfoData.totalTaxReduction = res2.data.greenTaxFreePrice
              ? res2.data.greenTaxFreePrice.toLocaleString() + "원"
              : "0원";
          }
          //총 할인
          res2.data.discountInfo &&
            res2.data.discountInfo.map(el => {
              totalDiscount += el.discountPrice;
              totalDiscountRate += el.discountRate || 0;
            });
          res2.data.pointInfo &&
            res2.data.pointInfo.map(el => {
              //총 포인트
              if (
                el.pointUseStateCode === "S" ||
                el.pointUseStateCode === "X"
              ) {
                // 처리 완료 상태 || 취소실패일때
                totalPoint += el.usePoint;
              }
            });
          if (res2.data.totalTcpRate) {
            totalPointRate = res2.data.totalTcpRate;
          }

          //총 할인금액 % = 할인금액% + 당사분담금액 포인트%
          totalDiscountRate += totalPointRate || 0;

          this.payAmountList.push({
            name: "총 할인금액",
            content: "",
            percent: totalDiscountRate
              ? totalDiscountRate.toFixed(1) + "%"
              : "0%",
            price: totalDiscount.toLocaleString() + "원",
            pointState: "",
            background: "red",
            type: ""
          });

          let discountDetailList = []
          let typeTotalDiscount = 0

          res2.data.discountInfo &&
            res2.data.discountInfo.map((el, idx, ary) => {

              /*
                [#9598/2021.11.09/A936506]
                출고 결제버튼 비활성화 추가
                단 출고 & 추가할인 전담DC인 경우 결제버튼 활성화 (A001) -> 현재 이 경우.
                discountCnsuNo 컬럼이 있는 경우 DC품의할인 (A001이 항상 포함인지는 모르겠음) -> 해당형태로 변경 가능성 o
              */
              /*
              1.
              ('전담 DC품의 번호가 존재하는 할인'인 경우에만)
              if(['A001'].includes(el.discountCode) && el.discountCnsuNo) {
                this.exclusiveDc = true
              }
              */
              // 2. 추가할인인 경우에만.
              if(['A001'].includes(el.discountCode)) {
                this.exclusiveDc = true
              }

              this.payAmountList.push({
                name:
                  idx === 0 ||
                  el.discountTypeName !== ary[idx - 1].discountTypeName
                    ? el.discountTypeName
                    : "",
                content:
                  el.discountContents !== null
                    ? el.discountContents
                    : el.discountName,
                percent: el.discountRate ? el.discountRate + '%' : '',
                price: el.discountPrice
                  ? el.discountPrice.toLocaleString() + '원'
                  : '',
                pointState: '',
                background: '',
                // [#9598/2021.11.09/A936506] 추가할인 전담DC인 경우 결제버튼 활성화 해야하므로 코드값 저장(A001)
                type: el.discountCode ? el.discountCode : ''
              });

              if(idx === 0 ||
                  el.discountTypeName !== ary[idx - 1].discountTypeName){

                   if(idx!==0){
                    this.discountAmountList.push({
                        name: ary[idx - 1].discountTypeName==="기본할인"?"기본할인(계)":ary[idx - 1].discountTypeName,
                        content: "",
                        price: typeTotalDiscount.toLocaleString() + "원",
                        pointState: "",
                        background: "",
                        type: "",
                        detail: discountDetailList
                      });
                    }

                    discountDetailList = [];
                    typeTotalDiscount = 0;
              }

              //타입별 할인금액 합산
              typeTotalDiscount += el.discountPrice;
              discountDetailList.push({
                name:
                  idx === 0 ||
                  el.discountTypeName !== ary[idx - 1].discountTypeName
                    ? el.discountTypeName
                    : "",
                content:
                  el.discountContents !== null
                    ? el.discountContents
                    : el.discountName,
                percent: el.discountRate ? el.discountRate + "%" : "",
                price: el.discountPrice
                  ? el.discountPrice.toLocaleString() + "원"
                  : "",
                pointState: "",
                background: "",
                type: ""
              });

            if(res2.data.discountInfo.length-1===idx){
              this.discountAmountList.push({
                  name: ary[idx ].discountTypeName,
                  content: "",
                  price: typeTotalDiscount.toLocaleString() + "원",
                  pointState: "",
                  background: "",
                  type: "",
                  detail: discountDetailList
                });
              }
            });



          this.payAmountList.push({
            name: "총 포인트 금액",
            content: "",
            percent: totalPointRate ? totalPointRate.toFixed(1) + "%" : "0%",
            price: totalPoint.toLocaleString() + "원",
            pointState: "",
            background: "red",
            type: ""
          });

          res2.data.pointInfo &&
            res2.data.pointInfo.map((el, idx) => {
              let payType = "";
              if (el.pointCode === "HC" && el.saveAutoPointYn) {
                payType = "save-auto"; // API-E-결제서비스-027 (세이브오토 취소 처리)
              } else if (el.pointCode === "HC" && !el.saveAutoPointYn) {
                payType = "m-point"; // API-E-결제서비스-025 (M포인트 취소 처리)
              } else if (el.pointCode === "OH" && el.saveAutoPointYn !== "Y") {
                payType = "blue-point"; // API-E-결제서비스-026 (블루멤버스 포인트 취소 처리)
              } else if (el.pointCode === "OH" && el.saveAutoPointYn === "Y") {
                payType = "blue-prepoint"; // API-E-결제서비스-026 (블루멤버스 선사용 포인트 취소 처리)
              }

              this.payAmountList.push({
                name: idx === 0 ? "포인트" : "",
                content: el.pointName || "",
                price: el.usePoint ? el.usePoint.toLocaleString() + "원" : "",
                pointState: el.pointUseState || "",
                background: "",
                type: "button",
                payType: payType,
                useCompleteYn: el.useCompleteYn,
                customerManagementNumber: el.customerManagementNumber
              });

              if (el.useCompleteYn === "Y" || el.pointUseStateCode === "S" || el.pointUseStateCode === "C"
              ||el.pointUseStateCode === "G" || el.pointUseStateCode === "P" ) {
                this.pointAmountList.push({
                  name: idx === 0 ? "포인트" : "",
                  content: el.pointName || "",
                  price: el.usePoint && el.useCompleteYn === "Y" ? el.usePoint.toLocaleString() + "원" : el.pointUseState ,
                  pointStateCode: el.pointUseStateCode || "",
                  pointState: el.pointUseState || "",
                  background: "",
                  type: el.usePoint && (el.useCompleteYn === "Y" || el.pointUseStateCode === "C") ? "button" : "",
                  payType: payType,
                  useCompleteYn: el.useCompleteYn,
                  customerManagementNumber: el.customerManagementNumber
                });
              }

              if (
                el.useCompleteYn === "Y" &&
                el.pointCode === "OH" &&
                el.saveAutoPointYn === "Y"
              ) {
                this.blueMembersPreUsePoint = el.usePoint;
              }
            });

          this.payInfoData.totalSalePrice =
            (res2.data.carPrice || 0) +
            (res2.data.deliveryPrice || 0) +
            (res2.data.insurancePayment || 0);
          this.payInfoData.totalDiscount = totalDiscount || 0;
          this.payInfoData.totalPoint = totalPoint || 0;
          this.payInfoData.totalPrice =
            (res2.data.carPrice || 0) +
            (res2.data.deliveryPrice || 0) +
            (res2.data.insurancePayment || 0) +
            (res2.data.certificateStamp || 0) -
            totalDiscount -
            totalPoint -
            (res2.data.greenTaxFreePrice || 0);
          this.payInfoData.totalPrice4Mypage =
            (res2.data.carPrice || 0) +
            (res2.data.deliveryPrice || 0) +
            (res2.data.insurancePayment || 0) +
            (res2.data.certificateStamp || 0) -
            totalDiscount -
            (res2.data.greenTaxFreePrice || 0);

          this.payInfoData.roundTripDeliveryPrice =
            res2.data.roundTripDeliveryPrice;

          this.payStateList = [];
          this.payStateList.push({
            contractCarTypeName: this.payInfoData.contractCarTypeName,
            taxationSectionalName: this.payInfoData.taxationSectionalName,
            taxationTypeName: this.payInfoData.taxationTypeName,
            qSignYn: this.payInfoData.qSignYn || "N",
            paymentStartDate: this.payInfoData.paymentStartDate || "없음",
            paymentTimeLimitDate: this.payInfoData.paymentTimeLimitDate || "없음",
            paymentDate: this.payInfoData.paymentDate || "없음",
            paymentStateName: this.payInfoData.paymentStateName || "없음",
            approveDate: this.payInfoData.approveDate || "없음",
            afterApproveDate: this.payInfoData.afterApproveDate || "없음"
          });

          //직원 할인 여부 체크///////////
          if(res2.data.discountInfo){
            for(let discountData of res2.data.discountInfo){
              if(discountData.discountCode === 'C003'){
                this.isEmployeeDc = true
              }
            }
          }
          /////////////////////////////////
        }
      } else {
        console.error(err2);
      }
      // }

      // API-E-업무담당자-022 (결제내역 상세조회)
      // if(Object.keys(this.payDetail).length===0) {
      const [res3, err3] = await this.$https.post(
        "/v2/exclusive/work/payment-details",
        { contractNumber: this.contractNumber }
      );
      if (!err3) {
        console.log("/work/payment/", res3.data);
        res3.data.installmentInfo &&
          res3.data.installmentInfo.map(el => {
            el.advancePayment = el.advancePayment
              ? el.advancePayment.toLocaleString() + "원"
              : "-";
            el.installmentPrincipal = el.installmentPrincipal
              ? el.installmentPrincipal.toLocaleString() + "원"
              : "-";
            el.monthlyPaymentTotal = el.monthlyPaymentTotal
              ? el.monthlyPaymentTotal.toLocaleString() + "원"
              : "-";
          });
        res3.data.cardInfo &&
          res3.data.cardInfo.map(el => {
            el.cardPaymentPrice = el.cardPaymentPrice
              ? el.cardPaymentPrice.toLocaleString() + "원"
              : "-";
          });

        this.requestPriceTotal = 0;
        this.requestPriceTotal = this.payInfoData.totalPrice;

        res3.data.paymentInfo &&
          res3.data.paymentInfo.map(el => {
            let payType = "";
            if (el.paymentTypeCode === "20") {
              payType = "card"; // API-E-결제서비스-023 (카드 취소 처리)
            } else if (el.paymentTypeCode === "10") {
              payType = "installment"; // API-E-결제서비스-024 (할부 취소 처리)
            } else if (el.paymentTypeCode === "30") {
              payType = "cash"; // cash 현금은 별도 처리 방식
            } else if (el.paymentTypeCode === "fakeExamine") {
              payType = "fakeExamine"; // 가승인 할부 API-WX-결제서비스-011 (현대캐피탈 할부 가심사 취소)
            }
            el.payType = payType;
          });

        res3.data.additionPaymentInfo &&
          res3.data.additionPaymentInfo.map(el => {
            let payType = "";
            if (el.paymentTypeCode === "20") {
              payType = "card"; // API-E-결제서비스-023 (카드 취소 처리)
            } else if (el.paymentTypeCode === "10") {
              payType = "installment"; // API-E-결제서비스-024 (할부 취소 처리)
            } else if (el.paymentTypeCode === "30") {
              payType = "cash"; // cash 현금은 별도 처리 방식
            }
            el.payType = payType;

            if(el.paymentSectionCode==="05"){
              this.requestPriceTotal += el.paymentPrice || 0; //추가결제 더하기
            }
          });

        res3.data.prepaymentInfo &&
          res3.data.prepaymentInfo.map(el => {
            //this.requestPriceTotal += el.paymentPrice || 0;  //계약금 더하기
          });

        this.payDetail = res3.data;

        if (
          this.contractData.penaltyYn === "Y" ||
          this.payDetail.additionPaymentInfo.length > 0
        ) {
          this.penaltyPriceTotal = 0;
          if (this.contractData.penaltyYn === "Y") {
            this.payDetail.prepaymentInfo.map(el => {
              if (el.paymentSectionName === "계약금") {
                this.penaltyPriceTotal += el.paymentCompletePrice || 0;
              }
            });
          }
          if (this.payDetail.additionPaymentInfo.length > 0) {
            this.payDetail.additionPaymentInfo.map(el => {
              if (el.paymentSectionCode === "05") {
                this.penaltyPriceTotal += el.paymentCompletePrice || 0;
              }
            });
          }
        }

        // API-WE-결제서비스-018_(현대카드 혜택 조회)
        // if(Object.keys(this.payDetail).length===0) {
       /*  const [res4, err4] = await this.$https.get(
          "payment/v2/payment/hyundai-card/benefit?contractNumber=" +
            this.contractNumber +
            "&customerManagementNumber=" +
            this.contractInfoData.customerNumber,
          null,
          null,
          "gateway"
        );
        if (!err4) {
          console.log("payment/v2/payment/hyundai-card/benefit", res4.data);
          if (res4.data && res4.data.pvslAplLimGrntYn) {
            if (res4.data.pvslAplLimGrntYn === "Y") {
              this.pointAmountList.push({
                name: idx === 0 ? "포인트" : "",
                content: "한도상향",
                price: "신청",
                pointState: "",
                background: "",
                type: "",
                payType: "",
                useCompleteYn: "",
                customerManagementNumber: ""
              });
            }
          }
        } */

        const {
          blueMembersRate,
          blueMembersPrearrangementPoint,
          blueMembersPoint,
          blueMembersContents
        } = res3.data;
        this.payDetail.blueInfo = [
          {
            blueMembersRate: blueMembersRate
              ? Number(blueMembersRate).toFixed(1)
              : "-",
            blueMembersPrearrangementPoint: blueMembersPrearrangementPoint
              ? Number(blueMembersPrearrangementPoint).toLocaleString()
              : "-",
            blueMembersPoint: blueMembersPoint
              ? blueMembersContents +
                " (" +
                Number(blueMembersPoint).toLocaleString() +
                ")"
              : blueMembersContents + " (-)",
            blueMembersContents: this.blueMembersPreUsePoint
              ? this.blueMembersPreUsePoint.toLocaleString() + "원"
              : "-"
          }
        ];
      } else {
        console.error(err3);
      }

      
      
      let unprocessedPrice = (this.requestPriceTotal||0) - (this.payDetail.paymentCompletePriceTotal||0) + (this.payDetail.refundCompletePriceTotal||0) ;
                    
      
      // console.log("this.requestPriceTotal >> "+ this.requestPriceTotal);
      // console.log("this.payDetail.paymentCompletePriceTotal >> "+ this.payDetail.paymentCompletePriceTotal);
      // console.log("this.payDetail.refundCompletePriceTotal||0 >> "+ this.payDetail.refundCompletePriceTotal||0);
      // console.log(this.requestPriceTotal - this.payDetail.paymentCompletePriceTotal + (this.payDetail.refundCompletePriceTotal||0));
      // console.log(this.requestPriceTotal && this.payDetail.paymentCompletePriceTotal);
      // console.log("unprocessedPrice >> "+ unprocessedPrice);

      if(unprocessedPrice === 0){
        this.QsignFlag = true;
      }else{
        this.QsignFlag = false;
      }
      console.log("QsignFlag >> "+ this.QsignFlag);

    },
    formatCash(data) {
      return data ? data.toLocaleString() + "원" : "";
    },
    tableFormatterCash(row) {
      return parseInt(row.paymentCompletePrice).toLocaleString() + "원";
    },
    tableRowClassName({ row }) {
      if (row.background === "red") {
        return "warning-row";
      } else if (row.border === "red") {
        return "warning-row1";
      }
      return "";
    },
    isValidAuthBtn(authId) {
      // 버튼별 권한 체크
      let bResult = false; // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || [];
      if (currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some(items => {
          if (items.btnId === authId) {
            bResult = true;
            return true;
          }
        });
      }
      return bResult;
    },
    onCheck(value) {
      console.log(value);
    },
    refundCheck(event, props, type) {
      this.partialCancellationInfoPop = false;
      
      // 현금 결제 팝업 - 환불금액 체크 박스 이벤트
      if (type === "part") {
        // 부분환불
        if (event) {
          // 카드 부분취소시 dialog
          if (event === '부분환불' && props.payType === 'card') {
            this.partialCancellationInfoPop = true;
          }
        
          // 체크한 경우에만
          this.checkedRefundAllType = false;
          this.disabledRefundAmt = false;
        }
      } else if (type === "all") {
        // 전액환불
        if (event) {
          // 체크한 경우에만
          this.checkedRefundPartType = false;
          this.disabledRefundAmt = true;
          this.refundInfo.stlRqAmt = props.paymentCompletePrice;
        }
      }
    },
    activePayBtn(type) {
      // 결제변경 버튼 - 타입별 변경 버튼 활성화

      const { legacyStatusCode = '' } = this.contractInfoData

      // 2020.02.28 취소 버튼 활성화 기준 변경
      // if(onlineStatusCode  !== '0200' && !isNaN(parseInt(legacyStatusCode)) && ![40, 50, 60].includes(parseInt(legacyStatusCode))) { // 허용  0200: 결제완료, 40: 출고요청, 50: 출고접수, 60: 출고
      
      /*
        [#9598/2021.11.09/A936506]
        출고상태(60) 결제버튼 비활성화 추가
        단 출고 & 추가할인 전담DC인 경우 결제버튼 활성화 (A001)
      */
      let legacyStatusCodeInt = parseInt(legacyStatusCode || 0)

      if ((this.exclusiveDc && legacyStatusCodeInt === 60) || ![40, 50, 60].includes(legacyStatusCodeInt)) {
        // 허용   40: 출고요청, 50: 출고접수, 60: 출고
        switch (type) {
        case 'point': // 포인트
          if (this.visiblePointBtn) {
            this.visiblePointBtn = false
          } else {
            this.visiblePointBtn = true
          }
          break
        case 'cash': // 할부 or 카드
          if (this.visibleCashBtn) {
            this.visibleCashBtn = false
          } else {
            this.visibleCashBtn = true
          }
          break
        }
      } else {
        // alert
        this.alertMessage = '결제 변경이 불가한 계약진행상태입니다.'
        this.alertMessagePop = true
        return false
      }
    },
    cancelPay(obj, type) {
      // 결제변경 버튼 - 포인트 - 취소 버튼
      this.beforePrepaymentCardProcessCheckFlag = false
      console.log(obj);
      if (type === 'prepayment') {
        // 선지급
        this.selCancelPayInfo = { ...obj, payType: "down-payment" }; // 계약금 취소
      } else {
        this.selCancelPayInfo = obj; // 클릭한 결제 취소 정보
      }

      this.alertVisibleCancelCash = true;
    },
    changePayCard(obj) {
      // 클릭한 현금 결제 정보
      this.selCancelPayInfo = obj;
      this.selCancelPayInfo.payType = "card";
      const cashPaymentInfo = this.payDetail.paymentInfo.filter(items => {
        const { paymentMeanNumber, paymentTypeCode } = this.selCancelPayInfo;
        return (
          paymentTypeCode === "20" &&
          paymentMeanNumber === items.paymentMeanNumber &&
          items.refundDate
        );
      });

      const sumRefundPrice = cashPaymentInfo.reduce((price, items) => {
        return price + items.refundPrice;
      }, 0); // 환불되어있는 케이스의 금액 합계

      const accSumPaymentPrice =
        Number(this.selCancelPayInfo.paymentCompletePrice) -
          Number(sumRefundPrice) || 0;

      this.selCancelPayInfo = {
        ...this.selCancelPayInfo,
        paymentCompletePrice: accSumPaymentPrice,
        refurndCompletePrice: Number(sumRefundPrice) || 0
      };

      this.refundCheck(true, this.selCancelPayInfo, "part");

      this.refundInfo.stlRqAmt = ""; // init
      this.checkedRefundPartType = Number(sumRefundPrice) > 0 ? true : false; // init
      this.checkedRefundAllType = false; // init
      this.popVisibleCard = true;
      this.$nextTick(() => {
        //this.$refs.cashPaymentPop && this.$refs.cashPaymentPop.doLayout(); // 선 체크안하면 error
      });
    },
    changePayCash(obj, type = "") {
      // 클릭한 현금 결제 정보
      this.selChangePayInfo = { ...obj, payType: type };
      if (type === "normal") {
        // 결제내역 - 현금 환불일 경우 =>(추가결제 case x)
        // 현금 결제 정보
        const cashPaymentInfo = this.payDetail.paymentInfo.filter(items => {
          const { paymentMeanNumber, paymentTypeCode } = this.selChangePayInfo;
          return (
            paymentTypeCode === "30" &&
            paymentMeanNumber === items.paymentMeanNumber &&
            items.refundDate
          );
        });

        const sumRefundPrice = cashPaymentInfo.reduce((price, items) => {
          return price + items.refundPrice;
        }, 0); // 환불되어있는 케이스의 금액 합계

        const accSumPaymentPrice =
          Number(this.selChangePayInfo.paymentCompletePrice) -
            Number(sumRefundPrice) || 0;

        this.selChangePayInfo = {
          ...this.selChangePayInfo,
          paymentCompletePrice: accSumPaymentPrice
        };
      }

      this.refundInfo.stlRqAmt = ""; // init
      this.checkedRefundPartType = false; // init
      this.checkedRefundAllType = false; // init
      this.popVisibleChangeCash = true;
      this.$nextTick(() => {
        //this.$refs.cashPaymentPop && this.$refs.cashPaymentPop.doLayout(); // 선 체크안하면 error
      });

      //visibleChangeCashAll 초기화///////////////
      this.visibleChangeCashAll.visible = false
      this.visibleChangeCashAll.item = {}
      this.visibleChangeCashAll.flag = ''
      /////////////////////////////////////////////////
    },
    changePayCashAll(obj, type = "") {
      //시작전 초기화
      this.selChangePayAllInfo = { depositor: '', payAmount: '', cancelAmount: 0}
      this.refundInfo = {
        stlRqAmt: "", // 결제 요청 금액
        bankCode: "", // 환불 은행 코드
        bankAccount: "", // 환불 계좌번호
        bankAccountOwner: "", // 환불 계좌 예금주
        cancleReason: "" // 취소사유
      }

      //현금 전체 취소 최초 팝업 확인시 현금 결제 변경 setting process
      //결제내역
      for(let info of this.payDetail.paymentInfo){
        if(info.paymentStateCode === '22' && info.paymentTypeCode === '30' && info.refundPossibleYn === 'Y'){
          if(this.selChangePayAllInfo.payAmount === ''){
            this.selChangePayAllInfo.payAmount = info.paymentCompletePrice.toLocaleString()
          }else{
            this.selChangePayAllInfo.payAmount = this.selChangePayAllInfo.payAmount + ' + ' + info.paymentCompletePrice.toLocaleString()
          }
          this.selChangePayAllInfo.cancelAmount = this.selChangePayAllInfo.cancelAmount + info.paymentCompletePrice
          this.selChangePayAllInfo.depositor = info.depositor
        }
      }

      //추가결제내역
      for(let addInfo of this.payDetail.additionPaymentInfo){
        if(addInfo.paymentStateCode === '22' && addInfo.paymentTypeCode === '30' && addInfo.refundPossibleYn === 'Y'){
          if(this.selChangePayAllInfo.payAmount === ''){
            this.selChangePayAllInfo.payAmount = addInfo.paymentCompletePrice.toLocaleString()
          }else{
            this.selChangePayAllInfo.payAmount = this.selChangePayAllInfo.payAmount + ' + ' + addInfo.paymentCompletePrice.toLocaleString()
          }
          this.selChangePayAllInfo.cancelAmount = this.selChangePayAllInfo.cancelAmount + addInfo.paymentCompletePrice
          this.selChangePayAllInfo.depositor = addInfo.depositor
        }
      }

      this.selChangePayAllInfo.cancelAmount = (this.selChangePayAllInfo.cancelAmount).toLocaleString()+ '원'

      this.popVisibleChangeCashAll = true

      //visibleChangeCashAll 초기화///////////////
      this.visibleChangeCashAll.visible = false
      this.visibleChangeCashAll.item = {}
      this.visibleChangeCashAll.flag = ''
      /////////////////////////////////////////////////
    },
    changePayCashPop() {
      // 현금결제변경 팝업 - 적용버튼
      if (this.checkedRefundPartType || this.checkedRefundAllType) {
        this.refundInfo.stlRqAmt = ("" + this.refundInfo.stlRqAmt)
          .split(",")
          .join("");
        if (parseInt(this.refundInfo.stlRqAmt.split(",").join("") || 0) > 0) {
          if (
            !this.checkedRefundAllType &&
            this.selChangePayInfo.paymentCompletePrice <
              parseInt(this.refundInfo.stlRqAmt)
          ) {
            this.alertMessage =
              "환불금액을 확인해주세요.\n(환불금액이 결제금액을 초과했습니다.)";
            this.alertMessagePop = true;
            return false;
          }
          this.alertVisibleChangeCash = true;
        } else {
          this.alertMessage = "환불금액을 확인해주세요.";
          this.alertMessagePop = true;
          return false;
        }
      } else {
        this.alertMessage = "환불유형을 선택해주세요.";
        this.alertMessagePop = true;
        return false;
      }
    },
    async cancelPayProcess() {
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      // 결제변경 - 취소 - 결제취소 진행 팝업 - 예
      const {
        contractNumber: saleCnttNo = "",
        employeeId: rqEeno = ""
      } = this.contractInfoData; // 계약출고 상세정보
      let {
        paymentOrder: stlNos = "",
        paymentMeanNumber: stlMeanNo = "",
        customerManagementNumber: csmrMgmtNo = "",
        payType = "",
        paymentPrice = "",
        paymentStateCode = "",
        paymentTypeCode = "",
        addStlRqSn = "",
        addStlTrtmSn = ""
      } = this.selCancelPayInfo; // 카드 or 할부일 경우에만 데이터가 존재함 ( 포인트 타입 해당 x )

      console.log(this.selCancelPayInfo);

      addStlRqSn = addStlRqSn || "";
      addStlTrtmSn = addStlTrtmSn || "";

      let params = {};

      if (paymentTypeCode === "30" && paymentStateCode === "21") {
        // 현금 - 입금 대기 케이스
        params = {
          saleCnttNo, // 판매계약번호
          refundList:[{
            stlNos, // 결제차수
            stlMeanNo, // 결제수단번호
            addStlRqSn, // 결제차수 - 추가결제
            addStlTrtmSn, // 결제수단번호 - 추가결제
            bank: this.refundInfo.bankCode,
            guja: this.refundInfo.bankAccount,
            amount: paymentPrice || 0, // 환불금액
            procDivs: "DC" // 입금대기
          }]
        };

        this.popVisibleLoading = true;

        const [res, err] = await this.$https.post(
          "/payment/v2/payment/refund/cash",
          params,
          null,
          "gateway"
        ); // API-E-결제서비스-022 (현금 환불대기/환불처리/입금취소)
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
          this.popVisibleLoading = false
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
        if (!err) {
          console.log(res);
          if (res.rspStatus && res.rspStatus.rspCode === "0000") {
            this.alertMessage = "취소되었습니다.";
            this.alertMessagePop = true;
            this.$emit("refresh", true);
            this.popVisibleLoading = false;
          } else {
            this.popVisibleLoading = false;
          }
        } else {
          this.popVisibleLoading = false;
          console.error(err);
        }
      } else if (payType === "blue-prepoint") {
        // 선사용 포인트 취소처리

        if (!this.contractData.blueMembersPrePointCode) {
          this.alertMessage = "선포인트 상품 코드 정보가 없습니다.";
          this.alertMessagePop = true;
          return;
        }

        params = {
          saleCnttNo, // 판매계약번호
          csmrMgmtNo, //고객관리번호
          alpCtyNo: this.contractData.blueMembersPrePointCode, // 선포인트 상품코드
          saleModelCode: this.contractInfoData.saleModelCode, // 판매모델코드
          saleAmt: this.blueMembersPreUsePoint, // 선포인트 상품가격
          csmrNm: this.contractInfoData.contractorName, // 주계약자 고객명
          exclusiveYn:"Y"
        };

        this.popVisibleLoading = true;
        const [res, err] = await this.$https.get(
          "payment/v2/payment/point/blue-point/advance-cancel",
          params,
          null,
          "gateway"
        ); // 결제 타입별 취소 API(API-E-결제서비스-023 ~ 027)
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
          this.popVisibleLoading = false
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
        if (!err) {
          console.log(res);
          if (res.rspStatus && res.rspStatus.rspCode === "0000") {
            this.alertMessage = res.data.errMsg || "환불되었습니다.";
            this.alertMessagePop = true;
            this.$emit("refresh", true);
            this.alertVisibleCancelCash = false;
            this.alertVisibleChangeCash = false;
            this.popVisibleLoading = false;
          } else {
            this.popVisibleLoading = false;
          }
        } else {
          this.popVisibleLoading = false;
          console.error(err);
        }
      } else if (
        this.checkedRefundPartType &&
        ["installment", "card"].includes(payType)
      ) {
        if (
          Number(this.refundInfo.stlRqAmt) >
          Number(this.selCancelPayInfo.paymentCompletePrice)
        ) {
          this.alertMessage =
            "환불금액을 확인해주세요.\n(환불금액이 결제금액을 초과했습니다.)";
          this.alertMessagePop = true;
          this.alertVisibleCancelCash = false;
          this.alertVisibleChangeCash = false;
          return;
        }

        if (Number(this.refundInfo.stlRqAmt) === 0) {
          this.alertMessage = "환불금액을 확인해주세요.";
          this.alertMessagePop = true;
          this.alertVisibleCancelCash = false;
          this.alertVisibleChangeCash = false;
          return;
        }

        params = {
          saleCnttNo,
          stlNos: this.selCancelPayInfo.paymentOrder,
          stlMeanNo: this.selCancelPayInfo.paymentMeanNumber,
          bank: '',
          guja: '',
          rqEeno,
          celAmt: this.refundInfo.stlRqAmt,
          procDivsType: 'CARD'
        };
        
        this.popVisibleLoading = true;
        const [res, err] = await this.$https.get(
          "payment/v2/payment/cancellation/partial",
          params,
          null,
          "gateway"
        ); // 결제 타입별 취소 API(API-E-결제서비스-023 ~ 027)
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
          this.popVisibleLoading = false
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
        if (!err) {
          console.log(res);
          if (res.rspStatus && res.rspStatus.rspCode === "0000") {
            this.alertMessage = res.data.errMsg || "환불되었습니다.";
            this.alertMessagePop = true;
            this.$emit("refresh", true);
            this.alertVisibleCancelCash = false;
            this.alertVisibleChangeCash = false;
            this.popVisibleLoading = false;
          } else {
            this.popVisibleLoading = false;
          }
        } else {
          this.popVisibleLoading = false;
          console.error(err);
        }
      }  else if (payType === "fakeExamine") {
        // 할부 가승인 취소처리

        params = {
          saleContractNumber: this.contractNumber, // 판매계약번호
          cancelReasonCode: "2" // 취소사유코드
        };

        this.popVisibleLoading = true;
        const [res, err] = await this.$https.get(
          "payment/v2/payment/installment/cancelFakeExamine",
          params,
          null,
          "gateway"
        ); // API-WX-결제서비스-011 (현대캐피탈 할부 가심사 취소)
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
          this.popVisibleLoading = false
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
        if (!err) {
          console.log(res);
          if (res.rspStatus && res.rspStatus.rspCode === "0000") {
            if(res.data.ifResult==="Z"){
              this.alertMessage = res.data.errMsg || "환불되었습니다.";
              this.alertMessagePop = true;
            }else{
              this.alertMessage = res.data.ifMessage || " 환불처리중 오류가 발생하였습니다.";
              this.alertMessagePop = true;
            }
            this.$emit("refresh", true);
            this.alertVisibleCancelCash = false;
            this.alertVisibleChangeCash = false;
            this.popVisibleLoading = false;
          } else {
            this.popVisibleLoading = false;
          }
        } else {
          this.popVisibleLoading = false;
          console.error(err);
        }
      } else {
        // 일반 환불 케이스
        if (["installment", "card"].includes(payType)) {
          // 할부 or 카드
          params = {
            saleCnttNo,
            stlNos,
            stlMeanNo,
            rqEeno,
            addStlRqSn,
            addStlTrtmSn
          };
        } else if (payType === "down-payment") {
          // 계약금 취소
          const bank = "",
            guja = "";
          params = { saleCnttNo, bank, guja };
        } else {
          params = { saleCnttNo, csmrMgmtNo, rqEeno, exclusiveYn:"Y" };
        }
        this.popVisibleLoading = true;
        const [res, err] = await this.$https.get(
          "payment/v2/payment/cancellation/" + payType,
          params,
          null,
          "gateway"
        ); // 결제 타입별 취소 API(API-E-결제서비스-023 ~ 027)
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
          this.popVisibleLoading = false
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
        if (!err) {
          console.log(res);
          if (res.rspStatus && res.rspStatus.rspCode === "0000") {
            this.alertMessage = res.data && res.data.errMsg || " 환불되었습니다.";
            this.alertMessagePop = true;
            this.$emit("refresh", true);
            this.alertVisibleCancelCash = false;
            this.alertVisibleChangeCash = false;
            this.popVisibleLoading = false;
          } else {
            this.popVisibleLoading = false;
          }
        } else {
          this.popVisibleLoading = false;
          console.error(err);
        }
      }
      this.popVisibleCard = false;
      this.alertVisibleCancelCash = false;
      this.alertVisibleChangeCash = false;
    },
    async changePayCashProcess() {
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      // 결제변경 - 변경 - 현금 결제 변경 팝업 - 적용 버튼
      const params = {
        saleCnttNo: this.contractInfoData.contractNumber, // 판매계약번호
        refundList: [{stlNos: this.selChangePayInfo.paymentOrder, // 결제차수
                      stlMeanNo: this.selChangePayInfo.paymentMeanNumber, // 결제수단번호
                      addStlRqSn: this.selChangePayInfo.addStlRqSn || "", // 결제차수 - 추가결제
                      addStlTrtmSn: this.selChangePayInfo.addStlTrtmSn || "", // 결제수단번호 - ���가결제
                      bank: this.refundInfo.bankCode,
                      guja: this.refundInfo.bankAccount,
                      amount: this.refundInfo.stlRqAmt || 0, // 환불금액
                      // 2022-02-09 전담 할불 처리시 RS로 요청으로 변경
                      procDivs: this.refundInfo.bankAccount ? "RP" : "RS" // 환불대기
                    }]
      }

      //부분 취소용 param
      const paramsPartial = {
        saleCnttNo: this.contractInfoData.contractNumber, // 판매계약번호
        stlNos: this.selChangePayInfo.paymentOrder, // 결제차수
        stlMeanNo: this.selChangePayInfo.paymentMeanNumber, // 결제수단번호
        bank: this.refundInfo.bankCode,
        guja: this.refundInfo.bankAccount,
        rqEeno: '',
        celAmt: this.refundInfo.stlRqAmt || 0, // 부분취소금액
        procDivsType: 'CASH' // 현금구분코드
      }

      console.log(this.selChangePayInfo);
      //const [res, err] = await this.$https.get('/payment/v2/payment/provision/activation', params, null, 'gateway') // API-E-결제서비스-019 (결제항목 활성화 처리)
      if(this.checkedRefundPartType){
        //부분 취소 API////////////////////////////
        if(!paramsPartial.bank || !paramsPartial.guja){
          alert('부분취소시 환불계좌 입력값(은행코드, 계좌번호)은 필수입니다.')
          return
        }
        const [res1, err1] = await this.$https.get(
          "/payment/v2/payment/cancellation/partial",
          paramsPartial,
          null,
          "gateway"
        ) // API-WX-결제서비스-023 (전담 부분 취소 처리)
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
          this.popVisibleLoading = false
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */        
        if (!err1) {
          console.log(res1);
          if (res1.rspStatus && res1.rspStatus.rspCode === "0000") {
            this.alertMessage = res1.data && res1.data.errMsg || "환불되었습니다.";
            this.alertMessagePop = true;
            this.$emit("refresh", true);
          }
        } else {
          console.error(err1);
        }
        this.popVisibleCard = false;
        this.popVisibleChangeCash = false;
        this.alertVisibleChangeCash = false;
      }else{
        //전체 취소 API////////////////////////////
        const [res2, err2] = await this.$https.post(
        "/payment/v2/payment/refund/cash",
        params,
        null,
        "gateway"
        ) // API-E-결제서비스-022 (현금 환불대기/환불처리/입금취소)
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
          this.popVisibleLoading = false
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */  
        if (!err2) {
          console.log(res2);
          if (res2.rspStatus && res2.rspStatus.rspCode === "0000") {
            this.alertMessage = res2.data && res2.data.errMsg || "환불되었습니다.";
            this.alertMessagePop = true;
            this.$emit("refresh", true);
          }
        } else {
          console.error(err2);
        }
        this.popVisibleCard = false;
        this.popVisibleChangeCash = false;
        this.alertVisibleChangeCash = false;
      }
    },
    async changePayAllCashProcess() {
      // 현금 결제 전체 변경 팝업 - 적용 버튼
      let refundListArr = []
      let objVal = {}
      //기본 결제 param setting
      for(let val of this.payDetail.paymentInfo){
        if(val.paymentStateCode === '22' && val.paymentTypeCode === '30' && val.refundPossibleYn === 'Y'){
          objVal = {
            stlNos: val.paymentOrder, // 결제차수
            stlMeanNo: val.paymentMeanNumber, // 결제수단번호
            addStlRqSn: val.addStlRqSn || "", // 결제차수 - 추가결제
            addStlTrtmSn: val.addStlTrtmSn || "", // 결제수단번호 - ���가결제
            bank: this.refundInfo.bankCode,
            guja: this.refundInfo.bankAccount,
            amount: val.paymentCompletePrice || 0, // 환불금액
            // 2022-02-09 전담 할불 처리시 RS로 요청으로 변경
            procDivs: this.refundInfo.bankAccount ? "RP" : "RS" // 환불대기
          }
          refundListArr.push(objVal)
          objVal = {}
        }
      }

      //추가 결제 param setting
      for(let addVal of this.payDetail.additionPaymentInfo){
        if(addVal.paymentStateCode === '22' && addVal.paymentTypeCode === '30' && addVal.refundPossibleYn === 'Y'){
          objVal = {
            stlNos: addVal.paymentOrder, // 결제차수
            stlMeanNo: addVal.paymentMeanNumber, // 결제수단번호
            addStlRqSn: addVal.addStlRqSn || "", // 결제차수 - 추가결제
            addStlTrtmSn: addVal.addStlTrtmSn || "", // 결제수단번호 - ���가결제
            bank: this.refundInfo.bankCode,
            guja: this.refundInfo.bankAccount,
            amount: addVal.paymentCompletePrice || 0, // 환불금액
            // 2022-02-09 전담 할불 처리시 RS로 요청으로 변경
            procDivs: this.refundInfo.bankAccount ? "RP" : "RS" // 환불대기
          }
          refundListArr.push(objVal)
          objVal = {}
        }
      }

      const params = {
        saleCnttNo: this.contractInfoData.contractNumber, // 판매계약번호
        refundList: refundListArr
      }

      this.popVisibleLoading = true

      //전체 취소 API////////////////////////////
      const [res2, err2] = await this.$https.post(
      "/payment/v2/payment/refund/cash",
      params,
      null,
      "gateway"
      ) // API-E-결제서비스-022 (현금 환불대기/환불처리/입금취소)
        this.popVisibleLoading = false
      if (!err2) {
        console.log(res2);
        if (res2.rspStatus && res2.rspStatus.rspCode === "0000") {
          this.alertMessage = res2.data && res2.data.errMsg || "환불되었습니다."
          this.alertMessagePop = true
          this.$emit("refresh", true)
        }
      } else {
        console.error(err2)
      }
      
      this.popVisibleChangeCashAll = false
      this.alertVisibleChangeCashAll = false
    },
    async updateContractAssign() {
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      console.log(moment().isAfter(this.payInfoData.afterApproveDate));

      if(!this.QsignFlag){
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
        this.popVisibleLoading = false
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */        
        this.alertMessage = "결제내역을 다시 확인해 주세요. \n미 처리금액이 없을 때 출고증 발급요청이 가능합니다.";
        this.alertMessagePop = true;
        console.log("미처리금액 있음");
        return;
      }

      if (this.isEmployee) {
          if (!this.payInfoData.afterApproveDate) {
          /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
          this.popVisibleLoading = false
          /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */          
          this.alertMessage = "현재 직원 재인증을 진행중입니다.";
          this.alertMessagePop = true;
          return;
        }

        if (
          this.payInfoData.afterApproveDate &&
          moment().isAfter(this.payInfoData.afterApproveDate)
        ) {
          /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
          this.popVisibleLoading = false
          /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */          
          this.alertMessage = "직원 2차 인증이 필요합니다.";
          this.alertMessagePop = true;
          return;
        }
      }

      const param = {
        saleContractNo : this.contractInfoData.contractNumber,        
      }

      //API-WX-결제서비스-024 (전담 Q싸인 가능여부 체크)
      const [res2, err2] = await this.$https.get(
        "/payment/v2/payment/qsignValidation",
        param,
        null,
        "gateway" 
      )

      if (!err2) {
        console.log(res2);
        if (res2.rspStatus && res2.rspStatus.rspCode === "0000") {
          if(!res2.data.ifResult === 'SUCCESS'){
            this.alertMessage = res2.data && res2.data.ifMessage;
            this.alertMessagePop = true;
            return; 
          }
        }
      } else {
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
        this.popVisibleLoading = false
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */        
        console.error(err2);
        return;
      }   

      const [res, err] = await this.$https.post(
        "purchase/v2/purchase/contract/contract-info/assign/" +
          this.contractInfoData.contractNumber,
        null,
        null,
        "gateway" 
      );
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
        this.popVisibleLoading = false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
      if (!err) {
        console.log(res);
        if (res.rspStatus && res.rspStatus.rspCode === "0000") {
          this.alertMessage = "변경되었습니다.";
          this.alertMessagePop = true;
          /* ######## W Project #12159 - <2022-04-25> - <A934118> - START ######## */          
          //this.$emit("refresh", true);
          this.$emit("searchContractAssignChange");
          /* ######## W Project #12159 - <2022-04-25> - <A934118> - END ######## */          
        }
      } else {
        console.error(err);
      }
      this.updateContractAssignPop = false;
    },
    async reopenAccount(obj) {
      console.log(obj);

      const param = {
        contractNumber : this.contractInfoData.contractNumber,
        reRegistrationAccountYn : "Y"
      }

      /* if (this.isEmployee) {
        if (!this.payInfoData.afterApproveDate) {
          this.alertMessage = "현재 직원 재인증을 진행중입니다.";
          this.alertMessagePop = true;
          return;
        }

        if (
          this.payInfoData.afterApproveDate &&
          moment().isAfter(this.payInfoData.afterApproveDate)
        ) {
          this.alertMessage = "직원 2차 인증이 필요합니다.";
          this.alertMessagePop = true;
          return;
        }
      } */

      const [res, err] = await this.$https.get(
        "purchase/v2/purchase/payment/re-registration/account" ,
        param,
        null,
        "gateway"
      );

      if (!err) {
        console.log(res);
        if (res.rspStatus && res.rspStatus.rspCode === "0000") {
          this.alertMessage = "변경되었습니다.";
          this.alertMessagePop = true;
          this.$emit("refresh", true);
        }
      } else {
        console.error(err);
      }
      this.updateContractAssignPop = false;
    },
    cancelPrepaymentCashPop(item) {
      //선지급 내역 계약금(현금) 환불 팝업 info setting...
      this.selCancelPrePayInfo = {...item}
      this.popVisiblePrepaymentCancelCash = true
    },
    async cancelPrepaymentCash() {
      //선지급 내역 계약금 환불 process...
      if(this.refundPreInfo.bank === 'all'){
        this.refundPreInfo.bank = ''
      }

      //은행,계좌번호 validation check
      if((this.refundPreInfo.bank && !this.refundPreInfo.guja) || (!this.refundPreInfo.bank && this.refundPreInfo.guja)){
        alert('환불계좌 입력값(은행코드, 계좌번호)을 확인바랍니다.')
        return
      }

      //환불 코드 설정//////////////////////////////////////////
      let refundCd = ''
      if(this.selCancelPrePayInfo.refundPossibleYn === 'Y' && !this.refundPreInfo.bank && !this.refundPreInfo.guja){
        refundCd = 'RS' //환불대기건
      } else if(this.selCancelPrePayInfo.refundPossibleYn === 'Y' && this.refundPreInfo.bank && this.refundPreInfo.guja){
        refundCd = 'RP' //환불처리건
      } else if(this.selCancelPrePayInfo.refundPossibleYn === 'N' && !this.refundPreInfo.bank && !this.refundPreInfo.guja){
        refundCd = 'DC' //입금취소건
      } else {
        alert('오류가 발생하였습니다.')
        return
      }
      ////////////////////////////////////////////////////////

      const param = {
        saleCnttNo: this.contractInfoData.contractNumber,
        bank: this.refundPreInfo.bank,
        guja: this.refundPreInfo.guja,
        procDivs: refundCd
      }

      this.popVisibleLoading = true

      const [res, err] = await this.$https.get(
        "payment/v2/payment/cancellation/down-payment",
        param,
        null,
        "gateway"
      )

      if (!err) {
        if(res.data && res.rspStatus){
          if(res.data.errCd === '0' && res.rspStatus.rspCode === '0000'){
            this.alertMessage = '현금결제 변경에 성공했습니다.'
            this.alertMessagePop = true
          }else{
            this.alertMessage = res.data && res.data.errMsg || '현금결제 변경에 실패했습니다.'
            this.alertMessagePop = true
          }
        }
        this.$emit("refresh", true)
        this.popVisibleLoading = false
      } else {
        this.popVisibleLoading = false
        console.error(err)
      }

      this.popVisiblePrepaymentCancelCash = false
    },
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
    oneClickDisable(event, clickEvent, ...args) {
      if(event.target.disabled === true){
        retrun
      }

      event.target.disabled = true

      try {
        clickEvent(...args)
      } catch {}
      setTimeout(() => {
        event.target.disabled = false
      }, 2000)
    },
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */ 
    changePayCashPreProcess(item, flag){
      //결제 내역 전체 취소 팝업 전 사전 작업 세팅
      this.visibleChangeCashAll.visible = true
      this.visibleChangeCashAll.item = item
      this.visibleChangeCashAll.flag = flag
    },
    alertVisibleChangeCashAllValidCheck(){
      if((!this.refundInfo.bankCode || this.refundInfo.bankCode === 'all') || !this.refundInfo.bankAccount){
        alert('환불계좌(은행코드, 계좌번호)를 입력해주세요.')
        return
      }else{
        this.alertVisibleChangeCashAll = true
      }
    },
    beforePrepaymentCardProcessFunc(item, flag){
      //선지급 내역 카드 승인일이 120일 경과 사전 체크
      this.preObj = {}

      if(item.paymentDate){
        let toDate = moment().format('YYYY-MM-DD')
        let dateFlag = false

        dateFlag = moment(toDate).isAfter(moment(item.paymentDate).add('118','d').format('YYYY-MM-DD'))

        if(dateFlag){
          this.beforePrepaymentCardProcessCheckFlag = true
          this.preObj = {...item}
          return
        }
      }

      this.cancelPay(item, flag)
    },
    updateContractAssignPopFunc(){
      this.updateContractAssignPop = true
      this.isEmployeeDcPop = false
    }
  }
};
</script>

<style lang="scss" scoped>
@import "~/assets/style/pages/detail.scss";
@import "~/assets/style/pages/tab/PayInfo.scss";
</style>
