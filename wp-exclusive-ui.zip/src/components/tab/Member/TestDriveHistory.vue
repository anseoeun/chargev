<template>
  <div>
    <div class="box">
      <el-table 
        :data="trialData"
        empty-text="조회된 결과가 존재하지 않습니다."
      >
        <el-table-column prop="tsrdCar" label="차명" width="399" align="center">
          <template slot-scope="props">
            <el-popover placement="top" trigger="hover">
              <ul>
                <li>차종: {{ props.row.tsrdCar }}</li><br>
                <li>옵션: {{ props.row.optCtyNm }}</li><br>
                <li>외장컬러: {{ props.row.xrclCtyNm }}</li><br>
                <li>내장컬러: {{ props.row.ieclCtyNm }}</li><br>
              </ul>
              <span slot="reference" class="item-hover">{{ props.row.tsrdCar }}</span>
            </el-popover>
          </template>
        </el-table-column>
        <el-table-column prop="tsrdCtrNm" label="시승센터" width="200" align="center">
          <template slot-scope="props">
            <el-popover placement="top" trigger="hover">
              <ul>
                <li>위치: {{ props.row.tsrdAdr }}</li>
                <li>전화번호: {{ props.row.tsrdTn }}</li>
              </ul>
              <span slot="reference" class="item-hover">{{ props.row.tsrdCtrNm }}</span>
            </el-popover>
          </template>
        </el-table-column>
        <el-table-column prop="tsrdSvcNm" label="시승서비스" width="200" align="center"></el-table-column>
        <el-table-column prop="tsrdPrctNo" label="시승예약번호" width="200" align="center"></el-table-column>
        <el-table-column prop="tsrdPrctScnNm" label="예약구분" width="170" align="center"></el-table-column>
        <el-table-column prop="tsrdPrctYmd" label="시승일시" width="200" align="center">
          <template slot-scope="props">
            <p v-html="props.row.tsrdPrctYmd"></p>
          </template>
        </el-table-column>
        <el-table-column prop="prctStNm" label="시승결과" width="170" align="center"></el-table-column>
      </el-table>
      <div class="btn-wrap">
          <div class="side"></div>
          <div class="pagination">
            <v-pagination
              v-if="trialData.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch"
            />
          </div>
          <div class="main"></div>
        </div>
    </div>
    <loading
      :pop-visible.sync="popVisibleLoading"
      :close-on-click-modal="false"
      @close="popVisibleLoading = false"
    />
  </div>
</template>
<script>
import Loading from '~/components/popup/Loading.vue'
import moment from 'moment'
export default {
  components: {
    Loading,
  },
  props: {
    customerName: {
      type: String,
      default: ''
    },
    mobile: {
      type: String,
      default: ''
    },
    year: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      popVisibleLoading: false, // 로딩 활성화 여부
      trialData: [],
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      },
    }
  },
  computed: {
    changeData() {
      return [
        this.customerName,
        this.mobile,
        this.year,
      ]
    }
  },
  watch: {
    changeData : function() {
      this.getTrialData()
    }
  },
  methods: {
    async getTrialData() {
      //시승이력 조회
      if(!this.customerName || !this.mobile) return

      let arr = []
      this.popVisibleLoading = true

      const { page, size } = this.$data.pageInfo
      const params = {
        pageNo: page,
        pageSize: size,
        reserveName : this.customerName,
        reserveTelephoneBackNumber: this.mobile.slice(-4), //마지막 4자리
        searchStartDate: this.year + '0101',
        searchEndDate: this.year + '1231',
      }
      const [res, err] = await this.$https.post('/v2/exclusive/total/member/trialHistory', params)
      if(!err) {
        if(res.data && res.data.resultList) {
          arr =  res.data.resultList.map(el => {
            return {
              ...el,
              tsrdPrctNo: el.tsrdPrctNo,
              tsrdSvcNm: el.tsrdSvcNm,
              tsrdTn: el.tsrdTn,
              tsrdCar: el.tsrdCar,
              tsrdCtrNm: el.tsrdCtrNm +' '+ el.tsrdStrgNm,
              tsrdPrctScnNm: el.tsrdPrctScnNm,
              tsrdPrctYmd: el.tsrdPrctYmd ? moment(el.tsrdPrctYmd).format('YYYY-MM-DD') + ' <br/>' + el.tsrdTim : '',
              prctStNm: el.prctStNm,
              optCtyNm: el.optCtyNm,
              xrclCtyNm: el.xrclCtyNm,
              ieclCtyNm: el.ieclCtyNm
            }
          })
        }
        this.$data.pageInfo = {
          ...this.$data.pageInfo,
          total: res.data.totalCount
        }
        this.$emit('trialCnt', this.pageInfo.total)
      }else {
        console.error('exclusive :: /v2/exclusive/total/member/trialHistory ERROR !! '+err)
      }
      this.popVisibleLoading = false
      this.trialData = arr
    },
    onSearch(page) {
      this.$data.pageInfo.page = page

      this.getTrialData()
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>