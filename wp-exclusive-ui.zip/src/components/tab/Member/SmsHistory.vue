<template>
  <div>
    
    <div class="box">
      <el-table :data="smsData">
        <el-table-column prop="no" label="No." width="50" align="center"></el-table-column>
        <el-table-column prop="adresseeName" label="이름" width="100" align="center"></el-table-column>
        <el-table-column prop="adresseeMobile" label="휴대전화" width="150" align="center"></el-table-column>
        <el-table-column prop="sendDate" label="발송일시" width="150" align="center"></el-table-column>
        <el-table-column prop="channelCode" label="구분" width="100" align="center"></el-table-column>
        <el-table-column prop="messageTitle" label="제목" width="200">
          <template slot-scope="props">
           <p class="text-omit">{{ props.row.messageTitle }}</p>
          </template>
        </el-table-column>
        <el-table-column label="본문" width="439">
          <template slot-scope="props">
          <p class="text-omit">{{ props.row.messageContents }}</p>
          </template>
        </el-table-column>
        <el-table-column prop="dispatcherName" label="보낸사람" width="100" align="center"></el-table-column>
        <el-table-column prop="sendMobile" label="발신번호" width="150" align="center"></el-table-column>
        <el-table-column label="발송상태" width="100" align="center">
          <template slot-scope="props">
            <el-button type="primary" class="btn-small" @click="resend(props.row)">재발송</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="btn-wrap">
          <div class="side"></div>
          <div class="pagination">
            <v-pagination
              v-if="smsData.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch"
            />
          </div>
          <div class="main"></div>
        </div>
    </div>
    <pop-message
        :pop-visible.sync="alertMessagePop"
        :pop-message.sync="alertMessage"
        @confirm="alertMessagePop = false"
        @close="alertMessagePop = false"
      />
      <loading
        :pop-visible.sync="popVisibleLoading"
        :close-on-click-modal="false"
        @close="popVisibleLoading = false"
      />
  </div>
</template>
<script>
import Loading from '~/components/popup/Loading.vue'
import PopMessage from '~/components/popup/PopMessage.vue'
export default {
  components: {
    Loading,
    PopMessage,
  },
  props: {
    customerName: {
      type: String,
      default: '',
    },
    mobile: {
      type: String,
      default: '',
    },
    year: {
      type: Number,
      default: 0,
    }
  },
  data() {
    return {
      smsData: [],
      popVisibleLoading: false, // 로딩 활성화 여부
      alertMessagePop: false,
      alertMessage: null,
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      },
    }
  },
  computed: {
    changeData() {
      return [
        this.customerName,
        this.mobile,
        this.year,
      ]
    }
  },
  watch: {
    changeData : function() {
      this.getSmsData()
    }
  },
  methods: {
    async getSmsData() {
      if(!this.customerName && !this.mobile && !this.year) return

      let arr = []
      this.popVisibleLoading = true

      const { page, size } = this.$data.pageInfo
      const params = {
        pageNo: page,
        pageSize: size,
        fullName: this.customerName,
        mobile: this.mobile,
        year: this.year,
      }

      const [res, err] = await this.$https.post('/v2/exclusive/total/member/smsHistory', params)
      if(!err) {
        if(res.data && res.data.list) {
          arr = res.data.list.map((el,idx) => {
            return {
              ...el,
              no: res.data.total - res.data.endRow + res.data.list.length - idx,
              serialNumber: el.msgIntegrationSendSerialNumber,
              adresseeName: el.adresseeName,
              adresseeMobile: el.adresseeMobile,
              sendDate: el.sendDate,
              messageTitle: el.messageTitle,
              messageContents: el.messageContents,
              dispatcherName: el.dispatcherName,
              sendMobile: el.sendMobile,
              channelCode: '쿠폰안내',
            }
          })
          this.$data.pageInfo = {
            ...this.$data.pageInfo,
            total: res.data.total
          }
          
          this.$emit('smsCnt', this.pageInfo.total)
        }
      }else {
        console.error('exclusive :: /v2/exclusive/total/member/smsHistory ERROR !! '+err)
      }

      this.popVisibleLoading = false
      this.smsData = arr
    },
    async resend(data){

      this.popVisibleLoading = true

      const params = {
        messageTypeCode: 'SMS',
        channelCode: 'WC',
        messageTitle: data.messageTitle,
        messageContents: data.messageContents,
        msgIntegrationSendSerialNumber: data.serialNumber,
      }

      const [res, err] = await this.$https.post('/v2/exclusive/total/member/sendSms', params)
      if(!err) {
        if(res.rspStatus && res.rspStatus.rspCode === '0000'){
          this.alertMessage = '메시지가 전송되었습니다.'
          this.alertMessagePop = true
        }
      }else {
        console.error('exclusive :: /v2/exclusive/total/member/sendSms ERROR !! '+err)
      }

      this.popVisibleLoading = false
      this.getSmsData() // reload
    },
    onSearch(page) {
      this.$data.pageInfo.page = page

      this.getSmsData()
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>