<template>
  <div>
    
    <div class="box">
      <el-table :data="contractData">
        <el-table-column prop="carn" label="차명" width="119" align="center">
          <template slot-scope="props">
            <el-popover placement="top" trigger="hover">
              <ul>
                <li>모델: {{ props.row.carn }}</li>
                <li>외장컬러: {{ props.row.exteriorColorName }}</li>
                <li>내장컬러: {{ props.row.interiorColorName }}</li>
              </ul>
              <span class="item-hover" slot="reference">{{ props.row.carn }}</span>
            </el-popover>
          </template>
        </el-table-column>
        <el-table-column prop="customerType" label="고객구분" width="120" align="center"></el-table-column>
        <el-table-column prop="contractNumber" label="계약번호" width="180" align="center">
          <template slot-scope="props">
              <a
                class="link"
                :href="`/#/wp/contract/${props.row.contractType}/release-detail`"
                target="_blank"
                @click="$utils.setLocalStorage({ contractNumber: props.row.contractNumber })"
              >
                {{ props.row.contractNumber }}
              </a>
            </template>
        </el-table-column>
        <el-table-column prop="contractDate" label="계약완료일" width="120" align="center"></el-table-column>
        <el-table-column prop="paymentCompleteDate" label="결제완료일" width="120" align="center"></el-table-column>
        <el-table-column prop="carWhotDate" label="출고일" width="120" align="center"></el-table-column>
        <el-table-column prop="certificateIssueDate" label="제작증발급일" width="120" align="center"></el-table-column>
        <el-table-column prop="consultantName" label="계약담당자" width="120" align="center"></el-table-column>
        <el-table-column prop="legacyStatusName" label="판매진행상태" width="120" align="center"></el-table-column>
        <el-table-column prop="onlineStatusName" label="온라인진행상태" width="120" align="center"></el-table-column>
        <el-table-column prop="vehicleNumber" label="차대번호" width="180" align="center"></el-table-column>
        <el-table-column prop="prebookYn" label="사전계약여부" width="100" align="center"></el-table-column>
      </el-table>
      <div class="btn-wrap">
          <div class="side"></div>
          <div class="pagination">
            <v-pagination
              v-if="contractData.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch($event,'1')"
            />
          </div>
          <div class="main"></div>
        </div>
    </div>
    <loading
      :pop-visible.sync="popVisibleLoading"
      :close-on-click-modal="false"
      @close="popVisibleLoading = false"
    />
  </div>
</template>
<script>
import Loading from '~/components/popup/Loading.vue'
export default {
  components: {
    Loading
  },
  props: {
    customerUniqNumber: {
      type: String,
      default: '',
    },
    year: {
      type: Number,
      default: 0,
    }
  },
  data() {
    return {
      popVisibleLoading: false, // 로딩 활성화 여부
      contractData: [],
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      },
    }
  },
  computed: {
    changeData() {
      return [
        this.customerUniqNumber,
        this.year,
      ]
    }
  },
  watch: {
    changeData : function() {
      this.getContractData()
    }
  },
  methods: {
    async getContractData() {
      /** 견적이력 조회 */
      if(!this.customerUniqNumber) return

      let arr = []
      this.popVisibleLoading = true

      const { page, size } = this.$data.pageInfo
      const params = {
        pageNo: page,
        pageSize: size,
        year: this.year,
        customerUniqNumber: this.customerUniqNumber,
      }

      const [res, err] = await this.$https.post('/v2/exclusive/total/member/contractHistory', params)
      if(!err) {
        if(res.data && res.data.list) {
          arr = res.data.list.map((el, idx) => {
            return {
              ...el,
              no: res.data.total - res.data.endRow + res.data.list.length - idx,
              carn: el.carn,
              exteriorColorName: el.exteriorColorName,
              interiorColorName: el.interiorColorName,
              customerType: el.customerType,
              contractNumber: el.contractNumber,
              contractDate: el.contractDate,
              paymentCompleteDate: el.paymentCompleteDate,
              carWhotDate: el.carWhotDate,
              certificateIssueDate: el.certificateIssueDate,
              consultantName: el.consultantName,
              legacyStatusName: el.legacyStatusName,
              onlineStatusName: el.onlineStatusName,
              vehicleNumber: el.vehicleNumber,
              prebookYn: el.prebookYn,
              contractType: el.corpYn === 'Y' ? 'corporation' : 'customer'
            }
          })
          this.$data.pageInfo = {
            ...this.$data.pageInfo,
            total: res.data.total
          }
          this.$emit('contractCnt', this.pageInfo.total)
        }
      }else {
        console.error('exclusive :: /v2/exclusive/total/member/contractHistory ERROR !! '+err)
      }
      
      this.popVisibleLoading = false
      this.contractData = arr
    },
    onSearch(page) {
      this.$data.pageInfo.page = page
      this.getContractData()
    },
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>