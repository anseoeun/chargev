<template>
  <div>
    
    <div class="box">
      <el-table :data="estimateData">
        <el-table-column prop="estimateNumber" label="견적번호" width="120" align="center">
          <template slot-scope="props">
            <a
              class="link"
              href="#"
              @click="estimatePopup(props.row.estimateUrl)"
            >
              {{ props.row.estimateNumber }}
            </a>
          </template>
        </el-table-column>
        <el-table-column prop="customerName" label="견적작성자" width="120" align="center">
          <template slot-scope="props">
            <p v-html="props.row.customerName"></p>
          </template>
        </el-table-column>
        <el-table-column prop="carModelName" label="모델" width="249" align="center"></el-table-column>
        <el-table-column prop="carTrimName" label="트림" width="150" align="center"></el-table-column>
        <el-table-column prop="exteriorColorName" label="외장컬러" width="150" align="center"></el-table-column>
        <el-table-column prop="interiorColorName" label="내장컬러" width="150" align="center"></el-table-column>
        <el-table-column prop="totalEstimatePrice" label="가격" width="150" align="center"></el-table-column>
        <el-table-column prop="estimateDate" label="견적일시" width="150" align="center"></el-table-column>
        <el-table-column prop="finalModifyDate" label="최종수정일시" width="150" align="center"></el-table-column>
        <el-table-column prop="contractNumber" label="계약번호" width="150" align="center">
          <template slot-scope="props">
              <a
                class="link"
                :href="`/#/wp/contract/${props.row.contractType}/release-detail`"
                target="_blank"
                @click="$utils.setLocalStorage({ contractNumber: props.row.contractNumber })"
              >
                {{ props.row.contractNumber }}
              </a>
            </template>
        </el-table-column>
      </el-table>
      <div class="btn-wrap">
          <div class="side"></div>
          <div class="pagination">
            <v-pagination
              v-if="estimateData.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch"
            />
          </div>
          <div class="main"></div>
        </div>
    </div>
    <loading
      :pop-visible.sync="popVisibleLoading"
      :close-on-click-modal="false"
      @close="popVisibleLoading = false"
    />
  </div>
</template>
<script>
import Loading from '~/components/popup/Loading.vue'
export default {
  components: {
    Loading
  },
  props: {
    customerUniqNumber: {
      type: String,
      default: '',
    },
    customerName: {
      type: String,
      default: '',
    },
    year: {
      type: Number,
      default: 0,
    }
  },
  data() {
    return {
      popVisibleLoading: false, // 로딩 활성화 여부
      estimateData: [],
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      },
    }
  },
  computed: {
    changeData() {
      return [
        this.customerUniqNumber,
        this.customerName,
        this.year,
      ]
    }
  },
  watch: {
    changeData : function() {
      this.getEstimateData()
    }
  },
  methods: {
    async getEstimateData() {
      /** 견적이력 조회 */
      if(!this.customerUniqNumber) return

      let arr = []
      this.popVisibleLoading = true

      const { page, size } = this.$data.pageInfo
      const params = {
        pageNo: page,
        pageSize: size,
        year: this.year,
        customerUniqNumber: this.customerUniqNumber,
      }

      const [res, err] = await this.$https.post('/v2/exclusive/total/member/estimate-history', params)
      if(!err) {
        if(res.data && res.data.list) {
          arr = res.data.list.map((el, idx) => {
            return { 
              ...el,
              no: res.data.total - res.data.endRow + res.data.list.length - idx,
              isSelected: false,
              estimateNumber: el.estimateNumber,
              estimateUrl: el.estimateUrl,
              customerName: el.name ? el.name + '<br/>(' + el.exrsEeno + ')' : this.customerName,
              exrsEeno: el.exrsEeno,
              carModelName: el.carModelName,
              carTrimName: el.carTrimName,
              exteriorColorName: el.exteriorColorName,
              interiorColorName: el.interiorColorName,
              totalEstimatePrice: el.totalEstimatePrice ? el.totalEstimatePrice.toLocaleString() + '원' : '',
              estimateDate: el.estimateDate,
              finalModifyDate: el.finalModifyDate,
              contractNumber: el.contractNumber,
              contractType: el.corpYn === 'Y' ? 'corporation' : 'customer'
            }
          })
          this.$data.pageInfo = {
            ...this.$data.pageInfo,
            total: res.data.total
          }
          this.$emit('estimateCnt', this.pageInfo.total)
        }
      }else {
        console.error('exclusive :: /v2/exclusive/total/member/estimate-history ERROR !! '+err)
      }
      this.popVisibleLoading = false
      this.estimateData = arr
    },
    onSearch(page) {
      this.$data.pageInfo.page = page

      this.getEstimateData()
    },
    estimatePopup(url) {
      let preffixUrl = 'http://10.7.137.110/dev/casper'
      if (['stg', 'dev', 'prod'].includes(process.env.VUE_APP_PROFILE)) {
        preffixUrl = process.env.VUE_APP_BASEURL_FRONT
      }

      let fullUrl = preffixUrl + '/estimation/detail?estimationUrl='

      let width = 1400
      let height = 1000
      let clientWidth = document.body.clientWidth
      let clientHeight = document.body.clientHeight
      let winX = window.screenX || window.screenLeft || 0
      let winY = window.screenY || window.screenTop || 0
      let left = winX + (clientWidth - width) / 2
      let top = winY + (clientHeight - height) / 2

      //window 팝업 오픈
      window.open(fullUrl+url, 'popup', 'top='+top+ ',left='+left+ ',width='+width+ ',height='+height+ ', status=no, menubar=no, toolbar=no')
    },

  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>