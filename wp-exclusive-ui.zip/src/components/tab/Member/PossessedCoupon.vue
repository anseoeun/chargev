<template>
  <div>
    
    <div class="box">
      <el-table :data="couponData">
        <el-table-column prop="couponCode" label="쿠폰번호" width="110" align="center"></el-table-column>
        <el-table-column prop="targetCode" label="타겟번호" width="110" align="center"></el-table-column>
        <el-table-column prop="couponName" label="쿠폰명" width="229" align="center"></el-table-column>
        <el-table-column prop="couponUsableType" label="다회사용여부" width="120" align="center"></el-table-column>
        <el-table-column prop="relatedCars" label="대상차종" width="150" align="center"></el-table-column>
        <el-table-column prop="discountAmount" label="할인율(금액)" width="150" align="center"></el-table-column>
        <el-table-column prop="couponIssuedDate" label="발급일" width="150" align="center"></el-table-column>
        <el-table-column prop="couponUsableDateRange" label="사용기한" width="300" align="center"></el-table-column>
        <el-table-column prop="couponStatus" label="상태" width="120" align="center"></el-table-column>
        <el-table-column label="비고" width="100" align="center">
          <el-button type="primary" class="btn-small" @click="openSmsPopup">문자발송</el-button>
        </el-table-column>
      </el-table>
      <div class="btn-wrap">
          <div class="side"></div>
          <div class="pagination">
            <v-pagination
              v-if="couponData.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch"
            />
          </div>
          <div class="main"></div>
        </div>
    </div>
    <el-dialog
        title="문자보내기"
        :visible.sync="popVisibleSMS"
        width="1100px"
      >
        <!-- Popup Contents -->
        <div class="board-wrap sandmessage">
          <h-title :title="'수신자 정보'" />
          <el-form
            ref="contractData"
            :model="ruleFormpopup"
            class="detail-form"
          >
            <el-row>
              <el-col :span="9">
                <el-form-item label="받는 사람">
                  {{ ruleFormpopup.receiverName }}
                </el-form-item>
              </el-col>
              <el-col :span="15">
                <el-form-item label="휴대전화번호">
                  {{ ruleFormpopup.receiverMobile }}
                </el-form-item>
              </el-col>
            </el-row>
          <h-title :title="'발신내용'" />
            <el-row>
              <el-col :span="24">
                <el-form-item label="제목">
                  <el-input
                    v-model="ruleFormpopup.title"
                    class="mms-title"
                    @blur="ruleFormpopup.title = $event.target.value"
                  />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item label="내용">
                  <el-input
                    v-model="ruleFormpopup.text"
                    type="textarea"
                    @blur="ruleFormpopup.text = $event.target.value"
                  />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item label="URL">
                  {{ ruleFormpopup.couponShareUrl }}
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="primary"
            @click="initRuleFormPop"
          >
            초기화
          </el-button>
          <el-button
            type="primary"
            @click="sendSms"
          >
            전송
          </el-button>
        </template>
      </el-dialog>
      <pop-message
        :pop-visible.sync="alertMessagePop"
        :pop-message.sync="alertMessage"
        @confirm="alertMessagePop = false"
        @close="alertMessagePop = false"
      />
      <loading
        :pop-visible.sync="popVisibleLoading"
        :close-on-click-modal="false"
        @close="popVisibleLoading = false"
      />
  </div>
</template>
<script>
import Loading from '~/components/popup/Loading.vue'
import HTitle from '~/components/common/HTitle.vue'
import PopMessage from '~/components/popup/PopMessage.vue'
export default {
  components: {
    Loading,
    HTitle,
    PopMessage,
  },
  props: {
    memberMngNumber: {
      type: String,
      default: '',
    },
    year: {
      type: Number,
      default: 0,
    },
    customerName: {
      type: String,
      default: '',
    },
    mobile: {
      type: String,
      default: '',
    }
  },
  data() {
    return {
      popVisibleLoading: false, // 로딩 활성화 여부
      popVisibleSMS:false,
      alertMessage: '',
      alertMessagePop: false,
      couponData: [],
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      },
      ruleFormpopup: {
        receiverName: '',
        receiverMobile: '',
        title: '',
        text:'',
        couponShareUrl: process.env.VUE_APP_BASEURL_FRONT +'/mypage/coupon',
      }
    }
  },
  computed: {
    changeData() {
      return [
        this.memberMngNumber,
        this.customerName,
        this.year,
        this.mobile,
      ]
    }
  },
  watch: {
    changeData : function() {
      if(this.customerName && this.mobile) {
        this.ruleFormpopup.receiverName = this.customerName
        this.ruleFormpopup.receiverMobile = this.mobile
      }
      this.getPossessedCoupon()
    }
  },
  methods: {
    async getPossessedCoupon() {
      if(!this.memberMngNumber || !this.year) return
      
      let arr = []
      this.popVisibleLoading = true

      const { page, size } = this.$data.pageInfo
      const params = {
        pageNo: page,
        pageSize: size,
        memberNumber: this.memberMngNumber,
        year: this.year,
      }
      const [res, err] = await this.$https.post('/v2/exclusive/total/member/possessedCoupon', params)
      if(!err) {
        if(res.data && res.data.list) {
          arr = res.data.list.map((el, idx) => {
            return {
              ...el,
              no: res.data.total - res.data.endRow + res.data.list.length - idx,
              couponCode: el.couponCode,
              targetCode: el.targetCode,
              couponName: el.couponName,
              couponUsableType: el.couponUsableType,
              relatedCars: el.relatedCars,
              discountAmount: el.discountPrice ? el.discountPrice.toLocaleString() + '원' : el.discountRate + '%',
              couponIssuedDate: el.couponIssuedDate,
              couponUsableDateRange: el.couponUsableDateRange,
              couponStatus: el.couponUsedCnt > 0 ? '사용 ('+el.couponUsedCnt+'회)' : '미사용',
            }
          })
          this.$data.pageInfo = {
            ...this.$data.pageInfo,
            total: res.data.total
          }
          this.$emit('couponCnt', this.pageInfo.total)
        }
      }else {
        console.error('exclusive :: /v2/exclusive/total/member/possessedCoupon ERROR !! '+err)
      }

      this.popVisibleLoading = false
      this.couponData = arr
    },
    async openSmsPopup() {
      if(!this.mobile && !this.customerName) return

      this.popVisibleSMS = true
    },
    async sendSms(){

      this.popVisibleLoading = true

      const params = {
        messageTypeCode: 'SMS',
        channelCode: 'WC',
        messageTitle: this.ruleFormpopup.title,
        messageContents: this.ruleFormpopup.text +'\n'+ this.ruleFormpopup.couponShareUrl,
        adresseeMobile: this.ruleFormpopup.receiverMobile,
        adresseeName: this.ruleFormpopup.receiverName,
      }

      const [res, err] = await this.$https.post('/v2/exclusive/total/member/sendSms', params)
      if(!err) {
        if(res.rspStatus && res.rspStatus.rspCode === '0000'){
          this.alertMessage = '메시지가 전송되었습니다.'
          this.alertMessagePop = true
        }
      }else {
        console.error('exclusive ::/v2/exclusive/total/member/sendSms ERROR !! '+err)
      }

      this.getPossessedCoupon() // reload
      this.initRuleFormPop() //초기화
      this.popVisibleSMS = false // 팝업 닫기
      this.popVisibleLoading = false
    },
    initRuleFormPop() {
      //SMS 발송form 초기화
      //Object.assign(this.$data.ruleFormpopup, this.$options.data().ruleFormpopup)
      this.ruleFormpopup.title = ''
      this.ruleFormpopup.text = ''
    },
    onSearch(page) {
      this.$data.pageInfo.page = page

      this.getPossessedCoupon()
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>