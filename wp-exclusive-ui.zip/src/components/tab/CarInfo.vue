<template>
  <div>
    <div class="car-info-box">
      <el-form ref="carinfobox" class="detail-form">
        <el-row>
          <el-col :span="6">
            <el-form-item label="차대번호">
              <div class="carInfo_content">
                {{ carInfoData.vehicleIdentificationNumber
                  ? carInfoData.vehicleIdentificationNumber
                  : '없음' }}  
              </div>           
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="판매 SPEC">
              <div class="carInfo_content">
                {{ formatSaleSpec(carInfoData) }}  
              </div>          
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="생산번호">
              <div class="carInfo_content">
                {{ carInfoData.carProductionNumber
                  ? carInfoData.carProductionNumber
                  : '없음' }}
              </div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="생산일">
              <div class="carInfo_content">
                {{ carInfoData.productionDate
                  ? carInfoData.productionDate
                  : '없음' }}
              </div>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <el-form-item label="차량구분">
              <div class="carInfo_content">
                {{ carInfoData.contractCarTypeName
                  ? carInfoData.contractCarTypeName
                  : '없음' }}
              </div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="부활차 여부">
              <div class="carInfo_content">
                {{ carInfoData.revivalYn
                  ? carInfoData.revivalYn
                  : '없음' }}
              </div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="전시입고일">
              <div class="carInfo_content">
                {{ carInfoData.carDisplayDate
                  ? carInfoData.carDisplayDate
                  : '없음' }}
              </div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="차량 보관장소">
              <div class="carInfo_content">
                {{ carInfoData.carLocation
                  ? carInfoData.carLocation
                  : '없음' }}
              </div>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6" class="rowspan-2">
            <el-form-item label="차량할인계">
              <div class="carInfo_content">
                {{ carInfoData.conditionCarDiscountPrice ? carInfoData.conditionCarDiscountPrice.toLocaleString() + '원' : '0원' }}
              </div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="차종기본">
              <div class="carInfo_content">
                 {{ carInfoData.basicDiscountPrice ? carInfoData.basicDiscountPrice.toLocaleString() + '원' : '0원' }} 
              </div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="재고(생산월)">
              <div class="carInfo_content">
                {{ carInfoData.productionMonthDiscountPrice ? carInfoData.productionMonthDiscountPrice.toLocaleString() + '원' : '0원' }} 
              </div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="판촉">
              <div class="carInfo_content">
                {{ carInfoData.promotionDiscountPrice ? carInfoData.promotionDiscountPrice.toLocaleString() + '원' : '0원' }} 
              </div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="전시">
              <div class="carInfo_content">
                {{ carInfoData.displayDiscountPrice ? carInfoData.displayDiscountPrice.toLocaleString() + '원' : '0원' }} 
              </div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="한정재고">
              <div class="carInfo_content">
                {{ carInfoData.etcDiscountPrice ? carInfoData.etcDiscountPrice.toLocaleString() + '원' : '0원' }} 
              </div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="특별재고">
              <div class="carInfo_content">
                {{ carInfoData.specialInventoryDiscountPrice ? carInfoData.specialInventoryDiscountPrice.toLocaleString() + '원' : '0원' }} 
              </div>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <el-form-item label="주행거리">
              <div class="carInfo_content">
                {{ carInfoData.carMileage
                  ? carInfoData.carMileage
                  : '없음' }}
              </div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="차량상태(외관)">
              <div class="carInfo_content">
                {{ carInfoData.exteriorProblemYn
                  ? carInfoData.exteriorProblemYn
                  : '없음' }}
              </div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="차량상태(내관)">
              <div class="carInfo_content">
                {{ carInfoData.interiorProblemYn
                  ? carInfoData.interiorProblemYn
                  : '없음' }}
              </div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="차량사진">
              <div class="carInfo_content">
                <div v-if="viewImg">
                  <el-button type="primary" class="btn-small" @click="popVisibleDedicatedDC = true">사진보기</el-button>
                </div>
                <div v-else>없음</div>
              </div>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="차량상태 세부내용">
              {{ carInfoData.problemContents
                ? carInfoData.problemContents
                : '없음' }}
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div>
      <article class="article">
        <div class="article-title gap">
          <h2>주문차량정보</h2>
          <div class="right">
             <el-button v-if="isValidAuthBtn('authExclusive') && activeUserFlag && visibleCarBtn" :disabled="visibleCarChangeBtn" type="primary" @click="changeCar">차량변경</el-button>
          </div>
        </div>
        <div class="accordion-table">
          <div class="accordion-headline">
            <div class="title">
              <span class="icon">
                {{ carInfoData.contractCarTypeName }}
              </span>
              <strong>{{ carInfoData.modelBasicInfo }}</strong>
              <span class="txt">
                {{ choiceOptionComment }}
              </span>
            </div>
            <div class="price">
              {{ carInfoData.carPrice ? carInfoData.carPrice.toLocaleString() + '원' : '' }}
            </div>
          </div>
          <div class="vehicle-info">
            <div class="item">
              <div class="accordion-title">모델</div>
              <div class="accordion-content">{{ carInfoData.modelBasicInfo }}</div>
              <div class="accordion-price">
                 {{ carInfoData.carModelPrice ? carInfoData.carModelPrice.toLocaleString() + '원' : '' }}
              </div>
            </div>
            <div class="item" name="2">
              <div class="accordion-title">색상</div>
              <div class="accordion-inside divide">
                <table class="inside-container">
                  <tbody>
                    <tr class="inside-content">
                      <th class="inside-title"><div>외장</div></th>
                      <td class="inside-content-child">
                        <div>
                          {{ carInfoData.exteriorColorName }}
                        </div>
                      </td>
                      <td class="inside-price">
                        <div>
                          {{ carInfoData.exteriorColorPrice ? carInfoData.exteriorColorPrice.toLocaleString() : '0'+'원' }}
                        </div>
                      </td>
                    </tr>
                    <tr class="inside-content">
                      <th class="inside-title"><div>내장</div></th>
                      <td class="inside-content-child">
                        <div>
                          {{ carInfoData.realityInteriorColorCode ? carInfoData.realityInteriorColorName : carInfoData.interiorColorName }}
                        </div>
                      </td>
                      <td class="inside-price">
                        <div>
                          {{ carInfoData.interiorColorPrice ? carInfoData.interiorColorPrice.toLocaleString() : '0'+'원' }}
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="item" name="3">
              <div class="accordion-title">옵션</div>
              <div class="accordion-inside">
                <div class="car-tab">
                  <el-tabs :tab-position="'left'">
                    <el-tab-pane v-if="choiceOptionVisible" :key="0" label="선택품목">
                      <table class="inside-container">
                        <tbody>
                          <tr v-for="(item, idx) in carInfoData.choiceOptionInfo" :key="`choice_${idx}`" class="inside-content">
                            <td class="inside-content-child">{{ item.carOptionName }}</td>
                            <td class="inside-price">
                              {{ item.carOptionPrice ? item.carOptionPrice.toLocaleString() + '원' : '0원' }} 
                            </td>
                          </tr>                   
                        </tbody>
                      </table>
                    </el-tab-pane>
                    <el-tab-pane :key="activeIndex" label="기본포함항목">
                      <div class="cate-basic">
                        <ul>
                          <li v-for="(item,idx) in carInfoData.basicOptionInfo" :key="`basic_${idx}`" :class="{'active': active == idx}" @click="getOptionNames(idx)">
                            {{ item.carOptionCategoryName }}
                          </li>
                        </ul>
                        <span class="price">0원</span>
                      </div>
                      <div class="list-basic">
                        <ul>
                          <li v-for="(item, idx) in basicOptionNames" :key="`opt_${idx}`">{{ '- '+item }}</li>
                        </ul>
                      </div>
                    </el-tab-pane>                    
                  </el-tabs>      
                </div>        
              </div>
            </div>
            <div class="item" name="4">
              <div class="accordion-title">파츠 <el-button v-if="isValidAuthBtn('authExclusive') && activeUserFlag && visibleTuixBtn" :disabled="visibleTuixChangeBtn" type="primary" class="btn-small" @click="changeTuix">변경</el-button></div>              
              <div class="accordion-inside divide">
                <table class="inside-container">
                  <tbody>
                    <tr v-for="(item, idx) in carInfoData.tuixOptionInfo" :key="`tuix${idx}`" class="inside-content">
                      <td class="inside-content-child">{{ item.carOptionName }}</td>
                      <td class="inside-price">
                        {{ item.carOptionPrice ? item.carOptionPrice.toLocaleString() + '원' : '' }}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <ul class="note">
          <li>·  차량의 판매가격은 할인 반영 전 옵션/패키지 가격을 포함한 가격입니다.</li>
          <li>·  견적서와 계약서의 차량정보는 다를 수 있습니다.</li>
        </ul>
      </article>
    </div>


    <!-- 차량변경 팝업 -->
    <el-dialog title="차량변경" :visible.sync="popVisibleCar" width="1100px">
      <!-- Popup Contents -->
      <div class="board-wrap">
        <table class="tbl-detail">
          <colgroup>
            <col style="width:16%" />
            <col style="width:42%" />
            <col style="width:42%" />
          </colgroup>
          <thead>
            <tr>
              <th>구분</th>
              <th>변경 전</th>
              <th>변경 후</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th>판매모델</th>
              <td>
                <span>{{ carInfoData.modelBasicInfo }}</span>
                <span class="car-price">
                  {{ carInfoData.carModelPrice ? carInfoData.carModelPrice.toLocaleString() + '원' : '' }}
                </span>
              </td>
              <td>
                <el-select v-model="changeCarInfo.saleModelCode" @change="selectSaleModel">
                  <el-option
                    v-for="(item, index) in changeCarInfo.trimList"
                    :key="index"
                    :value="item.saleModelCode"
                    :label="item.modelBasicInfo + item.carTrimName"
                  />
                </el-select>
                <span class="car-price"> {{ (changeCarInfo.carPrice ? changeCarInfo.carPrice.toLocaleString() : '0')+'원' }}</span>
              </td>
            </tr>
            <tr>
              <th>외장색상</th>
              <td>
                <span>
                  {{ carInfoData.exteriorColorName }}
                </span>
                <span class="car-price">
                  {{ carInfoData.exteriorColorPrice ? carInfoData.exteriorColorPrice.toLocaleString() : '0'+'원' }}
                </span>
              </td>
              <td>
                <el-select 
                v-model="selectedCarData.exteriorColor"
                :disabled="changeCarInfo.saleModelCode === ''"
                @change="selectExColor">
                  <el-option
                    v-for="{ exteriorColorCode, exteriorColorName } in changeCarInfo.exteriorColorList"
                    :key="exteriorColorCode"
                    :value="exteriorColorCode"
                    :label="exteriorColorName"
                  />
                </el-select>
                <span class="car-price">{{ (selectedCarData.exteriorColorPrice ? selectedCarData.exteriorColorPrice.toLocaleString() : '0')+'원' }}</span>
              </td>
            </tr>
            <tr>
              <th>내장색상</th>
              <td>
                <span>
                   {{ carInfoData.realityInteriorColorCode ? carInfoData.realityInteriorColorName : carInfoData.interiorColorName }}
                </span>
                <span class="car-price">
                  {{ carInfoData.interiorColorPrice ? carInfoData.interiorColorPrice.toLocaleString() : '0'+'원' }}
                </span>
              </td>
              <td>
                <el-select 
                v-model="selectedCarData.interiorColor"
                :disabled="selectedCarData.exteriorColor === ''"
                @change="selectInColor">
                  <el-option
                    v-for="{ realityInteriorColorCode, interiorColorName } in changeCarInfo.interiorColorList"
                    :key="realityInteriorColorCode"
                    :value="realityInteriorColorCode"
                    :label="interiorColorName"
                  />
                </el-select>
                <span class="car-price">{{ (selectedCarData.interiorColorPrice ? selectedCarData.interiorColorPrice.toLocaleString() : '0')+'원' }}</span>
              </td>
            </tr>
            <tr>
              <th>선택품목</th>
              <td colspan="2" class="multiple-wrap">
                <div class="multiple-inner">
                  <div class="multiple-control">
                    <el-select 
                    v-model="selectedCarData.choiceOption"
                    class="multiple-select"
                    :disabled="selectedCarData.interiorColor === ''"
                    multiple
                    @change="selectChoiceOption">
                      <el-option
                        v-for="{ choiceOptionCode, choiceOptionName, disabled } in changeCarInfo.choiceOptionList"
                        :key="choiceOptionCode"
                        :value="choiceOptionCode"
                        :label="choiceOptionName"
                        :disabled="disabled"
                      />
                    </el-select>
                    <span class="multiple-price">{{ (selectedCarData.choiceOptionPrice ? selectedCarData.choiceOptionPrice.toLocaleString() : '0')+'원' }}</span>
                  </div>
                  <table class="tbl-detail">
                    <tbody>
                      <tr v-for="(item, idx) in carInfoData.choiceOptionInfo" :key="idx">
                        <td>
                          <strong>{{ item.carOptionName }}</strong>
                          <span class="car-price">{{ item.carOptionPrice ? item.carOptionPrice.toLocaleString() : '0'+'원' }}</span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </td>
            </tr>  
             <tr>
               <th>파츠</th>
              <td colspan="2" class="multiple-wrap">
               <div class="multiple-inner">
                 <div class="multiple-control">
                  <el-select
                    v-model="selectedCarData.tuixOption"
                    class="multiple-select"
                    :disabled="selectedCarData.choiceOption.length === 0"
                    multiple
                    @change="onChangeTuixOption">
                     <el-option
                      v-for="{ tuixOptionCode, tuixOptionName } in changeCarInfo.tuixOptionList.filter((el) => el.tuixOptionCode !== 'AX0001')"
                      :key="tuixOptionCode"
                      :value="tuixOptionCode"
                      :label="tuixOptionName"
                    />
                    <!-- <el-option
                      v-for="{ tuixOptionCode, tuixOptionName, disabled } in changeCarInfo.tuixOptionList"
                      :key="tuixOptionCode"
                      :value="tuixOptionCode"
                      :label="tuixOptionName"
                      :disabled="disabled"
                    /> -->
                  </el-select>
                  <span class="multiple-price">{{ (selectedCarData.tuixOptionPrice ? selectedCarData.tuixOptionPrice.toLocaleString() : '0')+'원' }}</span>
                  </div>
                  <table class="tbl-detail">
                    <tbody>
                      <tr v-for="(item, idx) in carInfoData.tuixOptionInfo" :key="idx">
                        <td>
                          <strong>{{ item.carOptionName }}</strong>
                          <span class="car-price">{{ item.carOptionPrice ? item.carOptionPrice.toLocaleString() : '0'+'원' }}</span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </td>
              </tr>
              <tr>
                <th>총 구입비</th>
                <td><span class="car-price">{{ carInfoData.carPrice ? carInfoData.carPrice.toLocaleString() + '원' : '' }}</span></td>
                <td><span class="car-price">{{ (carTotalPrice ? carTotalPrice.toLocaleString() : '0')+'원' }}</span></td>
              </tr>
              <tr>
                <th>예상출고일</th>
                <td><span class="car-date">{{ carInfoData.releaseOrExpectDate ? carInfoData.releaseOrExpectDate : '-' }}</span></td>
                <td><span v-if="selectedCarData.inventoryCount > 0" class="car-date">즉시 출고가능</span><span v-else class="car-date">{{ selectedCarData.exemplificationDateText }}</span></td>
              </tr>             
          </tbody>
        </table>          
      </div>
      <!-- Popup Footer -->
      <template slot="footer">
        <div>
          <el-button type="info" @click="popVisibleCar = false">취소</el-button>
          <el-button type="primary" @click="oneClickDisable($event, doChangeCarInfo)">전송</el-button>
        </div>
      </template>
    </el-dialog>


    <!-- 파츠변경 팝업 -->
    <el-dialog title="파츠 변경" :visible.sync="popVisibleTuix" width="1100px">
      <!-- Popup Contents -->
      <div class="board-wrap">
        <table class="tbl-detail">
          <colgroup>
            <col style="width:16%" />
            <col style="width:42%" />
            <col style="width:42%" />
          </colgroup>
          <thead>
            <tr>
              <th>구분</th>
              <th>변경 전</th>
              <th>변경 후</th>
            </tr>
          </thead>
          <tbody>
             <tr>
              <th>판매모델</th>
              <td>
                <span>{{ carInfoData.modelBasicInfo }}</span>
                <span class="car-price">
                  {{ carInfoData.carModelPrice ? carInfoData.carModelPrice.toLocaleString() + '원' : '' }}
                </span>
              </td>
              <td>
                <el-select v-model="carInfoData.modelBasicInfo" disabled>
                  <el-option :value="carInfoData.modelBasicInfo" :label="carInfoData.modelBasicInfo"></el-option>
                </el-select>
                <span class="car-price">
                  {{ carInfoData.carModelPrice ? carInfoData.carModelPrice.toLocaleString() + '원' : '' }}
                </span>
              </td>
            </tr>
            <tr>
              <th>외장색상</th>
              <td>
                <span>{{ carInfoData.exteriorColorName }}</span>
                <span class="car-price">
                  {{ carInfoData.exteriorColorPrice ? carInfoData.exteriorColorPrice.toLocaleString() : '0'+'원' }}
                </span>
              </td>
              <td>
                <el-select v-model="carInfoData.exteriorColorName" disabled>
                  <el-option :value="carInfoData.exteriorColorName" :label="carInfoData.exteriorColorName"></el-option>
                </el-select>
                <span class="car-price">
                  {{ carInfoData.exteriorColorPrice ? carInfoData.exteriorColorPrice.toLocaleString() : '0'+'원' }}
                </span>
              </td>
            </tr>
            <tr>
              <th>내장색상</th>
              <td>
                <span>{{ carInfoData.realityInteriorColorCode ? carInfoData.realityInteriorColorName : carInfoData.interiorColorName }}</span>
                <span class="car-price">
                  {{ carInfoData.interiorColorPrice ? carInfoData.interiorColorPrice.toLocaleString() : '0'+'원' }}
                </span>
              </td>
              <td>
                <el-select v-model="carInfoData.interiorColorName" disabled>
                  <el-option :value="carInfoData.realityInteriorColorCode ? carInfoData.realityInteriorColorName : carInfoData.interiorColorName" label=""></el-option>
                </el-select>
                <span class="car-price">
                  {{ carInfoData.interiorColorPrice ? carInfoData.interiorColorPrice.toLocaleString() : '0'+'원' }}
                </span>
              </td>
            </tr>
            <tr>
              <th>선택품목</th>
              <td colspan="2" class="multiple-wrap">
                <div class="multiple-inner">
                  <div class="multiple-control">
                    <el-select 
                    v-model="choiceOptionNames"
                    class="multiple-select"
                    disabled>
                      <el-option
                        :label="choiceOptionNames"
                        :value="choiceOptionNames"
                      />
                    </el-select>
                    <span class="multiple-price">{{ (carInfoData.carOptionPrice ? carInfoData.carOptionPrice.toLocaleString() : '0')+'원' }}</span>
                  </div>
                  <table class="tbl-detail">
                    <tbody>
                      <tr v-for="(item, idx) in carInfoData.choiceOptionInfo" :key="idx">
                        <td>
                          <strong>{{ item.carOptionName }}</strong>
                          <span class="car-price">{{ item.carOptionPrice ? item.carOptionPrice.toLocaleString() : '0'+'원' }}</span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </td>
            </tr>
            <tr>
              <th>파츠</th>
              <td colspan="2" class="multiple-wrap">
               <div class="multiple-inner">
                 <div class="multiple-control">
                  <el-select
                    v-model="selectedCarData.tuixOption"
                    class="multiple-select"
                    multiple
                    @change="onChangeTuixOption"
                  >
                  <el-option
                      v-for="{ tuixOptionCode, tuixOptionName } in changeCarInfo.tuixOptionList.filter((el) => el.tuixOptionCode !== 'AX0001')"
                      :key="tuixOptionCode"
                      :value="tuixOptionCode"
                      :label="tuixOptionName"
                    />
                    <!-- <el-option
                      v-for="{ tuixOptionCode, tuixOptionName, disabled } in changeCarInfo.tuixOptionList"
                      :key="tuixOptionCode"
                      :value="tuixOptionCode"
                      :label="tuixOptionName"
                      :disabled="disabled"
                    /> -->
                  </el-select>
                  <span class="multiple-price">{{ (selectedCarData.tuixOptionPrice ? selectedCarData.tuixOptionPrice.toLocaleString() : '0')+'원' }}</span>
                  </div>
                  <table class="tbl-detail">
                    <tbody>
                      <tr v-for="(item, idx) in carInfoData.tuixOptionInfo" :key="idx">
                        <td>
                          <strong>{{ item.carOptionName }}</strong>
                          <span class="car-price">{{ item.carOptionPrice ? item.carOptionPrice.toLocaleString() : '0'+'원' }}</span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </td>
              </tr>
            <tr>
              <th>총 구입비</th>
              <td><span class="car-price">{{ carInfoData.carPrice ? carInfoData.carPrice.toLocaleString() + '원' : '' }}</span></td>
              <td><span class="car-price">{{ (carTotalPrice ? carTotalPrice.toLocaleString() : '0')+'원' }}</span></td>
            </tr>
            <tr>
              <th>예상출고일</th>
                <td><span class="car-date">{{ carInfoData.releaseOrExpectDate ? carInfoData.releaseOrExpectDate : '-' }}</span></td>
                <td><span class="car-date">{{ carInfoData.releaseOrExpectDate ? carInfoData.releaseOrExpectDate : '-' }}</span></td>
            </tr>             
          </tbody>
        </table>          
      </div>
      <!-- Popup Footer -->
      <template slot="footer">
        <div>
          <el-button type="info" @click="popVisibleTuix = false">취소</el-button>
          <el-button type="primary" @click="oneClickDisable($event, doChangeCarInfo)">적용</el-button>
        </div>
      </template>
    </el-dialog>    



    <!-- 차량 실 사진 이미지 -->
    <el-dialog title="" :visible.sync="popVisibleDedicatedDC">
      <!-- Popup Contents -->
      <div class="block wrap-carousel">
        <el-carousel 
          ref="carousel"
          :autoplay="false" 
          arrow="never"
          indicator-position="none"
          @change="carouselChange"
        >
          <el-carousel-item v-for="(item, idx) in imageList" :key="idx">
            <div class="img-carousel">
              <img :src="customBannerUrl(`${item.filePath}${item.fileName}`)" alt="" />              
            </div>
          </el-carousel-item>
        </el-carousel>
      </div>
      <div align="center">
        <el-button type="primary" class="btn-small" @click="onPrev">이전</el-button>
        <span class="space">{{ carouselIndex }} / {{ carouselTotal }}</span>        
        <el-button type="primary" class="btn-small space" @click="onNext">다음</el-button>
      </div>

    </el-dialog>
      <hipass-alert
        :pop-visible.sync="hipassAlertVisible"
        :pop-message.sync="hipassAlertMessage"
        @click="hipassAgreePopVisible = true"
        @close="hipassAlertVisible = false"
      />
      <hipass-popup
        :hipass-pop-visible.sync="hipassAgreePopVisible"
        :hipass-enabled="carInfoData.afterHighpassEnable"
        @close="hipassAgreeCheck"
      />
      <pop-message
        :pop-visible.sync="alertMessagePop"
        :pop-message.sync="alertMessage"
        @confirm="alertMessagePop = false"
        @close="alertMessagePop = false"
      />
      <loading
        :pop-visible.sync="popVisibleLoading"
        :close-on-click-modal="false"
        @close="popVisibleLoading = false"
      />

  </div>
</template>
<script>
import Loading from '~/components/popup/Loading.vue'
import PopMessage from '~/components/popup/PopMessage.vue'
import HipassPopup from '~/components/popup/HiPassAgreePopup.vue'
import HipassAlert from '~/components/popup/HiPassAlert.vue'
export default {
  name: 'CarInfo',
  components: {
    Loading,
    PopMessage,
    HipassPopup,
    HipassAlert
  },
  props: {
    contractNumber: {
      type: String,
      default: '',
    },
    contractInfoData: {
      type: Object,
      default: () => {}
    },
    activeUserFlag: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return { 
      popVisibleCar: false,
      popVisibleLoading: false,
      alertMessage: '',
      popVisibleTuix: false,
      alertMessagePop: false,
      visibleCarBtn: false,
      visibleCarChangeBtn: true,
      visibleTuixBtn: false,
      visibleTuixChangeBtn: true,
      disableTuixChange: false,
      tuixOptionNames: '',
      choiceOptionNames: '',
      choiceOptionInfo: '',
      choiceOptionComment: '',
      choiceOptionVisible: false,
      additionalInfo: [],
      basicOptionNames: [],
      carInfoData: [],
      active: 0,
      activeIndex: 0,
      eraser: '',
      viewImg: false,
      carPrice: 0,
      changeCarInfo: {
        saleModelCode:'',
        carPrice: '',
        trimList:[],
        exteriorColorList: [],
        interiorColorList: [],
        choiceOptionList: [],
        tuixOptionList: [],
      },
      selectedCarData: {
        exteriorColorPrice: 0,
        exteriorColor: '',
        interiorColorPrice: 0,
        interiorColor: '',
        choiceOptionPrice: 0,
        choiceOption: [],
        tuixOptionPrice: 0,
        tuixOption: [],
        tuixOptionData: '',
        exemplificationDateText:'',
        inventoryCount: 0,
      },
      imageList: [], 
      popVisibleDedicatedDC: false,
      carouselIndex: 1,
      carouselTotal: 1,
      /* [#10426/2022.01.12/A936506] 하이패스 동의/해제 */
      hipassAlertMessage: '',
      hipassAlertVisible: false,
      hipassAgreePopVisible: false, // 하이패스 추가
      hipassAgreeCompleted: false, 
    } 
  },
  computed: {
    carTotalPrice() {
      //차량가격 + 색상가격 + 선택 옵션 가격 + tuix 옵션 가격
      let price = 0

      if (this.changeCarInfo.carPrice) price += Number(this.changeCarInfo.carPrice)

      if (this.selectedCarData.exteriorColorPrice) {
        price += Number(this.selectedCarData.exteriorColorPrice)
      }

      if (this.selectedCarData.interiorColorPrice) {
        price += Number(this.selectedCarData.interiorColorPrice)
      }

      if(this.selectedCarData.choiceOptionPrice) {
        price += Number(this.selectedCarData.choiceOptionPrice)
      }

      if(this.selectedCarData.tuixOptionPrice) {
        price += Number(this.selectedCarData.tuixOptionPrice)
      }


      return price
    },
  },
  methods: {
    isValidAuthBtn(authId) {
      // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if (currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some(items => {
          if (items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    async getCarInfoData() {
      if(!this.contractNumber) return

      Object.assign(this.selectedCarData, this.$options.data().selectedCarData)

      const [res, err] = await this.$https.post('/v2/exclusive/work/car', { contractNumber: this.contractNumber })
      if(!err) {
        console.log('/work/car/', res.data)
        if(res.data) {
          this.carInfoData = res.data
          let choiceOptionNameAry = [], tuixOptionNameArr = [], tuixOptionTotalPrice = 0

          const basicOptionCnt = this.carInfoData.basicOptionInfo.length
          if(basicOptionCnt > 0) {
            this.basicOptionNames = this.carInfoData.basicOptionInfo[0].carOptionNameList
          }

          this.carInfoData.choiceOptionInfo && this.carInfoData.choiceOptionInfo.map(el => {
            choiceOptionNameAry.push(el.carOptionName)
            if(el.carOptionDeailName !== null) {
              el.carOptionDeailNameAry = el.carOptionDeailName.split('+')
            }
          })
          this.choiceOptionNames = choiceOptionNameAry.join(', ')
          
          let comment = '', index= 0, viewYn = false
          const choiceOptionCnt = this.carInfoData.choiceOptionInfo.length
          if(choiceOptionCnt > 0){
            viewYn = true, index = 1
            const optionName = this.carInfoData.choiceOptionInfo[0].carOptionName
            choiceOptionCnt > 1 ? comment = optionName + ' 외 옵션 '+ (choiceOptionCnt -1) + '개' : comment = optionName
          }
          this.activeIndex = index
          this.choiceOptionVisible = viewYn
          this.choiceOptionComment = comment
          
          this.carInfoData.tuixOptionInfo = 
            this.carInfoData.tuixOptionInfo && this.carInfoData.tuixOptionInfo
              .filter(el => el.carOptionName !== '액티브 플러스')
        
          this.carInfoData.tuixOptionInfo && this.carInfoData.tuixOptionInfo.map(el => {
            tuixOptionTotalPrice += el.carOptionPrice
            tuixOptionNameArr.push(el.carOptionName)
            if(el.carOptionDeailName !== null) {
              el.carOptionDeailNameAry = el.carOptionDeailName.split('+')
            }
          })
          this.tuixOptionNames = tuixOptionNameArr.join(', ')
          this.carInfoData = { ...this.carInfoData, tuixOptionTotalPrice: tuixOptionTotalPrice }

          if(this.carInfoData.contractCarTypeCode) {
            let code = this.carInfoData.contractCarTypeCode;
            
            //조건재고차의 경우 '차량변경' 버튼 미노출
            // 10 (일반재고)
            // 20 (할인재고)
            // 30 (전시재고)
            // 40 (판촉재고)
            // 50 (생산주문차량)
            // 60 (신차사전예약)

            (code === '20' || 
              code === '30' || 
              code === '40') ? this.visibleCarBtn = false : this.visibleCarBtn = true
            
            if(code === '40') { //판촉재고자의 경우 차량 이미지 및 부가 정보 가져오기
              if(this.carInfoData.criterionDate && this.carInfoData.carProductionNumber) {
                this.getAdditionalCarInfo()
              }
            }

            let deliveryCenterCode = this.contractInfoData.deliveryCenterCode
            let legacyStatusCode = this.contractInfoData.legacyStatusCode

            // if(code === '50') {
            //   //생상주문차량 일 시
            //   this.visibleTuixBtn = true  //파츠변경 버튼 노출
            // }

            this.visibleTuixBtn = false
            this.visibleTuixChangeBtn = true
            this.disableTuixChange = false
            this.visibleCarChangeBtn = true

            //'파츠변경' 버튼 활성화 조건
            if(deliveryCenterCode === 'Z19' || deliveryCenterCode === 'Z22') {
              //출고센터가 '칠곡(Z19)' 또는 '남양(Z22)' 일 시
              if(code === '50') {
                //생산주문차량 일 시
                this.visibleTuixBtn = true
                if(legacyStatusCode === '20' || legacyStatusCode === '30') {
                  //국판진행상태가 '배정요청' 또는 '배정' 일 시
                  this.visibleTuixChangeBtn = false
                }
              } else if(code === '20' || code === '30' || code === '40') {
                //조건재고차량 일 시
                if(legacyStatusCode === '30') {
                  //국판진행상태가 '배정' 일 시
                  this.visibleTuixBtn = true
                  this.visibleTuixChangeBtn = false
                }
              }
            }else if(deliveryCenterCode !== 'Z19' && deliveryCenterCode !== 'Z22') {
              //출고센터가 '칠곡(Z19)' 또는 '남양(Z22)' 이 아닐 시
              if(code === '50') { 
                //생산주문차량일시
                this.visibleTuixBtn = true //버튼 노출
                if(legacyStatusCode === '10' || legacyStatusCode === '20') { 
                  //국판진행상태가 '계약' 또는 '배정요청' 상태 일 시
                  this.visibleTuixChangeBtn = false //버튼 활성화
                  if(legacyStatusCode === '20') { //'배정요청'일 경우에는 버튼 클릭 시 출고센터 변경 필요 안내 alert
                    this.disableTuixChange = true
                  }
                }
              }
            }
          }
          //온라인 상태 코드 (배정취소: 0999)
          if(this.contractInfoData.onlineStatusCode === '0999') { 
            this.visibleCarChangeBtn = false //차량변경버튼 활성화 처리
          }

          if(this.carInfoData.carProductionNumber) {
            this.$emit('data', this.carInfoData.carProductionNumber)
          }

          /* [#10426/2022.01.07/A936506] 하이패스 차량 동의여부를 위해 차량조회 시 하이패스 여부 검사 */
          this.carInfoData.beforeHighpassEnable = await this.getHipassYn(this.carInfoData) 

        }
      } else {
        console.error(err)
      }
    },
    formatSaleSpec(data) {   
      const { saleModelCode = '', optionMixCode = '', tuixMixCode = '', exteriorColorCode = '',  interiorColorCode = '' } = data
      
      return (saleModelCode || '') + ' ' + (optionMixCode || '') + ' ' + (exteriorColorCode || '') + ' ' + (interiorColorCode || '') + ' ' + (tuixMixCode || '')
    },
    formatColor(data) {
      const { realityInteriorColorCode = '', realityInteriorColorName = '', exteriorColorName = '', interiorColorName = '', interiorColorCode = '', exteriorColorCode = '' } = data
      let result = '' // return value
      let exteriorColor = '', interiorColor = '' // 외장, 내장 이름

      exteriorColor = exteriorColorCode ? '외장(' + exteriorColorName + ')' : ''
      if(realityInteriorColorCode) { // 실제 색상코드가 있을경우
        interiorColor = realityInteriorColorCode ? '내장(' + realityInteriorColorName + ')' : ''
        result = exteriorColor + ' ' + interiorColor
      } else { // 실제 색상코드가 없을경우
        interiorColor = interiorColorCode ? '내장(' + interiorColorName + ')' : ''
        result = exteriorColor + ' ' + interiorColor
      }
      return result
    },
    customBannerUrl(suffixUrl) {
      let preffixUrl = 'http://10.7.137.110/dev/casper'
      if (['stg', 'dev', 'prod'].includes(process.env.VUE_APP_PROFILE)) {
        preffixUrl = process.env.VUE_APP_BASEURL_FRONT
      }
      return preffixUrl + suffixUrl
    },
    getOptionNames(idx) {
      //기본내장옵션 카테고리 선택시 옵션내용 출력
      this.basicOptionNames = this.carInfoData.basicOptionInfo[idx].carOptionNameList
      this.eraser = false
      if (this.active === idx) {
        this.active = ''
      } else {
        this.active = idx
      }
    },
    async getTuixData(params) {
      // 파츠 조회 api
      const saleModelCode = this.carInfoData.saleModelCode

      const [res, err] = await this.$https.get('/product/v2/product/options/tuix/'+saleModelCode, params, null, 'gateway')
      if(!err) {
        if(res.data) {
          this.changeCarInfo.tuixOptionList = res.data.map(el=> {
            return {
              tuixOptionCode: el.tuixOptionCode,
              tuixOptionPrice: el.tuixOptionPrice,
              tuixOptionName: el.tuixOptionName,
              unity: el.unityChoiceYn,
              disabled: el.unityChoiceYn === 'Y' ? false : true
            }
          })
        }
      }else {
        console.error('exclusive :: /product/v2/product/options/tuix ERROR !! '+err)
      }
    },
    async changeTuix() {
      if(this.disableTuixChange) {
        this.alertMessage = '파츠를 변경하시려면, 먼저 출고센터를 "칠곡" 또는 "남양"으로 변경해주세요.'
        this.alertMessagePop = true
        return
      }
      //파츠변경
      this.popVisibleTuix = true

      Object.assign(this.selectedCarData, this.$options.data().selectedCarData)

      this.selectedCarData.exteriorColor = this.carInfoData.exteriorColorCode
      this.selectedCarData.exteriorColorPrice = this.carInfoData.exteriorColorPrice
      this.selectedCarData.interiorColor = this.carInfoData.interiorColorCode
      this.selectedCarData.interiorColorPrice = this.carInfoData.interiorColorPrice
      this.selectedCarData.choiceOptionPrice = this.carInfoData.carOptionPrice
      this.changeCarInfo.carPrice = this.carInfoData.carModelPrice
      this.carInfoData.choiceOptionInfo.map(item => {
        this.selectedCarData.choiceOption.push(item.carOptionCode)
      })

      const params = {
        optionCode: this.carInfoData.optionMixCode,
        exteriorColorCode: this.carInfoData.exteriorColorCode,
        interiorColorCode: this.carInfoData.interiorColorCode,
        saleSpecCode: ''
      }      
      this.getTuixData(params) //파츠 조회 

    },
    async getAdditionalCarInfo() {
      // API-WX-상품서비스-059 (재고차량 부가정보 조회)
      const [res, err] = await this.$https.get('/product/v2/product/stock-car/addition', {
        criterionYearMonth: this.carInfoData.criterionDate,
        carProductionNumber: this.carInfoData.carProductionNumber
      }, null, 'gateway')
      if(!err && res) {
        console.log('/product/v2/product/stock-car/addition ::: '+res.data.imageCount)
        if(res.data){
          this.additionalInfo = res.data

          let imgArr = [], count = 1
          if(res.data.imageCount > 0) {
            this.viewImg = true
            count = res.data.imageCount
            imgArr = res.data.imageList.map(items => {
              return {
                filePath: items.FILEPATH+'/',
                fileName: items.FILENAME
              }
            })
          }
          this.imageList = imgArr
          this.carouselTotal = count
        }

      }
    },
    carouselChange(index){
  		this.carouselIndex = index+1
  	},
  	onPrev(){
    	this.$refs.carousel.prev()
    },
    onNext(){
    	this.$refs.carousel.next()
    },
    async changeCar() {
      if(this.contractInfoData.possibleChangeCar === 'N') {
        
        this.alertMessage = '통합계약 내 모든 계약이 \'배정취소\'된 상태에서 차량변경이 가능합니다.'
        this.alertMessagePop = true

        return
      }

      this.popVisibleCar = true //팝업 show

      //선택된 차 정보 초기화
      Object.assign(this.selectedCarData, this.$options.data().selectedCarData)
      Object.assign(this.changeCarInfo, this.$options.data().changeCarInfo)

      //트림 조회
      const [res, err] = await this.$https.get(`/v2/exclusive/work/car/trim/${this.carInfoData.carCode}`)
      if(!err) {
        if(res.data) {
          this.changeCarInfo.trimList = res.data.map(items => {
            return{
              carModelPrice: items.carModelPrice,
              carTrimName: items.carTrimName ,
              modelBasicInfo: items.modelBasicInfo,
              saleModelCode: items.saleModelCode,
              saleSpecCode: items.saleSpecCode,
              sortNo: items.sortNo
            }
          })
        }
      }else {
        console.error('exclusive :: /v2/exclusive/work/car/trim ERROR !! '+err)
      }
    },
    async selectSaleModel(saleModelCode) { 
      /*차량변경에서 판매모델 선택시 호출*/

      // 차량 선택시 값(외장색상,내장색상,선택옵션,파츠) 초기화
      Object.assign(this.selectedCarData, this.$options.data().selectedCarData)

      //선택한 옵션의 인덱스
      let index = 0
      this.changeCarInfo.trimList.find(function(item, i){
        if(item.saleModelCode === saleModelCode){
          index = i
        }
      })
      //선택된 차량의 가격
      this.changeCarInfo.carPrice = Number(this.changeCarInfo.trimList[index].carModelPrice)

      //선택한 차량의 외장색상 조회API
      const [res, err] = await this.$https.get('/product/v2/product/exterior-color/'+saleModelCode, null, null, 'gateway')
      if(!err) {
        if(res.data) {
          this.changeCarInfo.exteriorColorList = res.data.map(items => {
            return {
              exteriorColorCode: items.exteriorColorCode,
              exteriorColorName: items.exteriorColorName,
              exteriorColorPrice: items.exteriorColorPrice,
              choiceYn: items.choiceYn
            }
          }).filter((items) => items.choiceYn !== 'N')
        }
      }else {
        console.error('exclusive :: /product/v2/product/exterior-color ERROR !! '+err)
      }

      //선택한 차량의 선택옵션 조회API
      const [res1, err1] = await this.$https.get('/product/v2/product/options/choice/'+saleModelCode, null, null, 'gateway')
      if(!err1) {
        if(res1.data) {
          this.changeCarInfo.choiceOptionList = res1.data.map(items => {
            return {
              choiceOptionCode: items.choiceOptionCode,
              choiceOptionName: items.choiceOptionName,
              choiceOptionPrice: items.choiceOptionPrice,
              disabled: items.unityChoiceYn === 'Y' ? false : true,
              unity: items.unityChoiceYn,
              optionGroup: items.choiceOptionGroupCodes
            }
          })
        }
      }else {
        console.error('exclusive :: product/v2/product/options/choice ERROR !! '+err1)
      }
    },
    async selectExColor(exColorCode) {
      /* 차량 변경에서 외장색상 선택시 호출 */

      //선택한 옵션의 인덱스
      let index = 0
      this.changeCarInfo.exteriorColorList.find(function(item, i){
        if(item.exteriorColorCode === exColorCode){
          index = i
        }
      })
      //선택한 외장색상의 가격
      this.selectedCarData.exteriorColorPrice = Number(this.changeCarInfo.exteriorColorList[index].exteriorColorPrice)

      //선택한 차량모델의 내장색상 리스트 조회API
      const [res, err] = await this.$https.get(`/product/v2/product/interior-color/${this.changeCarInfo.saleModelCode}`, {
        exteriorColorCode: exColorCode
      }, null, 'gateway')
      if(!err) {
        if(res.data) {
          this.changeCarInfo.interiorColorList = res.data.map(items => {
            return {
              interiorColorCode: items.interiorColorCode,
              interiorColorName: items.interiorColorName,
              realityInteriorColorCode: items.realityInteriorColorCode,
              realityInteriorColorName: items.realityInteriorColorName,
              choiceYn: items.choiceYn,
            }
          }).filter((items) => items.choiceYn !== 'N')
        }
      }else {
        console.error('exclusive :: /product/v2/product/interior-color ERROR !! '+err)
      }
    },
    async selectInColor(inColorCode) {
      //선택된 옵션정보 초기화
      this.resetSelectedData('inColor')

      let index = 0
      this.changeCarInfo.interiorColorList.find(function(item, i){
        if(item.interiorColorCode === inColorCode){
          index = i
        }
      })
      //선택한 내장색상의 가격
      this.selectedCarData.interiorColorPrice = Number(this.changeCarInfo.interiorColorList[index].interiorColorPrice)

      //컬러에 따른 필수 옵션 조회 API
      const params ={
        saleModelCode: this.changeCarInfo.saleModelCode,
        saleSpecCode: 'A',
        exteriorColorCode: this.selectedCarData.exteriorColor,
        interiorColorCode: inColorCode
      }

      let arr = []
      const [res, err] = await this.$https.get('/product/v2/product/option-required-choice', params, null, 'gateway')
      if(!err) {
        if(res.data) {
          arr = res.data.map(el => {
            return {
              optionCode: el.OPTIONCODE
            }
          })

          arr.map(items => {
            const idx = this.changeCarInfo.choiceOptionList.findIndex(function(item) {
              return item.choiceOptionCode === items.optionCode
            }) 
            
            if(idx > -1) {
              this.selectedCarData.choiceOption.push(this.changeCarInfo.choiceOptionList[idx].choiceOptionCode)
            }
          })
          
        }
      }else {
        console.error('exclusive :: /product/v2/product/option-required-choice ERROR !! '+err)
      }

      this.selectChoiceOption()

    },
    async selectChoiceOption() {
      /* 차량변경에서 선택옵션 클릭시 호출 */
      
      // 선택되어있는 파츠 초기화
      this.resetSelectedData('option')

      let turboChk = this.changeCarInfo.saleModelCode.substr(5,1) === 'T' ? true : false
      let chkt = this.selectedCarData.choiceOption.findIndex(el => el === 'CA1' || el === 'CA2') > -1

      if(turboChk && !chkt) {
        let turboOpt = this.changeCarInfo.choiceOptionList.find(el => el.choiceOptionCode === 'CA1' || el.choiceOptionCode === 'CA2')
        if(turboOpt) {
          this.selectedCarData.choiceOption.unshift(turboOpt.choiceOptionCode)
        }
      }
      // 선택한 항목에 따른 비활성화 옵션 조회
      this.disabledOptionList()

      let saleModelCode = this.changeCarInfo.saleModelCode
      let index, price = 0
      //선택한 선택옵션의 총 가격 계산
      for(let data of this.selectedCarData.choiceOption) {
        this.changeCarInfo.choiceOptionList.find(function(item, i){
          if(item.choiceOptionCode === data){
            index = i
          }
        })
        price += Number(this.changeCarInfo.choiceOptionList[index].choiceOptionPrice)
      }
      this.selectedCarData.choiceOptionPrice = price
      
      //선택한 차량모델과 옵션, 색상코드로 파츠 리스트 조회API
      let optionCode = this.selectedCarData.choiceOption.length
        ? this.selectedCarData.choiceOption.join(',')
        : ''

      const params = {
        carAbbreviation: this.carInfoData.carnCode,
        optionCode: optionCode,
        exteriorColorCode: this.selectedCarData.exteriorColor,
        interiorColorCode: this.selectedCarData.interiorColor,
        saleSpecCode: ''
      }
      this.getTuixData(params) //파츠 조회

      //필수 파츠옵션 조회 API
      const params2 = {
        saleModelCode: saleModelCode,
        optionCode: optionCode,
        saleSpecCode: 'A' //AX차량의 경우 판매스펙코드 'A'로 고정
      }
      let arr =[]
      const [res1, err1] = await this.$https.get('/product/v2/product/tuix-required-choice', params2, null, 'gateway')
      if(!err1) {
        if(res1.data) {
          arr = res1.data.map(el => {
            return { tuixCode: el.tuixCode }
          }).filter((items) => items.tuixCode !== 'AX0001')

          arr.map(items => {
            const idx = this.changeCarInfo.tuixOptionList.findIndex(function(item) {
              return item.tuixOptionCode === items.tuixCode
            })
            if(idx !== ''){
              this.selectedCarData.tuixOption.push(this.changeCarInfo.tuixOptionList[idx].tuixOptionCode)
            }
            
          })
        }
      }else {
        console.error('exclusive :: /product/v2/product/tuix-required-choice ERROR !! '+err1)
      }
      
      //예상 출고일 조회
      let optionMixCode = await this.getOptionMixCode(saleModelCode, optionCode) //옵션조합코드 조회
      const data = {
        saleModelCode : saleModelCode,
        optionMixCode : optionMixCode ? optionMixCode.code : '', 
        exteriorColorCode : this.selectedCarData.exteriorColor,
        interiorColorCode : this.selectedCarData.interiorColor,
      }
      this.getExemplification(data)


      // let activePlusOpt = this.selectedCarData.choiceOption.findIndex(el => el === 'CAP') > -1
      // let activePlus = this.selectedCarData.tuixOptionData = 'AX0001'
      // let tuixVal = ''
      
      // if(activePlusOpt && activePlus) {
      //   tuixVal = 'AX0001'
      // }
      // this.selectedCarData.tuixOptionData = tuixVal

       
    },
    async disabledOptionList() {
      this.optionUniqCheck() //단독으로 선택될 수 없는 옵션 체크 해제 처리

      const params = {
        optionCode: this.selectedCarData.choiceOption.join(',')
      }

      if(!params.optionCode) {
        this.changeCarInfo.choiceOptionList.map(items => {
          items.disabled = items.unity === 'Y' ? false : true
        })
        return
      }

      let arr = []
      const [res, err] = await this.$https.get('/product/v2/product/disable-option/'+ this.changeCarInfo.saleModelCode, params, null, 'gateway')
      if(!err) {
        if(res.data) {
          res.data.map(items => {
            const idx = this.changeCarInfo.choiceOptionList.findIndex(function(item) {
              return item.choiceOptionCode === items.optionCode
            })
            if(idx !== ''){
              this.changeCarInfo.choiceOptionList[idx].disabled = true
            }
            arr.push(items.optionCode)
          })
          
          this.changeCarInfo.choiceOptionList.map(el => {
            if(arr.indexOf(el.choiceOptionCode) === -1) {
              el.disabled = false
            }
          })
        }
      }else {
        console.error('exclusive :: /product/v2/product/disable-option/ ERROR !! '+err)
      }
      
      this.possibleOptionList(params)
      // const [res1, err1] = await this.$https.get('/product/v2/product/add-possible-option/'+ this.changeCarInfo.saleModelCode, params, null, 'gateway')
      // if(!err1) {
      //   if(res1 && res1.data) {
      //     res1.data.map(items => {
      //       const idx = this.changeCarInfo.choiceOptionList.findIndex(function(item) {
      //         return item.choiceOptionCode === items.optionCode
      //       })
      //       if(idx) this.changeCarInfo.choiceOptionList[idx].disabled = false
      //     })
      //   }
      // }else {
      //   console.error('exclusive ::/product/v2/product/add-possible-option ERROR !! '+err1)
      // }
    },
    async possibleOptionList(params) {
      const [res1, err1] = await this.$https.get('/product/v2/product/add-possible-option/'+ this.changeCarInfo.saleModelCode, params, null, 'gateway')
      if(!err1) {
        if(res1 && res1.data) {
          res1.data.map(items => {
            const idx = this.changeCarInfo.choiceOptionList.findIndex(function(item) {
              return item.choiceOptionCode === items.optionCode
            })
            if(idx !== '') this.changeCarInfo.choiceOptionList[idx].disabled = false
          })
        }
      }else {
        console.error('exclusive ::/product/v2/product/add-possible-option ERROR !! '+err1)
      }

    },
    optionUniqCheck() {
      //단독으로 선택될 수 없는 옵션의 경우 체크 해제 처리
      let arr =[]
      this.selectedCarData.choiceOption.map(el => {
        let idx = this.changeCarInfo.choiceOptionList.findIndex(function(item) {
          return item.choiceOptionCode === el
        })
        if(idx > -1){
          let unity = this.changeCarInfo.choiceOptionList[idx].unity
          let group = this.changeCarInfo.choiceOptionList[idx].optionGroup

          if(unity === 'N'){
            let chkVal = false
            this.selectedCarData.choiceOption.map(item => {
              if(item !== el) {
                if(group.indexOf(item) > -1){
                  chkVal = true
                }
              }
            })
            if(!chkVal) {
              arr.push(el)
            }
          }
        }
      })
      if(arr.length > 0) {
        arr.map(el => {
          this.selectedCarData.choiceOption.map((item, idx) => {
            if(item === el) this.selectedCarData.choiceOption.splice(idx, 1)
          })
        })
      }
    },
    async onChangeTuixOption() {
      let index, price = 0
      let saleModelCode = this.changeCarInfo.saleModelCode ? this.changeCarInfo.saleModelCode : this.carInfoData.saleModelCode
      //선택한 파츠의 총 가격 계산
      for(let data of this.selectedCarData.tuixOption) {
        this.changeCarInfo.tuixOptionList.find(function(item, i){
          if(item.tuixOptionCode === data) {
            index = i
          }
        })
        price += Number(this.changeCarInfo.tuixOptionList[index].tuixOptionPrice)
      }
      this.selectedCarData.tuixOptionPrice = price

      let arr = []
      const params = {
        tuixCode: this.selectedCarData.tuixOption.join(',')
      }
      const [res, err] = await this.$https.get('/product/v2/product/disable-tuix/'+saleModelCode, params, null, 'gateway')
      if(!err) {
        if(res.data) {
          res.data.map(items => {
            const idx = this.changeCarInfo.tuixOptionList.findIndex(function(item) {
              return item.tuixOptionCode === items.tuixCode
            })
            if(idx !== '') {
              this.changeCarInfo.tuixOptionList[idx].disabled = true
            }
            arr.push(items.tuixCode)
          })

          this.changeCarInfo.tuixOptionList.map(el => {
            if(arr.indexOf(el.tuixOptionCode) === -1) {
              el.disabled = false
            }
          })
        
        }
      }else {
        console.error('exclusive :: /product/v2/product/disable-tuix ERROR !! '+err)
      }
    },
    async getExemplification(data) {
      //예상 출고일 문구 조회 API
      const [res, err] = await this.$https.get('/purchase/v2/purchase/contract/car/exemplification/info', {
        saleModelCode : data.saleModelCode,
        optionMixCode : data.optionMixCode,
        exteriorColorCode : data.exteriorColorCode,
        interiorColorCode : data.interiorColorCode,
      }, null, 'gateway')
      if(!err) {
        if(res.data) {
          this.selectedCarData.inventoryCount = res.data.inventoryCount ? Number(res.data.inventoryCount) : 0
          this.selectedCarData.exemplificationDateText = res.data.exemplificationDateText
        }
      }else {
        console.error('exclusive :: /purchase/v2/purchase/contract/car/exemplification/info ERROR !! '+err)
      }
    },
    resetSelectedData(type) {
      if(type === 'all') Object.assign(this.selectedCarData, this.$options.data().selectedCarData)

      if(type === 'exColor') {
        this.selectedCarData.interiorColor = ''
        this.selectedCarData.interiorColorPrice = 0
      }
      if(type === 'exColor' || type === 'inColor') {
        this.selectedCarData.choiceOption = []
        this.selectedCarData.choiceOptionPrice = 0
      }
      if(type === 'exColor' || type === 'inColor' || type === 'option') {
        this.selectedCarData.tuixOption = []
        this.selectedCarData.tuixOptionPrice = 0
      }
    },
    async doChangeCarInfo() {
     
      this.popVisibleLoading = true

      if(!this.selectedCarData.interiorColor) {
        this.popVisibleLoading = false
        return
      }

      let activePlusOpt = this.selectedCarData.choiceOption.findIndex(el => el === 'CAP') > -1
      let activePlus = this.selectedCarData.tuixOptionData = 'AX0001'
      let tuixVal = ''

      if(activePlusOpt && activePlus) {
        tuixVal = 'AX0001'
      }
      
      this.selectedCarData.tuixOptionData = tuixVal

      const saleModelCode = this.changeCarInfo.saleModelCode ? this.changeCarInfo.saleModelCode : this.carInfoData.saleModelCode
      let optionCode = this.selectedCarData.choiceOption.length
        ? this.selectedCarData.choiceOption.join(',')
        : ''
      
      let tuixCode = this.selectedCarData.tuixOption.length
        ? this.selectedCarData.tuixOption.join(',')
        : ''

      let tuixOptionData = this.selectedCarData.tuixOptionData
      if(tuixOptionData) {
        tuixCode = tuixCode === '' ? tuixOptionData : tuixCode + ','+tuixOptionData
      }

      console.log('tuixCode :: '+tuixCode)

      let optionMixCode = await this.getOptionMixCode(saleModelCode, optionCode) //옵션조합코드 조회
      let tuixMixCode = await this.getTuixMixCode(saleModelCode, tuixCode) //파츠조합코드 조회
      
      const params = {
        contractNumber: this.contractNumber,
        contractCarTypeCode: this.carInfoData.contractCarTypeCode,
        saleModelCode: saleModelCode,
        optionMixCode: optionMixCode ? optionMixCode.code : '',
        exteriorColorCode: this.selectedCarData.exteriorColor,
        interiorColorCode: this.selectedCarData.interiorColor,
        tuixOptionCode: tuixMixCode ? tuixMixCode.code : '',
        realityInteriorColorCode: this.selectedCarData.interiorColor,
        carCode: this.carInfoData.carCode,
        assignReqYn: 'N',
        oneContractNoYn : this.contractInfoData.possibleChangeCar === 'Y' ? 'N' : 'Y',
        carProductionNumber: this.carInfoData.carProductionNumber
      }

      /* [#10426/2021.12.28/A936506]
         1. 일반 주문 차량 -> 특별 주문 차량 변경 제한
         2. 하이패스 차량 선택 시 동의 여부 팝업 .
      */
      let carChangeValidationResult = await this.carChangeValidation(params)
      
      if(!carChangeValidationResult) {
        return
      }

      const [res, err] = await this.$https.post('/purchase/v2/purchase/contract/carInfoChange', params, null, 'gateway')
      if(!err) {
        if(res.rspStatus.rspCode === '0000') {
          this.alertMessage = '차량정보를 변경했습니다.'
          this.alertMessagePop = true

          this.popVisibleCar = false
          this.popVisibleTuix = false

          this.$emit('searchContract', this.contractNumber)

          //this.getCarInfoData()
        }
      }else {
        console.error('exclusive :: /purchase/v2/purchase/contract/carInfoChange ERROR !! '+err)
      }

      this.popVisibleLoading = false
    },
    /* [#10426/2021.12.30/A936506] 차량변경 시 체크 밸리데이션 추가 및 하이패스 조회 Start */
    async carChangeValidation(param) {
      
      let result = true

      // 1. 일반 주문 차량 -> 특별 주문 차량 제한
      if(this.contractInfoData.specialOrderYn !== 'Y') {
        //API-WE-상품서비스-025 (계약가능여부조회) (특별차 )
        const [res, err] = await this.$https.get('/product/v2/product/contract/down-payment/info', param, null, 'gateway')

        if(!err) {
          if(res.data && res.data.specialCarYn === 'Y') {
            this.alertMessage = '선택하신 차량은 특별주문차량이므로 변경이 불가합니다.'
            this.alertMessagePop = true

            result = false
          }
        } else {
          console.log('Error 계약가능여부조회 {}' , JSON.stringify(err))
        }
        
      }
      // 특별주문차 우선 체크. 통과 후 하이패스 체크.
      // 하이패스 동의여부가 완료된 상황인 경우 체크 x
      if(result && !this.hipassAgreeCompleted) {
        // 2. 하이패스 차량
        this.carInfoData.afterHighpassEnable = await this.getHipassYn(param)
  
        if(this.carInfoData.beforeHighpassEnable !== this.carInfoData.afterHighpassEnable) {
          // 안내문구 -> 동의 팝업 
          this.hipassAlertMessage = '하이패스 개통 신청 대행을 위한 개인정보 제3자 제공 동의 여부를 변경해주세요.'
          this.hipassAlertVisible = true
          // this.hipassAgreePopVisible = true
          result = false
        }
      }
      return result
    },
    async getHipassYn(param) {
      
      if(!param.contractNumber) {
        param.contractNumber = this.contractNumber
      }
      // 하이패스 장착여부 조회
      // const [res, err] = await this.$https.post('/hds-eis/domestic-sales/sale/Eco?actionName=ListCommWork&cmd=R005', param, null, 'gateway')
      const [res, err] = await this.$https.post('/v2/exclusive/work/car/highpassEnable', param)

      let hipass = false

      if(!err) {
        // 하이패스 장착 여부
        hipass = (res.data) ? res.data : hipass  

      }
      return hipass
    },
    hipassAgreeCheck(value) {
      this.hipassAgreePopVisible = false
      //hipassAgree
      if(value) {
        this.hipassAgreeCompleted = value
      }
      
      if(this.hipassAgreeCompleted) {
        this.doChangeCarInfo()
      }
    },
    /* [#10426/2021.12.30/A936506] 차량변경 시 체크 밸리데이션 추가 및 하이패스 조회 End */
    async getOptionMixCode(saleModelCode, optionCode) {
      const params = {
        saleModelCode: saleModelCode,
        optionCode: optionCode,
        saleSpecCode:'',
      }
      const [res, err] = await this.$https.get('/product/v2/product/option-mix-info', params, null, 'gateway')
      if(!err) {
        if(res.data) {
          return {
            code : res.data.optionMixCode
          }
        }
      }else {
        console.error('exclusive :: /product/v2/product/option-mix-info ERROR !! '+err)
      }
    },
    async getTuixMixCode(saleModelCode, tuixCode) {
      const params = {
        saleModelCode: saleModelCode,
        tuixCode: tuixCode,
      }

      const [res, err] = await this.$https.get('/product/v2/product/tuix-info', params, null, 'gateway')
      if(!err) {
        if(res.data) {
          return {
            code: res.data.tuixMixCode
          }
        }
      }else {
        console.error('exclusive :: /product/v2/product/tuix-info ERROR !! '+err)
      }
    },
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
    oneClickDisable(event, clickEvent, ...args) {
      if(event.target.disabled === true){
        retrun
      }

      event.target.disabled = true

      try {
        clickEvent(...args)
      } catch {}
      setTimeout(() => {
        event.target.disabled = false
      }, 2000)
    }
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */    
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
  .wrap-carousel {
    position:relative;
    top:-30px;
  }
  .img-carousel {
    overflow:hidden;
    width:100%;
    img {
      width:100%;
      height:auto;
    }
  }

</style>

