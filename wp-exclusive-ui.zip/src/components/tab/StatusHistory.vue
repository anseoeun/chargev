<template>
  <div>
    <component
      v-bind:is="currentComponent(item)"
      :ref="currentComponentRef(item)"
      v-for="(item, index) in componentSortList"
      :key="index"
      :contract-number.sync="contractNumber"
      @refresh="refresh()"
    ></component>
    <!-- <dc-history
      ref="DcHistory"
      :contract-number="contractNumber"
    />
    <sale-history
      ref="SaleHistory"
      :contract-number="contractNumber"
    />
    <sales-history
      ref="SalesHistory"
      :contract-number="contractNumber"
    />
    <payment-history
      ref="PaymentHistory"
      :contract-number="contractNumber"
    />
    <point-history
      ref="PointHistory"
      :contract-number="contractNumber"
    />
    <consultant-history
      ref="ConsultantHistory"
      :contract-number="contractNumber"
    />
    <paper-history 
      ref="PaperHistory"
      :contract-number="contractNumber"
    />
    <sign-history
      ref="SignHistory"
      :contract-number="contractNumber"
    />
    <api-log-history
      ref="ApiLogHistory"
      :contract-number="contractNumber"
    /> -->
  </div>
</template>
<script>
import DcHistory from '~/components/tab/Status/DcHistory.vue'
import SalesHistory from '~/components/tab/Status/SalesHistory.vue'
import SaleHistory from '~/components/tab/Status/SaleHistory.vue'
import ConsultantHistory from '~/components/tab/Status/ConsultantHistory.vue'
import PaymentHistory from '~/components/tab/Status/PaymentHistory.vue'
import PaperHistory from '~/components/tab/Status/PaperHistory.vue'
import SignHistory from '~/components/tab/Status/SignHistory.vue'
import ApiLogHistory from '~/components/tab/Status/ApiHistory.vue'
import PointHistory from '~/components/tab/Status/PointHistory.vue'
import ChangeHistory from '~/components/tab/Status/ChangeHistory.vue'
import { mapState } from 'vuex'

export default {
  name: 'StatusHistory',
  components: {
    DcHistory,
    SalesHistory,
    SaleHistory,
    PaymentHistory,
    PaperHistory,
    SignHistory,
    ApiLogHistory,
    PointHistory,
    ConsultantHistory,
    ChangeHistory
  },
  props: {
    contractNumber: {
      type: String,
      default: ''
    },
    componentSortList: {
      type: Array,
      default: () => [        
        'change-history',
        'dc-history',
        'sale-history',
        'sales-history',
        'payment-history',
        'point-history',
        'consultant-history',
        'paper-history',
        'sign-history',
        'api-log-history',        
      ]
    }
  },
  data() {
    return {
      filterReviewList: null,
      commonCodes: {},
      popLogDetail:false,
      logInfo: {
        siteConnectTime:'',
        logDetail:''
      }
    }
  },
  computed: {
    ...mapState(['documentTargets']),
  },
  async created() {
    await this.loadCommonCode()
  },
  mounted () {
    this.$store.dispatch('loadDocumentTargets', {vm: this})
  },
  methods: {
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null
      switch(systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {vm: this, codeTypeCode: codeType})
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {vm: this, codeTypeCode: codeType})
        break
      }
      return res
    },
    async loadCommonCode() {
      const [ccT002] = await Promise.all([
        this.fetchCommonCodeData('E', 'T002'), // 상태
      ])

      this.commonCodes = { ...ccT002 }
    },
    getAllData() {
      if(!this.contractNumber) return
      this.getDcHistory()
      this.getConsultantHistory()
      this.getSalesHistory()
      this.getSaleHistory()
      this.getPaymentHistory()
      this.getPaperHistory()
      this.getSignHistory()
      this.getApiHistory()
      this.getPointHistory()
      this.getChangeHistory()
    },
    getDcHistory() {
      this.$refs.DcHistory[0].getDcHistory()
    },
    getSalesHistory() {
      this.$refs.SalesHistory[0].getSalesHistoryData()
    },
    getSaleHistory() {
      this.$refs.SaleHistory[0].getSaleHistoryData()
    },
    getPaymentHistory() {
      this.$refs.PaymentHistory[0].getPaymentHistoryData()
    },
    getPaperHistory() {
      this.$refs.PaperHistory[0].getPaperHistoryData()
    },
    getSignHistory() {
      this.$refs.SignHistory[0].getSignHistoryData()
    },
    getApiHistory() {
      this.$refs.ApiLogHistory[0].getApiLogHistoryData()
    },
    getPointHistory(){
      this.$refs.PointHistory[0].getPointHistoryData()
    },
    getConsultantHistory() {
      this.$refs.ConsultantHistory[0].getConsultantHistoryData()
    },
    getChangeHistory() {
      this.$refs.ChangeHistory[0].getChangeHistoryData()
    },
    currentComponent(compo) {
      return compo
    },
    currentComponentRef(value) {
      return value
        .split('-')
        .map((el) =>
          el.charAt(0).toUpperCase() + el.slice(1)
        )
        .join('')
    }
  }
}
</script>

<style lang="scss" scoped>
.pdt20{
  padding-top: 20px;
}
</style>
