<template>
  <div>
    <div class="article-title gap">
      <div>
        <h2 class="fl">서비스 가입</h2>
        <el-button type="info" class="btn-small space" @click="agreePopOpen()"
          >정보 활용동의</el-button
        >
        <el-button type="info" class="btn-small space" @click="PLCCUrlSend(true)"                    
          >현대카드 신청 URL 발송</el-button
        >
      </div>
      <div class="right">
        <el-button
          type="primary"
          v-if="isValidAuthBtn('authExclusive')"
          :disabled=" !activeUserFlag ||
                      btnDisable "
          @click="oneClickDisable($event, saveChangeService)"
          >변경</el-button
        >
      </div>
    </div>

    <!-- <div class="right">
      <el-button type="primary" @click="saveChangeService">변경</el-button>
    </div> -->
    <el-form ref="service" :model="contractData" class="detail-form">
      <el-row>
        <el-col :span="8">
          <!-- <el-form-item
            label="블루멤버스"
            prop="blueMembersPetitionYn"
            v-if="!contractInfoData.deliveryRequestDate"
          >
            <el-radio-group v-model="contractData.blueMembersPetitionYn">
              <el-radio label="N">아니요</el-radio>
              <el-radio label="Y">예</el-radio>
            </el-radio-group>
          </el-form-item> -->
          <el-form-item label="블루멤버스">
            <!-- {{ contractData.blueMembersPetitionYn === "Y" ? "예" : "아니오" }} -->
            {{this.blueMembersMemberStatusName}}
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <!-- <el-form-item
            label="하이패스"
            prop="hipassChoiceYn"
            v-if="!contractInfoData.deliveryRequestDate"
          >
            <el-radio-group v-model="contractData.hipassChoiceYn">
              <el-radio label="N">아니요</el-radio>
              <el-radio label="Y">예</el-radio>
            </el-radio-group>
          </el-form-item> -->
          <el-form-item label="CASPER 전용카드">
            {{ plccChoiceYn === "Y" ? "신청" : "미신청" }}
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item
            label="보증제도"
            prop="guarantyRepairType"
            v-if="!contractInfoData.deliveryRequestDate"
          >
            <el-select
              v-model="contractData.guarantyRepairTypCode"
              placeholder="선택"
            >
              <el-option
                v-for="{ value, label } in LegacyCommonCodes.C913 &&
                  LegacyCommonCodes.C913"
                :key="value"
                :value="value"
                :label="label"
              />
            </el-select>
          </el-form-item>
          <el-form-item
            label="보증제도"
            v-if="contractInfoData.deliveryRequestDate"
            >{{ contractData.guarantyRepairTypeName }}</el-form-item
          >
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="표준 서비스 물품">{{
            contractData.standardServiceName
          }}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="등록대행 서비스">
          	<template v-if="contractData.registAgencyApplyYn">
              {{
                contractData.registAgencyApplyYn === "Y" ? "등록대행" : "직접등록"
              }}
            </template>
            <template v-else>
              	없음
            </template>
          </el-form-item>
        </el-col>        
        <el-col :span="8">          
          <el-form-item label="특별차량 동의여부" v-if="contractData.specialCarYn ==='Y'">동의</el-form-item>
        </el-col>
      </el-row>
      <el-row v-for="(dataList, index) in selectServiceList" :key="index">
        <el-col
          :span="dataList.length < 3 && idx != 0 ? 8 * (idx + 1) : 8"
          v-for="(data, idx) in dataList"
          :key="idx"
        >
          <el-form-item
            :label="data.needPapersName"
            :prop="data.needPapersNumber"
          >
            <el-radio-group v-model="data.choiceYn">
              <el-radio label="N">아니요</el-radio>
              <el-radio label="Y">예</el-radio>
            </el-radio-group>
          </el-form-item>
          <!-- <el-form-item
            label="중고차가격보장"
            v-if="contractInfoData.deliveryRequestDate"
            >{{ contractData.tradeInYn }}</el-form-item
          > -->
        </el-col>
      </el-row>
      <!-- <el-row>
        <el-col :span="8">
          <el-form-item label="차량 구분">{{
            contractData.contractCarTypeName
          }}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="특화 서비스">
            <el-tooltip placement="bottom" effect="light">
              <div slot="content">
                <el-row>
                  <el-col :span="6">서비스 선택</el-col>
                  <el-col :span="18">{{
                    contractData.specialServiceContents
                  }}</el-col>
                </el-row>

                <el-row v-if="contractData.specialServiceDelivertAddress">
                  <el-col :span="6">수령지</el-col>
                  <el-col :span="18">{{
                    contractData.specialServiceDelivertAddress
                  }}</el-col>
                </el-row>
              </div>
              <span>
                <el-button type="text">{{
                  contractData.specialServiceName
                }}</el-button>
              </span>
            </el-tooltip>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="표준 서비스 물품">{{
            contractData.standardServiceName
          }}</el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="하이패스">{{
            contractData.hipassChoiceYn
          }}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="블루링크">
            <el-tooltip placement="bottom" effect="light">
              <div slot="content">
                <div class="tootip-title">
                  <h3>{{ contractData.blueLinkName }}</h3>
                </div>
                <el-row>
                  <el-col :span="6">기본료</el-col>
                  <el-col :span="18">{{
                    contractData.blueLinkPrice &&
                      contractData.blueLinkPrice.toLocaleString() + "원 / 월"
                  }}</el-col>
                </el-row>
                <el-row>
                  <el-col :span="6">가입일</el-col>
                  <el-col :span="18">{{
                    contractData.blueLinkSubscribeDate &&
                      contractData.blueLinkSubscribeDate
                  }}</el-col>
                </el-row>
                <el-row>
                  <el-col :span="6">무료기간 만료일</el-col>
                  <el-col :span="18">{{
                    contractData.blueLinkFreeUseEndDate &&
                      contractData.blueLinkFreeUseEndDate
                  }}</el-col>
                </el-row>
              </div>
              <span>
                <el-button type="text">{{
                  contractData.blueLinkName
                }}</el-button>
              </span>
            </el-tooltip>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="업무담당자 블루핸즈">
            <el-tooltip placement="bottom" effect="light">
              <div slot="content">
                <div class="tootip-title">
                  <h3>{{ contractData.blueHandsName }}</h3>
                </div>
                <el-row>
                  <el-col :span="6">주소</el-col>
                  <el-col :span="18">{{
                    contractData.blueHandsAddress
                  }}</el-col>
                </el-row>
                <el-row>
                  <el-col :span="6">연락처</el-col>
                  <el-col :span="18">{{ contractData.blueHandsTel }}</el-col>
                </el-row>
              </div>
              <span>
                <el-button type="text">{{
                  contractData.blueHandsName
                }}</el-button>
              </span>
            </el-tooltip>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="16">
          <el-form-item label="선택형 서비스">{{
            contractData.choiceServiceName
          }}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="보증제도">{{
            contractData.guarantyRepairTypeName
          }}</el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="블루멤버스 신청여부">{{
            contractData.blueMembersPetitionYn
          }}</el-form-item>
        </el-col>
        <el-col :span="16">
          <el-form-item label="선택한 카드">{{
            contractData.blueMembersCardName
          }}</el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <el-form-item label="카드수령지">{{
            contractData.blueMembersDelivertAddress
          }}</el-form-item>
        </el-col>
      </el-row> -->
    </el-form>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />          
      <!-- 현대카드 신청 URL 전송 팝업 -->
      <el-dialog custom-class="message"
        :visible.sync="isPLCCPopFlag" 
        
      >
        <!-- 문구 -->
        현대카드 신청 URL을 재발송 하시겠습니까?
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button type="info" @click="PLCCUrlSend(false)">
            취소
          </el-button>
          <el-button type="primary" @click="SendPLCCUrl()">
            확인
          </el-button>
        </template>
      </el-dialog>
      <!-- ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## -->    
      <loading
        :pop-visible.sync="popVisibleLoading"
        @close="popVisibleLoading = false"
      />
      <!-- ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## -->      
  </div>
</template>
<script>
import HTableList from "~/components/common/HTableList.vue";
import HTable from "~/components/common/HTable.vue";
import HTitle from "~/components/common/HTitle.vue";
import PopMessage from "~/components/popup/PopMessage.vue";
import moment from "moment";
/* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */      
import Loading from "~/components/popup/Loading.vue";
/* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */

export default {
  name: "ServiceInfo",
  components: {
    HTableList,
    HTable,
    HTitle,
    PopMessage,
/* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */      
    Loading
/* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
  },
  props: {
    contractNumber: {
      type: String,
      default: ""
    },
    contractData: {
      type: Object,
      default: () => {}
    },
    userInfoData: {
      // 로그인 사용자 정보
      type: Object,
      default: () => {}
    },
    activeUserFlag: {
      type: Boolean,
      default: false
    },
    contractInfoData: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      isAuth: process.env.VUE_APP_AUTH === "true", // 권한 패스용
      alertMessage: "",
      alertMessagePop: false,
      agreePop: false, // 활용 동의 팝업
      agreeTable: [], // 정보제공 동의 정보,
      service: {},
      serviceList: [],
      selectServiceList: [],
      LegacyCommonCodes: {},
      plccChoiceYn: "N",
      isPLCCPopFlag: false,
      mainContractor: {},
      blueMembersMemberStatusName : "",
      btnDisable: false,
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      popVisibleLoading: false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
    };
  },
  async created() {
    await this.loadCommonCode();
  },
  methods: {
    fetchCommonCodeData(systemType = "", codeType = "") {
      let res = null;
      switch (systemType) {
        case "E":
          res = this.$store.dispatch("loadCommonCodesE", {
            vm: this,
            codeTypeCode: codeType
          });
          break;
        case "C":
          res = this.$store.dispatch("loadLegacyCommonCodesC", {
            vm: this,
            codeTypeCode: codeType
          });
          break;
      }
      return res;
    },
    async loadCommonCode() {
      const [ccT017, ccC913] = await Promise.all([
        this.fetchCommonCodeData("C", "T017"), // 개인정보 활용동의
        this.fetchCommonCodeData("C", "C913")
      ]);
      this.LegacyCommonCodes = { ...ccC913 };
      this.commonCodes = { ...ccT017 };
      this.commonCodes.T017.shift();
      this.LegacyCommonCodes.C913.shift();
    },
    onCheck(value) {
      console.log(value);
    },
    isValidAuthBtn(authId) {
      // 버튼별 권한 체크
      let bResult = false; // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || [];
      if (currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some(items => {
          if (items.btnId === authId) {
            bResult = true;
            return true;
          }
        });
      }
      return bResult;
    },
    agreePopOpen() {
      // 활용 동의 팝업 활성화
      this.$emit("agreePopOpen", this.contractData.contractorInfo[0]);
    },
    btnAbleCheck() {
      //서비스 변경 버튼 체크용

      //출고후 15일 체크용///////////////////////////////////////////////
      let toDate = moment().format('YYYY-MM-DD')
      let flag = false

      if(this.contractInfoData.releaseDate !== null){
        flag = moment(toDate).isAfter(moment(this.contractInfoData.releaseDate).add('14','d').format('YYYY-MM-DD'))
      }
      /////////////////////////////////////////////////////////////////

      if((this.contractData.contractStatusCode === '60' && flag) || this.contractData.contractStatusCode > 60){
        this.btnDisable = true
      }

    },
    async getServiceData() {
      //서류심사 목록
      this.selectServiceList = [];
      const [res, err] = await this.$https.get(
        "/purchase/v2/purchase/contract/agreement-info?contractNumber=" +
          this.contractNumber,
        null,
        null,
        "gateway"
      );
      if (!err) {
        console.log("/purchase/v2/purchase/contract/agreement-info", res.data);
        this.serviceList = res.data;
        const plccChoice = this.serviceList
          .filter(el => el.needPapersNumber === "FRAW0002")
          .map(el => el.choiceYn);
        // 동의정보 미사용으로 주석처리 ->  #12751 블루멤버스 회원정보조회 (EP_IF_블루멤버스(CM)_002) PLCC카드 신청 정보를 가져옴  
        //this.plccChoiceYn = plccChoice.length > 0 ? plccChoice[0] : "N";

        let rowList = [];

           
        
        // 블루맴버스 상태 정보 보강을 위한 주계약자 세팅 
        let mainContractorInfo = [];
        mainContractorInfo = this.contractData.contractorInfo.filter(items => {          
          return items.contractorTypeCode === "01";
        }); // 주계약자 정보

        //블루맴버스 가입 여부 정보 보강 
        //기가입 : blueMembersMemberStatusCode(10), 동의항목 없음 
        //신규가입 : 동의항목 있음 
        //미신청 : blueMembersMemberStatusCode(01, 02), 동의항목 없음
        if(mainContractorInfo[0].blueMembersMemberStatusCode === "10"){
          this.blueMembersMemberStatusName = "기가입";
        }else if(mainContractorInfo[0].blueMembersMemberStatusCode === "01" || mainContractorInfo[0].blueMembersMemberStatusCode === "02"){
          this.blueMembersMemberStatusName = "미신청";
        }else{
          this.blueMembersMemberStatusName = "가입 불가";
        }

        this.serviceList &&
          this.serviceList.map((el, idx) => {
            //주계약자 정보만 가져온다.
            if(el.relationPersonTypeCode  === "01"){
              // 동의정보 미사용으로 주석처리 ->  #12751 블루멤버스 회원정보조회 (EP_IF_블루멤버스(CM)_002) PLCC카드 신청 정보를 가져옴
              /*if (el.needPapersNumber === "FRAW0002") {
                this.plccChoiceYn = el.choiceYn;
              }*/
              // 2022-01-19 판촉차량 구매 동의 추가 AGRW0007
              if (el.needPapersNumber.includes("FRAW") || el.needPapersNumber.includes("AGRW0007")) {              
                if (
                  el.needPapersNumber != "FRAW0001" &&
                  el.needPapersNumber != "FRAW0002"
                ) {                
                  if (rowList.length > 3) {
                    rowList = [];
                  }
                  rowList.push({
                    choiceYn: el.choiceYn || "",
                    needPapersName: el.needPapersName || "",
                    needPapersNumber: el.needPapersNumber || "",
                    papersFormAttributeNumber: el.papersFormAttributeNumber || ""
                  });
                  // ASIS ~ 2021-10-13
                  // if (
                  //   rowList.length %3 === 0 ||
                  //   idx === this.serviceList.length - 1
                  // ) {
                  //   this.selectServiceList.push(rowList);
                  // }
                  //if (
                  //  rowList.length === 3 ||
                  //  idx === this.serviceList.length - 1
                  //) {
                  //  this.selectServiceList.push(rowList);
                  //}                  
                }

                if(el.needPapersNumber === "FRAW0001"){                  
                  this.blueMembersMemberStatusName = "신규가입";
                }
              }
            }
          });
          this.selectServiceList.push(rowList);
          /* ######## W Project #12751 - <2022-04-19> - <A934118> - START ######## */
          // 동의정보 미사용으로 주석처리 ->  #12751 블루멤버스 회원정보조회 (EP_IF_블루멤버스(CM)_002) PLCC카드 신청 정보를 가져옴
          this.plccChoiceYn = mainContractorInfo[0].axPlccHldgYn
          /* ######## W Project #12751 - <2022-04-19> - <A934118> - END ######## */

      } else {
        console.error(err);
      }

      //버튼 체크용
      this.btnAbleCheck()
    },
    async saveChangeService() {
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      let saveForm = {
        contractNumber: this.contractNumber,
        guarantyRepairTypeCode: this.contractData.guarantyRepairTypCode
      };
      let rowList = [];
      this.selectServiceList.map(el => {
        el.map(item => {
          rowList.push(item);
        });
      });

      let needPapersForm = {};
      let contractPapersInfoList = [];
      let contractPapersAttrList = [];

      this.serviceList &&
        this.serviceList.map((el, idx) => {
          ////리스트 한칸씩 밀림 여기부터 수정 필요
          if (!needPapersForm.needPapersNumber) {
            needPapersForm = {
              needPapersNumber: el.needPapersNumber
            };
          } else if (needPapersForm.needPapersNumber != el.needPapersNumber) {
            needPapersForm.contractPapersAttrList = contractPapersAttrList;
            contractPapersInfoList.push(needPapersForm);
            contractPapersAttrList = [];
            needPapersForm = {
              needPapersNumber: el.needPapersNumber
            };
          }

          const selectedService = rowList
            .filter(
              chiceItem =>
                chiceItem.papersFormAttributeNumber ===
                el.papersFormAttributeNumber
            )
            .map(chiceItem => chiceItem.choiceYn);

          let contractPapersAttr = {
            papersFormAttributeNumber: el.papersFormAttributeNumber,
            formAttributeTypeSerialNumber: el.formAttributeTypeSerialNumber,
            requestPapersTypeInputContents: el.requestPapersTypeInputContents,
            choiceYn:
              selectedService.length > 0 ? selectedService[0] : el.choiceYn
          };
          contractPapersAttrList.push(contractPapersAttr);

          if (idx === this.serviceList.length - 1) {
            needPapersForm.contractPapersAttrList = contractPapersAttrList;
            contractPapersInfoList.push(needPapersForm);
            contractPapersAttrList = [];
            needPapersForm = {
              needPapersNumber: el.needPapersNumber
            };
          }
        });
      console.log("contractPapersInfoList>>>>>>>", contractPapersInfoList);
      saveForm.contractPapersInfoList = contractPapersInfoList;
      console.log("saveForm>>>>>>>", saveForm);

      const [res, err] = await this.$https.post(
        "/purchase/v2/purchase/contract/serviceInfoAdd",
        saveForm,
        null,
        "gateway"
      );
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
        this.popVisibleLoading = false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      if (!err) {
        console.log("/purchase/v2/purchase/contract/serviceInfoAdd", res.data);
        if (res.rspStatus && res.rspStatus.rspCode === "0000") {
          this.alertMessage = "변경되었습니다.";
          this.alertMessagePop = true;
          this.$emit("refresh");
        }
      } else {
        console.error(err);
      }
    },
    PLCCUrlSend(flag){
      this.isPLCCPopFlag = flag;
    },
    async SendPLCCUrl(){
      
      //TODO - 나중에 걸어달라 할 거 같음
      // if(this.contractData.blueMembersPetitionYn !== "Y" && this.plccChoiceYn !== "Y"){
      //     this.alertMessage = "PLCC 카드 신청 대상이 아닙니다.";
      //     this.alertMessagePop = true;          
      //     this.isPLCCPopFlag = false;
      //     return;
      // }
      
      if(this.contractInfoData.payEndDate === null || this.contractInfoData.payEndDate ==='' ){
          
          this.alertMessage = "계약완료 상태가 아닙니다.";
          this.alertMessagePop = true;          
          this.isPLCCPopFlag = false;
          return;
      }

      // API-WE-결제서비스-030 (현대카드 세이브오토/특정한도/PLCC카드신청 URL발송 요청)      
      this.mainContractor = this.contractData.contractorInfo.filter(items => {
        return items.contractorTypeCode === "01";
      }); // 주계약자 정보

      
      const param = {
        contractNumber: this.contractNumber,  
        customerManagementNumber : this.mainContractor[0].customerManagementNumber, 
        userTel :  this.mainContractor[0].customerMobile.replace(/-/gi, "") ,   // 주계약자 핸드폰번호
        selectType : '3'  //PLCC카드 
      };

      console.log('param >>' + JSON.stringify(param));
      
      this.popVisibleLoading = true

      const [res, err] = await this.$https.post(
        "payment/v2/payment/card/m-limit/url",
        param,
        null,
        "gateway"
      );

      this.popVisibleLoading = false

      if (!err) {
        if (res.rspStatus.rspCode === "0000") {
          this.alertMessage = "현대카드 신청 URL이 발송되었습니다.";
          this.alertMessagePop = true;          
          this.isPLCCPopFlag = false;
        }
      } else {
        console.error(err);
      }

      
    },
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
    oneClickDisable(event, clickEvent, ...args) {
      if(event.target.disabled === true){
        retrun
      }

      event.target.disabled = true

      try {
        clickEvent(...args)
      } catch {}
      setTimeout(() => {
        event.target.disabled = false
      }, 2000)
    }
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */    
  }
};
</script>
<style lang="scss" scoped>
@import "~/assets/style/pages/detail.scss";
</style>
