<template>
  <div>
    <div class="article-title">
      <h2>심사 대상 서류목록</h2>
      <!-- <el-button
        type="primary"
        class="btn-md"
        icon="el-icon-plus"
        :disabled="!workAssignNumber"
        @click="addDocumentPopOpen"
      /> -->
      <!-- <el-button
        type="primary"
        class="btn-md"
        icon="el-icon-plus"
        v-if="
          isValidAuthBtn('authDocument') &&
            (activeUserFlag ||
              userInfoData.eeno === contractInfoData.consultantId)
        "
        :disabled="!workAssignNumber"
        @click="addDocumentPopOpen"
      /> -->
    </div>

    <h-table
      :table-type="'DefultTable'"
      :table-header="paperReviewHeader"
      :table-datas="paperReviewData"
    />
  </div>
</template>
<script>
import HTable from '~/components/common/HTable.vue'
export default {
  name: 'PaperReviewInfo',
  components: {
    HTable
  },
  props: {
    workAssignNumber: {
      type: String,
      default: ''
    },
    userInfoData: {
      // 로그인 사용자 정보
      type: Object,
      default: () => {}
    },
    addDocumentData: {
      // 소속 정보 선택에 따른 기본+추가 서류 목록 추가 데이터
      type: Object,
      default: () => {}
    },
    activeUserFlag: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      isAuth: process.env.VUE_APP_AUTH === 'true', // 권한 패스용
      paperReviewData: [],
      paperReviewHeader: [
        {
          label: 'NO.',
          prop: 'no',
          align: 'center',
          width: '80px'
        },
        {
          label: '구분',
          prop: 'papersSectionalName',
          align: 'center',
          width: '300px'
        },
        {
          label: '소분류',
          prop: 'papersTypeName',
          align: 'center',
          width: '200'
        },
        {
          label: '스크래핑 여부',
          prop: 'scrapingTargetYn',
          align: 'center',
          width: '100px'
        },

        {
          label: '스크래핑 결과',
          prop: 'scrapingResult',
          align: 'center',
          width: '100px'
        },
        {
          label: '추가서류여부',
          prop: 'additionPapersYn',
          align: 'center',
          width: '100px'
        },
        {
          label: '서류요청일시',
          prop: 'papersRequestDate',
          align: 'center'
        },
        {
          label: '상태변경일시',
          prop: 'papersExaminationDate',
          align: 'center'
        },
        {
          label: '상태',
          prop: 'papersExaminationState',
          align: 'center',
          width: '100px'
        }
      ]
    };
  },
  async created() {
    this.getPaperReviewData()
  },
  methods: {
    async getPaperReviewData() {
      //서류심사 목록
      const [res, err] = await this.$https.get(
        '/v2/exclusive/employeeAuth/document/papers/' + this.workAssignNumber
      )
      
      if (!err) {
        console.log('/employeeAuth/document/papers/', res.data)
        this.paperReviewData = res.data.map((el, idx) => {
          el.papersNameList =
            (el.papersNameList && el.papersNameList.join(', ')) || ''
          el.no = idx + 1
          //el.isAdd = false
          return el
        })
      } else {
        console.error(err)
      }
    },
    setPaperReviewData() {
      // 저장 시 현재 설정된 review data를 넘겨준다 (추가된 것)
      let addPaperReviewData = this.paperReviewData.filter((items) => {
        return items.isAdd === true
      })    

      this.$emit('setPaperReviewData', addPaperReviewData)
      // this.$emit('setPaperReviewData', this.paperReviewData)
    },
    async addReviewPaperRow(paperData){

      // 기존의 소속 선택으로 추가된 데이터 reset
      this.paperReviewData = this.paperReviewData.filter((items) => {
        return items.isAdd === undefined || !items.isAdd
      })

      // 이미 있는 Document는 x, 없는 것만 추가
      paperData.filter((el) => {
        this.paperReviewData.map((doc) => {
          if(el.neceDocNo === doc.neceDocNo && el.neceDocTargNo === doc.neceDocTargNo) {
            el.dupleKey = true
          }
        })
      })
      
      if(paperData && paperData.length > 0) {
        paperData.map((items) => {
          if(!items.dupleKey) {
            this.paperReviewData.push({
              ...items,
              no: this.paperReviewData.length + 1
            // 서류요청일시/상태변경일시/상태는 넣을때 setting
            })
            //             this.paperReviewData.push({
            //   no: this.paperReviewData.length + 1,
            //   neceDocNo: items.neceDocNo,
            //   neceDocTargNo: items.neceDocTargNo,
            //   papersSectionalName: items.neceDocTargNm,
            //   papersTypeName: items.neceDocNm,
            //   scrapingTargetYn: items.scrapingTargetYn,
            //   scrapingResult: items.scrapingResult,
            //   additionPapersYn: items.attcScnCd === 10 ? 'N' : 'Y'
            //   // 서류요청일시/상태변경일시는 넣을때 setting
            // })
          }
        })
      }
    },
    isValidAuthBtn(authId) {
      // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if (currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some(items => {
          if (items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    }
    // addDocumentPopOpen() {
    //   this.$EventBus.$emit('addDocumentPopOpen')
    // }
  }
}
</script>
<style lang="scss" scoped>
.btn-md {
  min-width: 40px;
  height: 40px;
}
@import "~/assets/style/pages/detail.scss";
</style>
