<template>
  <div>
    <h-title :title="'계약금 결제'" />
    <el-form ref="payment" :model="contractData" class="detail-form">
      <el-row>
        <el-col :span="8">
          <el-form-item label="계약금">
            {{
              contractData.contractPrice && contractData.contractPrice > 0
                ? contractData.contractPrice.toLocaleString() + "원"
                : "비대상"
            }}

            <!-- {{
              contractData.contractPrice &&
                contractData.contractPrice.toLocaleString() + "원"
            }} --></el-form-item
          >
        </el-col>
        <el-col :span="8">
          <el-form-item
            label="결제수단"
          >
            <template v-if="contractData.contractPricePaymentTypeName ">
              {{
                contractData.contractPricePaymentTypeName
                  ? contractData.contractPricePaymentTypeName
                  : ""
              }}
              {{
                contractData.cardCompanyName
                  ? "(" + contractData.cardCompanyName + ")"
                  : ""
              }}
              {{
                contractData.receiptsBankName
                  ? "(" + contractData.receiptsBankName
                  : ""
              }}
              {{
                contractData.virtualAccount
                  ? " " + contractData.virtualAccount + ")"
                  : ""
              }}
            </template>
            <template v-else>없음</template>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item
            label="처리상태"
            v-if="
              contractData.refundYn === 'N' &&
                contractData.contractPricePaymentDate
            "
          >
            납부
          </el-form-item>
          <el-form-item
            label="처리상태"
            v-if="
              contractData.refundYn === 'N' &&
                !contractData.contractPricePaymentDate
                &&!contractData.contractCancellationDate
            "
          >
            대기
          </el-form-item>
          <el-form-item
            label="처리상태"
            v-if="
              contractData.refundYn === 'N' &&
                contractData.contractPricePaymentTypeName==='현금'
                &&!contractData.contractPricePaymentDate
                &&(contractData.contractCancellationDate||contractInfoData.legacyStatusCode==='90')
                &&contractData.contractPricePaymentStatusCode==='21'
            "
          >
            취소
          </el-form-item>
          <el-form-item label="처리상태" v-if="contractData.refundYn !== 'N'">
            환불
          </el-form-item>
        </el-col>
        <!-- <el-col :span="8">
          <el-form-item label="계약금 납입">{{
            contractData.contractPricePaymentDate
          }}</el-form-item>
        </el-col> -->
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="납부기한">{{
            contractData.contractPricePaymentTimeLimitDate||"없음"
          }}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item
            label="납부일시"
            v-if="
              contractData.refundYn === 'N' &&
                contractData.contractPricePaymentDate
            "
          >
            {{ contractData.contractPricePaymentDate }}
          </el-form-item>
          <el-form-item label="납부일시" v-else>
            없음
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item
            label="환불일시"
            v-if="
              contractData.refundYn !== 'N' &&
                contractData.contractPricePaymentDate
            "
          >
            {{ contractData.contractPricePaymentDate }}
          </el-form-item>
          <el-form-item label="환불일시" v-else>
            없음
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>
<script>
import HTableList from "~/components/common/HTableList.vue";
import HTable from "~/components/common/HTable.vue";
import HTitle from "~/components/common/HTitle.vue";

export default {
  name: "PaymentInfo",
  components: {
    HTableList,
    HTable,
    HTitle
  },
  props: {
    contractNumber: {
      type: String,
      default: ""
    },
    contractData: {
      type: Object,
      default: () => {}
    },
    contractInfoData: {
      type: Object,
      default: () => {}
    },
    userInfoData: {
      // 로그인 사용자 정보
      type: Object,
      default: () => {}
    },
    activeUserFlag: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      isAuth: process.env.VUE_APP_AUTH === "true", // 권한 패스용
      alertMessage: "",
      alertMessagePop: false,
      agreePop: false, // 활용 동의 팝업
      agreeTable: [], // 정보제공 동의 정보
      statusDateData: {}
    };
  },
  async created() {},
  methods: {
    onCheck(value) {
      console.log(value);
    },
    isValidAuthBtn(authId) {
      // 버튼별 권한 체크
      let bResult = false; // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || [];
      if (currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some(items => {
          if (items.btnId === authId) {
            bResult = true;
            return true;
          }
        });
      }
      return bResult;
    }
  }
};
</script>
