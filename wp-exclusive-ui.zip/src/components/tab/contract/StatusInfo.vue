<template>
  <div>
    <h-title :title="'상태별 일자'" />
    <el-form ref="date" :model="statusDateData" class="detail-form">
      <el-row>
        <el-col :span="8">
          <el-form-item label="계약서 작성 시작일">{{
            statusDateData.contractDocumentFramingStartDate
              ? statusDateData.contractDocumentFramingStartDate
              : "없음"
          }}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="계약서 변경일">{{
            statusDateData.contractDocumentAlterationDate
              ? statusDateData.contractDocumentAlterationDate
              : "없음"
          }}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="매출취소일">{{
            statusDateData.salesCancellationDate
              ? statusDateData.salesCancellationDate
              : "없음"
          }}</el-form-item>
        </el-col>
        <!-- <el-col :span="12">
          <el-form-item label="계약 완료일">{{
            statusDateData.contractCompleteDate
          }}</el-form-item>
        </el-col> -->
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="계약서 작성 취소일">{{
            statusDateData.contractDocumentFramingCancellationDate
              ? statusDateData.contractDocumentFramingCancellationDate
              : "없음"
          }}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="계약 취소일">{{
            statusDateData.contractCancellationDate
              ? statusDateData.contractCancellationDate
              : "없음"
          }}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="계약서 취소 사유">
            <el-tooltip placement="bottom" effect="light">
              <div slot="content">
                 {{
                  statusDateData.contractDocumentCancellationReasonDetail
                }}
              </div>
              <el-button type="text">
                {{ statusDateData.contractDocumentCancellationReason || "없음" }}
               
               <!--  {{
                  !statusDateData.contractDocumentCancellationReason
                    ? "없음"
                    : ""
                }} -->
              </el-button>
            </el-tooltip>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="배정 요청일">{{
            statusDateData.carAssignmentRequestDate
              ? statusDateData.carAssignmentRequestDate
              : "없음"
          }}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="배정일">{{
            statusDateData.carAssignmentDate
              ? statusDateData.carAssignmentDate
              : "없음"
          }}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="출고 예정일">{{
            statusDateData.carWarehouseOutPrearrangementDate
              ? statusDateData.carWarehouseOutPrearrangementDate
              : "없음"
          }}</el-form-item>
        </el-col>
        <!-- <el-col :span="6">
          <el-form-item label="출고일">{{
            statusDateData.carWarehouseOutDate
          }}</el-form-item>
        </el-col> -->
      </el-row>
      <!-- <el-row>
        <el-col :span="6">
          <el-form-item label="제작증 발급일">{{
            statusDateData.makeDocumentIssueDate
          }}</el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="등록 기한일">{{
            statusDateData.carRegistrationTimeLimitDate
          }}</el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="매출 취소일">{{
            statusDateData.salesCancellationDate
          }}</el-form-item>
        </el-col>
      </el-row> -->
    </el-form>
  </div>
</template>
<script>
import HTableList from "~/components/common/HTableList.vue";
import HTable from "~/components/common/HTable.vue";
import HTitle from "~/components/common/HTitle.vue";

export default {
  name: "StatusInfo",
  components: {
    HTableList,
    HTable,
    HTitle
  },
  props: {
    contractNumber: {
      type: String,
      default: ""
    },
    contractData: {
      type: Object,
      default: () => {}
    },
    userInfoData: {
      // 로그인 사용자 정보
      type: Object,
      default: () => {}
    },
  },
  data() {
    return {
      isAuth: process.env.VUE_APP_AUTH === "true", // 권한 패스용
      statusDateData: {}
    };
  },
  async created() {},
  methods: {
    onCheck(value) {
      console.log(value);
    },
    isValidAuthBtn(authId) {
      // 버튼별 권한 체크
      let bResult = false; // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || [];
      if (currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some(items => {
          if (items.btnId === authId) {
            bResult = true;
            return true;
          }
        });
      }
      return bResult;
    },
    async getStatusData() {
      //상태별 일자
      // if(Object.keys(this.statusDateData).length===0) {
        this.statusDateData = {}
      const [res3, err3] = await this.$https.get(
        "/v2/exclusive/work/state-day/" + this.contractNumber
      );
      if (!err3) {
        console.log("/work/state-day/", res3.data);
        if (res3 && res3.data) {
          this.statusDateData = res3.data;
        }
      } else {
        console.error(err3);
      }
    }
  }
};
</script>
