<template>
  <div>
    <div class="article-title">
      <h2>
        계약자 정보
        <span class="contractor"
          >(ID: {{ contractInfoData.loginId }}
          {{
            contractData.employeeName ? ", " + contractData.employeeName : ""
          }}
          {{
            contractData.employeeNumber
              ? ", " + contractData.employeeNumber
              : ""
          }}
          , NO: {{ contractInfoData.loginCustomerNumber }}
          <!-- , 길인수, H202020 -->)</span
        >
      </h2>
      <!-- <div
        class="right"
        v-if="isValidAuthBtn('authExclusive') &&(
          ((contractInfoData.legacyStatusCode === '10' ||
            contractInfoData.legacyStatusCode === '20' ||
            contractInfoData.legacyStatusCode === '30' ||
            contractInfoData.legacyStatusCode === '40' ||
            contractInfoData.legacyStatusCode === '50') &&
            (contractInfoData.contractPersonalCorporationCode === '2' &&
              checkCorpNum)) ||
            contractInfoData.contractPersonalCorporationCode === '1' ||
            (privateBusiness && checkCorpNum))
        "
      > -->
      <div class="right">
        <el-button type="primary"
        v-if="
            isValidAuthBtn('authExclusive')
          "
          :disabled="!activeUserFlag"
          @click="oneClickDisable($event, checkCustomerTypeCode)"         
          >변경</el-button
        >
      </div>
    </div>
    <!-- <div
      class="box"
      v-if="contractData.contractorInfo && data"
     > -->
    <div
      class="box"
      v-for="(data, index) in contractData.contractorInfo"
      :key="index"
      v-if="data.contractorTypeCode !== '03'"
    >
      <el-form
        ref="ruleForm"
        class="detail-form table-wrap"
        :model="ruleForm[index]"
      >
        <!-- ###### [W Project/##12163/2022.04.10/A934118] START ###### -->
        <el-row v-if="contractInfoData.customerTypeCode === 'CA1' 
        || contractInfoData.customerTypeCode === 'CL1' 
        || contractInfoData.customerTypeCode === 'CL2' 
        || contractInfoData.customerTypeCode === 'CR1'">
          <el-col :span="24">
            <el-form-item label="고객구분">
              <el-select
                v-model="contractInfoData.customerTypeCode"
                filterable
                placeholder="고객구분을 선택해 주세요"
                @change="onChangeCustomerTypeCode"
                :disabled ="
                      contractInfoData.legacyStatusCode === '60' ||
                      contractInfoData.legacyStatusCode === '70' ||
                      contractInfoData.legacyStatusCode === '71' ||
                      contractInfoData.legacyStatusCode === '90' ||
                      contractInfoData.legacyStatusCode === '91'"            
              >
                <el-option
                  value="CA1"
                  label="법인사업자"
                />
                <el-option
                  value="CR1"
                  label="렌터카"
                />
                <el-option
                  value="CL1"
                  label="리스(캐피탈)"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>        
        <!-- ###### [W Project/##12163/2022.04.10/A934118] END ###### -->      
        <el-row>
          <el-col :span="8">
            <el-form-item label="구분">
              <span
                >{{
                  data.contractorTypeCode === "01"
                    ? "주계약자"
                    : "공동명의자 (관계:"+data.contractorRelationName+")"
                }}
              </span>
              <el-button
                v-if="
                  isValidAuthBtn('authExclusive')
                "
                type="info"
                class="btn-small space"
                :disabled=" !activeUserFlag  "
                @click="$emit('agreePopOpen', data)"
                >정보활용동의</el-button
              >
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item
              :label="
                contractInfoData.contractPersonalCorporationCode !== '3'
                  ? '고객관리번호'
                  : '법인번호'
              "
              >
              {{
                contractInfoData.contractPersonalCorporationCode === "1"
                  ? data.customerManagementNumber
                  : ""
              }}
              {{
                contractInfoData.contractPersonalCorporationCode === "2"
                  ? data.firstCustomerManagemontNumber
                  : ""
              }}

              <el-input
                v-if="contractInfoData.contractPersonalCorporationCode === '3'"
                v-model="ruleForm[index].corporateRegistNo"
                :disabled="true"
                style="width:70%"
              />


              <el-checkbox
                v-if="contractInfoData.contractPersonalCorporationCode === '3'"
                v-model="isNonProfitCorporation"
                :disabled="true"
                class="private"
                :label="true"
                @change="checkIsNonProfitCorporation"
                >비영리법인</el-checkbox
              >
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item
              :label="
                contractInfoData.contractPersonalCorporationCode !== '3'
                  ? '이름'
                  : '상호'
              "
            >
              <span v-if="contractInfoData.contractPersonalCorporationCode !== '3'">
                {{ data.customerName }}
              </span>
              <span v-else>
                <el-input 
                  v-model="data.businessName"
                  :disabled ="
                    contractInfoData.legacyStatusCode === '60' ||
                    contractInfoData.legacyStatusCode === '70' ||
                    contractInfoData.legacyStatusCode === '71' ||
                    contractInfoData.legacyStatusCode === '90' ||
                    contractInfoData.legacyStatusCode === '91'"
                />
              </span>
              <el-checkbox
                v-if="
                  data.contractorTypeCode === '01' &&
                    (contractInfoData.customerTypeCode === 'AA1' ||
                      contractInfoData.customerTypeCode === 'AL1' ||
                      contractInfoData.customerTypeCode === 'BA1')
                "
                v-model="privateBusiness"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
                class="private"
                :label="true"
                @change="checkPrivateBusiness"
                >개인사업자</el-checkbox
              >

              <el-checkbox
                v-if="data.personalCorporationCode!=='3'&&
                  (data.contractorTypeCode === '01' &&
                    contractInfoData.customerTypeCode !== 'AA1' &&
                    contractInfoData.customerTypeCode !== 'AL1' &&
                    contractInfoData.customerTypeCode !== 'BA1' &&
                    contractInfoData.customerTypeCode !== 'CL1' &&
                    contractInfoData.customerTypeCode !== 'CA1' &&
                    contractInfoData.customerTypeCode !== 'CL2') ||
                    data.relationPersonRelationCode === '05'
                "
                v-model="isEmployee"
                :disabled="
                  (contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50') ||
                    data.relationPersonRelationCode === '05'
                "
                :label="true"
                class="private"
                @change="checkIsEmployee"
                >직원할인</el-checkbox
              >
            </el-form-item>
          </el-col>
        </el-row>

        <el-row v-if="contractInfoData.contractPersonalCorporationCode === '3'">
          <el-col :span="8">
            <el-form-item label="업태/종목">
              <el-select
                v-model="ruleForm[index].businessConditionCode"
                filterable
                placeholder="업태를 검색해주세요."
                @change="onChangeBusinessConditionCode($event, ruleForm[index])"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              >
                <!-- commonCodes.T010 -->
                <el-option
                  v-for="{ value, label } in commonCodes.A005 &&
                    commonCodes.A005.slice(1)"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
              <el-input 
                style="width:40%"
                v-model="data.itemName"
                :disabled ="
                  contractInfoData.legacyStatusCode === '60' ||
                  contractInfoData.legacyStatusCode === '70' ||
                  contractInfoData.legacyStatusCode === '71' ||
                  contractInfoData.legacyStatusCode === '90' ||
                  contractInfoData.legacyStatusCode === '91'"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="사업자번호">
              {{ ruleForm[index].businessNumber }}
              <el-button
                type="info"
                class="btn-small"
                @click="checkCorporationNumber(ruleForm[index].businessNumber)"
                >휴폐업조회</el-button
              >
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="대표자명">
              <el-input 
                v-model="data.representativeName"
                :disabled ="
                  contractInfoData.legacyStatusCode === '60' ||
                  contractInfoData.legacyStatusCode === '70' ||
                  contractInfoData.legacyStatusCode === '71' ||
                  contractInfoData.legacyStatusCode === '90' ||
                  contractInfoData.legacyStatusCode === '91'"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <!--  -->
        <el-row v-if="contractInfoData.contractPersonalCorporationCode === '3'">
          <el-col :span="8">
            <el-form-item label="렌트 기간">
              <el-radio
                v-model="ruleForm[index].rentCarPeriodType"
                label="2"
                :disabled="contractInfoData.customerTypeCode !== 'CR1'"
                @change="checkRentPeriod"
                >장기(12개월 이상)</el-radio
              >
              <el-radio
                v-model="ruleForm[index].rentCarPeriodType"
                label="1"
                :disabled="contractInfoData.customerTypeCode !== 'CR1'"
                @change="checkRentPeriod"
                >단기(12개월 미만)</el-radio
              >
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="고객관리번호">
              {{ data.customerManagementNumber }}
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="이름(구매담당)">
              {{ data.customerName }}
            </el-form-item>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="8">
            <el-form-item label="생년월일"
              >{{ data.customerBirthday }}
              {{
                data.customerSex ? "- " + data.customerSex : ""
              }}</el-form-item
            >
          </el-col>
          <el-col :span="8">
            <el-form-item label="휴대전화">
              <el-input
                v-model="ruleForm[index].customerMobile"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              />
              <!-- <el-input
                v-model="data.customerMobile"
                :disabled="item.customerSendYn === 'Y'"
                @blur="ruleFormpopup.title = $event.target.value"
              /> -->
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="이메일">
              <el-input
                v-model="ruleForm[index].customerEamilNoMasking"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="주소">
              <el-input
                v-model="ruleForm[index].zipCode"
                class="short"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
                :readonly="true"
              />
              <el-button
                v-if="
                  contractInfoData.legacyStatusCode === '10' ||
                    contractInfoData.legacyStatusCode === '20' ||
                    contractInfoData.legacyStatusCode === '30' ||
                    contractInfoData.legacyStatusCode === '40' ||
                    contractInfoData.legacyStatusCode === '50'
                "
                type="primary"
                class="btn-small"
                @click="searchAddressPopOpen(index)"
                >주소검색</el-button
              >
              <el-input
                v-model="ruleForm[index].addressContents"
                class="inp-addr"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
                :readonly="true"
              />
              <!-- [#10015/2021.11.19/A936506] strCheck 메소드 추가
              주소 입력시 특수문자(@, #, %. $, ~, /)를 key in 하는 경우 화면에서 alert 노출 -->
              <el-input
                v-model="ruleForm[index].detailAddressContents"
                class="inp-addr"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
                maxlength="100"
                :keyup="strCheck(index)"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row v-if="privateBusiness && data.contractorTypeCode === '01'">
          <el-col :span="8">
            <el-form-item label="사업자번호">
              <el-input
                v-model="ruleForm[index].businessNumber"
                class="short"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              />
              <el-button
                type="info"
                class="btn-small"
                @click="checkCorporationNumber(ruleForm[index].businessNumber)"
                >휴폐업조회</el-button
              >
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="상호">
              <el-input
                v-model="data.businessName"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="대표자명">
              <el-input
                v-model="data.representativeName"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row v-if="privateBusiness && data.contractorTypeCode === '01'">
          <el-col :span="8">
            <el-form-item label="업태">
              <!-- <el-input
                v-model="data.businessConditionName"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              /> -->
              <el-select
                v-model="ruleForm[index].businessConditionCode"
                filterable
                placeholder="업태를 검색해주세요."
                @change="onChangeBusinessConditionCode($event, ruleForm[index])"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              >
                <!-- commonCodes.T010 -->
                <el-option
                  v-for="{ value, label } in commonCodes.A005 &&
                    commonCodes.A005.slice(1)"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="16">
            <el-form-item label="종목">
              <el-input
                v-model="data.itemName"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              />
            </el-form-item>
          </el-col>
          <!-- <el-col :span="8">
            <el-form-item label="구매담당 연락처">
              <el-input
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              />
            </el-form-item>
          </el-col> -->
        </el-row>
      </el-form>
    </div>
    <!--  <div class="box" v-if="contractData.contractorInfo && contractData.contractorInfo[1]">
      <el-form class="detail-form table-wrap">
        <el-row>
          <el-col :span="8">
            <el-form-item label="구분">
              <span>공동명의자 (관계:가족)</span>
              <el-button type="info" class="btn-small space"
                >정보활용동의</el-button
              >
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="고객관리번호">A3720TM001530</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="이름">지성민</el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="생년월일">1980-02-13 남자</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="휴대전화">
              <el-input />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="이메일">
              <el-input />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="주소">
              <el-input class="short" />
              <el-button type="primary" class="btn-small">주소검색</el-button>
              <el-input class="inp-addr" />
              <el-input class="inp-addr" />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div> -->
    <!-- -->
    <div
      v-if="
        data.contractorTypeCode === '03' &&
          ((contractInfoData.contractPersonalCorporationCode === '3' &&
            (contractInfoData.customerTypeCode === 'CL1' ||
              contractInfoData.customerTypeCode === 'CR1')) ||
            contractInfoData.customerTypeCode === 'CL2' ||
            contractInfoData.contractPersonalCorporationCode === '2')
      "
      class="box"
      v-for="(data, index) in contractData.contractorInfo"
      :key="index"
    >
      <el-form class="detail-form table-wrap" :model="ruleForm[index]">
        <el-row>
          <el-col :span="8">
            <el-form-item label="구분">실차주정보</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="고객구분">
              <span>
                <el-radio
                  label="1"
                  v-model="ruleForm[index].personalCorporationCode"
                  :disabled="
                    contractInfoData.contractPersonalCorporationCode === '2'
                  "
                  @change="checkBusinessCorporationCode"
                  >개인</el-radio
                >
                <!-- <el-radio
                  label="2"
                  v-model="data.personalCorporationCode"
                  :disabled="
                    contractInfoData.contractPersonalCorporationCode === '2'
                  "
                  >개인사업자</el-radio
                > -->
                <el-radio
                  label="3"
                  v-model="ruleForm[index].personalCorporationCode"
                  :checked="
                    contractInfoData.contractPersonalCorporationCode === '2'
                  "
                  :disabled="
                    contractInfoData.legacyStatusCode !== '10' &&
                      contractInfoData.legacyStatusCode !== '20' &&
                      contractInfoData.legacyStatusCode !== '30' &&
                      contractInfoData.legacyStatusCode !== '40' &&
                      contractInfoData.legacyStatusCode !== '50' &&
                      contractInfoData.contractPersonalCorporationCode === '2'
                  "
                  @change="checkBusinessCorporationCode"
                  >법인</el-radio
                >
              </span>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="이용개월수">
              <el-input
                v-model="contractData.rentcarMonth"
                style="width:50%"
              />개월
            </el-form-item>
          </el-col>
        </el-row>
        <el-row v-if="ruleForm[index].personalCorporationCode === '3'">
          <el-col :span="8">
            <el-form-item label="상호/대표자명">
              <el-input
                v-model="ruleForm[index].businessName"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
                style="width:40%"
              />
              <el-input
                v-model="ruleForm[index].representativeName"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
                style="width:40%"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="사업자번호">
              <el-input v-model="data.businessNumber" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="법인번호">
              <el-input
                v-model="data.corporateRegistNo"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row v-if="ruleForm[index].personalCorporationCode === '1'">
          <el-col :span="8">
            <el-form-item label="이름">
              <el-input
                v-model="ruleForm[index].customerName"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="주민등록번호">
              <el-input
                v-model="ruleForm[index].customerBirthday"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
                style="width:30%"
              />-
              <el-input
                v-model="ruleForm[index].customerSex"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
                style="width:20%"
              />******
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="휴대전화">
              <el-input
                v-model="ruleForm[index].customerMobile"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="주소">
              <el-input
                class="short"
                v-model="ruleForm[index].zipCode"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              />
              <el-button
                type="primary"
                class="btn-small"
                v-if="
                  contractInfoData.legacyStatusCode === '10' ||
                    contractInfoData.legacyStatusCode === '20' ||
                    contractInfoData.legacyStatusCode === '30' ||
                    contractInfoData.legacyStatusCode === '40' ||
                    contractInfoData.legacyStatusCode === '50'
                "
                @click="searchAddressPopOpen(index)"
                >주소검색</el-button
              >
              <el-input
                class="inp-addr"
                v-model="ruleForm[index].addressContents"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              />
              <el-input
                class="inp-addr"
                v-model="ruleForm[index].detailAddressContents"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              />
            </el-form-item>
          </el-col>
        </el-row>

        <el-row v-if="ruleForm[index].personalCorporationCode === '3'">
          <el-col :span="8">
            <el-form-item label="업태">
              <el-select
                v-model="ruleForm[index].businessConditionCode"
                filterable
                placeholder="업태를 검색해주세요."
                @change="onChangeBusinessConditionCode($event, ruleForm[index])"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              >
                <!-- commonCodes.T010 -->
                <el-option
                  v-for="{ value, label } in commonCodes.A005 &&
                    commonCodes.A005.slice(1)"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
              <!-- <el-input
                v-model="ruleForm[index].businessConditionName"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              /> -->
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="종목">
              <el-input
                v-model="ruleForm[index].itemName"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="구매담당 연락처">
              <el-input
                v-model="ruleForm[index].customerMobile"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              />
            </el-form-item>
          </el-col>
        </el-row>

        <!-- <el-row v-if="data.personalCorporationCode !== '1'">
          <el-col :span="8">
            <el-form-item label="업태">
              <el-input
                v-model="data.businessConditionName"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              />
            </el-form-item>
          </el-col>
          <el-col :span="data.personalCorporationCode === '3' ? 8 : 16">
            <el-form-item label="종목">
              <el-input
                v-model="data.itemName"
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              />
            </el-form-item>
          </el-col>
          <el-col :span="8" v-if="data.personalCorporationCode === '3'">
            <el-form-item label="구매담당 연락처">
              <el-input
                :disabled="
                  contractInfoData.legacyStatusCode !== '10' &&
                    contractInfoData.legacyStatusCode !== '20' &&
                    contractInfoData.legacyStatusCode !== '30' &&
                    contractInfoData.legacyStatusCode !== '40' &&
                    contractInfoData.legacyStatusCode !== '50'
                "
              />
            </el-form-item>
          </el-col>
        </el-row> -->
      </el-form>
    </div>

    <div
      class="box"
    >
      <el-form v-if="alarmTalkList.length" class="detail-form table-wrap" :model="ruleForm[index]">
        <el-row>
          <el-col>
            <el-form-item label="알림톡 수신">
              <div>
                <el-radio-group v-model="alarmTalkCheck">
                  <el-radio
                    v-for="(item, index) in alarmTalkList"
                    :key="index"
                    :label="item.value"
                  >
                    <span>{{ item.label }}</span>
                  </el-radio>
                </el-radio-group>
              </div>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />

    <el-dialog
      custom-class="message"
      :visible.sync="popVisible"
      width="30%"
      :center="true"
    >
      <span
        >고객구분을 개인일반으로 변경하시면 직원할인이 취소됩니다. 계속 진행
        하시겠습니까?</span
      >
      <span slot="footer" class="dialog-footer">
        <el-button type="info" @click="popVisible = false">
          취소
        </el-button>
        <el-button
          type="primary"
          @click="
            popVisible = false; 
            onSaveContractorsInfo();
          "
        >
          확인
        </el-button>
      </span>
    </el-dialog>
    <!-- ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## -->    
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />
    <!-- ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## -->    
  </div>

  <!--
  <div>
    <h-table-list
      :list-table-type="'TwoThListTable'"
      :th-table="'Thtable01'"
      :table-info="
        contractData.contractorInfo && data
      "
      :title="'계약자 정보(ID : )'"
      :article-title="'use3'"
    >
      <template slot="btn">
        <el-button
          type="info"
          class="btn-agree"
          @click="agreePopOpen(data)"
          >활용 동의</el-button
        >
      </template>
    </h-table-list>

    <h-table-list
      :list-table-type="'TwoThListTable'"
      :th-table="'Thtable02'"
      :table-info="
        contractData.contractorInfo && contractData.contractorInfo[1]
      "
      class="margin-top-none"
    >
      <template slot="btn">
        <el-button
          type="info"
          class="btn-agree"
          @click="agreePopOpen(contractData.contractorInfo[1])"
          >활용 동의</el-button
        >
      </template>
    </h-table-list>
  </div> -->
</template>
<script>
import PopMessage from "~/components/popup/PopMessage.vue";
/* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */      
import Loading from "~/components/popup/Loading.vue";
/* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
export default {
  name: "ContractorInfo",
  components: { 
    PopMessage,
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */    
    Loading 
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */    
  },
  props: {
    contractNumber: {
      type: String,
      default: ""
    },
    contractData: {
      type: Object,
      default: () => {}
    },
    contractInfoData: {
      type: Object,
      default: () => {}
    },
    contractorInstallmentYn: {
      type: Boolean,
      default: false
    },
    userInfoData: {
      // 로그인 사용자 정보
      type: Object,
      default: () => {}
    },
    activeUserFlag: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      isAuth: process.env.VUE_APP_AUTH === "true", // 권한 패스용
      alertMessage: "",
      alertMessagePop: false,
      agreePop: false, // 활용 동의 팝업
      popVisible: false,
      agreeTable: [], // 정보제공 동의 정보
      privateBusiness: false,
      isEmployee: false,
      isNonProfitCorporation: false,
      alarmTalkCheck: null,
      checkCorpNum: false, // 휴폐업조회 여부
      ruleForm: [
        {
          businessNumber: ''
        }
      ],
      saveForm: {
        contractNumber: "",
        customerTypeCode: "",
        rentcarCode: "",
        relationPersonList: []
      },
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */      
      popVisibleLoading: false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */       
    }
  },
  computed: {
  	alarmTalkList() {
  		const list = []
  		this.contractData.contractorInfo.forEach((e) => {
  			list.push({ label: e.customerName, value: e.customerManagementNumber })
  		})
  		return list
  	}
  },
  watch: {
    contractData: function() {
      this.ruleForm = this.contractData.contractorInfo;
      //console.log('ruleForm > '+ JSON.stringify(this.ruleForm));
      this.isNonProfitCorporation =
        this.contractData.nonProfitCorporateYn === "Y" ? true : false;
		if(this.contractData.contractorInfo)
			this.contractData.contractorInfo.forEach((e) => {
				if(e.smsNoticeYn === 'Y') this.alarmTalkCheck = e.customerManagementNumber
			})
    },
    alertMessagePop(value) {
      if(value) this.popVisibleLoading = false
    },
    contractInfoData: function() {
      this.privateBusiness =
        this.contractInfoData.customerTypeCode === "BA1" ||
        this.contractInfoData.customerTypeCode === "BL1"
          ? true
          : false;
      this.isEmployee =
        this.contractInfoData.contractPersonalCorporationCode !== "3" &&
        (this.contractInfoData.customerTypeCode !== "AA1" &&
          this.contractInfoData.customerTypeCode !== "BA1" &&
          this.contractInfoData.customerTypeCode !== "BL1")
          ? true
          : false;
      this.saveForm.customerTypeCode = this.contractInfoData.customerTypeCode
    }
  },
  async created() {
    await this.loadCommonCode()
  },
  mounted(){
    //console.log(this.ruleForm)
    this.$EventBus.$on('selectedAddress', juso => {
      if (juso) {
        this.ruleForm[juso.addrIdex].zipCode = juso.zipNo;
        this.ruleForm[juso.addrIdex].addressContents = juso.roadAddr;
        this.ruleForm[juso.addrIdex].detailAddressContents = "";
        this.ruleForm[juso.addrIdex].buildingNumber = juso.bdMgtSn;
      }
    })
  },
  methods: {
    fetchCommonCodeData(systemType = "", codeType = "") {
      let res = null
      switch (systemType) {
      case 'E':
        res = this.$store.dispatch("loadCommonCodesE", {
          vm: this,
          codeTypeCode: codeType
        })
        break
      case 'C':
        res = this.$store.dispatch("loadLegacyCommonCodesC", {
          vm: this,
          codeTypeCode: codeType
        })
        break
      }
      return res
    },
    async loadCommonCode() {
      const [ccT017, ccA005] = await Promise.all([
        this.fetchCommonCodeData("E", "T017"), // 개인정보 활용동의
        this.fetchCommonCodeData("C", "A005") // 개인정보 활용동의
      ]);

      this.commonCodes = { ...ccT017, ...ccA005 };
      this.commonCodes.T017.shift();
      this.commonCodes.A005.shift();
    },
    onCheck(value) {
      console.log(value);
    },
    isValidAuthBtn(authId) {
      // 버튼별 권한 체크
      let bResult = false; // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || [];
      if (currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some(items => {
          if (items.btnId === authId) {
            bResult = true;
            return true;
          }
        });
      }
      return bResult;
    },
    agreePopOpen(data) {
      // 활용 동의 팝업 활성화
      const ccT017 = this.commonCodes.T017 || [];
      if (ccT017 && ccT017.length) {
        // 공통코드 데이터가 있을경우
        this.agreeTable = ccT017.map(items => {
          const findIdx = data.informationGatheringInfo.findIndex(
            items2 => items2.informationGatheringCode === items.value
          );
          return {
            informationGatheringCode: items.value,
            informationGatheringName: items.label,
            informationGatheringYn:
              findIdx > -1
                ? data.informationGatheringInfo[findIdx].informationGatheringYn
                : "N"
          };
        });
      } else {
        this.agreeTable = data.informationGatheringInfo;
      }
      // this.agreePopOpen = row
      this.agreePop = true;
    },
    async checkCorporationNumber(corpNum) {
      if (corpNum === "") {
        this.alertMessage = "사업자번호를 확인해주세요.";
        this.alertMessagePop = true;
        return;
      }

      // API-WX-공통서비스-004 (휴폐업 조회)
      const [res, err] = await this.$https.get(
        "common/v2/common/popbill/checkCorpNum/" + corpNum,
        null,
        null,
        "gateway"
      ); // API-E-업무담당자-120 (등록대행업체 등록)
      if (!err) {
        console.log("/popbill/checkCorpNum/", res.data);
        if (res.data.state === "1") {
          this.checkCorpNum = true;
          let businessType = ""
          switch (res.data.type) {
          	case "1":
          		businessType = "일반과세자 입니다. "
          		break
          	case "2":
          		businessType = "면세과세자 입니다. "
                break
          	case "3":
          		businessType = "간이과세자 입니다. "
          		break
          	case "4":
          		businessType = "비영리법인 또는 국가기관, 고유번호가 부여된 단체 입니다. "
          		break
          }
          this.alertMessage =
            businessType + "계약을 계속 진행하세요.";
          this.alertMessagePop = true;
        } else if (res.data.state === "0") {
          this.alertMessage =
            "국세청에 등록되지 않은 사업자등록번호입니다. 다시 확인해주세요.";
          this.alertMessagePop = true;
        } else if (res.data.state === "2" || res.data.state === "3") {
          this.alertMessage =
            "폐업자입니다. 계약을 진행할 수 없습니다. 다시 확인해주세요.";
          this.alertMessagePop = true;
        }
      } else {
        console.error(err);
      }

      //}
    },
    searchAddressPopOpen(index) {
      this.$EventBus.$emit("searchAddressPopOpen", index);
    },
    checkCustomerTypeCode() {
      this.popVisibleLoading = true
      if (
        !this.isEmployee &&
        (this.contractInfoData.contractPersonalCorporationCode !== "3" &&
          (this.contractInfoData.customerTypeCode !== "AA1" &&
            this.contractInfoData.customerTypeCode !== "BA1" &&
            this.contractInfoData.customerTypeCode !== "BL1"))
      ) {
        this.popVisible = true;
      } else if (
        this.contractorCount > 1 &&
        (this.customerTypeCode === "AL1" ||
          this.customerTypeCode === "CL1" ||
          this.customerTypeCode === "BL1")
      ) {
        this.$emit(
          "alertMsg",
          "공동명의자가 있으면 이용자명의리스로 변경할 수 없습니다."
        );
      } else {
        this.onSaveContractorsInfo();
      }
    },
    async onSaveContractorsInfo() {

      //계약자 결제 정보 할부 존재시 return
      // if(this.contractorInstallmentYn === true){
      //   this.alertMessage = "할부 이용 고객은 변경이 불가합니다. 할부 취소 후 변경바랍니다."
      //   this.alertMessagePop = true
      //   return
      // }

      console.log("===ruleForm===", this.ruleForm);
      this.saveForm.rentcarCode = null;
      let checkVal = this.ruleForm.some(item => {
        console.log("!item.customerMobile", !item.customerMobile);
        if (!item.customerMobile) {
          this.alertMessage = "휴대전화를 입력해주세요.";

          return true;
        }
        var mobileExp = /^\d{3}-\d{3,4}-\d{4}$/;
        if (!mobileExp.test(item.customerMobile)) {
          this.alertMessage = "휴대전화 형식이 잘못됐습니다.";
          return true;
        }

        if (item.contractorTypeCode !== "03" && !item.customerEamilNoMasking) {
          this.alertMessage = "이메일을 입력해주세요.";
          return true;
        }

        if(item.relationPersonRelationCode==="14"&&item.personalCorporationCode!=="1"
        &&item.businessNumber===this.contractInfoData.companyNumber){
          this.alertMessage = "실차주의 사업자번호와 주계약자의 사업자번호가 동일합니다.";
          return true;
        }

        if(item.personalCorporationCode=="2"&&this.privateBusiness){
          if(item.businessNumber){
            let checkNumRange = item.businessNumber.substring(3, 5);
            if (80 < +checkNumRange && +checkNumRange < 90) {
              this.alertMessage = "사업자등록번호가 정확하지 않습니다. 다시 확인해주세요.";
              return true;
            }
          }else{
              this.alertMessage = "사업자등록번호가 정확하지 않습니다. 다시 확인해주세요.";
              return true;
          }

        }
      });

      if (checkVal) {
        this.alertMessagePop = true;
        return;
      }

      const rentCarType = this.ruleForm
        .filter(
          el =>
            el.contractorTypeCode === "01" &&
            el.rentCarPeriodType &&
            this.contractInfoData.contractPersonalCorporationCode === "3"
        )
        .map(el => el.rentCarPeriodType);

      if (rentCarType.length > 0) {
        this.saveForm.rentcarCode = rentCarType[0];
      }

      this.saveForm = {
        ...this.saveForm,
        contractNumber: this.contractNumber,
        rentcarMonth: this.contractData.rentcarMonth,
        nonProfitCorporateYn: this.isNonProfitCorporation ? "Y" : "N"
      };

      this.saveForm.relationPersonList = this.ruleForm.map(el => {
        let CorporationCode = "1";
        if (
          el.contractorTypeCode === "01" &&
          this.saveForm.customerTypeCode === "BA1"
        ) {
          CorporationCode = "2";
        } else if (
          (el.contractorTypeCode === "01" &&
            this.saveForm.customerTypeCode === "CA1") ||
            (el.relationPersonRelationCode!=="14"&&
          (this.saveForm.customerTypeCode === "CL2" ||
          this.saveForm.customerTypeCode === "CR1" ||
          this.saveForm.customerTypeCode === "CL1")
          )
          ||
          (el.relationPersonRelationCode==="14"&&el.personalCorporationCode!=="1")

        ) {
          CorporationCode = "3";
        }

        if(el.contractorTypeCode === "03" &&!el.residentRegistrationNumber){
          el.residentRegistrationNumber = el.customerBirthday+""+el.customerSex;
        }


        el.businessNumber = el.businessNumber
          ? el.businessNumber.replace(/-/gi, "")
          : "";
        el.informationGatheringInfo = "";
        return {
          ...el,
          relationPersonName: el.customerName,
          relationPersonTypeCode: el.contractorTypeCode,
          emailAddress: el.customerEamilNoMasking,
          mobilePhoneNumber1: el.customerMobile
            ? el.customerMobile.split("-")[0]
            : "",
          mobilePhoneNumber2: el.customerMobile
            ? el.customerMobile.split("-")[1]
            : "",
          mobilePhoneNumber3: el.customerMobile
            ? el.customerMobile.split("-")[2]
            : "",
          personalCorporationCode: CorporationCode,
          smsNoticeYn: this.alarmTalkCheck === el.customerManagementNumber? 'Y' : 'N'
        };
      });

      console.log("===saveForm===", this.saveForm);

      const [res, err] = await this.$https.post(
        "purchase/v2/purchase/contract/customer/change",
        this.saveForm,
        null,
        "gateway"
      );
      this.popVisibleLoading = false

      if (!err) {
        console.log(res);
        // screenUseTypeCode (01:열람,02:수정,03:삭제,04:인쇄,05:입력,06:업로드,07:다운로드)
        this.$store.dispatch('commonSupportLog', { vm: this, params: { screenUseTypeCode: '02', useInfo: JSON.stringify(this.saveForm) } })

        if (res.rspStatus && res.rspStatus.rspCode === "0000") {

          const [res2, err2] = await this.$https.get("/v2/exclusive/work/workContractorInfo/change/" + this.contractNumber);

          if (res2.rspStatus && res2.rspStatus.rspCode === "0000" && res2.data === 1) {
            this.alertMessage = "변경되었습니다.";
            this.alertMessagePop = true;
            this.$emit("refresh");
          }

        }
      } else {
        console.error(err);
      }

      //this.ruleForm;
    },
    checkPrivateBusiness() {
      this.saveForm.customerTypeCode = this.privateBusiness ? "BA1" : "AA1";
      if (this.privateBusiness) {
        this.saveForm.customerTypeCode = "BA1";
      } else {
        this.saveForm.customerTypeCode = "AA1";

        this.ruleForm.map(el => {
          if (el.contractorTypeCode === "01") {
            el.businessConditionCode = "";
            el.businessConditionName = "";
            el.businessNumber = "";
            el.businessName = "";
            el.representativeName = "";
            el.corporateRegistNo = "";
            el.itemName = "";
            el.residentRegistrationNumber = "";
            if (this.contractInfoData.contractPersonalCorporationCode === "2") {
              el.customerManagemontNumber = el.firstCustomerManagemontNumber;
            }
          }
        });
      }
    },
    checkIsEmployee() {
      if (this.isEmployee && this.contractInfoData.customerTypeCode !== "AA1") {
        this.saveForm.customerTypeCode = this.contractInfoData.customerTypeCode;
      } else if (
        this.isEmployee &&
        this.contractInfoData.customerTypeCode === "AA1"
      ) {
        this.saveForm.customerTypeCode = "AH1";
      } else {
        this.saveForm.customerTypeCode = "AA1";
      }
    },
    checkIsNonProfitCorporation() {
      console.log("this.isNonProfitCorporation", this.isNonProfitCorporation);
      if (
        this.isNonProfitCorporation &&
        this.contractInfoData.customerTypeCode !== "AA1"
      ) {
        this.saveForm.customerTypeCode = this.contractInfoData.customerTypeCode;
      } else if (
        this.isNonProfitCorporation &&
        this.contractInfoData.customerTypeCode === "AA1"
      ) {
        this.saveForm.customerTypeCode = "AH1";
      } else {
        if (this.contractInfoData.contractPersonalCorporationCode === "3") {
          this.saveForm.customerTypeCode = "CA1";
        } else {
          this.saveForm.customerTypeCode = "AA1";
        }
      }
    },
    onChangeBusinessConditionCode(e, form) {
      this.commonCodes.A005.map(item => {
        if (item.value === e) {
          form.businessConditionCode = item.value;
          form.businessConditionName = item.label.trim();
        }
      });
    },
    checkRentPeriod(value){
      console.log(value)
      let isExistContractorTypeCode = false;

      this.ruleForm.map(el => {
          if (el.contractorTypeCode === "03") {
            isExistContractorTypeCode = true;
          }
        });

      if(value==="2"&&!isExistContractorTypeCode){
        const param = {
          contractorTypeCode:"03",
          personalCorporationCode: "1",
          relationPersonRelationCode: "14",
          businessName: "",
          representativeName: "",
          businessNumber: "",
          corporateRegistNo: "",
          customerName: "",
          customerBirthday: "",
          customerSex: "",
          customerMobile: "",
          zipCode: "",
          addressContents: "",
          detailAddressContents: "",
          businessConditionName: "",
          itemName: "",
        }
        this.contractData.contractorInfo.push(
          param
        )
       /*  this.ruleForm.push(
            param
          )*/
      }else if(value==="1"){
        let rentTypeShort = 0;

        this.ruleForm.map((el, idx) => {
          if (el.contractorTypeCode === "03") {
            rentTypeShort = idx;
          }
        });

        if(rentTypeShort>0){
          this.contractData.contractorInfo.splice(rentTypeShort,1);
          this.ruleForm.splice(rentTypeShort,1);
        }
      }

    },
    checkBusinessCorporationCode(value){
      if(value==="1"){
        this.ruleForm.map(el => {
          if (el.contractorTypeCode === "03") {
            el.personalCorporationCode = "1"
            el.businessConditionCode = "";
            el.businessConditionName = "";
            el.businessNumber = "";
            el.businessName = "";
            el.representativeName = "";
            el.corporateRegistNo = "";
            el.itemName = "";
            el.residentRegistrationNumber = "";
            el.zipCode = ""
            el.addressContents = ""
            el.detailAddressContents = ""
            el.buildingNumber = ""
          }
        });
      }else if(value==="3"){
        this.ruleForm.map(el => {
          if (el.contractorTypeCode === "03") {
            el.personalCorporationCode = "3"
            el.customerBirthday = "";
            el.customerMobile = "";
            el.customerName = "";
            el.customerSex = "";
            el.mobilePhoneNumber1 = "";
            el.mobilePhoneNumber2 = "";
            el.mobilePhoneNumber3 = "";
            el.zipCode = ""
            el.addressContents = ""
            el.detailAddressContents = ""
            el.buildingNumber = ""
          }
        })
      }
    },
    /* [#10015/2021.11.19/A936506] 주소 입력시 특수문자(@, #, %. $, ~, /)를 key in 하는 경우 화면에서 alert 노출  */
    strCheck(index) {
      let str = this.ruleForm[index].detailAddressContents

      // 특수문자 체크
      if (str && str.match(/[@#%$~'/]/)) {
        this.$alert('특수문자 입력이 불가합니다.')
        this.ruleForm[index].detailAddressContents = str.slice(0, -1)
        return
	    }
    },
    /* ############################# [W Project/##12163/2022.04.10/A934118] START ###################################### */
    onChangeCustomerTypeCode(value){
      if(value === 'CR1'){
        let rentTypeShort = 0;

        this.ruleForm.map((el, idx) => {
          if (el.contractorTypeCode === "03") {
            rentTypeShort = idx;
          }
        });

        if(rentTypeShort>0){
          this.contractData.contractorInfo.splice(rentTypeShort,1);
          this.ruleForm.splice(rentTypeShort,1);
        } else if(rentTypeShort===0){
          this.ruleForm[rentTypeShort].rentCarPeriodType = "1"
        }
      } else if(value === 'CL1') {
        let isExistContractorTypeCode = false;

        this.ruleForm.map(el => {
          if (el.contractorTypeCode === "03") {
            isExistContractorTypeCode = true;
          }
        });

        if(!isExistContractorTypeCode){
          const param = {
            contractorTypeCode:"03",
            personalCorporationCode: "1",
            relationPersonRelationCode: "14",
            businessName: "",
            representativeName: "",
            businessNumber: "",
            corporateRegistNo: "",
            customerName: "",
            customerBirthday: "",
            customerSex: "",
            customerMobile: "",
            zipCode: "",
            addressContents: "",
            detailAddressContents: "",
            businessConditionName: "",
            itemName: "",
          }
          this.contractData.contractorInfo.push(
            param
          )
        }
      } else {
        this.ruleForm[0].rentCarPeriodType = "1"
      }
      this.saveForm.customerTypeCode = value
    },
    oneClickDisable(event, clickEvent, ...args) {
      if(event.target.disabled === true){
        retrun
      }

      event.target.disabled = true

      try {
        clickEvent(...args)
      } catch {}
      setTimeout(() => {
        event.target.disabled = false
      }, 2000)
    }       
    /* ############################# [W Project/##12163/2022.04.10/A934118] END ###################################### */
  }
};
</script>
<style lang="scss" scoped>
@import "~/assets/style/pages/detail.scss";
</style>
