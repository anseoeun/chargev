<template>
  <div>
    <div class="article-title">
      <h2>서류심사목록</h2>
      <el-button
        type="primary"
        class="btn-md"
        icon="el-icon-plus"
        v-if="
          isValidAuthBtn('authDocument') &&
            (activeUserFlag ||
              userInfoData.eeno === contractInfoData.consultantId)
        "
        :disabled="
          !contractNumber || contractInfoData.legacyStatusCode === '90'
        "
        @click="addDocumentPopOpen"
      />
    </div>

    <div class="box">
      <el-table
        v-if="paperReviewData"
        :data="paperReviewData"
        class="box append-box"
      >
        <el-table-column
          label="NO."
          prop="no"
          align="center"
          width="80px"
        />
        <el-table-column
          label="업무번호"
          prop="workAssignNo"
          align="center"
          width="150px"
        >
          <template slot-scope="props">
            <a
              class="link"
              v-if="contractInfoData.contractPersonalCorporationCode === '3'"
              href="/#/wp/mypage-reception/corporation/process"
              target="_blank"
              @click="$utils.setLocalStorage({ workSerialNumber: props.row.workAssignNo })"
            >
              {{ props.row.workAssignNo }}
            </a>
            <a
              class="link"
              v-else
              href="/#/wp/mypage-reception/customer/process"
              target="_blank"
              @click="$utils.setLocalStorage({ workSerialNumber: props.row.workAssignNo })"
            >
              {{ props.row.workAssignNo }}
            </a>
          </template>
        </el-table-column>
        <el-table-column
          label="구분"
          prop="papersSectionalName"
          align="center"
          width="300px"
        />
        <el-table-column
          label="소분류"
          prop="papersTypeName"
          align="center"
          width="200px"
        />
        <el-table-column
            label="제출서류"
            prop="fileGroupSerialNumber"
            align="center"
            width="150"
        >
          <template slot-scope="scope">
            <span
              v-if="scope.row.papersExaminationState === '대기' || scope.row.papersExaminationState === '재심사'"
              style="cursor: pointer; color: #1a0dab;"
            >
            <el-upload
              ref="upload"
              name="file"
              accept=".jpg, .jpeg, .gif, .pdf"
              action=""
              :auto-upload="false"
              :multiple="false"
              :limit="1"
              :on-change="handleChange"
            >
              <el-button
                slot="trigger"
                type="info"
                class="btn-small"
                @click="modifyDoucment(scope.row.ncssPpNo, scope.row.ncssPpSubjNo, scope.row.papersExaminationState)"
              >
                등록
              </el-button>
            </el-upload>
            </span>
            <span
              v-else
              style="cursor: pointer; color: #1a0dab;"
              @click="getFileData(scope.row)"
            >
              <i class="file_img"></i>{{ scope.row.papersNameList }}<br />
            </span>
          </template>
        </el-table-column>
        <el-table-column
          label="스크래핑 여부"
          prop="scrapingTargetYn"
          align="center"
          width="100px"
        />
        <el-table-column
          label="스크래핑 결과"
          prop="scrapingResult"
          align="center"
          width="100px"
        />
        <el-table-column
          label="추가서류여부"
          prop="additionPapersYn"
          align="center"
          width="100px"
        />
        <el-table-column
          label="서류요청일시"
          prop="papersRequestDate"
          align="center"
        />
        <el-table-column
          label="상태변경일시"
          prop="papersExaminationDate"
          align="center"
        />
        <el-table-column
          label="상태"
          prop="papersExaminationState"
          align="center"
          width="100px"
        />
      </el-table>
    </div>
    <!-- <h-table
      :table-type="'DefultTable'"
      :table-header="paperReviewHeader"
      :table-datas="paperReviewData"
    /> -->
  </div>
</template>
<script>
import HTableList from "~/components/common/HTableList.vue";
import HTable from "~/components/common/HTable.vue";
import HTitle from "~/components/common/HTitle.vue";

export default {
  name: "PaperReviewInfo",
  components: {
    HTableList,
    HTable,
    HTitle
  },
  props: {
    contractNumber: {
      type: String,
      default: ""
    },
    contractData: {
      type: Object,
      default: () => {}
    },
    contractInfoData: {
      type: Object,
      default: () => {}
    },
    userInfoData: {
      // 로그인 사용자 정보
      type: Object,
      default: () => {}
    },
    activeUserFlag: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      isAuth: process.env.VUE_APP_AUTH === "true", // 권한 패스용
      paperReviewData: [],
      paperReviewHeader: [
        {
          label: "NO.",
          prop: "no",
          align: "center",
          width: "80px"
        },
        {
          label: "업무번호",
          prop: "workAssignNo",
          align: "center",
          width: "150px"
        },
        {
          label: "구분",
          prop: "papersSectionalName",
          align: "center",
          width: "300px"
        },
        {
          label: "소분류",
          prop: "papersTypeName",
          align: "center",
          width: "200px"
        },
        {
          label: "제출서류",
          prop: "documentFile",
          align: "center",
          width: "150px"
        },
        {
          label: "스크래핑 여부",
          prop: "scrapingTargetYn",
          align: "center",
          width: "100px"
        },

        {
          label: "스크래핑 결과",
          prop: "scrapingResult",
          align: "center",
          width: "100px"
        },
        {
          label: "추가서류여부",
          prop: "additionPapersYn",
          align: "center",
          width: "100px"
        },
        {
          label: "서류요청일시",
          prop: "papersRequestDate",
          align: "center"
        },
        {
          label: "상태변경일시",
          prop: "papersExaminationDate",
          align: "center"
        },
        {
          label: "상태",
          prop: "papersExaminationState",
          align: "center",
          width: "100px"
        }
      ],
      uploadDocumentIndex: 0, // 파일 업로드한 문서 index,
      ncssPpNo: '',
      ncssPpSubNo: ''
    };
  },
  async created() {},
  methods: {
    async getPaperReviewData() {
      //서류심사 목록
      const [res4, err4] = await this.$https.get(
        "/v2/exclusive/work/contract/papers/" + this.contractNumber
      );
      if (!err4) {
        console.log("/work/contract/papers/", res4.data);
        this.paperReviewData = res4.data.map((el, idx) => {
          return {
            ...el,
            no : idx+1,
            papersNameList : (el.papersNameList && el.papersNameList.join(", ")) || ""
          }
        })
      } else {
        console.error(err4);
      }
    },
    onCheck(value) {
      console.log(value);
    },
    isValidAuthBtn(authId) {
      // 버튼별 권한 체크
      let bResult = false; // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || [];
      if (currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some(items => {
          if (items.btnId === authId) {
            bResult = true;
            return true;
          }
        });
      }
      return bResult;
    },
    addDocumentPopOpen() {
      this.$EventBus.$emit("addDocumentPopOpen");
    },
    // 파일업로드
    async handleChange(file) {
      if (file) {
        const allowedTypes = [
          'image/jpg',
          'image/jpeg',
          'image/gif',
          'application/pdf'
        ] // 허용 가능한 파일
        let formData = new FormData()
        if (allowedTypes.includes(file.raw.type)) {
          formData.append('file', file.raw)
          formData.append('fileBizTypeCode', '004')
          formData.append('privateYn', 'Y')
          formData.append('customerNumber', this.userInfoData.eeno)

          // 파일 크기 체크 (3MB)
          const size = 10485760
          if (file.size > size) {
            this.alertMessagePop = true
            this.alertMessage = '파일당 10MB 를 넘지 않아야 합니다'
            return
          }

          const [res, err] = await this.$https.postMultiPart(
            '/common/v2/common/file/upload/files',
            formData,
            null,
            'gateway'
          ) // API-WE-공통서비스-004_파일 업로드

          if (!err) {

            const paramData = [{
              saleContractNumber: this.contractNumber || '', // 계약번호
              customerManagemontNumber: this.contractData.contractorInfo[0].customerManagementNumber,
              needPapersSubjectNumber: this.ncssPpSubjNo,
              needPapersNumber: this.ncssPpNo,
              fileGroupSeq: res.data.fileGroupSn,
              needPapersSubject: '',
              customerNumber: this.userInfoData.eeno,
              saveType: 'save'
            }]
            
            //전담 업무 할당
            const [res2, err2] = await this.$https.post("/purchase/v2/purchase/references/judgement/registration", paramData, null, "gateway")

            //파일 업로드후 탭 다시 setting
            this.ncssPpNo = ''
            this.ncssPpSubjNo = ''
            this.paperReviewData = []
            this.getPaperReviewData()
            /////////////////////////////
          } 

        } else {
          this.$refs.upload.clearFiles() // 파일 초기화
          this.alertMessage = '허용되지 않는 확장자입니다.'
          this.alertMessagePop = true
        }
      }
    },
    async getFileData(row) {
      const { fileGroupSerialNumber: fileGroupSn = ''} = row
      const [res, err] = await this.$https.get('/common/v2/common/file/inquiry/' + fileGroupSn , null, null, 'gateway')

      if(!err) {
        // screenUseTypeCode (01:열람,02:수정,03:삭제,04:인쇄,05:입력,06:업로드,07:다운로드)
        this.$store.dispatch('commonSupportLog', { vm: this, params: { screenUseTypeCode: '07', useInfo: JSON.stringify({ contractNumber: this.contractNumber }), fileName: res.data[0].fileName, fileSize: res.data[0].fileCapa } })
        this.fileData = res.data[0]
        this.downloadLink()
      }
    },
    async downloadLink() {
      const { fileSn, fileGroupSn, fileName, fileExtentions } = this.fileData
      const [res, err] = await this.$https.getb('/common/v2/common/file/download/'+ fileGroupSn  + '/' + fileSn, null, null, 'gateway')

      if(!err) {
        const blob = new Blob([res], {type : fileExtentions })
        if(window.navigator.msSaveOrOpenBlob) {
          // IE11
          window.navigator.msSaveOrOpenBlob(blob, fileName)
        } else {
          // IE11 외 브라우저
          const blobURL = window.URL.createObjectURL(blob)
          const tempLink = document.createElement('a')

          tempLink.href = blobURL

          tempLink.setAttribute('download', fileName)
          document.body.appendChild(tempLink)
          tempLink.click()
          document.body.removeChild(tempLink)
          window.URL.revokeObjectURL(blobURL)
        }
      }
    },
    async modifyDoucment(ncssPpNo, ncssPpSubjNo, papersExaminationState){

      this.ncssPpNo = ncssPpNo
      this.ncssPpSubjNo = ncssPpSubjNo

      if(papersExaminationState === '재심사'){
        //재심사일경우 기존 파일 삭제처리
        const submitData = {
          saleContractNumber: this.contractNumber,
          customerManagemontNumber: this.contractData.contractorInfo[0].customerManagementNumber,
          needPapersSubjectNumber: ncssPpSubjNo
        };

        const [resA, errA] = await this.$https.get("/purchase/v2/purchase/references/judgement/submits", submitData, null, "gateway")

        if(!errA){
          if(resA.data[0].fileGroupSeq !== null){
            const delParam = {
              saleContractNumber: resA.data[0].saleContractNumber,
              customerManagemontNumber: resA.data[0].customerManagemontNumber,
              needPapersSubjectNumber: resA.data[0].needPapersSubjectNumber,
              needPapersNumber: resA.data[0].needPapersNumber,
              fileGroupSeq: resA.data[0].fileGroupSeq,
              customerNumber: this.userInfoData.eeno
            }
            const [resB, errB] = await this.$https.delete(
              "/purchase/v2/purchase/references/judgement",
              delParam,
              delParam,
              null,
              "gateway"
            );
          }
        }
      }
    },
  }
};
</script>
<style lang="scss" scoped>
.btn-md {
  min-width: 40px;
  height: 40px;
}
@import "~/assets/style/pages/detail.scss";
</style>
