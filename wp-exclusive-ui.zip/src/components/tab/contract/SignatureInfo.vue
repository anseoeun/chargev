<template>
  <div>
    <h-title :title="'전자서명'" />
    <el-table :data="signData" @selection-change="onCheck">
      <el-table-column
        label="수단"
        prop="electronSignTypeCodeName"
        align="center"
      />
      <el-table-column label="이름" prop="customerName" align="center" />
      <el-table-column label="구분" align="center">
        <template slot-scope="scope"
          >{{ scope.row.contractorSectionalName }}
          {{
            scope.row.contractorRelationName !== "본인" ? "(관계:가족)" : ""
          }}</template
        >
      </el-table-column>
      <!-- <el-table-column
        label="계약완료(변경)시각"
        prop="contractAlterationDate"
        align="center"
      /> -->
        <!-- <template slot-scope="scope"
          >{{ scope.row.electronSignCompleteYn }}
          {{
            scope.row.electronSignCompleteYn === "Y"
              ? `(${scope.row.electronSignCompleteDate})`
              : ""
          }}</template
        > -->
      <el-table-column label="전자서명 요청시각" align="center">
        <template slot-scope="scope">
          {{
            scope.row.electronSignTypeCodeName !== "공동인증"
              ? `${scope.row.electronSignRequestDate}`
              : ""
          }}</template
        >
      </el-table-column>
      <el-table-column label="전자서명 완료시각" align="center">
        <template slot-scope="scope">
          <span
            v-if="
              isValidAuthBtn('authExclusive') &&
                (activeUserFlag || isAuth) &&
                scope.row.electronSignCompleteYn === 'N' &&
                scope.row.electronSignTypeCodeName !== '공동인증'
            "
          >
            <el-button
              class="resand"
              type="primary"
              v-if="isValidAuthBtn('authExclusive')"
              :disabled=" !activeUserFlag  "
              @click="signReSend(scope.row)"
              >전자서명 재전송</el-button
            >
          </span>
          <span v-else>{{
            scope.row.electronSignCompleteYn === "N"
              ? "-"
              : scope.row.electronSignCompleteDate
          }}</span>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
import HTableList from "~/components/common/HTableList.vue";
import HTable from "~/components/common/HTable.vue";
import HTitle from "~/components/common/HTitle.vue";

export default {
  name: "SignatureInfo",
  components: {
    HTableList,
    HTable,
    HTitle
  },
  props: {
    contractNumber: {
      type: String,
      default: ""
    },
    contractData: {
      type: Object,
      default: () => {}
    },
    userInfoData: {
      // 로그인 사용자 정보
      type: Object,
      default: () => {}
    },
    activeUserFlag: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      isAuth: process.env.VUE_APP_AUTH === "true", // 권한 패스용
      alertMessage: "",
      alertMessagePop: false,
      agreePop: false, // 활용 동의 팝업
      agreeTable: [], // 정보제공 동의 정보
      signData: []
    };
  },
  async created() {},
  methods: {
    onCheck(value) {
      console.log(value);
    },
    isValidAuthBtn(authId) {
      // 버튼별 권한 체크
      let bResult = false; // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || [];
      if (currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some(items => {
          if (items.btnId === authId) {
            bResult = true;
            return true;
          }
        });
      }
      return bResult;
    },
    async getElectronSignData(electKcd) {
      // API-E-업무담당자-015 (전자서명목록 조회)
      // if(Object.keys(this.signData).length===0) {
      const [res2, err2] = await this.$https.post(
        "/v2/exclusive/work/electron",
        { contractNumber: this.contractNumber , elecSignKcd : electKcd }
      );
      if (!err2) {
        console.log("/work/electron/", res2.data);
        this.signData = res2.data;
      } else {
        console.error(err2);
      }
      //}
    },
    async signReSend(row) {
      // 재전송
      console.log(this.contractNumber);
      if (!this.contractNumber) return;

      let params = new URLSearchParams();
      params.append("contractNumber", this.contractNumber);
      params.append("customerManagementNumber", row.customerManagementNumber);

      // API-E-구매서비스-057 (전자서명 재전송 - 계약정보)
      const [res, err] = await this.$https.post(
        "purchase/v2/purchase/contract/electronic-signature/request-repeat/contract-info",
        params,
        null,
        "gateway"
      );
      if (!err) {
        if (res.rspStatus && res.rspStatus.rspCode === "0000") {
          this.alertMessage = "재전송되었습니다.";
          this.alertMessagePop = true;
        }
        console.log(res);
      } else {
        console.error(err);
      }
    }
  }
};
</script>
