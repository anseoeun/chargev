<template>
  <div>
    <h-title :title="'추천인 정보'" />
    <el-form ref="date" :model="recommenderData" class="detail-form">
      <el-row>
        <el-col :span="12">
          <el-form-item label="앰버서더">{{
            recommenderData && recommenderData.acquaintanceRecommendCustomerManagementNo
              ? recommenderData.acquaintanceRecommendCustomerManagementNo
              : "없음"
          }}</el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="추천 카마스터">
            <template v-if="recommenderData">
              {{
                recommenderData && recommenderData.carMasterEmployeeName
                  ? "이름 :" + recommenderData.carMasterEmployeeName
                  : ""
              }}
              {{
                recommenderData && recommenderData.carMasterOpsNm
                  ? ", 소속:" + recommenderData.carMasterOpsNm
                  : ""
              }}
              {{
                recommenderData && recommenderData.carMasterEmployeeNumber
                  ? ", 사번:" + recommenderData.carMasterEmployeeNumber
                  : ""
              }}
              {{recommenderData&&!recommenderData.carMasterEmployeeName&&!recommenderData.carMasterOpsNm
              &&!recommenderData.carMasterEmployeeNumber?"없음":""}}
            </template>
            <template v-else>없음</template>
            <el-button type="info" class="btn-small space" 
            @click="popVisibleSearch = true"
              >변경</el-button
            >            
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>






    <!-- 추천 카마스터 변경 팝업 -->
    <el-dialog
      title="추천 카마스터 변경"
      :visible.sync="popVisibleSearch"
      width="1000px"
    >
      <!-- Popup Contents -->      
      <div class="car-master map-search">          
          <div class="search-top">
            <div class="search-type">
              <el-radio v-model="radioType" label="3" @change="noCarMaster()">선택 안 함</el-radio>
              <el-radio v-model="radioType" label="1">이름으로 찾기</el-radio>
              <el-radio v-model="radioType" label="2">지점/대리점으로 찾기</el-radio>
            </div>
            <div class="master-input">
              <div  class="label-input inbl-wrap">
              <el-input v-model="searchName" @keyup.enter.native="searchCarmaster" placeholder="이름을 입력해주세요.">
              </el-input>
              <el-button type="primary" @click="searchCarmaster()" >확인</el-button>
              </div>
            </div>          
        </div>    
        <div class="search-top">
            <div class="search-type">
              <el-radio v-model="agentType" label="3" @change="carMasterListFilter(3)">전체</el-radio>
              <el-radio v-model="agentType" label="1" @change="carMasterListFilter(1)">지점</el-radio>
              <el-radio v-model="agentType" label="2" @change="carMasterListFilter(2)">대리점</el-radio>
            </div>                    
        </div>                
          
        <div class="search-result">
          <div class="search-list">
            <ul v-if="carMasterList.length > 0">
              <template v-for="(items, index) in carMasterList">
                <li
                  :key="items.carMasterCode" :class="index === active? 'on' : ''"
                >
                  <div class="search-info">
                    <div class="title">
                      <span class="num">{{ index + 1 }}</span>
                      <strong class="name">{{ items.carMasterName }}</strong>
                    </div>
                    <p>{{ items.agencyName }} ({{ items.agencyTypeName }})</p>
                    <p>{{ items.agencyTel }} / {{ items.carMasterMobile }}</p>
                  </div>
                  <el-button type="text" @click="viewCarMasterChange($event, items, index)"
                    >선택</el-button
                  >
                </li>
              </template>
            </ul>

            <div class="no-result" v-if="carMasterList.length <= 0">
              검색 결과가 없습니다.
            </div>
            
            
          </div>
        </div>          
      </div>   
      <template slot="footer">
        <div>
          <el-button type="info" @click="popVisibleSearch = false">취소</el-button>
          <el-button type="primary" @click="oneClickDisable($event, carMasterChange)">저장</el-button>
        </div>
      </template>   
    </el-dialog>

    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
    <!-- ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## -->    
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />
    <!-- ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## -->
  </div>
</template>
<script>
import HTableList from "~/components/common/HTableList.vue";
import HTable from "~/components/common/HTable.vue";
import HTitle from "~/components/common/HTitle.vue";
import PopMessage from "~/components/popup/PopMessage.vue";
import moment from "moment";
/* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */      
import Loading from "~/components/popup/Loading.vue";
/* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */

export default {
  name: "RecommendInfo",
  components: {
    HTableList,
    HTable,
    HTitle,
    PopMessage,
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
    Loading
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */    
  },
  props: {
    contractNumber: {
      type: String,
      default: ""
    },
    userInfoData: {
      // 로그인 사용자 정보
      type: Object,
      default: () => {}
    },
    activeUserFlag: {
      type: Boolean,
      default: false
    },
    contractInfoData :{
      type: Object,
      default: () => {}
    }
    
  },
  data() {
    return {
      isAuth: process.env.VUE_APP_AUTH === "true", // 권한 패스용
      alertMessage: "",
      alertMessagePop: false,
      agreePop: false, // 활용 동의 팝업
      agreeTable: [], // 정보제공 동의 정보
      recommenderData: {},
      popVisibleSearch: false,
      carMasterList: [],
      agencyCarMasterList :[],
      radioType :"",
      agentType :"",
      searchName : "",
      carMasterChangeForm :{},
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      popVisibleLoading: false,
      active: "",
      carMasterCode: "",
      changeCarMasterName: ""
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
    };
  },
  async created() {},
  methods: {
    onCheck(value) {
      console.log(value);
    },
    isValidAuthBtn(authId) {
      // 버튼별 권한 체크
      let bResult = false; // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || [];
      if (currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some(items => {
          if (items.btnId === authId) {
            bResult = true;
            return true;
          }
        });
      }
      return bResult;
    },
    async getRecommenderData() {
      //서류심사 목록
      const [res, err] = await this.$https.get(
        "/v2/exclusive/work/contract/recommender/" + this.contractNumber
      );
      if (!err) {
        console.log("/work/contract/recommender/", res.data);
        this.recommenderData = res.data;
      } else {
        console.error(err);
      }
    },    
    async searchCarmaster(){
      
      console.log("contractInfoData.legacyStatusCode >>" + this.contractInfoData.legacyStatusCode)
      console.log("dd "+ this.radioType+ "/"+ this.searchName);


      //카마스터 조회
      let carMasterName ="";
      let agentName ="";
      let contAgentType = "";

      if(this.radioType === "1"){
        carMasterName = this.searchName;
      }else if(this.radioType === "2"){
        agentName = this.searchName;
      }else{
        return;
      }

      if(this.agencyType === "3"){
        contAgentType = "";
      }else{
        contAgentType = this.agencyType;
      }


      const [res, err] = await this.$https.get(
        "customer-support/v2/customer-support/agency/recommend/car-masters?"
        +"pageNo=1&pageSize=1000"
        +"&searchName="+carMasterName
        +"&searchAgency="+agentName        
        +"&agencyTypeCode="+contAgentType
        ,
        null,
        null,
        "gateway"
      );

      if (!err) {
        
        this.carMasterList = res.data.info.list; 
        this.agencyCarMasterList = res.data.info.list; 
      } else {
        console.error(err);
      }

    },
    viewCarMasterChange($event, item, index) {
      // 카마스터 선택값 유지
      this.active = index;

      if(this.contractInfoData.legacyStatusCode !== '10' &&
         this.contractInfoData.legacyStatusCode !== '20' &&
         this.contractInfoData.legacyStatusCode !== '30' &&
         this.contractInfoData.legacyStatusCode !== '40' &&
         this.contractInfoData.legacyStatusCode !== '50' &&
         this.contractInfoData.legacyStatusCode !== '60' 
      ){          
          return;                    
      }

      //this.recommenderData.carMasterEmployeeName = item.carMasterName
      //this.recommenderData.carMasterOpsNm = item.agencyName
      //this.recommenderData.carMasterEmployeeNumber = item.carMasterCode
      this.carMasterCode = item.carMasterCode
      this.changeCarMasterName = item.carMasterName
      

      this.carMasterChangeForm = {      
        contractNumber: this.contractNumber,
        carMasterEmployeeNumber: item.carMasterCode        
      };
      console.log('carMasterChangeForm >> '+JSON.stringify(this.carMasterChangeForm));
    },
    noCarMaster(){
      this.carMasterList = [];
      this.agencyCarMasterList = []; 
      
    },
    carMasterListFilter(){

      if(this.agentType  === "3"){
        this.carMasterList = this.agencyCarMasterList;
      }else if(this.agentType ==="1"){
        this.carMasterList = this.agencyCarMasterList;
        this.carMasterList = this.carMasterList.filter(          
          el => el.agencyTypeCode ==="1"
        )
      }else if(this.agentType ==="2"){
        this.carMasterList = this.agencyCarMasterList;
        this.carMasterList = this.carMasterList.filter(
          el => el.agencyTypeCode ==="2"
        )
      }
      
    },
    async carMasterChange(){
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
      //출고후 3개월 -1일 체크//////////////////////////////////////
      let toDate = moment().format('YYYY-MM-DD')
      let flag = false

      if(this.contractInfoData.releaseDate !== null){
        flag = moment(toDate).isAfter(moment(this.contractInfoData.releaseDate).add('3','M').add('-1','d').format('YYYY-MM-DD'))
      }
      ///////////////////////////////////////////////////////////////

      if(this.contractInfoData.legacyStatusCode !== '10' &&
         this.contractInfoData.legacyStatusCode !== '20' &&
         this.contractInfoData.legacyStatusCode !== '30' &&
         this.contractInfoData.legacyStatusCode !== '40' &&
         this.contractInfoData.legacyStatusCode !== '50' &&
         (this.contractInfoData.legacyStatusCode !== '60' || flag)
      ){
          //this.alertMessage = "추천 카마스터 변경은 [출고증발급요청] - 결제확정 - 이전에만 가능합니다.";
          this.alertMessage = "추천 카마스터 변경은 출고일 포함 3개월까지 변경 가능합니다.";
          this.alertMessagePop = true;
          return;                  
      }

      let carMasterEeNo = ""


      if(this.radioType !== "3"){
        //carMasterEeNo = this.recommenderData.carMasterEmployeeNumber;
        carMasterEeNo = this.carMasterCode
      }else if(this.radioType === "3"){
        this.recommenderData.carMasterEmployeeName = ""
        this.recommenderData.carMasterOpsNm = ""
        this.recommenderData.carMasterEmployeeNumber = ""
      }

      let param = {
        contractNumber: this.contractNumber,
        carMasterEmployeeNumber : carMasterEeNo
      };

      console.log("param >>"+this.recommenderData.carMasterEmployeeNumber+"//" + JSON.stringify(param))

      const [res, err] = await this.$https.get(
        "purchase/v2/purchase/contract/carmaster/change?"
        +"contractNumber="+this.contractNumber
        +"&carMasterEmployeeNumber="+carMasterEeNo
        ,
        null,
        null,
        "gateway"
      );
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
        this.popVisibleLoading = false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
      if (!err) {
        if (res.rspStatus.rspCode === "0000") {
          this.alertMessage = this.changeCarMasterName + " 카마스터로 변경되었습니다.";
          this.alertMessagePop = true;          
          this.popVisibleSearch = false;
          this.$emit("refresh");
        }
      } else {
          this.alertMessage = "카마스터 변경 API 호출에 실패하였습니다.";
          this.alertMessagePop = true;      
          this.popVisibleSearch = false;
      }
    },
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
    oneClickDisable(event, clickEvent, ...args) {
      if(event.target.disabled === true){
        retrun
      }

      event.target.disabled = true

      try {
        clickEvent(...args)
      } catch {}
      setTimeout(() => {
        event.target.disabled = false
      }, 2000)
    }
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
  }
};
</script>
<style lang="scss">
//@import "~/assets/style/pages/detail.scss";
</style>

<style lang="scss">
.map-search {
  padding-bottom: 30px;
  .search-top {
    .el-select {
      margin-right: 10px;
    }
  }
  .search-result {
    overflow-x: hidden;
    overflow-y: auto;
    max-height: 450px;
    margin-top: 20px;
    border-top: 1px solid #000;
    border-bottom: 1px solid #000;
  }
  .search-list {
    width: 500px;
    li {
      position: relative;
      padding: 25px 30px 25px 20px;
      border-bottom: 1px solid #eee;
      &:hover {
        background: #f4f4f4;
      }
    }
    li.on {
      position: relative;
      padding: 25px 30px 25px 20px;
      border-bottom: 1px solid #eee;
      background: #f4f4f4;
    }    
    .el-button {
      position: absolute;
      bottom: 20px;
      right: 35px;
      font-size: 13px;
      color: #002c5f;
      &:after {
        display: inline-block;
        content: '>';
        margin-left: 6px;
      }
    }
  }
  .search-info {
    display: inline-block;
    font-size: 15px;
    position: relative;
    margin-left: 36px;
    .num {
      display: inline-block;
      position: absolute;
      top: 0;
      left: -40px;
      width: 25px;
      height: 30px;
      font-size: 13px;
      color:#fff;
      text-align: center;
      line-height: 2;
      margin-right: 10px;
      vertical-align: top;
      background: url('~@/assets/images/icon/ico-map.png') no-repeat center;
    }
    .name {
      display: inline-block;
      margin-top: 2px;
      font-size: 16px;
      color: #000;
      vertical-align: top;
    }
    p {
      margin-top: 6px;
      color: #666;
    }
  }
  .no-result {
    padding: 160px 0;
    text-align: center;
    color: #999;
  }
}
.car-master .offscreen { 
    position: absolute;
    overflow: hidden;
    clip: rect(0 0 0 0);
    height: 1px; 
    width: 1px;
    margin: -1px;
    padding: 0;
    border: 0;
}
 
.car-master .inbl-wrap > * {
    display: inline-block !important;
    vertical-align: top;
}
.car-master .search-top {
    height: 40px;
	display:flex;flex-direction:row;align-items:center;
}
.car-master .search-top  ~ .search-top {
  margin-top:10px;
}
.car-master .search-top .search-type {
    width: 450px;
}
.car-master .search-top .master-input {
    width: 300px;
    margin-left:10px;
}
.car-master .search-top .master-input .label-input{
   display:inline-flex;align-items: center;
}
.car-master .search-top .master-input .el-input{
  height:40px;
}
.car-master .search-top .master-input .el-input input {
    position: relative;
    font-size: 14px;
    display: inline-block;
    width: 250px;
    height:100%;
}
.car-master .search-top .master-input button{
  min-width:85px;
  margin-left:10px;
}
.car-master .search-top .master-input .el-input .el-input--suffix .el-input__inner {
    padding-right: 30px;
}
.car-master .search-top .master-input .el-input .el-input__suffix {
    position: absolute;
    height: 100%;
    right: 5px;
    top: 1px;
    text-align: center;
    color: #C0C4CC;
    -webkit-transition: all .3s;
    transition: all .3s;
    pointer-events: none;
}
.car-master .search-top .master-input .icon-search {
    margin: 8px 5px;
    display: inline-block;
    vertical-align: middle;
    width: 22px;
    height: 22px;
    background: url("data:img/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB8AAAA1CAMAAACOR8BbAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAABiVBMVEX///8AAAAdHRsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsdHRsAAAAdHRv///9C7aMlAAAAgHRSTlMAAAAxisnx67t3H8D8nxn+uGg6JChCec/uSpW8KkfZ/VuBAQyv+0AEtuUNEueDYu8HBk+kjfK3XWTFfbIR+T2C3AL3ZRXfQeSx+C0UdcPv8sh9GWPx9gGI4XY2IDFw152UBgSCe375IuLPi2HZHwcJGwhZ38WTgWv8Kv2bnuQkLXT/yRcAAAABYktHRACIBR1IAAAAB3RJTUUH5QwNECcpOZacNAAAAilJREFUOMuF0ulbElEUBvAZcFIUV1QwUURx35fcKhVNrcQNlXJNzCVc0lxSM/E9/3kDzJ2Zey/p+2Ue+L0PlznnKkomzhztFZCb58pXM1HscRaAxV1YJLnLjeKS0jJPeUWlF/BVCf4aqPYbP6vW1CJQx7kLCNYrzNWGEBqbbO50I6g/TFebW9DaZnkBqus5V9s70Gm6E8V+hXe1C909zHNQooje60Mfcw2lkqv9GGD+BmWyuzDIHPDIPgTN8nLZhzHCPBcVso8ixDwPlbK/TY/MmK5X8nfvMcY8340a0ccxETbnW4jaBt79k5iy5l/kQ6jZ7h+moYVt+60KoKXdcv80AjPc/ahrREdXr/HXxicRwKyHu19Nrfqt6ncNDY9+/ARoM7N6gbufbZ3d7H5OTIVVj1RQevoGBrWRUHAsnDolS4GbX5aC+kJBfaEguiIUJBcKsqcK3udc8Xg/Kw49c5H5BVpcWo46WKxz9Q8rq5TJWiSWxb8QfV3f2Nza3iH6FpN8hWg3nv5y7zvRvuhzq7RrHntAh0eCR+hH3PRYgo4Fn6d1h5UTOhV8gTZsfkb0k3eiTZufE0V5X6Qtm18Q/eJ9ibZtfklXwvnLtLNn+TXdCB5do98m39LdvTi/CNGBMdXbP/QgzTf2lyhxcnZ+cXmtr+gxKe0ntn9o7O/u4dEocPt1HB2f6np1c+9IGgXe9cSj6fdmBcnNZAr/90zhGU8VEs+5I5l4MvkfAaGX0BaX4kgAAAAASUVORK5CYII=") left top -31px no-repeat;
    background-size: auto;
}
</style>
