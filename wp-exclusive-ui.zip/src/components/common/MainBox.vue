<template>
  <div class="main-box">
    <div class="contentTitle">
      <p v-if="tableTitleType === 'A'" v-html="tableTitleB"></p>
      <p v-if="tableTitleType === 'B'">
        {{ tableTitle1 }} <span class="red">{{ tableTitle2 }}</span>
      </p>
      
      <router-link
        :to="{ path: `${tableLink}` }"
        class="link"
      >
        &gt;
      </router-link>
    </div>
    <div
      v-if="alramType === 'A'"
      class="contentAlram"
    >
      <el-row>
        <el-col :span="12">
          <el-col :span="12">
            진행중 알림
          </el-col>
          <el-col :span="12">
            <span>{{ progressNum }}</span>개
          </el-col>
        </el-col>
        <el-col :span="12">
          <el-col :span="12">
            읽지 않은 알림
          </el-col>
          <el-col :span="12">
            <span>{{ notReadNum }}</span>개
          </el-col>
        </el-col>
      </el-row>
    </div>
    <!-- <div v-else /> -->
    <div v-if="tableContent === 'A'" class="content">
      <ul v-if="tableDatas !== null && tableDatas.length > 0">
        <li
          v-for="(data, index) in tableDatas"
          :key="index"
          :class="data.state === 'success' ? 'end': ''"
        >
          <router-link
            :to="'/wp/notice/manager/detail?noticeSerialNumber='+ data.noticeNumber"
            class="link"
          >
            <div class="title">
              <p
                :class="data.titleP === 'important' ? 'important': ''"
              >
                {{ data.title }}
              </p>
              <p class="date">
                {{ removeTime(data.date) }}
              </p>
            </div>
            <div v-if="!(tableLink.indexOf('notice') > -1)" class="con">
              {{ data.content }}
            </div>
          </router-link>
        </li>
      </ul>
      <ul v-if="tableDatas === null || tableDatas.length === 0">
        <li class="tableDatas-none">
          {{
            tableLink.indexOf("notice") > -1
              ? "공지사항이 없습니다."
              : "수신 알림이 없습니다."
          }}
        </li>
      </ul>
    </div>
    <div v-else-if="tableContent === 'B'" class="content">
      <ul v-if="tableDatas !== null && tableDatas.length > 0">
        <li
          v-for="(data, index) in tableDatas"
          :key="index"
          :class="data.state === 'success' ? 'end' : ''"
        >
          <a class="link">
            <div class="title">
              <p>
                {{ data.exclusiveUserName }}
              </p>
              <p class="date">
                {{ data.absenceStartDate }} ~ {{ data.absenceEndDate }}
              </p>
            </div>
          </a>
        </li>
      </ul>
      <ul v-if="tableDatas === null || tableDatas.length === 0">
        <li class="tableDatas-none">
          부재 등록이 없습니다.
        </li>
      </ul>
    </div>
    <div
      v-else
      class="content"
    >
      <ul v-if="tableDatas !== null">
        <li
          v-for="(data, index) in tableDatas"
          :key="index"
          :class="data.state === 'success' ? 'end': ''"
        >
          <router-link
            :to="linkData(data.path)"
            class="link"
          >
            <div class="title">
              <p>{{ data.title }}</p>
              <p class="state">
                {{ data.contract }}
              </p>
            </div>
            <div class="con">
              <p>{{ data.name }}</p>
              <p class="date">
                {{ data.date }}
              </p>
            </div>
          </router-link>
        </li>
      </ul>
      <ul v-if="tableDatas === null || tableDatas.length === 0">
        <li
          class="tableDatas-none"
        >
          수신 알림이 없습니다.
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MainBox',
  props: 
  {
    tableTitle: {
      type: String,
      default: '마이페이지  수신업무'
    },
    tableTitle1: {
      type: String,
      default: '고객센터이관'
    },
    tableTitle2: {
      type: String,
      default: '긴급알림'
    },
    tableTitleType: {
      type: String,
      default: 'A'
    },
    tableLink: {
      type: String,
      default: '/'
    },
    tableDatas: {
      type: Array,
      default: null
    },
    alramType: {
      type: String,
      default: 'A'
    },
    progressNum: {
      type: Number,
      default: 0
    },
    notReadNum: {
      type: Number,
      default: 0
    },
    tableContent:{
      type: String,
      default:null
    },
    absenteeCount: {
      type: Number,
      default: -1
    }
  },
  computed: {
    tableTitleB() {
      const absentee =
        this.absenteeCount !== -1
          ? `&nbsp;&nbsp;[금일 부재 ${this.absenteeCount}명]`
          : ''
      return `${this.tableTitle}${absentee}`
    }
  },
  methods: {
    removeTime(date) {
      return date.substr(0, 10)
    },
    linkData(link) {
      return link ? (typeof link === 'object' ? { ...link } : link) : null
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/mainBox.scss';
</style>
