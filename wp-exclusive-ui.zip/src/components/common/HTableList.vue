<template>
  <div>
    <div>
      <div 
        class="article-title"
      >
        <h2>
          {{ title }} 
          <span v-if="articleDate === 'use'">결제일시 : {{ date }}</span>
        </h2>
        <div
          v-if="articleTitle ==='use'"
          class="right"
        >
          <p>{{ subTtitle }}</p>
          <p>{{ price }}</p>
          <el-button type="primary">
            결제변경
          </el-button>
        </div>
        <div
          v-if="articleTitle ==='use2'"
          class="right"
        >
          <p>{{ price }}</p>
        </div>
      </div>
      <div
        v-if="listTableType === 'List'"
        class="accordion-table"
      >
        <el-table    
          :data="tableDatas"
          border
          :show-header="false"
          :row-class-name="tableRowClassName"
        >
          <el-table-column
            v-for="(field, index) in tableHeader"
            :key="index"
            :prop="field.prop"
            :label="field.label"
            :width="field.width"
            :align="field.align"
          >
            <slot
              v-if="field.type === 'button'"
              name="table1"
            />
          </el-table-column>
        </el-table>
      </div>
      <div
        v-if="listTableType === 'Accordion'"
        class="accordion-table"
      >
        <el-table
          :data="tableDatas"
          row-key="id"
          border
          :tree-props="{children: 'children', hasChildren: 'hasChildren'}"
          :show-header="false"
          default-expand-all
        >
          <el-table-column
            v-for="(field, index) in tableHeader"
            :key="index"
            :prop="field.prop"
            :label="field.label"
            :width="field.width"
          />
        </el-table>
      </div>
      <div v-if="listTableType === 'ListTable'">
        <table
          class="list-talbe"
        >
          <thead>
            <tr>
              <th colspan="2">
                구분 
              </th>
              <th colspan="2">
                결제방법
              </th>
              <th>결제자/입금자</th>
              <th>진행상태</th>
              <th>결제금액</th>
              <th>결제입력일시</th>
              <th colspan="2">
                결제처리일시
              </th>
            </tr>
          </thead>
          <tbody v-if="paymentDT"> 
            <tr>
              <td rowspan="2">
                {{ paymentDT.col1 }}
              </td>
              <td>{{ paymentDT.col2 }}</td>
              <td>{{ paymentDT.col3 }}</td>
              <td>{{ paymentDT.col4 }}</td>
              <td>{{ paymentDT.col5 }}</td>
              <td>{{ paymentDT.col6 }}</td>
              <td>{{ paymentDT.col7 }}</td>
              <td>{{ paymentDT.col8 }}</td>
              <td colspan="2">
                {{ paymentDT.col9 }}
              </td>
            </tr>
            <tr>
              <td>{{ paymentDT.col10 }}</td>
              <td>{{ paymentDT.col11 }}</td>
              <td>{{ paymentDT.col12 }}</td>
              <td>{{ paymentDT.col13 }}</td>
              <td>{{ paymentDT.col14 }}</td>
              <td>{{ paymentDT.col15 }}</td>
              <td>{{ paymentDT.col16 }}</td>
              <td colspan="2">
                {{ paymentDT.col17 }}
              </td>
            </tr>
            <tr>
              <td
                rowspan="3"
                colspan="2"
              >
                {{ paymentDT.col18 }}
              </td>
              <td>{{ paymentDT.col19 }}</td>
              <td>{{ paymentDT.col20 }}</td>
              <td>{{ paymentDT.col21 }}</td>
              <td>{{ paymentDT.col22 }}</td>
              <td>{{ paymentDT.col23 }}</td>
              <td>{{ paymentDT.col24 }}</td>
              <td>{{ paymentDT.col25 }}</td>
              <td>
                <el-button type="text">
                  {{ paymentDT.col26 }}
                </el-button>
              </td>           
            </tr>
            <tr>
              <td>{{ paymentDT.col27 }}</td>
              <td>{{ paymentDT.col28 }}</td>
              <td>{{ paymentDT.col29 }}</td>
              <td>{{ paymentDT.col30 }}</td>
              <td>{{ paymentDT.col31 }}</td>
              <td>{{ paymentDT.col32 }}</td>
              <td>{{ paymentDT.col33 }}</td>
              <td>
                <el-button type="text">
                  {{ paymentDT.col34 }}
                </el-button>
              </td>           
            </tr>
            <tr>
              <td>{{ paymentDT.col35 }}</td>
              <td>
                {{ paymentDT.col36 }}
              </td>
              <td>
                {{ paymentDT.col37 }}
              </td>
              <td>{{ paymentDT.col38 }}</td>
              <td>{{ paymentDT.col39 }}</td>
              <td>{{ paymentDT.col40 }}</td>
              <td>{{ paymentDT.col41 }}</td>
              <td>
                <el-button type="text">
                  {{ paymentDT.col42 }}
                </el-button>
              </td>           
            </tr>
          </tbody>
        </table>
      </div>
      <div v-if="listTableType === 'TwoThListTable'"> 
        <table
          v-if="thTable === 'Thtable01'"
          class="two-th-table"
        >
          <tbody v-if="tableInfo">
            <tr class="table-list">
              <th rowspan="4">
                주계약자<br>
                {{ tableInfo.officerYn === 'Y' ? '(임직원)' : '(가족)' }} 
                <slot
                  name="btn"
                />
              </th>
              <th>고객관리 번호 </th>
              <td>{{ tableInfo.customerManagementNumber }}</td>
              <th>이름</th>
              <td>{{ tableInfo.customerName }}</td>
              <th>생년월일</th>
              <td>{{ tableInfo.customerBirthday }} {{ tableInfo.customerSex }}</td>
              <th class="non border-right" />
            </tr>
            <tr class="table-list">
              <th>전화번호</th>
              <td>{{ tableInfo.customerMobile }}</td>
              <th>이메일</th>
              <td colspan="4">
                {{ tableInfo.customerEamil }}
              </td>
            </tr>
            <tr class="table-list">
              <th>주소</th>
              <td colspan="6">
                {{ tableInfo.customerAddress }}
              </td>
            </tr>
          </tbody>
        </table>
        <table
          v-if="thTable === 'Thtable02'"
          class="two-th-table"
          style="margin-top: 20px;"
        >
          <tbody v-if="tableInfo">
            <tr class="table-list">
              <th rowspan="4">
                공동명의자<br>
                {{ tableInfo.officerYn === 'Y' ? '(임직원)' : '(가족)' }} 
                <slot
                  name="btn"
                />
              </th>
              <th>고객관리 번호</th>
              <td>{{ tableInfo.customerManagementNumber }}</td>
              <th>이름</th>
              <td>{{ tableInfo.customerName }}</td>
              <th>생년월일</th>
              <td>{{ tableInfo.customerBirthday }} {{ tableInfo.customerSex }}</td>
              <th class="non border-right" />
            </tr>
            <tr class="table-list">
              <th>전화번호</th>
              <td>{{ tableInfo.customerMobile }}</td>
              <th>이메일</th>
              <td colspan="4">
                {{ tableInfo.customerEamil }}
              </td>
            </tr>
            <tr class="table-list">
              <th>주소</th>
              <td colspan="3">
                {{ tableInfo.customerAddress }}
              </td>
              <th>주계약자와의 관계</th>
              <td>{{ tableInfo.contractorRelationName }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>  
</template>


<script>
export default {
  name: 'HTableList',
  props: 
  {
    title:{
      type: String,
      default: null
    },
    subTtitle:{
      type: String,
      default: null
    },
    price:{
      type: String,
      default: null
    },
    date:{
      type: String,
      default: null
    },
    articleDate:{
      type: String,
      default: null
    },
    listTableType :{
      type: String,
      default: 'List'
    },
    thTable:{
      type: String,
      default: null
    },
    tableDatas: {
      type: Array,
      default: null
    },
    tableHeader:{
      type: Array,
      default: null
    },
    lisTableDatas:{
      type: Array,
      default: null
    },
    articleTitle:{
      type: String,
      default: null
    },
    tableInfo:{
      type :Object,
      default: null
    },
    paymentDT:{
      type:Object,
      default:null
    }
  },
  methods:{
    tableRowClassName({row}) {
      if (row.background === 'red') {
        return 'warning-row'
      }
    
      return ''
    }
  }
}
</script>

<style lang="scss" scoped>
.article{
  .article-title{
    display: flex; 
    justify-content: space-between;
    h2>span{
      font-size: 12px;
      margin-left: 20px;
      font-weight: normal;
    }
    .right{
      display: flex; 
      align-items: center;
      line-height: 40px;
      p{
        margin-left: 30px;
        &+.el-button{
          margin-left: 20px;
        }
      }
    } 
  }
}
.el-table tr.el-table__row.warning-row {
  background: #f6f3f2;
  td{
    border-bottom: 0px;
  }
}

// .list-talbe{
//   width: 100%;
//   border-spacing: 0;
//   thead{
//     background: #f6f3f2;
//     line-height: 40px;
//     th{border-top: 2px solid #7f7f7f;}
//   }
//   th,td{
//     padding:10px 10px;
//     line-height: 25px;
//     font-size: 12px;
//   }
//   td{
//     border-bottom: 1px solid #e5e5e5;
//     &.align-center { text-align: center }
//     &.align-right { text-align: right }
//   }
//   tr.warning-row{
//     background: #f6f3f2;
//     font-weight: bold;
//     td{
//       font-size: 14px;
//     } 
//   }
// }

.two-th-table{
  width: 100%; 
  border-spacing: 0;
  .table-list{
    &:first-child{
      th,td{
        border-top: 1px solid #e4dcd3;
      }
    }
    th{
      background: #e4dcd3; 
      border-right: 1px solid #fff; 
      border-top: 1px solid #fff;
      min-width: 140px;
    }
    th,td{
      padding:5px 15px;
      line-height: 25px;
      font-size: 14px;
    }
    td{
      width: 340px;
      border-bottom: 1px solid #e5e5e5;
      &:last-child{
        border-right: 1px solid #e5e5e5;
      }
    }
    .non{
    background: transparent;
    border-bottom: 1px solid #e5e5e5;
    &.border-right{
      border-right: 1px solid #e5e5e5;
    }
  }
  }
  
}
//   .accordion-table{
//     .el-table {
//     border:0px;
//     border-top: 2px solid #7f7f7f;
//     border-bottom: 2px solid #7f7f7f;
//     .el-table__body-wrapper{
//       max-height: 100%;
//     }
//     td{
//     border:0px;
//     border-bottom:1px solid #e5e5e5;
//     }
//   }
// }



</style>
