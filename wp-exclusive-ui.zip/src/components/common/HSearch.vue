<template>
  <div> 
    <div class="search">
      <h2>{{ title }}</h2>
      <el-input
        :value="value"
        style="margin-left: 20px; margin-right:5px;"
        @input="onInput"
        @keyup.enter.native="onEnter($event)"
      />
      <el-button
        v-if="activeButton"
        type="primary" 
        @click="onClick(value)"
      > 
        조회
      </el-button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HSearch',
  props: {
    title: {
      type: String,
      default: null
    },
    value: {
      type: String,
      default: null
    },
    onClick: {
      type: Function,
      default: null
    },
    activeButton: {
      type: Boolean,
      default: true
    }
  },
  data: () => ({
    // input: this.value
  }),
  methods: {
    onInput(value) {
      this.$emit('input', value)
    },
    onEnter(event) {
      const keyword = event.target.value
      this.$emit('enter', keyword)
    }
  }
}
</script>

<style lang="scss" scoped>
 .search{
    display: flex;
    align-items: center;
    /deep/.el-input {
      height: 40px;
      input.el-input__inner {
        height: 40px;
      }
    }
  }
  h2{
    line-height: 30px;
  }
</style>
