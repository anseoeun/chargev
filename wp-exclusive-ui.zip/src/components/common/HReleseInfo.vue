<template>
  <div>
    <el-form ref="info" :model="info" class="detail-form table-wrap">
      <el-row>
        <el-col :span="8">
          <el-form-item label="계약번호" v-if="info.contractPersonalCorporationCode!=='3'">{{ info.contractNumber }}</el-form-item>
          <el-form-item label="통합계약번호" v-if="info.contractPersonalCorporationCode==='3'">{{ info.groupContractNumber }}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="계약자">{{ info.contractPersonalCorporationCode!=='3'? info.contractorName : info.companyName +'('+info.companyNumber+')'}}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="계약 담당자">{{ info.consultantName }}</el-form-item>
        </el-col>  
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="온라인 진행상태">{{ info.contractPersonalCorporationCode!=='3'? info.onlineStatusName : info.onlineStatusNameList }}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="국판 진행상태">{{ info.contractPersonalCorporationCode!=='3'? info.legacyStatusName : info.legacyStatusNameList }}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item prop="customerTypeCode" label="고객구분">
            {{info.customerTypeName}}
          </el-form-item>
        </el-col>
      </el-row>
      <el-row v-if="info.contractPersonalCorporationCode!=='3'">
        <el-col :span="8">
          <el-form-item label="계약완료일">{{ info.payEndDate }}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="결제완료일">{{ info.paymentDate }}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="출고예정일">{{ info.exemplificationDateText }}</el-form-item>
        </el-col>
        <!-- <el-col :span="8">
          <el-form-item label="배정요청일">{{ info.assignRequestDate }}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="배정일">{{ info.assignDate }}</el-form-item>
        </el-col> -->
      </el-row>
      <!-- 법인전용 출고예정일을 위한 row 추가 2021-10-20 -->
      <el-row v-if="info.contractPersonalCorporationCode==='3'">
        <el-col :span="24">
          <el-form-item label="출고예정일">{{ info.exemplificationDateText }}</el-form-item>
        </el-col>
      </el-row>        

      <el-row v-if="info.contractPersonalCorporationCode!=='3'">
        <el-col :span="8">
          <el-form-item label="인도확정일">{{ info.carAcquireDecisionDate }}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="제작증 발급일">{{ info.makeDocumentIssueDate }}</el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="출고일">{{ info.releaseDate }}</el-form-item>
          
        </el-col>
      </el-row>  
    </el-form>
    <div class="article-title">
      <h2>진행 상황 메모</h2>
      <el-button type="primary" v-if="this.info.contractNumber" @click="memoPopAdd()">
        추가
      </el-button>
    </div>
    <el-table
      :data="messageData"
      max-height="450"
      empty-text="조회된 결과가 존재하지 않습니다."
      @row-click="onMemoRowClick"
    >
      <el-table-column prop="no" label="NO" width="50" align="center"></el-table-column>
      <el-table-column prop="eeNm" label="작성자" width="150" align="center"></el-table-column>
      <el-table-column prop="memoDate" label="작성일시" width="200" align="center"></el-table-column>
      <el-table-column prop="memoContent" label="내용" align="left" class-name="cell-ellips"></el-table-column>
      <el-table-column prop="memoSn" label="SN" v-if="false"></el-table-column>
      <el-table-column prop="eeNo" label="eeNo" v-if="false"></el-table-column>
    </el-table>

    <el-dialog title="메모 내용 작성/수정" :visible.sync="memoPopFlag">
      <div>
        <el-form
          ref="cashPaymentPop"
          class="detail-form"
          :model="memoInfo"
        >
          <el-row>
            <el-col :span="24">
              <el-form-item>
                <el-input
                  v-model="memoInfo.content"
                  type="textarea"
                />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <template slot="footer">
        <div>
          <el-button type="info" @click="memoPopFlag = false">취소</el-button>
          <el-button type="primary" v-if="memoInfo.serialNo === 0" @click="insertPopFlag = true">저장</el-button>
          <el-button type="primary" v-if="memoInfo.serialNo !== 0 && memoInfo.eeNo === userInfo.eeno" @click="updatePopFlag = true">수정</el-button>
          <el-button type="primary" v-if="memoInfo.serialNo !== 0 && memoInfo.eeNo === userInfo.eeno"  @click="deletePopFlag = true">삭제</el-button>
        </div>
      </template>
    </el-dialog>
    <!-- ######## 메모 저장 ########-->    
    <el-dialog custom-class="message" :visible.sync="insertPopFlag">
      <!-- Message -->
      입력하신 내용을 저장하시겠습니까?
      <!-- Popup Footer -->
      <template slot="footer">
        <el-button type="info" @click="insertPopFlag = false">
          취소
        </el-button>
        <el-button type="primary" @click="memoProcess('insert')">
          확인
        </el-button>
      </template>
    </el-dialog>
    <!-- ######## 메모 수정 ########-->  
    <el-dialog custom-class="message" :visible.sync="updatePopFlag">
      <!-- Message -->
      수정하신 내용을 저장하시겠습니까?
      <!-- Popup Footer -->
      <template slot="footer">
        <el-button type="info" @click="updatePopFlag = false">
          취소
        </el-button>
        <el-button type="primary" @click="memoProcess('update')">
          확인
        </el-button>
      </template>
    </el-dialog>
    <!-- ######## 메모 삭제 ######## -->    
    <el-dialog custom-class="message" :visible.sync="deletePopFlag">
      <!-- Message -->
      선택한 메모를 삭제하시겠습니까?
      <!-- Popup Footer -->
      <template slot="footer">
        <el-button type="info" @click="deletePopFlag = false">
          취소
        </el-button>
        <el-button type="primary" @click="memoProcess('delete')">
          확인
        </el-button>
      </template>
    </el-dialog>
    <!-- ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## -->    
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />
    <!-- ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## -->    
  </div>
</template>
<script>
/* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */      
import Loading from "~/components/popup/Loading.vue";
/* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */ 
import { mapState } from "vuex";     

export default {
  name: "HReleseInfo",
  /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
  components: {
    Loading
  },
  /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
  props: {
    info: {
      type: Object,
      default: null
    },
    contractorCount : {
      type: Number,
      default: 0
    },
    activeUserFlag: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      customerTypeCode: "",
      progressMemo: "",
      popVisible: false,
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */      
      popVisibleLoading: false,
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
      memoPopFlag: false,       
      messageData: [],
      memoInfo:{
        serialNo: 0,
        content: '',
        eeNo:'',
      },
      insertPopFlag: false,
      updatePopFlag: false,
      deletePopFlag: false,
    };
  },
  async created() {
    await this.getMemoList()
  },
  computed: {
    ...mapState({
      userInfo: state => state.userInfo
    }),
  },
  watch: {
    info: function() {
      this.customerTypeCode = this.info?this.info.customerTypeCode:""
      this.getMemoList()
    }
  },
  methods:  {
    memoPopAdd() {
      this.memoPopFlag = true
      this.memoInfo.serialNo = 0
      this.memoInfo.content = ''
    },
    async memoProcess(flag){

      //preCheck
      if(!this.preCheck()){
        return
      }

      if(flag == 'insert'){
        //Insert
        const insertParam = {
          saleContractNumber: this.info.contractNumber, 
          eeNo: this.userInfo.eeno, 
          memoContent: this.memoInfo.content
        }

        const [res1, err1] = await this.$https.post("/v2/exclusive/work/memoInsert", insertParam)

      } else if(flag == 'update'){
        //Update
        const updateParam = {
          memoSn : this.memoInfo.serialNo,
          saleContractNumber : this.info.contractNumber,
          eeNo: this.userInfo.eeno,
          memoContent: this.memoInfo.content
        }

        const [res2, err2] = await this.$https.post("/v2/exclusive/work/memoUpdate", updateParam)

      }else if(flag == 'delete'){
        //Delete
        const deleteParam = {
          memoSn : this.memoInfo.serialNo,
          saleContractNumber : this.info.contractNumber,
          eeNo: this.userInfo.eeno,
        }

        const [res3, err3] = await this.$https.post("/v2/exclusive/work/memoDelete", deleteParam)

      }

      this.memoPopFlag = false
      this.getMemoList()
    },
    async getMemoList() {
      if(this.info.contractNumber){
        const [res, err] = await this.$https.get(
          "/v2/exclusive/work/getMemoList",
          { saleContractNumber: this.info.contractNumber }
        )

        if(!err){
          this.messageData = res.data.map((el, idx) => {
            return {
              ...el,
              no: (res.data.length)-idx
            }
          })
        }
      }
    },
    onMemoRowClick(row, column){
      this.memoInfo.serialNo = row.memoSn
      this.memoInfo.content = row.memoContent
      this.memoInfo.eeNo = row.eeNo

      this.memoPopFlag = true
    },
    preCheck(){
      //팝업 close//////////////
      this.insertPopFlag = false
      this.updatePopFlag = false
      this.deletePopFlag = false
      /////////////////////////

      if(!this.memoInfo.content){
        alert('메모 내용을 입력해주세요')
        return false
      } else if( this.memoInfo.content && this.memoInfo.content.length > 1000) {
        alert('최대 1,000자까지 입력하실수 있습니다.')
        return false
      }

      return true
    }
  },
};
</script>

<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
