<template>
  <div>
    <el-table
      v-if="tableType === 'DefultTable'"
      ref="table"
      :data="tableDatas"
      max-height="300"
      highlight-current-row
      empty-text="조회 결과가 존재하지 않습니다."
      @selection-change="onSelectionChange"
      @current-change="onCurrentRow"
      @row-click="onRowClick"
    >
      <el-table-column
        v-for="(field, index) in tableHeader"
        :key="index"
        :type="field.type"
        :label="field.label"
        :prop="field.prop"
        :width="field.width"
        :align="field.align"
        :fixed="field.fixed"
      > 
        <template slot-scope="scope">
          <el-checkbox
            v-if="field.type === 'checkBox'"
            v-model="scope.row.isSelected"
            @change="onChange($event, scope.row)"
            @click.native.stop
          />
          <template 
            v-else-if="lineBreakCheck(scope.row[field.prop])"
          >
            {{ scope.row[field.prop].split('|')[0] }}<br />{{ scope.row[field.prop].split('|')[1] }}
          </template>
          <template v-else>
            {{ scope.row[field.prop] }}
          </template>
        </template>
          
        <slot
          v-if="field.type === 'button'"
          name="table1"
        ></slot>
      </el-table-column>
    </el-table>
    <el-table
      v-if="tableType === 'TwoHeadTable'"
      ref="table"
      :data="tableDatas"
      max-height="450"
      highlight-current-row
      :row-class-name="tableRowClassName"
      empty-text="조회 결과가 존재하지 않습니다."
      @select="onSelection"
      @select-all="onSelectionAll"
      @selection-change="onSelectionChange"
      @row-click="onRowClick"
      @sort-change="sortChanges"
    >
      <template v-for="(field, index) in tableHeader">
        <el-table-column
          v-if="field.children"
          :key="index"
          :type="field.type"
          :label="field.label"
          :prop="field.prop"
          :width="field.width"
          :align="field.align"
          :fixed="field.fixed"
          :sortable="field.sortable"
        >
          <template slot-scope="scope">
            <el-checkbox
              v-if="field.type === 'checkBox'"
              v-model="scope.row.isSelected"
              @change="onChange($event, scope.row)"
              @click.native.stop
            />
            <template v-else-if="field.type === 'link'">
              <a
                v-if="field.query"
                class="link"
                :href="`${field.link}?${field.query}=${scope.row[field.query]}`"
                target="_blank"
              >
                {{ scope.row[field.prop] }}
              </a>
              <a
                v-else-if="field.linkData"
                class="link"
                :href="field.link"
                target="_blank"
                @click="$utils.setSessionStorage({ [field.linkData]: scope.row[field.linkData] })"
              >
                {{ scope.row[field.prop] }}
              </a>
              <a
                v-else
                class="link"
                :href="`${field.link}`"
                target="_blank"
              >
                {{ scope.row[field.prop] }}
              </a>
            </template>
            <template v-else>
              {{ scope.row[field.prop] }}
            </template>
          </template>
          
          <el-table-column 
            v-for="(subField, subIndex) in field.children"
            :key="subIndex"
            :type="checkColumnType(subField.type)"
            :label="subField.label"
            :prop="subField.prop"
            :width="subField.width"
            :align="subField.align"
            :fixed="field.fixed"
            :sortable="subField.sortable"
          >
            <template 
              slot-scope="scope"
            >
              <template v-if="subField.type === 'link'">
                <a
                  v-if="subField.query"
                  class="link"
                  :href="`${subField.link}?${subField.query}=${scope.row[subField.query]}`"
                  target="_blank"
                >
                  {{ scope.row[subField.prop] }}
                </a>
                <a
                  v-else-if="subField.linkData"
                  class="link"
                  :href="subField.link"
                  target="_blank"
                  @click="$utils.setSessionStorage({ [subField.linkData]: scope.row[subField.linkData] })"
                >
                  {{ scope.row[subField.prop] }}
                </a>
                <a
                  v-else
                  class="link"
                  :href="`${subField.link}`"
                  target="_blank"
                >
                  {{ scope.row[subField.prop] }}
                </a>
              </template>
              <template v-else>
                {{ scope.row[subField.prop] }}
              </template>
            </template> 
            
            <slot
              v-if="subField.type === 'button'"
              name="table1"
            ></slot>
          </el-table-column>
        </el-table-column>
      </template>
    </el-table>
    <el-table
      v-if="tableType === 'SumTable'"
      ref="table"
      :data="tableDatas"
      show-summary
      max-height="450"
      @selection-change="onSelectionChange"
      @row-click="onRowClick"
    >
      <template v-for="(field, index) in tableHeader">
        <el-table-column
          v-if="field.children"
          :key="index"
          :type="field.type"
          :label="field.label"
          :prop="field.prop"
          :width="field.width"
          :align="field.align"
          :fixed="field.fixed"
        >
          <el-table-column 
            v-for="(subField, subIndex) in field.children"
            :key="subIndex"
            :type="subField.type"
            :label="subField.label"
            :prop="subField.prop"
            :width="subField.width"
            :align="subField.align"
          />
        </el-table-column>
      </template>
    </el-table>
  </div>  
</template>

<script>
export default {
  name: 'HTable',
  props: 
  {
    tableHeader: {
      type: Array,
      default: null
    },
    tableDatas: {
      type: Array,
      default: null
    },
    tableType: {
      type: String,
      default: 'A'
    },
    tableLable: {
      type: String,
      default: null
    },
    tableHeaderType: {
      type: String,
      default: null
    },
    handleSelection: {
      type: Function,
      default: null
    },
    handleSelectionAll: {
      type: Function,
      default: null
    },
    handleSelectionChange: {
      type: Function,
      default: null
    },
    handleRowClick: {
      type: Function,
      default: null
    },
    handleCurrentRow: {
      type: Function,
      default: null
    },
    handleChange: {
      type: Function,
      default: null
    },
    sortChange: {
      type: Function,
      default: null
    }
  },
  methods: {
    onChange($event, row) {
      this.handleChange($event, row)
    },
    onSelection(val, row) {
      this.handleSelection(val, row)
    },
    onSelectionAll(val) {
      this.handleSelectionAll(val)
    },
    onSelectionChange(val) {
      this.handleSelectionChange(val)
    },
    onRowClick(row, col, event) {
      this.handleRowClick && this.handleRowClick(row, col, event)
    },
    onCurrentRow(val) {
      this.handleCurrentRow(val)
    },
    toggleAllSelection() {
      this.$refs.table.toggleAllSelection()
    },
    toggleRowSelection(val) {
      this.$refs.table.toggleRowSelection(val)
    },
    clearSelection() {
      this.$refs.table.clearSelection()
    },
    tableRowClassName({row}) {
      if(row.bold === 'bold') {
        return 'bold'
      }
    },
    lineBreakCheck(val) {
      let bResult = false, data = '' + val
      if(data && data.split('|').length > 1) { bResult = true }
      return bResult
    },
    sortChanges(props) {
      this.sortChange(props)
    },
    checkColumnType(type = '') {
      const acceptTypeArr = ['selection', 'index', 'expand']
      return acceptTypeArr.includes(type) ? type : ''
    }
  },
}
</script>
