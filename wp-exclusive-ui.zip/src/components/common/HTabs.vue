<template>
  <el-tabs
    type="card" 
    stretch
  >
    <el-tab-pane
      v-for="(tabInfo, index) in tabDatas" 
      :key="index"
      :label="tabInfo.label"
    />
    <slot name="tabContent" />
  </el-tabs>
</template>

<script>
export default {
  name: 'HTabs',
  props:{
    tabDatas: {
      type: Array,
      default: null
    }
  },
  data() {
    return {
      activeName: 'first'
    }
  }
}
</script>

<style>

</style>
