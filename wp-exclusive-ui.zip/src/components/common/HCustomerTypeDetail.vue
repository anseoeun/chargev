<template>
  <el-select
    v-model="detailTypeCode"
    placeholder="선택"
    style="margin-left: 8px;width:170px"
    :disabled="detailDisable"
    @change="onDetailTypeChange"
  >
    <el-option
      v-for="{ value, label } in detailCustomerTypeCode"
      :key="value"
      :value="value"
      :label="label"
    />
  </el-select>
</template>
<script>
export default {
  name: "HCustomerTypeDetail",
  props: {
    value: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      detailCustomerTypeCode: [{ value: "all", label: "선택" }],
      detailDisable: true,
      detailTypeCode: ""
    };
  },
  methods: {
    changeCustomerType(customerTypeCode) {
      this.detailTypeCode = "all";
      this.detailCustomerTypeCode = [{ value: "all", label: "선택" }];
      this.detailDisable = true;

      if (customerTypeCode === "CA1") {
        this.detailCustomerTypeCode.push({
          value: "Y",
          label: "비영리법인"
        });
        this.detailDisable = false;
      } else if (customerTypeCode === "CR1") {
        this.detailCustomerTypeCode.push(
          {
            value: "1",
            label: "장기"
          },
          {
            value: "2",
            label: "단기"
          }
        );
        this.detailDisable = false;
      }
    },
    onDetailTypeChange(value) {
      this.$emit("detailTypeChange", value);
    }
  }
};
</script>
