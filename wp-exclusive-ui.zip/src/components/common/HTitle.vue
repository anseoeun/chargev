<template>
  <div class="article-title">
    <h2 :class="`${agree === 'Y' ? 'fl' : ''}`">{{ title }}</h2>
    <el-button
      type="info"
      class="btn-small space"
      @click="$emit('agreePopOpen')"
      v-if="agree === 'Y'"
      >정보 활용동의</el-button
    >
  </div>
</template>
<script>
export default {
  name: "HTitle",
  props: {
    title: {
      type: String,
      default: null
    },
    agree: {
      type: String,
      default: null
    }
  }
};
</script>

<style lang="scss" scoped>
.article-title {
  margin: 10px 0;
}
@import "~/assets/style/pages/detail.scss";
</style>
