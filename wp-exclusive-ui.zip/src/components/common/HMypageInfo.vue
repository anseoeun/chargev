<template>
  <div>
    <el-form
      ref="info"
      :model="info"
      class="detail-form table-wrap"
    >
      <el-row>
        <el-col :span="8">
          <el-form-item label="계약번호">
            {{ info.contractNumber }}
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="계약자">
            {{ info.contractorName }}
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="계약 담당자">
            {{ info.consultantName }}
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="온라인 진행상태">
            {{ info.onlineStatusName }}
          </el-form-item>
        </el-col>

        <el-col :span="8">
          <el-form-item label="국판 진행상태">
            {{ info.legacyStatusName }}
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="고객구분">
            {{ info.customerType }}
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="계약완료일">
            {{ info.contractCompleteDate }}
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="결제완료일">
            {{ info.payEndDate }}
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="출고일">
            {{ info.releaseOrExpectDate }}
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="인도확정일">
            {{ info.carAcquireDecisionDate }}
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="제작증발급일">
            {{ info.prdCertificationIssueDate }}
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>
<script>
export default {
  name: 'HMypageInfo',
  props: {
    info: {
      type: Object,
      default: null
    }
  },
  methods: {
    onChange(event, val){
      console.log('info ==> ' + JSON.stringify(this.$props.info))
      this.$emit('valChange', val)
    },
  }
}
</script>

<style lang="scss" scoped>
.detail-form > .el-row > .el-col > .el-form-item > .el-form-item__label, .detail-form > .el-form-item > .el-form-item__label{
  width: 140px;
}
</style>
