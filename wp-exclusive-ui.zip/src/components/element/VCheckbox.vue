<template>
  <div :class="`checkbox ${checkType}`">
    <el-checkbox v-if="oneCheck" v-model="isChecked" :disabled="disabled" :custom-style="customStyle" @change="onChange">
      <slot></slot>
    </el-checkbox>

    <el-checkbox-group v-else v-model="selected" :disabled="disabled" :custom-style="customStyle">
      <el-checkbox v-if="allChkName !== ''" label="all" :disabled="disabled" :custom-style="customStyle" @change="allChange">
        {{
        allChkName
        }}
      </el-checkbox>
      <el-checkbox
        v-for="(item, index) in data"
        :key="index"
        :label="item[valueKey]"
        :disabled="item.disabled || item.fixed"
        :custom-style="item.customStyle"
        @change="onChange($event, item[valueKey])"
      >
        <slot v-if="customLabel" :item="item"></slot>
        <span v-else>{{ item[labelKey] }}</span>
      </el-checkbox>
    </el-checkbox-group>
  </div>
</template>

<script>
export default {
  model: {
    prop: 'selected',
    event: 'change'
  },
  props: {
    value: {
      type: Array,
      default: () => []
    },
    // eslint-disable-next-line
    checked: [String, Boolean],
    allChkName: {
      type: String,
      default: ''
    },
    trueValue: {
      type: String,
      default: null
    },
    valueKey: {
      type: String,
      default: 'value'
    },
    labelKey: {
      type: String,
      default: 'label'
    },
    disabled: {
      type: Boolean,
      default: false
    },
    customLabel: {
      type: Boolean,
      default: false
    },
    checkType: {
      type: String,
      default: ''
    },
    data: {
      type: Array,
      default: () => []
    },
    fixedSelected: {
      type: Array,
      default: () => []
    },
    oneCheck: {
      type: Boolean,
      default: false
    },
    customStyle: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      selected: (this.fixedSelected)? this.fixedSelected : [],
      isChecked: null,
      checkAll: null
    }
  },
  watch: {
    value(newValue, oldValue) {
      //console.log('---[vC]  watch -  value :', newValue)
      const diffList = newValue.filter((val, index) => val !== oldValue[index])
      if (diffList.length) {
        this.selected = [...newValue]
      }
    },
    checked(newValue, oldValue) {
      if (newValue !== oldValue) {
        this.isChecked =
          typeof this.checked === 'boolean' ? newValue : newValue !== '' && newValue !== undefined && newValue !== null
      }
    },
    fixedSelected(newValue, oldValue) {
      if(newValue.length > 0) {
        this.selected = newValue
        //console.log('---[vC]  watch -  fixedSelected ', newValue)
  
        newValue.forEach((code)=>{
          const idx = this.data.findIndex( (o) => code === o[this.valueKey] ) 
          //this.data[idx].disabled = true
          this.$set(this.data, idx , Object.assign({}, this.data[idx], { disabled : true }))
          //console.log('---[vC]  watch ------------- DISABLED!',idx , this.data[idx].disabled)
        })
      }
    },
    data(value){
      if(value){
        //console.log('---[vC] watch - optionList', value.map((obj, idx) => (obj.disabled)?`${idx}`:'') )
      }
    }
  },
  created() {
    if (this.oneCheck) {
      const checked =
        typeof this.checked === 'boolean'
          ? this.checked
          : this.checked !== '' && this.checked !== undefined && this.checked !== null
      if (this.isChecked !== checked) {
        this.isChecked = checked
        this.onChange()
      }
    } else {
      this.selected = [...this.value]
      if (this.selected.length) {
        this.onChange()
      }
    }
  },
  mounted() {
    this.$EventBus && this.$EventBus.$on('resetSeleted', () => {
			this.resetSeleted()
		})
    this.$EventBus && this.$EventBus.$on('addSeleted', () => {
      this.addSeleted()
    })
    //console.log('---[vC] mounted !!! ----- selected    :::', this.selected)
  },
  beforeDestroy() {
    this.$EventBus && this.$EventBus.$off('resetSeleted')
    this.$EventBus && this.$EventBus.$off('addSeleted')
  },
  methods: {
    onChange(chk, val) {
      if (this.oneCheck) {
        const value = typeof this.checked === 'boolean' ? this.isChecked : this.isChecked ? this.trueValue : ''
        this.$emit('update:checked', value)
        this.$emit('change', value)
      } else {
        this.$emit('input', this.selected)
        this.$emit('change', this.selected)
      }
      if (chk === true) this.$emit('checked', val)
      else if (chk === false) this.$emit('unchecked', val)
    },
    allChange(val) {
      let allChk = val ? ['all'] : []

      if (val)
        this.data.forEach((element) => {
          allChk.push(element.value)
        })
      this.selected = allChk
      this.$emit('input', this.selected)
      this.$emit('change', this.selected)
    },
    reload() {
      this.selected = this.value
    },
    resetSeleted() {
      //console.log('resetSeleted')
      this.selected = []
    },
    addSeleted(o = null) {
      if(o) this.selected.push(o)
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~/assets/style/common/mixin.scss';
@import '~/assets/style/common/var.scss';
@import '~/assets/style/components/checkbox.scss';
</style>
