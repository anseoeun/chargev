<template>
  <div :class="`radio ${radioType}`">
    <el-radio-group v-model="selected" :disabled="disabled">
      <el-radio
        v-for="(item, index) in data"
        :key="index"
        :label="item[valueKey]"
        :disabled="item.disabled"
        @change="onChange"
      >
        <slot v-if="customLabel" :item="item"></slot>
        <span v-else>{{ item[labelKey] }}</span>
      </el-radio>
    </el-radio-group>
  </div>
</template>

<script>
export default {
  props: {
    value: {
      type: String,
      default: ''
    },
    valueKey: {
      type: String,
      default: 'value'
    },
    labelKey: {
      type: String,
      default: 'label'
    },
    disabled: {
      type: Boolean,
      default: false
    },
    customLabel: {
      type: Boolean,
      default: false
    },
    radioType: {
      type: String,
      default: ''
    },
    data: {
      type: Array,
      default: () => []
    }
  },

  data() {
    return {
      selected: ''
    }
  },

  watch: {
    value(newValue, oldValue) {
      if (newValue !== oldValue) {
        this.selected = newValue
      }
    }
  },

  created() {
    this.selected = this.value === '' ? this.data[0][this.valueKey] : this.value
    if (this.selected !== '') {
      this.onChange(this.selected)
    }
  },

  methods: {
    onChange(value) {
      this.$emit('input', value)
      this.$emit('change', value)
    }
  }
}
</script>

<style lang="scss">
@import '~/assets/style/common/mixin.scss';
@import '~/assets/style/common/var.scss';

// Radio & Checkbox - (similar Element-ui base / add after 'el-')
</style>
