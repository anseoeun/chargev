<template>
  <div
    :class="`list-item ${itemType} ${isActive ? 'active' : ''} ${disabled ? 'disabled' : ''}`"
    :data-id="dataId"
    :data-seq="dataSeq"
  >
    <div v-if="!disabled && isBtnType" class="list-title list-title2">
      <div v-if="$slots.title">
        <slot name="title"></slot>
        <span class="title2-btn" @click="onItemClick(dataId, dataSeq)"></span>
      </div>
      <div v-else class="title">
        <label v-if="label !== null">{{ label }}</label>
        <slot v-else name="label"></slot>
        <span class="title2-btn" @click="onItemClick(dataId, dataSeq)"></span>
      </div>
    </div>

    <button v-else-if="!disabled" type="button" class="list-title" @click="onItemClick(dataId, dataSeq)">
      <slot v-if="$slots.title" name="title"></slot>
      <div v-else class="title">
        <label v-if="label !== null">{{ label }}</label>
        <slot v-else name="label"></slot>
      </div>
    </button>

    <div v-else class="list-title">
      <slot v-if="$slots.title" name="title"></slot>
      <div v-else class="title">
        <label v-if="label !== null">{{ label }}</label>
        <slot v-else name="label"></slot>
      </div>
    </div>

    <slot name="fixed" class="list-fix"></slot>

    <slot v-if="$slots.contents && isActive" name="contents"></slot>
    <div v-if="!(!contents && disabled) && isActive" class="conts">
      <slot></slot>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    dataId: {
      type: String,
      default: ''
    },
    dataSeq: {
      type: String,
      default: ''
    },
    label: {
      type: String,
      default: null
    },
    itemType: {
      type: String,
      default: ''
    },
    disabled: {
      type: Boolean,
      default: false
    },
    contents: {
      type: Boolean,
      default: true
    },
    isBtnType: {
      type: Boolean,
      default: false
    },
    preventActive: {
      type: Boolean,
      default: true
    }
  },
  computed: {
    isActive() {
      const result = ( this.$parent.selected.includes(this.dataId) && this.preventActive )
      return result
    }
  },
  methods: {
    onItemClick(dataId, dataSeq, value) {
      // eslint-disable-next-line no-useless-call
      if (!value && this.preventActive) {
        this.$parent.$emit.apply(this.$parent, ['item-click', dataId])
        this.$emit('toggle', dataId, dataSeq)
      }
    }
  }
}
</script>

<style lang="scss">
@import '~/assets/style/common/mixin.scss';
@import '~/assets/style/common/var.scss';
</style>
