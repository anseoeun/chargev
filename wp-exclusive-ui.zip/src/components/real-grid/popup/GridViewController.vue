<template>
		<v-popup :visible="visible" :width="'776px'" @close="$emit('close')">
  >
    <template slot="body">
      
      <!-- <label style="margin-right: 20px;">틀 고정</label><el-select
        v-model="fixedOptionCount"
        class="edit-select"
        placeholder="틀 고정"
      >
        <el-option
          v-for="item in fixedOptionCountList"
          :key="item"
          :value="item"
          :label="item"
        />
      
      </el-select> -->
      <div>
      <ul style="height: 500px; overflow-y: scroll;margin-top: 20px;border: solid 1px #eee;padding: 20px;">
        <template v-for="{ items, index } in columnList">
          <li v-if="items.title" :key="index" style="padding: 10px;">
            <label>{{ items.title }}</label>
          </li>
          <li :key="index" :style="items.subMenu? 'padding-left: 45px;display: inline-block;width: 50%;padding-bottom: 5px;' : 'padding-left: 30px;display: inline-block;width: 50%;padding-bottom: 5px;'" class="items">
            <el-checkbox
              :checked.sync="items.visible"
              @change="onChangeVisible($event, items)"
            >
              {{ items.text }}
            </el-checkbox>
          </li>
        </template>
      </ul>
      </div>
			<el-button
				type="primary"
				style="margin-top: 20px;width: 100%;"
			@click="save()">
			저장
			</el-button>
    </template>
  </v-popup>
</template>

<script>
import VPopup from '~/components/element/VPopup.vue'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    gridView: {
      type: Object,
      default: () =>{}
    },
    fixedOptionCount: {
      type: Number,
      default: 2
    },
    columns: {
      type: Array,
      default: () =>[]
    }
  },
  data() {
    return {
      columnList: [],
      fixedOptionCountList: [0, 1, 2, 3, 4, 5],
      count: 0
    }
  },
  watch: {
    visible(val) {
      if(val)
        this.visibleList()
    }
  },
  methods: {
    
    visibleList() {
      if(!this.gridView) return []
      const columns = this.gridView.saveColumnLayout()
      const list = []
      let first = true
      let noTitle = false
      columns.forEach(e => {
        if(e.items && e.items.length) {
          first = true
          noTitle = true
          e.items.forEach(e2 => {
            const val = {}
            if(first) {
              val['items'] = {column: e2.column, visible: e2.visible, text: this.columns.find((c) => c.fieldName === e2.column).header.text, title: e.header.text, subMenu: true}
            } else {
              val['items'] = {column: e2.column, visible: e2.visible, text: this.columns.find((c) => c.fieldName === e2.column).header.text, subMenu: true}
            }
            first = false
            val['index'] = this.count++
            list.push(val)
          })
        } else {
          const val = {}
          if(noTitle) {
            val['items'] = {column: e.column, visible: e.visible, text: this.columns.find((c) => c.fieldName === e.column).header.text, title: ' '}
          } else {
            val['items'] = {column: e.column, visible: e.visible, text: this.columns.find((c) => c.fieldName === e.column).header.text}
          }
          noTitle= false
          val['index'] = this.count++
          list.push(val)
        }
      })
      this.columnList = list
    },
    onChangeVisible(el, items) {
      items.visible = el
      console.log(this.columnList)
    },
    save() {
      const columns2 = this.gridView.saveColumnLayout()
      columns2.forEach(e => {
        if(e.items && e.items.length) {
          e.items.forEach(e2 => {
            e2.visible = this.columnList.find((c) => c.items.column === e2.column).items.visible
          })
        } else {
          e.visible = this.columnList.find((c) => c.items.column === e.column).items.visible
        }
      })
      this.gridView.setColumnLayout(columns2)
      
      this.gridView.setFixedOptions({colCount: this.fixedOptionCount})
      this.$emit('confirm', this.fixedOptionCount)
    }
  },
}
</script>
