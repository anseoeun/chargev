<template>
	<section>
		<div id="contract-grid" style="width: 100%;height: 700px;"></div>
		<grid-visible-controller
			:visible="gridVisibleControllerVisible"
			:grid-view="gridView"
			:columns="columns"
			:fixed-option-count="fixedOptionCount"
			@confirm="saveGridLayout"
			@close="gridVisibleControllerVisible = false"
					/>
	</section>
</template>


<script>

import { mapGetters } from 'vuex'
import GridVisibleController from '~/components/real-grid/popup/GridViewController.vue'
export default {
  components: {
    GridVisibleController
  },
  props: {
    menuId: {
      type: String,
      default: '',
      required: true
    },
    tableData: {
      type: Array,
      default: () =>[],
      required: true
    }
  },
  data() {
    return {
      gridVisibleControllerVisible: false,
      columns: [],
      layout: [],
      provider: {},
      gridView: {},
      fixedOptionCount: 2
    }
  },
  computed: {
    ...mapGetters(
      ['userInfo']
    )
  },
  watch: {
    tableData(val) {
      if(this.provider) {
        this.provider.clearRows()
        if(val)
          this.provider.setRows(val)
      }
    }
  },
  async mounted() {

    this.provider = new RealGrid.LocalDataProvider(false)
    this.gridView = new RealGrid.GridView('contract-grid')
    this.gridView.setDataSource(this.provider)
    const fields = [
      {
        fieldName: 'contractNumber',
        dataType: 'text',
      },
      {
        fieldName: 'onlineStatusName',
        dataType: 'text',
      },
      {
        fieldName: 'legacyStatusName',
        dataType: 'text',
      },
      {
        fieldName: 'depositYn',
        dataType: 'text',
      },
      {
        fieldName: 'type',
        dataType: 'text',
      },
      {
        fieldName: 'customerTypeName',
        dataType: 'text',
      },
      {
        fieldName: 'groupContractNumber',
        dataType: 'text',
      },
      {
        fieldName: 'corporateRegistNo',
        dataType: 'text',
      },
      {
        fieldName: 'companyName',
        dataType: 'text',
      },
      {
        fieldName: 'representativeName',
        dataType: 'text',
      },
      {
        fieldName: 'loginId',
        dataType: 'text',
      },
      {
        fieldName: 'contractorName',
        dataType: 'text',
      },
      {
        fieldName: 'customerMobile',
        dataType: 'text',
      },
      {
        fieldName: 'customerEamil',
        dataType: 'text',
      },
      {
        fieldName: 'companyNumber',
        dataType: 'text',
      },
      {
        fieldName: 'contractCancleName',
        dataType: 'text',
      },
      {
        fieldName: 'stockType',
        dataType: 'text',
      },
      {
        fieldName: 'carSaleCode',
        dataType: 'text',
      },
      {
        fieldName: 'carColor',
        dataType: 'text',
      },
      {
        fieldName: 'csptCode',
        dataType: 'text',
      },
      {
        fieldName: 'acquisitionTypeCode',
        dataType: 'text',
      },
      {
        fieldName: 'deliveryPlace',
        dataType: 'text',
      },
      {
        fieldName: 'contractDate',
        dataType: 'text',
      },
      {
        fieldName: 'contractCompletionDate',
        dataType: 'text',
      },
      {
        fieldName: 'assignRequestDate',
        dataType: 'text',
      },
      {
        fieldName: 'assignDate',
        dataType: 'text',
      },
      {
        fieldName: 'payExpireDate',
        dataType: 'text',
      },
      {
        fieldName: 'payStartDate',
        dataType: 'text',
      },
      {
        fieldName: 'payEndDate',
        dataType: 'text',
      },
      {
        fieldName: 'releaseOrExpectDate',
        dataType: 'text',
      },
      {
        fieldName: 'craftCertificateDate',
        dataType: 'text',
      },
      {
        fieldName: 'cancelDate',
        dataType: 'text',
      },
      {
        fieldName: 'carPrice',
        dataType: 'text',
      },
      {
        fieldName: 'contractPrice',
        dataType: 'text',
      },
      {
        fieldName: 'discountPrice',
        dataType: 'text',
      },
      {
        fieldName: 'usePoint',
        dataType: 'text',
      },
      {
        fieldName: 'taxReduction',
        dataType: 'text',
      },
      {
        fieldName: 'deliveryPrice',
        dataType: 'text',
      },
      {
        fieldName: 'insurancePayment',
        dataType: 'text',
      },
      {
        fieldName: 'installmentType',
        dataType: 'text',
      },
      {
        fieldName: 'installment',
        dataType: 'text',
      },
      {
        fieldName: 'pgsStCd',
        dataType: 'text',
      },
      {
        fieldName: 'pvDate',
        dataType: 'text',
      },
      {
        fieldName: 'cardPayment',
        dataType: 'text',
      },
      {
        fieldName: 'cashPayment',
        dataType: 'text',
      },
      {
        fieldName: 'consultantId',
        dataType: 'text',
      },
      {
        fieldName: 'consultantName',
        dataType: 'text',
      }
    ]
    this.columns = [
      {
        name: 'contractNumber',
        fieldName: 'contractNumber',
        type: 'data',
        width: '110',
        header: {
          text: '계약번호',
        }
      },
      {
        name: 'onlineStatusName',
        fieldName: 'onlineStatusName',
        type: 'data',
        width: '170',
        header: {
          text: '온라인',
        }
      },
      {
        name: 'legacyStatusName',
        fieldName: 'legacyStatusName',
        type: 'data',
        width: '100',
        header: {
          text: '국판',
        }
      },
      {
        name: 'depositYn',
        fieldName: 'depositYn',
        type: 'data',
        width: '100',
        header: {
          text: '무통장입금여부',
        }
      },
      {
        name: 'type',
        fieldName: 'type',
        type: 'data',
        width: '150',
        header: {
          text: '유형',
        }
      },
      {
        name: 'customerTypeName',
        fieldName: 'customerTypeName',
        type: 'data',
        width: '100',
        header: {
          text: '고객구분',
        }
      },
      {
        name: 'groupContractNumber',
        fieldName: 'groupContractNumber',
        type: 'data',
        width: '120',
        header: {
          text: '통합계약번호',
        }
      },
      {
        name: 'corporateRegistNo',
        fieldName: 'corporateRegistNo',
        type: 'data',
        width: '120',
        header: {
          text: '법인번호',
        }
      },
      {
        name: 'companyName',
        fieldName: 'companyName',
        type: 'data',
        width: '120',
        header: {
          text: '상호',
        }
      },
      {
        name: 'representativeName',
        fieldName: 'representativeName',
        type: 'data',
        width: '120',
        header: {
          text: '대표자명',
        }
      },
      {
        name: 'loginId',
        fieldName: 'loginId',
        type: 'data',
        width: '200',
        header: {
          text: '회원ID',
        }
      },
      {
        name: 'contractorName',
        fieldName: 'contractorName',
        type: 'data',
        width: '120',
        header: {
          text: '이름',
        }
      },
      {
        name: 'customerMobile',
        fieldName: 'customerMobile',
        type: 'data',
        width: '150',
        header: {
          text: '휴대전화',
        }
      },
      {
        name: 'customerEamil',
        fieldName: 'customerEamil',
        type: 'data',
        width: '200',
        header: {
          text: '이메일',
        }
      },
      {
        name: 'companyNumber',
        fieldName: 'companyNumber',
        type: 'data',
        width: '180',
        header: {
          text: '사업자번호',
        }
      },
      {
        name: 'contractCancleName',
        fieldName: 'contractCancleName',
        type: 'data',
        width: '300',
        header: {
          text: '취소사유',
        }
      },
      {
        name: 'stockType',
        fieldName: 'stockType',
        type: 'data',
        width: '100',
        header: {
          text: '재고구분',
        }
      },
      {
        name: 'carSaleCode',
        fieldName: 'carSaleCode',
        type: 'data',
        width: '150',
        renderer: {
     	   showTooltip: true //툴팁 표시 여부
        },
        header: {
          text: '판매코드',
        }
      },
      {
        name: 'carColor',
        fieldName: 'carColor',
        type: 'data',
        width: '100',
        header: {
          text: '칼라',
        }
      },
      {
        name: 'csptCode',
        fieldName: 'csptCode',
        type: 'data',
        width: '100',
        header: {
          text: 'TUIX',
        }
      },
      {
        name: 'acquisitionTypeCode',
        fieldName: 'acquisitionTypeCode',
        type: 'data',
        width: '100',
        header: {
          text: '인수유형',
        }
      },
      {
        name: 'deliveryPlace',
        fieldName: 'deliveryPlace',
        type: 'data',
        width: '200',
        header: {
          text: '탁송지',
        }
      },
      {
        name: 'contractDate',
        fieldName: 'contractDate',
        type: 'data',
        width: '100',
        header: {
          text: '계약시작일',
        }
      },
      {
        name: 'contractCompletionDate',
        fieldName: 'contractCompletionDate',
        type: 'data',
        width: '100',
        header: {
          text: '계약완료일',
        }
      },
      {
        name: 'assignRequestDate',
        fieldName: 'assignRequestDate',
        type: 'data',
        width: '100',
        header: {
          text: '배정 요청일',
        }
      },
      {
        name: 'assignDate',
        fieldName: 'assignDate',
        type: 'data',
        width: '100',
        header: {
          text: '배정일',
        }
      },
      {
        name: 'payExpireDate',
        fieldName: 'payExpireDate',
        type: 'data',
        width: '150',
        header: {
          text: '결제기한일',
        }
      },
      {
        name: 'payStartDate',
        fieldName: 'payStartDate',
        type: 'data',
        width: '150',
        header: {
          text: '결제시작일',
        }
      },
      {
        name: 'payEndDate',
        fieldName: 'payEndDate',
        type: 'data',
        width: '150',
        header: {
          text: '결제완료일',
        }
      },
      {
        name: 'releaseOrExpectDate',
        fieldName: 'releaseOrExpectDate',
        type: 'data',
        width: '150',
        header: {
          text: '출고일/출고예정일',
        }
      },
      {
        name: 'craftCertificateDate',
        fieldName: 'craftCertificateDate',
        type: 'data',
        width: '100',
        header: {
          text: '제작증 발급일',
        }
      },
      {
        name: 'cancelDate',
        fieldName: 'cancelDate',
        type: 'data',
        width: '150',
        header: {
          text: '해약/매취일',
        }
      },
      {
        name: 'carPrice',
        fieldName: 'carPrice',
        type: 'data',
        width: '150',
        header: {
          text: '차량가격',
        }
      },
      {
        name: 'contractPrice',
        fieldName: 'contractPrice',
        type: 'data',
        width: '150',
        header: {
          text: '계약금',
        }
      },
      {
        name: 'discountPrice',
        fieldName: 'discountPrice',
        type: 'data',
        width: '150',
        header: {
          text: '할인액',
        }
      },
      {
        name: 'usePoint',
        fieldName: 'usePoint',
        type: 'data',
        width: '150',
        header: {
          text: '포인트',
        }
      },
      {
        name: 'taxReduction',
        fieldName: 'taxReduction',
        type: 'data',
        width: '150',
        header: {
          text: '감면액',
        }
      },
      {
        name: 'deliveryPrice',
        fieldName: 'deliveryPrice',
        type: 'data',
        width: '150',
        header: {
          text: '탁송료',
        }
      },
      {
        name: 'insurancePayment',
        fieldName: 'insurancePayment',
        type: 'data',
        width: '150',
        header: {
          text: '의무보험료',
        }
      },
      {
        name: 'installmentType',
        fieldName: 'installmentType',
        type: 'data',
        width: '100',
        header: {
          text: '할부유형',
        }
      },
      {
        name: 'installment',
        fieldName: 'installment',
        type: 'data',
        width: '150',
        header: {
          text: '할부금',
        }
      },
      {
        name: 'pgsStCd',
        fieldName: 'pgsStCd',
        type: 'data',
        width: '120',
        header: {
          text: '할부진행상태',
        }
      },
      {
        name: 'pvDate',
        fieldName: 'pvDate',
        type: 'data',
        width: '150',
        header: {
          text: 'PV진행일자',
        }
      },
      {
        name: 'cardPayment',
        fieldName: 'cardPayment',
        type: 'data',
        width: '150',
        header: {
          text: '카드 결제액',
        }
      },
      {
        name: 'cashPayment',
        fieldName: 'cashPayment',
        type: 'data',
        width: '150',
        header: {
          text: '현금 입금액',
        }
      },
      {
        name: 'consultantId',
        fieldName: 'consultantId',
        type: 'data',
        width: '100',
        header: {
          text: '사번',
        }
      },
      {
        name: 'consultantName',
        fieldName: 'consultantName',
        type: 'data',
        width: '80',
        header: {
          text: '성명',
        }
      }
    ]
    this.layout = [
      {column: 'contractNumber', cellWidth: 110},
      {
        name: 'contractStatus',
        direction: 'horizontal',
        items: [
          {column: 'onlineStatusName', cellWidth: 170},
          {column: 'legacyStatusName', cellWidth: 100}
        ],
        header: {
          text: '진행상태'
        }
      },
      {
        name: 'contractInfo',
        direction: 'horizontal',
        items: [
          {column: 'depositYn', cellWidth: 100},
          {column: 'type', cellWidth: 150},
          {column: 'customerTypeName', cellWidth: 100},
          {column: 'groupContractNumber', cellWidth: 120},
          {column: 'corporateRegistNo', cellWidth: 120},
          {column: 'companyName', cellWidth: 120},
          {column: 'representativeName', cellWidth: 120},
          {column: 'loginId', cellWidth: 186},
          {column: 'contractorName', cellWidth: 120},
          {column: 'customerMobile', cellWidth: 150},
          {column: 'customerEamil', cellWidth: 200},
          {column: 'companyNumber', cellWidth: 180},
          {column: 'contractCancleName', cellWidth: 300}
        ],
        header: {
          text: '계약정보'
        }
      },
      {
        name: 'carInfo',
        direction: 'horizontal',
        items: [
          {column: 'stockType', cellWidth: 100},
          {column: 'carSaleCode', cellWidth: 150},
          {column: 'carColor', cellWidth: 100},
          {column: 'csptCode', cellWidth: 100}
        ],
        header: {
          text: '차량정보'
        }
      },
      {column: 'acquisitionTypeCode', cellWidth: 100},
      {column: 'deliveryPlace', cellWidth: 200},
      {column: 'contractDate', cellWidth: 100},
      {column: 'contractCompletionDate', cellWidth: 100},
      {column: 'assignRequestDate', cellWidth: 100},
      {column: 'assignDate', cellWidth: 100},
      {column: 'payExpireDate', cellWidth: 150},
      {column: 'payStartDate', cellWidth: 150},
      {column: 'payEndDate', cellWidth: 150},
      {column: 'releaseOrExpectDate', cellWidth: 150},
      {column: 'craftCertificateDate', cellWidth: 100},
      {column: 'cancelDate', cellWidth: 150},
      {
        name: 'priceInfo',
        direction: 'horizontal',
        items: [
          {column: 'carPrice', cellWidth: 150},
          {column: 'contractPrice', cellWidth: 150},
          {column: 'discountPrice', cellWidth: 150},
          {column: 'usePoint', cellWidth: 150},
          {column: 'taxReduction', cellWidth: 150},
          {column: 'deliveryPrice', cellWidth: 150},
          {column: 'insurancePayment', cellWidth: 150},
          {column: 'installmentType', cellWidth: 100},
          {column: 'installment', cellWidth: 150},
          {column: 'pgsStCd', cellWidth: 120},
          {column: 'pvDate', cellWidth: 150},
          {column: 'cardPayment', cellWidth: 150},
          {column: 'cashPayment', cellWidth: 150}
        ],
        header: {
          text: '결제 정보'
        }
      },
      {
        name: 'priceInfo',
        direction: 'horizontal',
        items: [
          {column: 'consultantId', cellWidth: 100},
          {column: 'consultantName', cellWidth: 80}
        ],
        header: {
          text: '업무담당자'
        }
      }

    ]
    this.gridView.displayOptions.emptyMessage = '표시할 데이타가 없습니다.'
    this.gridView.header.height = 80
    this.gridView.displayOptions.rowHeight = 30
    this.gridView.setDataSource(this.provider)
    this.provider.setFields(fields)
    this.gridView.setColumns(this.columns)


    const [res, err] = await this.$https.get(`/v2/exclusive/common/grid/selectGridAttribute?eeno=${this.userInfo.eeno}&menuId=${this.menuId}`) // API-WX-공통서비스-024 (담당자별 Grid 속성 조회)
    if(res && res.data && res.data.gridAttribute) {
      const jsonObj = JSON.parse(res.data.gridAttribute)
      this.gridView.setColumnLayout(jsonObj['layout'])
      this.fixedOptionCount = jsonObj['fixedOptionCount']
    } else {
      this.gridView.setColumnLayout(this.layout)
    }
    this.gridView.setStateBar({
      visible: false
    })
    this.gridView.setFooter({
      visible: false
    })
    this.gridView.setFixedOptions({colCount: this.fixedOptionCount})
    this.gridView.editOptions.editable = false
    this.gridView.onCellClicked = (grid, clickData) => {
      if(clickData.column !== 'contractNumber') return
      this.$emit('onClick', this.tableData[clickData.dataRow])
    }
    this.gridView.onSorting = (grid, f, direction ) => {
      const props = {prop: f.length?fields[f[0]].fieldName:'', order: direction.length? direction[0]: ''}
      this.$emit('onSearch', props)
    }
    this.gridView.onShowTooltip = (grid, index, value) => {
      var column = index.column
      var itemIndex = index.itemIndex
     
      var tooltip = value
      if (column === 'carSaleCode') {
        tooltip = '차종&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : ' + (this.tableData[itemIndex].saleModelName) +
            '\r\n옵션&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : ' + (this.tableData[itemIndex].optionName || '') +
            '\r\n외, 내장 칼라\t : ' + (`외장(${this.tableData[itemIndex].exteriorColorName ||
                            ''}), 내장(${this.tableData[itemIndex].interiorColorName || ''})`) +
            '\r\nTUIX&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : ' + (this.tableData[itemIndex].tuixName || '') +
            '\r\n가격&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : ' + (this.tableData[itemIndex].carPrice &&
                            this.tableData[itemIndex].carPrice.toLocaleString() + '원')
      }
      console.log(tooltip)
      return tooltip
    }
  },
  methods: {
    showGridVisibleController() {
      this.gridVisibleControllerVisible = true
    },
    reset() {
      this.$confirm('현재 상태를 초기화하시겠습니까? 초기화된 뒤에는 다시 되돌릴 수 없습니다.', '', {
        confirmButtonText: '확인',
        cancelButtonText: '취소',
        callback: async (action) => {
          if (action === 'confirm') {
            this.gridView.setColumnLayout(this.layout)
            this.gridView.setFixedOptions({colCount: 2})
            this.$alert('초기화되었습니다.')
          } else {
            return
          }
        },
        dangerouslyUseHTMLString: true,
        customClass: 'el-message-box--confirm'
      })
    },
    async save() {
      this.$confirm('현재 상태를 저장하시겠습니까? 저장된 뒤에는 다시 되돌릴 수 없습니다.', '', {
        confirmButtonText: '확인',
        cancelButtonText: '취소',
        callback: async (action) => {
          if (action === 'confirm') {
            const columns = this.gridView.saveColumnLayout()
            const jsonObj = {}
            jsonObj['layout'] = columns
            jsonObj['fixedOptionCount'] = this.fixedOptionCount
            const params = {
              eeno : this.userInfo.eeno,
              menuId: this.menuId,
              gridAttribute: JSON.stringify(jsonObj)
            }
            const [res, err] = await this.$https.post('/v2/exclusive/common/grid/gridAttributeSave', params) // API-WX-공통서비스-023 (담당자별 Grid 속성 등록/저장)
            if(res && res.data && res.data.setAttributeYesOrNo === 'Y') {
              this.$alert('저장되었습니다.')
            }
          } else {
            return
          }
        },
        dangerouslyUseHTMLString: true,
        customClass: 'el-message-box--confirm'
      })
    },
    saveGridLayout(fixedOptionCount) {
      this.gridVisibleControllerVisible = false
      this.fixedOptionCount = fixedOptionCount
    },
    getCheckContractNumbers() {
      const numbers = this.gridView.getCheckedItems()
      const contracts = []
      numbers.forEach(e => {
        contracts.push(this.tableData[e])
      })
      return contracts
    }
  },

}
</script>

<style>
.rg-grid .rg-header .rg-table tr td {
	background-color: #e4dcd3;
	border-left: 1px solid #fff;
	border-bottom: 1px solid #fff;
	border-right: none;
	border-top: none;
	color: #000;font-weight: bold;
	font-family: HyundaiSansTextKR,Magul Gothic;
	font-size: 14px;
}

.rg-grid .rg-head .rg-table tr td {
	background-color: #e4dcd3;
	border-left: 1px solid #fff;
	border-bottom: 1px solid #fff;
	border-right: none;
	border-top: none;
	font-weight: bold;
	font-family: HyundaiSansTextKR,Magul Gothic;
	font-size: 14px;color: #000;
}
.rg-body .rg-table tr td, .rg-fixed-body .rg-table tr td {
	border-top: none;
	border-right: 1px solid #D2D5DA !important;
	border-bottom: 1px solid #D2D5DA !important;
	border-right: none;
	border-top: none;
	background-color: #fff;
	border-left: none;}

td.rg-data-cell.rg-data-readonly-cell {
	border-top: none;
	border-right: none;
	border-bottom: 1px solid #e4dcd3;
	border-left: 1px solid #e4dcd3;
}

.rg-fixed-column-bar {
	background: transparent;
	width: 0px !important;
}
.rg-header {
	background: none;
}
td.rg-rowindicator-cell {
	background-color: #fff !important;
}
td.rg-checkbar-cell {
	background-color: #fff !important;
}
.rg-root.rg-grid {
	border: 1px solid #ebeef5;
}
</style>