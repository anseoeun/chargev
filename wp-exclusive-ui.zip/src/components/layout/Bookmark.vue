<template>
  <div>
    <div class="bookmark-title">
      <h4>즐겨찾기</h4>
      <el-button
        type="primary"
        @click="goSetBookMark"
      >
        설정
      </el-button>
    </div>
    <el-menu
      :router="true"
      :default-active="$route.path"
    >
      <el-menu-item-group 
        v-if="data"
      >
        <el-menu-item
          v-for="{ menuId, menuName, menuLink } in data"
          :key="menuId"
          :index="menuLink"
          :route="{ path: menuLink }"
        >
          {{ menuName }}
          <!-- <i class="el-icon-arrow-right" /> -->
        </el-menu-item>
      </el-menu-item-group>
    </el-menu>
  </div>
</template>

<script>
export default {
  props: {
    data: {
      type: Array,
      default: () => ([])
    },
  },
  methods: {
    goSetBookMark() { // 설정 링크
      // location.hash = '/set/book-mark'
      this.$router.push('/wp/set/book-mark')
    }
  }
}
</script>
