<template>
  <div class="header">
    <div class="gnb-wrap">
      <!-- <h1 class="logo">
        <router-link to="/">
          hyundai system admin
        </router-link>
      </h1> -->
      <div class="gnb_left">
        <div class="menu">
          <el-button type="text" class="default" @click="menuToggle">
            menu
          </el-button>
          <el-button type="text" class="close">
            close
          </el-button>
        </div>
        <el-button type="text" class="home" @click="moveHome">
          home
        </el-button>
        <!-- GRANDOPEN  -->
        <el-button type="text" class="star" @click="favoriteToggle">
          즐겨찾기
        </el-button>
      </div>
      <div class="gnb_right">
        <!-- GRANDOPEN  -->
        <div class="alarm-wrap">
          <el-select
            v-model="siteShortcuts"
            placeholder="사이트 바로가기"
            :popper-append-to-body="false"
          >
            <el-option
              v-for="{ value, label } in siteShortcutsList"
              :key="value"
              :value="value"
              :label="label"
            />
          </el-select>
          <div class="menus">
            <div class="notice" style="cursor: pointer" @click="goPage('notice')">
              <span class="icon">
                <span
                  v-if="
                    unConfirmInfo.unconfirmNoticeCount &&
                      parseInt(unConfirmInfo.unconfirmNoticeCount) !== 0
                  "
                  class="count"
                >
                  {{ unConfirmInfo.unconfirmNoticeCount || 0 }}
                </span>
              </span>
              <span>공지</span>
            </div>
            <div class="my" style="cursor: pointer" @click="goPage('mypage')">
              <span class="icon">
                <span
                  v-if="
                    unConfirmInfo.unconfirmMyPageCount &&
                      parseInt(unConfirmInfo.unconfirmMyPageCount) !== 0
                  "
                  class="count"
                >
                  {{ unConfirmInfo.unconfirmMyPageCount || 0 }}
                </span>
              </span>
              <span>마이</span>
            </div>
            <div class="emergency" style="cursor: pointer" @click="goPage('csU')">
              <span class="icon">
                <span
                  v-if="
                    unConfirmInfo.unconfirmCustomerImportantCount &&
                      parseInt(unConfirmInfo.unconfirmCustomerImportantCount) !==
                        0
                  "
                  class="count"
                >
                  {{ unConfirmInfo.unconfirmCustomerImportantCount }}
                </span>
              </span>
              <span>긴급</span>
            </div>
            <div class="general" style="cursor: pointer" @click="goPage('csG')">
              <span class="icon">
                <span
                  v-if="
                    unConfirmInfo.unconfirmCustomerNormalCount &&
                      parseInt(unConfirmInfo.unconfirmCustomerNormalCount) !== 0
                  "
                  class="count"
                >
                  {{ unConfirmInfo.unconfirmCustomerNormalCount || 0 }}
                </span>
              </span>
              <span>일반</span>
            </div>
          </div>
        </div>

        <div class="user-wrap">
          <!-- <span class="user-icon" /> -->
          <span class="user-icon"></span>
          <span class="user">{{ userInfo && userInfo.eeNm }}</span>
          <el-button
            type="text"
            class="logout"
            @click="popVisible = !popVisible"
          >
            Logout
          </el-button>
        </div>
      </div>
    </div>
    <el-dialog
      custom-class="message"
      :visible.sync="popVisible"
      width="30%"
      :center="true"
    >
      <span>로그아웃 하시겠습니까?</span>
      <span slot="footer" class="dialog-footer">
        <el-button type="info" @click="popVisible = false">
          취소
        </el-button>
        <el-button type="primary" @click="logout()">
          확인
        </el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { mapState } from 'vuex'
export default {
  props: {
    data: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      popVisible: false,
      siteShortcutsList: [
        { value: '', label: '사이트 바로가기' },
        { value: process.env.VUE_APP_BASEURL_FRONT, label: '캐스퍼 온라인' },
        {
          value: process.env.VUE_APP_BASEURL_FRONT + '/vehicles/making/model',
          label: '캐스퍼 견적내기'
        },
        { value: 'https://map.kakao.com', label: '카카오지도' },
        { value: 'https://map.naver.com', label: '네이버지도' },
        {
          value: 'https://www.juso.go.kr/openIndexPage.do',
          label: '도로명주소안내'
        }
      ],
      siteShortcuts: ''
    }
  },
  computed: {
    ...mapState(['userInfo', 'unConfirmInfo'])
  },
  watch: {
    siteShortcuts(value) {
      if (value) {
        window.open(value, '_blank')
      }
      value = ''
    }
  },
  mounted() {
    if (this.userInfo) {
      this.$store.dispatch('loadUnConfirmInfo', { vm: this })
    }
  },
  methods: {
    menuToggle: function() {
      this.$emit('showside')
    },

    favoriteToggle: function() {
      this.$emit('showfav')
    },

    moveHome: function() {
      this.$router.push('/wp/main')
      // window.location.href = '/#/main'
    },

    goPage: function(pgNm) {
      switch (pgNm) {
      case 'notice':
        this.$router.push({
          path: '/wp/notice/manager',
          query: { ruleDate: 'day30' }
        })
        // location.hash = '/notice/manager'
        break
      case 'csU':
        this.$router.push({
          path: '/wp/cs/reception',
          query: { workLevelCode: 'U' }
        })
        // location.hash = '/cs/reception'
        break
      case 'csG':
        this.$router.push({
          path: '/wp/cs/reception',
          query: { workLevelCode: 'G' }
        })
        // location.hash = '/cs/reception'
        break
      case 'mypage':
        this.$router.push('/wp/mypage-reception/reception')
        // location.hash = '/mypage-reception/reception'
        break
      }
    },
    logout() {
      this.popVisible = false
      this.$store.dispatch('logout', { vm: this }).then(() => {
        this.$router.push('/login')
      })
    }
  }
}
</script>
