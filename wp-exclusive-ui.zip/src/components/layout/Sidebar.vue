<template>
  <div>
    <el-menu
      ref="ttt"
      :router="true"
      :default-active="$route.path"
      :default-openeds="menuArr"
    >
      <el-submenu
        v-for="(obj, idx1) in data"
        :key="obj.id"
        :index="`${idx1}`"
        :title="obj.menuName"
      >
        <template slot="title">
          {{ obj.menuName }}
        </template>
        <template
          v-for="({ menuId, menuName, menuLink, children: children2, linkType },
          idx2) in obj.children"
        >
          <el-submenu
            v-if="children2 && children2.length > 0"
            :key="menuId"
            :index="`${idx1}-${idx2}`"
          >
            <template slot="title">
              {{ menuName }}
            </template>
            <el-menu-item
              v-for="({
                menuId: menuId2,
                menuName: menuName2,
                menuLink: menuLink2,
                linkType: linkType2
              },
              idx3) in children2"
              :key="menuId2"
              :index="`${idx1}-${idx2}-${idx3}`"
              :route="setRoute(menuLink2, linkType2)"
            >
              {{ menuName2 }}
              <!-- <i class="el-icon-arrow-right" /> -->
            </el-menu-item>
          </el-submenu>
          <el-menu-item
            v-else
            :key="menuId"
            :index="`${idx1}-${idx2}`"
            :route="setRoute(menuLink, linkType)"
          >
            {{ menuName }}
            <!-- <i class="el-icon-arrow-right" /> -->
          </el-menu-item>
        </template>
      </el-submenu>
    </el-menu>
  </div>
</template>

<script>
export default {
  props: {
    data: {
      type: Array,
      default: () => []
    }
  },
  computed: {
    menuArr: function() {
      const menuLength = this.data.length;
      let menuArr = Array.from({ length: menuLength }, (v, i) => "" + i);

      this.data.map((items, idx) => {
        // depth 2 - index add
        if (items.children.length > 0) {
          items.children.map((items2, idx2) => {
            if (items2.children.length > 0) {
              menuArr.push(idx + "-" + idx2);
            }
          });
        }
      });
      return menuArr;
    }
  },
  methods: {
    setRoute(menuLink, linkType) {
      // 메뉴 경로 및 메뉴 링크 유형(10: self, 20: 팝업, 30:이동없음(?) 40:외부링크, 50: 새창 )
      // path
      // const routeObj = { path: menuLink }

      // if(menuLink.endsWith('/process') || menuLink.endsWith('/release-detail')) {
      //   routeObj.query = { isNewTab: true }
      // }

      // convert path -> name
      let newMenuName = menuLink.split("/").join("-");
      if (newMenuName.startsWith("-")) {
        // - 으로 시작할 경우 제거
        newMenuName = newMenuName.substring(1);
      }

      if (newMenuName.includes("agency") || newMenuName.includes("notice")) {
        // file name bind
        newMenuName += "-index";
      }

      const isNewTab = linkType ? linkType === "50" : false;
      const routeObj = { name: newMenuName, params: { isNewTab } };
      // console.log(routeObj)
      return routeObj;
    }
  }
};
</script>
