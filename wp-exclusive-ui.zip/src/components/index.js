import VImg from './VImg'
import VPagination from './VPagination'

export default { VImg, VPagination }
