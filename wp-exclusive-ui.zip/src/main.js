import '@babel/polyfill'
import 'url-search-params-polyfill'
import Vue from 'vue'
import Element from 'element-ui'
import locale from 'element-ui/lib/locale/lang/ko'
import moment from 'moment'
import App from './App.vue'
import router from './router'
import store from './store'
import VComponents from './components'
import Https from './https'
import validate from './validate'
import Utils from './utils'

require('./plugins/smooth-scroll')
require('froala-editor/js/froala_editor.pkgd.min.js')
require('froala-editor/css/froala_editor.pkgd.min.css')
require('froala-editor/css/froala_style.min.css')
import VueFroala from 'vue-froala-wysiwyg'
Vue.use(VueFroala)

import VueMeta from 'vue-meta'
Vue.use(VueMeta)

moment.locale('ko')
Vue.use(require('vue-moment'), {
  moment
})
Vue.use(Element, { locale })

Object.entries(VComponents).forEach(([name, component]) => {
  Vue.component(name, component)
})

Vue.filter('capitalize', value => {
  if (!value) return ''
  value = value.toString()
  return value.charAt(0).toUpperCase() + value.slice(1)
})

Vue.filter('currency', value => {
  if (!value) return ''
  value = Number(value)
  return value.toFixed(0).replace(/(\d)(?=(\d{3})+(?:\.\d+)?$)/g, '$1,')
})

Vue.prototype.$rules = validate
Vue.prototype.$https = new Https()
Vue.prototype.$utils = new Utils()
Vue.prototype.$EventBus = new Vue()

Vue.config.productionTip = false

// IE 예외 케이스 처리 - hash route 문제 ==> keyword: popstate, vue hash mode, ie
const IE11RouterFix = {
  methods: {
    hashChangeHandler() { this.$router.push(window.location.hash.substring(1, window.location.hash.length)) },
    isIE11() { return !!window.MSInputMethodContext && !!document.documentMode }
  },
  mounted() { if ( this.isIE11() ) { window.addEventListener('hashchange', this.hashChangeHandler) } },
  destroyed() { if ( this.isIE11() ) { window.removeEventListener('hashchange', this.hashChangeHandler) } }
}

new Vue({
  router,
  store,
  mixins: [IE11RouterFix],
  render: h => h(App)
}).$mount('#app')