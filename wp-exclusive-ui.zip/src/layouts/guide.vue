<template>
  <el-container>
    <el-header height="70px">
      <header-comp :data="menuList" />
    </el-header>
    <el-container>
      <el-aside width="240px">
        Guide
      </el-aside>
      <el-main>
        <!-- Title Area -->
        <section class="title">
          <h1>Guide</h1>
        </section>
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import { mapGetters } from 'vuex'
import Header from '~/components/layout/Header'

export default {
  components: {
    HeaderComp: Header
  },

  computed: {
    ...mapGetters({
      menuList: 'menuList'
    })
  }
}
</script>
