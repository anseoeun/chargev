<template>
  <el-container>
    <el-header v-show="showHeader" height="70px">
      <header-comp
        :data="menuList"
        @showside="showMenuToggle"
        @showfav="showFavToggle"
      />
    </el-header>
    <el-container :class="{ widthFix: showMenu || showFav }">
      <div v-show="showMenu" class="transition-box">
        <el-aside width="240px">
          <sidebar-comp :data="sideMenu" />
        </el-aside>
      </div>
      <div v-show="showFav" class="transition-box">
        <el-aside width="240px">
          <bookmark-comp :data.sync="bookMarkMenu" />
        </el-aside>
      </div>

      <el-main>
        <!-- Title Area -->
        <section class="title">
          <h1>{{ currentMenu.menuName }}</h1>
          <!-- Indicator -->
          <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/' }">
              홈
            </el-breadcrumb-item>
            <el-breadcrumb-item v-for="(item, index) in routeList" :key="index">
              {{ item.menuName }}
            </el-breadcrumb-item>
          </el-breadcrumb>
        </section>
        <router-view />
      </el-main>
    </el-container>
    <v-top class="l-btn-top" :go-to="0" />
  </el-container>
</template>

<script>
import { mapGetters } from "vuex";
import Header from "~/components/layout/Header";
import Sidebar from "~/components/layout/Sidebar";
import Bookmark from "~/components/layout/Bookmark";
import VTop from "~/components/common/VTop.vue";

export default {
  metaInfo() {
    const $this = this;
    return {
      title: $this.currentMenu.menuName || "CASPER 구매 지원시스템"
    };
  },
  name: "Layout",

  components: {
    HeaderComp: Header,
    SidebarComp: Sidebar,
    BookmarkComp: Bookmark,
    VTop
  },
  data: () => ({
    showMenu: true,
    showFav: false,
    showHeader: true
  }),
  computed: {
    isDesktop() {
      return this.$mq === "desktop";
    },
    ...mapGetters({
      userInfo: "userInfo",
      menuList: "menuList",
      menuMap: "menuMap",
      menus: "menus",
      bookMarkList: "bookMarkList"
    }),
    sideMenu() {
      // const findId = this.parentMenu.menuId
      // return this.menuList.find(({ menuId }) => menuId === findId)
      return this.menuList;
    },

    currentMenu() {
      const pathArr = this.$route.path.split("/");
      if (pathArr.length > 5) {
        pathArr.pop();
      }
      const path = pathArr.join("/");

      return this.menuMap[path] || {};
    },

    parentMenu() {
      const parentPath = "wp/" + this.$route.path.split("/")[2];
      return this.menuMap[`/${parentPath}`] || {};
    },

    routeList() {
      return [{ ...this.parentMenu }, { ...this.currentMenu }];
    },

    bookMarkMenu() {
      return this.bookMarkList;
    }
  },
  async created() {
    await this.fetchData();
  },
  methods: {
    async fetchData() {
      await Promise.all([...this.loadData()]).then(() => {
        this.$store.commit("setCurrMenuId", this.$route.path);
      });
    },
    loadData() {
      const uesrInfoPromise = this.$store.dispatch("loadUserInfo", {
        vm: this
      });
      const menuListPromise = this.$store.dispatch("loadMenuList", {
        vm: this
      });
      const bookMarkListPromise = this.$store.dispatch("loadBookMarkList", {
        vm: this
      });
      const authBtnListPromise = this.$store.dispatch("loadAuthBtnList", {
        vm: this
      });
      return [
        uesrInfoPromise,
        menuListPromise,
        bookMarkListPromise,
        authBtnListPromise
      ];
    },
    showMenuToggle: function() {
      this.showFav = false;
      this.showMenu = !this.showMenu;
    },

    showFavToggle: function() {
      this.showMenu = false;
      this.showFav = !this.showFav;
    }
  }
};
</script>

<style lang="scss">
.transition-box {
  height: 100%;
  box-sizing: border-box;
  transition: all 0.2s ease;
  .el-aside {
    height: 100%;
  }
}

.el-header {
  background-color: #a36b4f;
}
</style>
