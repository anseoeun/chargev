// Utils Module
class Utils {
  constructor(globalObj = {}) {
    this.gObj = globalObj || {} // 전역 객체 
  }

  // openNewWindowWithPost(url = '', name = '', params = {}) { // 새창 띄우기 - post
  //   console.log('call me new window')

  //   const form = document.createElement('form')
  //   form.setAttribute('method', 'post')
  //   form.setAttribute('action', url)
  //   form.setAttribute('target', name)

  //   for (const val in params) {
  //     if (params.hasOwnProperty(val)) {
  //       const input = document.createElement('input')
  //       input.type = 'hidden'
  //       input.name = val
  //       input.value = params[val]
  //       form.appendChild(input)
  //     }
  //   }
    
  //   document.body.appendChild(form)
  //   window.open('', name)
  //   form.submit()
  //   document.body.removeChild(form)
  // }
  
  setSessionStorage(obj = {}) { // storage setting - multiple
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) { // hasOwnProperty => 성능 문제 있을시 주석
        sessionStorage.setItem(key, obj[key])
      }
    }
  }

  setLocalStorage(obj = {}) { // storage setting - multiple
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) { // hasOwnProperty => 성능 문제 있을시 주석
        localStorage.setItem(key, obj[key])
      }
    }
  }

  async sendMessageAll(vm, obj = {}) {
    // sendMessageAll
    const [res, err] = await vm.$https.post(
      "/common/v2/common/notification/sendMessageAll",
      obj,
      null,
      "gateway"
    ); //API-WX-공통서비스-011 (메세지 통합발송)
    if (!err) {
    } else {
      console.error("error : ", err);
    }
  }
}

export default Utils
