const pubMenuList = [
  {
    'data': [
      {
        'menuId': 'PUB',
        'menuName': '퍼블리싱 파일 목록',
        'screenUrlAddress': '-',
        'upperMenuId': '-',
        'menuSortNo': '1'
      },
      {
        'menuId': '',
        'menuName': '# 전체작업목록',
        'screenUrlAddress': '/wp-pub/main',
        'upperMenuId': 'PUB',
        'menuSortNo': '1'
      },
      {
        'menuId': 'SO-ETC-001',
        'menuName': '공통레이어-빠른결제요청',
        'screenUrlAddress': '/wp-pub/pages/SO-ETC-001',
        'upperMenuId': 'PUB',
        'menuSortNo': '2'
      },
      {
        'menuId': 'SO-ETC-002',
        'menuName': '공통레이어-차량실사진보기',
        'screenUrlAddress': '/wp-pub/pages/SO-ETC-002',
        'upperMenuId': 'PUB',
        'menuSortNo': '2'
      },
      {
        'menuId': 'SO-ETC-007',
        'menuName': '공통레이어-해약',
        'screenUrlAddress': '/wp-pub/pages/SO-ETC-007',
        'upperMenuId': 'PUB',
        'menuSortNo': '4'
      },
      {
        'menuId': 'SO-ETC-011',
        'menuName': '공통레이어-현금결제변경',
        'screenUrlAddress': '/wp-pub/pages/SO-ETC-011',
        'upperMenuId': 'PUB',
        'menuSortNo': '5'
      },
      {
        'menuId': 'SO-ETC-012',
        'menuName': '공통레이어-카드결제변경',
        'screenUrlAddress': '/wp-pub/pages/SO-ETC-012',
        'upperMenuId': 'PUB',
        'menuSortNo': '6'
      },
      {
        'menuId': 'SO-ETC-013',
        'menuName': '공통레이어-출고센터변경',
        'screenUrlAddress': '/wp-pub/pages/SO-ETC-013',
        'upperMenuId': 'PUB',
        'menuSortNo': '7'
      },
      {
        'menuId': 'SO-ETC-014',
        'menuName': '공통레이어-탁송지변경',
        'screenUrlAddress': '/wp-pub/pages/SO-ETC-014',
        'upperMenuId': 'PUB',
        'menuSortNo': '8'
      },
      {
        'menuId': 'SO-ETC-019',
        'menuName': '공통레이어-생산차변경',
        'screenUrlAddress': '/wp-pub/pages/SO-ETC-019',
        'upperMenuId': 'PUB',
        'menuSortNo': '9'
      },
      {
        'menuId': 'SO-ETC-020',
        'menuName': '공통레이어-재고차조회',
        'screenUrlAddress': '/wp-pub/pages/SO-ETC-020',
        'upperMenuId': 'PUB',
        'menuSortNo': '10'
      },
      {
        'menuId': 'SO-ETC-023',
        'menuName': '공통레이어-파츠변경',
        'screenUrlAddress': '/wp-pub/pages/SO-ETC-023',
        'upperMenuId': 'PUB',
        'menuSortNo': '11'
      },
      {
        'menuId': 'SO-ETC-024',
        'menuName': '공통레이어-주소검색',
        'screenUrlAddress': '/wp-pub/pages/SO-ETC-024',
        'upperMenuId': 'PUB',
        'menuSortNo': '12'
      },
      {
        'menuId': 'SO-ETC-027',
        'menuName': '공통레이어-업체조회',
        'screenUrlAddress': '/wp-pub/pages/SO-ETC-027',
        'upperMenuId': 'PUB',
        'menuSortNo': '12'
      },
      {
        'menuId': 'SO-ETC-028',
        'menuName': '공통레이어-법인번호입력',
        'screenUrlAddress': '/wp-pub/pages/SO-ETC-028',
        'upperMenuId': 'PUB',
        'menuSortNo': '12'
      },
      {
        'menuId': 'SO-ETC-029',
        'menuName': '공통레이어-공식지정인수점조회',
        'screenUrlAddress': '/wp-pub/pages/SO-ETC-029',
        'upperMenuId': 'PUB',
        'menuSortNo': '12'
      },
      {
        'menuId': 'SO-ETC-026',
        'menuName': '공통레이어-고객조회',
        'screenUrlAddress': '/wp-pub/pages/SO-ETC-026',
        'upperMenuId': 'PUB',
        'menuSortNo': '12'
      },
      {
        'menuId': 'SO-SHP-003',
        'menuName': '계약출고-대고객계약출고상세',
        'screenUrlAddress': '/wp-pub/pages/SO-SHP-003',
        'upperMenuId': 'PUB',
        'menuSortNo': '13'
      },
      {
        'menuId': 'SO-SHP-010',
        'menuName': '계약출고-법인계약출고상세',
        'screenUrlAddress': '/wp-pub/pages/SO-SHP-010',
        'upperMenuId': 'PUB',
        'menuSortNo': '14'
      },
      {
        'menuId': 'SO-MRT-003',
        'menuName': '마이페이지수신업무-수신업무처리',
        'screenUrlAddress': '/wp-pub/pages/SO-MRT-003',
        'upperMenuId': 'PUB',
        'menuSortNo': '15'
      },
      {
        'menuId': 'SO-EMP-001',
        'menuName': '직원인증-직원인증업무조회',
        'screenUrlAddress': '/wp-pub/pages/SO-EMP-001',
        'upperMenuId': 'PUB',
        'menuSortNo': '16'
      },
      {
        'menuId': 'SO-EMP-002',
        'menuName': '직원인증-직원인증업무생성/처리',
        'screenUrlAddress': '/wp-pub/pages/SO-EMP-002',
        'upperMenuId': 'PUB',
        'menuSortNo': '17'
      },       
      {
        'menuId': 'SO-SPT-001',
        'menuName': '지원업무-계열사직원계약출고조회',
        'screenUrlAddress': '/wp-pub/pages/SO-SPT-001',
        'upperMenuId': 'PUB',
        'menuSortNo': '18'
      },
      {
        'menuId': 'SO-SPT-005',
        'menuName': '지원업무-전담DC품의조회',
        'screenUrlAddress': '/wp-pub/pages/SO-SPT-005',
        'upperMenuId': 'PUB',
        'menuSortNo': '19'
      },
      {
        'menuId': 'SO-SPT-006',
        'menuName': '지원업무-대행견적목록',
        'screenUrlAddress': '/wp-pub/pages/SO-SPT-006',
        'upperMenuId': 'PUB',
        'menuSortNo': '20'
      },
      {
        'menuId': 'SO-SPT-007',
        'menuName': '지원업무-대행견적상세조회',
        'screenUrlAddress': '/wp-pub/pages/SO-SPT-007',
        'upperMenuId': 'PUB',
        'menuSortNo': '21'
      },
      {
        'menuId': 'SO-STA-002',
        'menuName': '집계-회원통합조회',
        'screenUrlAddress': '/wp-pub/pages/SO-STA-002',
        'upperMenuId': 'PUB',
        'menuSortNo': '22'
      },
      {
        'menuId': 'SO-STA-008',
        'menuName': '집계-엠버서더실적조회',
        'screenUrlAddress': '/wp-pub/pages/SO-STA-008',
        'upperMenuId': 'PUB',
        'menuSortNo': '23'
      },
      {
        'menuId': 'SO-STA-010',
        'menuName': '집계-쿠폰발급사용조회',
        'screenUrlAddress': '/wp-pub/pages/SO-STA-010',
        'upperMenuId': 'PUB',
        'menuSortNo': '24'
      },
      {
        'menuId': 'SO-STA-011',
        'menuName': '집계-쿠폰발급사용상세조회',
        'screenUrlAddress': '/wp-pub/pages/SO-STA-011',
        'upperMenuId': 'PUB',
        'menuSortNo': '25'
      },
    ]
  }  
]

export default pubMenuList