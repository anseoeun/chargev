import Vue from 'vue'
import Router from 'vue-router'
import routes from 'vue-auto-routing'
import { createRouterLayout } from 'vue-router-layout'
import store from './store'
import Cookies from 'js-cookie'

Vue.use(Router)

const RouterLayout = createRouterLayout(layout => {
  return import('@/layouts/' + layout + '.vue')
})

const router = new Router({
  routes: [
    {
      path: '/',
      component: RouterLayout,
      children: routes,
      beforeEnter: (to, from, next) => {
        next()
      }
    }
  ],
  scrollBehavior () {
    return { x: 0, y: 0 }
  }
})

router.beforeEach((to, from, next) => {
  const sId = Cookies.get('sessionId')
  const userInfo = Cookies.get('userInfo')
  if(sId) { // 새로고침시 state에 저장
    store.state.isAuthenticated = true
    store.state.sessionId = sId
    store.state.userInfo = userInfo ? JSON.parse(userInfo) : null
  }

  if(!to.matched.length) { // 404 Error check
    next('/error/error404')
  }

  if(to.name === 'login') { // 로그인 페이지로 갈 경우
    // console.log(store.state.isAuthenticated)
    if(!store.getters.isAuthenticated) { // 인증 정보가 없다면 로그인 페이지로
      next()
      return
    } else {
      next('/wp/main') // 인증 정보가 있다면 메인으로
    }
    
  } else { // 로그인 페이지외의 페이지로 갈 경우
    if(store.getters.isAuthenticated) { // 인증 정보가 있다면
      if(to && to.params && to.params.isNewTab === true) { // 새창 띄우기
        let route = router.resolve({ name: to.name })
        window.open(route.href, '_blank')
        next(false)
        return
      } else { 
        if(to.path === '/') { // index => main 으로 url 변경
          next('/wp/main')
          return
        } else {
          next()
          return
        }
      }
    } else {
      // exception ssoLogin
      if(to.name === 'ssoLogin') {
        next()
        return
      } else {
        next('/login')
      }
    }
  }
})

router.afterEach((to) => {
  store.commit('setCurrPath', to.path)
  store.commit('setCurrMenuId', to.path)
})


export default router
