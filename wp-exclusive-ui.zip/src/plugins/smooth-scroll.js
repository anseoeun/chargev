import Vue from 'vue'
import SmoothScroll from 'smooth-scroll/dist/smooth-scroll.polyfills.min.js'

let scroll

Vue.prototype.$smoothScroll = {
  create: () => {
    scroll = new SmoothScroll(null, {
      speed: 1000,
      easing: 'easeInOutCubic',
      speedAsDuration: true
    })

    return scroll
  },

  state: {
    isBind: false
  },

  delete: () => {
    scroll.destroy()
    scroll = null
  },

  bindEvents: (fn) => {
    const smoothScroll = Vue.prototype.$smoothScroll
    const event = (event) => {
      switch (event.type) {
      case 'scrollStart': {
        fn(true)
        break
      }

      case 'scrollStop': {
        fn(false)
        console.log('called')
        smoothScroll.delete()
        break
      }
      }
    }

    if (!smoothScroll.state.isBind) {
      document.addEventListener('scrollStart', event, false)
      document.addEventListener('scrollStop', event, false)
      smoothScroll.state.isBind = true
    }
  }
}
