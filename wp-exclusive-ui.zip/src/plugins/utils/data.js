export default {
  phone: [
    {
      value: '010',
      label: '010'
    },
    {
      value: '011',
      label: '011'
    },
    {
      value: '016',
      label: '016'
    },
    {
      value: '017',
      label: '017'
    }
  ],

  address1: [
    {
      value: '',
      label: '전체'
    },
    {
      value: '서울',
      label: '서울'
    },
    {
      value: '강원',
      label: '강원'
    },
    {
      value: '경기',
      label: '경기'
    },
    {
      value: '경남',
      label: '경남'
    },
    {
      value: '경북',
      label: '경북'
    },
    {
      value: '광주',
      label: '광주'
    },
    {
      value: '대구',
      label: '대구'
    },
    {
      value: '대전',
      label: '대전'
    },
    {
      value: '부산',
      label: '부산'
    },
    {
      value: '세종',
      label: '세종'
    },
    {
      value: '울산',
      label: '울산'
    },
    {
      value: '인천',
      label: '인천'
    },
    {
      value: '전남',
      label: '전남'
    },
    {
      value: '전북',
      label: '전북'
    },
    {
      value: '제주',
      label: '제주'
    },
    {
      value: '충남',
      label: '충남'
    },
    {
      value: '충북',
      label: '충북'
    }
  ],

  seoul: [
    {
      centerId: 'center1',
      centerName: '강남 시승센터',
      address: '서울 강남구 영동대로 302',
      phone: '02-542-5300',
      carList: [
        {
          carId: 'car100',
          carName: '아반떼',
          carFuel: '라바 오렌지 / 가솔린 2.0T'
        }
      ]
    },
    {
      centerId: 'center2',
      centerName: '잠실 시승센터',
      address: '서울특별시 송파구 올림픽로 145 (잠실동, 리센츠) 리센츠빌딩 2층 C10호',
      phone: '02-542-5300',
      carList: [
        {
          carId: 'car100',
          carName: '아반떼',
          carFuel: '라바 오렌지 / 가솔린 2.0T'
        },
        {
          carId: 'car101',
          carName: '엑센트',
          carFuel: '라바 오렌지 / 가솔린 2.0T'
        },
        {
          carId: 'car102',
          carName: 'i30',
          carFuel: '라바 오렌지 / 가솔린 2.0T'
        }
      ]
    },
    {
      centerId: 'center3',
      centerName: '원효로 시승센터',
      address: '서울 용산구 원효로 86',
      phone: '02-542-5300',
      carList: [
        {
          carId: 'car100',
          carName: '아반떼',
          carFuel: '라바 오렌지 / 가솔린 2.0T'
        },
        {
          carId: 'car101',
          carName: '엑센트',
          carFuel: '라바 오렌지 / 가솔린 2.0T'
        }
      ]
    },
    {
      centerId: 'center4',
      centerName: '대방 시승센터',
      address: '서울 동작구 노량진로 53',
      phone: '02-542-5300',
      carList: [
        {
          carId: 'car102',
          carName: 'i30',
          carFuel: '라바 오렌지 / 가솔린 2.0T'
        }
      ]
    }
  ]
}
