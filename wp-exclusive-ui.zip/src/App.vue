<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style lang="scss">
@import '@/assets/style/element-theme-chalk/src/index.scss';
@import '@/assets/style/index.scss';
</style>
