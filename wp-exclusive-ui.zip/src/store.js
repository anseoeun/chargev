import Vue from 'vue'
import Vuex from 'vuex'
import Cookies from 'js-cookie'
// import { stat } from 'fs'

// 퍼블리싱 화면 활성화
// import pubMenuList from './pubMenuList'

Vue.use(Vuex)
const convertList = ml => {
  // menuList customize
  const ptMenu = ml.filter(items => {
    return items.parentId === null || items.parentId === '-'
  })
  const totalMenu =
    ptMenu.map(items => {
      // depth1
      const obj = Object.assign({ children: [] }, items)
      createMenuTree(ml, obj, 3)
      return obj
    }) || []
  return totalMenu
}

const createMenuTree = (source, target, depth) => {
  // depth별로 children list 생성
  let sDepth = 1
  source.map(items => {
    const obj = Object.assign({ children: [] }, items)
    if (target.menuId === obj.parentId) {
      if (sDepth < depth) {
        createMenuTree(source, obj, sDepth + 1)
      }
      target.children.push(obj)
    }
  })
  sDepth++
}

const exceptionMenuList = [
  {
    children: [],
    menuLink: '/support/duty-free',
    parentId: '',
    menuId: 'M0500003',
    menuName: '면세신고',
    menuSortNo: '80',
    useAuthGroupId: 'M0003',
    authGroupName: '업무담당자 조회전용',
    systemUserNo: '',
    linkType: ''
  },
  {
    children: [],
    menuLink: '/agency/_id',
    parentId: '',
    menuId: 'M0800010',
    menuName: '등록대행 업체 정보 수정',
    menuSortNo: '80',
    useAuthGroupId: 'M0003',
    authGroupName: '업무담당자 조회전용',
    systemUserNo: '',
    linkType: ''
  },
  {
    children: [],
    menuLink: '/agency/create',
    parentId: '',
    menuId: 'M0800010',
    menuName: '등록대행 업체 신규 등록',
    menuSortNo: '80',
    useAuthGroupId: 'M0003',
    authGroupName: '업무담당자 조회전용',
    systemUserNo: '',
    linkType: ''
  },
  {
    children: [],
    menuLink: "/wp/notice/manager/write",
    parentId: "",
    menuId: "WT0800002",
    menuName: "공지사항 신규 등록",
    menuSortNo: "80",
    useAuthGroupId: "WT002",
    authGroupName: "업무담당자 조회전용",
    systemUserNo: "",
    linkType: ""
  },
  {
    children: [],
    menuLink: "/wp/notice/manager/_id",
    parentId: "",
    menuId: "WT0800002",
    menuName: "공지사항 정보 수정",
    menuSortNo: "80",
    useAuthGroupId: "WT002",
    authGroupName: "업무담당자 조회전용",
    systemUserNo: "",
    linkType: ""
  },
  {
    children: [],
    menuLink: "/wp/notice/manager/detail",
    parentId: "",
    menuId: "WT0800002",
    menuName: "공지사항 상세",
    menuSortNo: "80",
    useAuthGroupId: "WT002",
    authGroupName: "업무담당자 조회전용",
    systemUserNo: "",
    linkType: ""
  },
  {
    children: [],
    menuLink: '/wp/employee-auth/process_write',
    parentId: '',
    menuId: 'WT0500002',
    menuName: '직원인증 업무생성',
    menuSortNo: '50',
    useAuthGroupId: 'WT001',
    authGroupName: '업무담당자 조회전용',
    systemUserNo: '',
    linkType: ''
  },
  {
    children: [],
    menuLink: '/wp/support/estimate-detail',
    parentId: '',
    menuId: 'WT0600007',
    menuName: '대행견적 상세조회',
    menuSortNo: '50',
    useAuthGroupId: 'WT002',
    authGroupName: '업무담당자 조회전용',
    systemUserNo: '',
    linkType: ''
  }
]

export default new Vuex.Store({
  state: {
    menus: [],
    commonCodes: {},
    LegacyCommonCodes: {},
    consultants: [],
    carTypes: [],
    // allTypeCars: {},
    documentTargets: [],
    unConfirmInfo: {}, // 알림 카운트 정보
    menuList: [], // 메뉴 목록
    bookMarkList: [], // 즐겨찾기 목록
    userInfo: null, // 로그인 사용자 정보
    sessionId: null, // 세션 ID
    isAuthenticated: false, // 로그인 완료(인증) 여부
    currMenuId: '', // 현재 화면 매칭 메뉴 ID
    currPath: '', // 현재 화면 path
    authBtnList: [], // 버튼 권한 목록
    currAuthBtnList: [], // 현재 화면 버튼 권한 목록
    banners: [], // 메인 - 배너 목록
    authConsultants: [],
    commonCodesCustomerType: {}
  },
  mutations: {
    setCurrMenuId: (state, data) => {
      const exceptionMenus = exceptionMenuList.map(items => {
        return {
          authGroupName: items.authGroupName,
          linkType: items.linkType,
          menuId: items.menuId,
          menuName: items.menuName,
          menuSortNo: items.menuSortNo,
          screenUrlAddress: items.menuLink,
          systemUserNo: items.systemUserNo,
          upperMenuId: items.parentId,
          useAuthGroupId: items.useAuthGroupId
        }
      })

      const customMenus = [...state.menus, ...exceptionMenus]
      console.log(customMenus, data)

      customMenus.some(items => {
        if (items.screenUrlAddress === data) {
          state.currMenuId = items.menuId
          return true
        } else {
          state.currMenuId = ''
        }
      })
      if (state.currMenuId) {
        const currAuthList = state.authBtnList.filter(items => {
          return items.menuId === state.currMenuId
        })
        state.currAuthBtnList = currAuthList
      } else {
        state.currAuthBtnList = []
      }
      console.log('setCurrMenuId', state.currMenuId)
      console.log('setCurrAuthBtnList', state.currAuthBtnList)
    },
    setCommonCodes: (state, data) => {
      state.commonCodes = { ...data }
      console.log('setCommonCodes', state.commonCodes)
    },
    setLegacyCommonCodes: (state, data) => {
      state.LegacyCommonCodes = { ...data }
      console.log('setLegacyCommonCodes', state.LegacyCommonCodes)
    },
    setConsultants: (state, data) => {
      state.consultants = data;
      state.consultants = state.consultants.sort((compareA, compareB) => {
        return compareA.sysUserNm > compareB.sysUserNm ? 1 : -1;
      });
      console.log("setConsultants", state.consultants);
    },
    setAuthConsultants: (state, data) => {
      state.authConsultants = data;
      state.authConsultants = state.authConsultants.sort(
        (compareA, compareB) => {
          return compareA.sysUserNm > compareB.sysUserNm ? 1 : -1;
        }
      );
      console.log("setAuthConsultants", state.authConsultants);
    },
    setAllTypeCars: (state, data) => {
      state.carTypes = { ...data }
      // data.map(el => {
      //   const { carTypeCode, carTypeName } = el
      //   state.allTypeCars[carTypeCode] = el.list
      //   return { carTypeCode, carTypeName }
      // })
      // state.allTypeCars.all = allCarList

      console.log('setAllTypeCars', state.carTypes)
    },
    setDocumentTargets: (state, data) => {
      state.documentTargets = data;
      console.log("setDocumentTargets", state.documentTargets);
    },
    setCommonCodesCustomerType: (state, data) => {
      state.commonCodesCustomerType = data;
      console.log("setCommonCodesCustomerType", state.commonCodesCustomerType);
    },
    setUserInfo: (state, userInfo) => {
      state.userInfo = { ...userInfo }
    },
    setUnConfirmInfo: (state, data) => {
      state.unConfirmInfo = data
    },
    setMenuList: (state, data) => [(state.menuList = data)],
    setOriginMenus: (state, data) => [(state.menus = data)],
    setBookMarkList: (state, data) => [(state.bookMarkList = data)],
    setSessionId: (state, sessionId) => {
      state.sessionId = sessionId
    },
    setAuth: (state, isAuthenticated) => {
      state.isAuthenticated = isAuthenticated
    },
    setAuthBtn: (state, data) => {
      state.authBtnList = data
    },
    setCurrPath: (state, path) => {
      console.log('setCurrPath => ', path)
      state.currPath = path
    },
    setCurrAuthBtnList: (state, data) => {
      state.currAuthBtnList = data
    },
    setBanners: (state, data) => {
      state.banners = data
    }
  },
  getters: {
    commonCodes: state => state.commonCodes,
    LegacyCommonCodes: state => state.LegacyCommonCodes,
    menus: state => state.menus,
    menuMap: state => {
      let customs = []
      const load = list => {
        list.forEach(obj => {
          customs.push({
            ...obj,
            children: []
          })
          if (obj.children.length) {
            load(obj.children)
          }
        })
      }
      load(state.menuList)

      customs = [...customs, ...exceptionMenuList]

      return customs.reduce((map, obj) => {
        map[obj.menuLink] = { ...obj }
        // console.log(map)
        return map
      }, {})
    },
    menuList: state => state.menuList,
    bookMarkList: state => state.bookMarkList,
    userInfo: state => state.userInfo,
    isAuthenticated: state => state.isAuthenticated,
    authBtnList: state => state.authBtnList
  },
  actions: {
    loadCommonCodes: async ({ commit, state }, { vm }) => {
      if (Object.keys(state.commonCodes).length > 0) {
        return
      }

      const [res, err] = await vm.$https.get(
        '/common/v2/common/common-code',
        { systemTypeCode: 'E' },
        null,
        'gateway'
      ) //API-WH-공통서비스-016 (공통코드조회-전체 리스트)
      let codes = {}
      if (!err) {
        res.data &&
          res.data.forEach(elem => {
            if (!codes[elem.codeTypeCode])
              codes[elem.codeTypeCode] = [{ label: '전체', value: 'all' }]
            codes[elem.codeTypeCode].push({
              label: elem.codeName,
              value: elem.code
            })
          })
        commit('setCommonCodes', codes)
      }
    },

    loadLegacyCommonCodes: async ({ commit, state }, { vm }) => {
      if (Object.keys(state.LegacyCommonCodes).length > 0) {
        return
      }

      const [res, err] = await vm.$https.get(
        '/common/v2/common/common-code',
        { systemTypeCode: 'C' },
        null,
        'gateway'
      ) //API-WH-공통서비스-016 (공통코드조회-전체 리스트)
      let codes = {}
      if (!err) {
        res.data &&
          res.data.forEach(elem => {
            if (!codes[elem.codeTypeCode])
              codes[elem.codeTypeCode] = [{ label: '전체', value: 'all' }]
            codes[elem.codeTypeCode].push({
              label: elem.codeName,
              value: elem.code
            })
          })
        commit('setLegacyCommonCodes', codes)
      }
    },

    // eslint-disable-next-line no-unused-vars
    loadCommonCodesE: async ({ commit }, { vm, codeTypeCode }) => {
      const [res, err] = await vm.$https.get(
        '/common/v2/common/common-code',
        { systemTypeCode: 'E', codeTypeCode },
        null,
        'gateway'
      ) //API-WH-공통서비스-016 (공통코드조회-전체 리스트)
      let codes = {},
        codeList = []
      if (!err) {
        codeList =
          res.data &&
          res.data.map(items => {
            return { label: items.codeName, value: items.code }
          })
        codeList.unshift({ label: '전체', value: 'all' })
      }
      codes[codeTypeCode] = codeList
      // console.log(codes)
      return codes
    },

    // eslint-disable-next-line no-unused-vars
    loadCommonCodesW: async ({ commit }, { vm, codeTypeCode }) => {
      // const [res, err] = await vm.$https.get(
      //   "/common/v2/common/common-code",
      //   { systemTypeCode: "W", codeTypeCode },
      //   null,
      //   "gateway"
      // ); //API-WH-공통서비스-016 (공통코드조회-전체 리스트)
      // let codes = {},
      //   codeList = [];
      // if (!err) {
      //   codeList =
      //     res.data &&
      //     res.data.map(items => {
      //       return { label: items.codeName, value: items.code };
      //     });
      //   codeList.unshift({ label: "전체", value: "all" });
      // }
      // codes[codeTypeCode] = codeList;`
      // console.log(codes);
      // return codes;

      /* [#9951/2021.12.02/A936505] 온라인 상태코드 NVL(TH5_CHRR_NM, CD_NM) 적용 */
      const param = { systemTypeCode : 'W', codeTypeCode}

      const [res, err] = await vm.$https.get(
        `/common/v2/common/common-code/${param.systemTypeCode}/${param.codeTypeCode}`, null, null, 'gateway')

      let codes = {},
        codeList = []
      if (!err) {
        codeList =
          res.data &&
          res.data.map(items => {
            return {
              label: items.chrrName5 ? items.chrrName5 : items.codeName,
              value: items.code
            }
          })
        codeList.unshift({ label: '전체', value: 'all' })
      }
      codes[codeTypeCode] = codeList
      return codes
    },

    // eslint-disable-next-line no-unused-vars
    loadLegacyCommonCodesC: async ({ commit }, { vm, codeTypeCode }) => {
      /* const [res, err] = await vm.$https.get(
        "/common/v2/common/common-code",
        { systemTypeCode: "C", codeTypeCode },
        null,
        "gateway"
      );  */ //API-WH-공통서비스-016 (공통코드조회-전체 리스트)
      const [res, err] = await vm.$https.get(
        '/common/v2/common/common-code',
        { systemTypeCode: 'C', codeTypeCode },
        null,
        'gateway'
      ) //API-WH-공통서비스-016 (공통코드조회-전체 리스트)
      let codes = {},
        codeList = []
      if (!err) {
        codeList =
          res.data &&
          res.data.map(items => {
            return { label: items.codeName, value: items.code }
          })
        codeList.unshift({ label: '전체', value: 'all' })
      }
      codes[codeTypeCode] = codeList
      return codes
    },

    loadConsultants: async ({ commit, state }, { vm }) => {
      if (state.consultants.length > 0) return;
      const [res, err] = await vm.$https.get(
        "/v2/exclusive/common/consultant-name"
      );
      if (!err) {
        commit("setConsultants", res.data);
      }
    },

    loadAuthConsultants: async ({ commit, state }, { vm }) => {
      const [res, err] = await vm.$https.get(
        "/v2/exclusive/common/consultant-name-useauth"
      );
      if (!err) {
        commit("setAuthConsultants", res.data);
      }
    },

    loadAllTypeCars: async ({ commit, state }, { vm }) => {
      if (state.carTypes.length > 0) return
      const params = {
        carTypeFlag: '', // 차종전체구분
        siteTypeCode: 'E' // 임직원몰
      }
      const [res, err] = await vm.$https.get(
        '/product/v2/product/car/type',
        params,
        null,
        'gateway'
      )
      if (!err) {
        res.data.unshift({ carTypeCode: 'all', carTypeName: '전체' })
        commit('setAllTypeCars', res.data)
      }
    },

    loadDocumentTargets: async ({ commit, state }, { vm }) => {
      if (state.documentTargets.length > 0) return
      const [res, err] = await vm.$https.get(
        '/v2/exclusive/mypage/document/target'
      ) //API-WE-업무담당자-118 (마이페이지 필요서류대상 리스트 조회)
      if (!err) {
        res.data &&
          res.data.unshift({ neceDocTargNo: 'all', neceDocTargNm: '전체' })
        commit('setDocumentTargets', res.data)
      }
    },
    loadCommonCodesCustomerType: async (
      { commit, state },
      { vm, customerType }
    ) => {
      const [res, err] = await vm.$https.get(
        "/v2/exclusive/common/customerTypeCode",
        { customerType }
      );
      if (!err) {
        let codeList = [];

        codeList =
          res.data &&
          res.data.map(items => {
            return { label: items.codeName, value: items.code };
          });
        codeList.unshift({ label: "전체", value: "all" });

        commit("setCommonCodesCustomerType", codeList);
      }
    },
    loadCommonCodesCustomerType2: async (
      { commit, state },
      { vm, customerType }
    ) => {
      const [res, err] = await vm.$https.get(
        "/v2/exclusive/common/customerTypeCode",
        { customerType }
      );
      if (!err) {
        let codeList = [];

        codeList =
          res.data &&
          res.data.map(items => {
            return { label: items.codeName, value: items.code };
          });

        return codeList
      }
    },
    // eslint-disable-next-line no-unused-vars
    loadUnConfirmInfo: async ({ commit, state }, { vm }) => {
      // if(state.unConfirmInfo.length > 0) return
      const [res, err] = await vm.$https.get('/v2/exclusive/main/notice-count') // API-WE-업무담당자-006 (메인화면 업무 및 공지사항 알림 건수 조회)
      if (!err) {
        commit('setUnConfirmInfo', res.data)
      }
    },
    login: async ({ dispatch, commit }, { vm, uid, pwd }) => {
      const body = { id: uid, password: pwd }
      //const [res, err] = await vm.$https.post("/common/v2/common/login-exclusive/id", body, null, "gateway"); //API-WE-공통서비스-029 (업무담당자 ID/Password 로그인) //API-WE-공통서비스-029 (업무담당자 ID/Password 로그인)
      const [res, err] = await vm.$https.post(
        '/common/v2/common/login-exclusive/id',
        body,
        null,
        'gateway'
      )
      if (!err) {
        const { result = '', sessionId = '' } = res.data

        if (result === 'SUCCESS' && sessionId) {
          Cookies.set('sessionId', sessionId) // cookie 저장
          commit('setSessionId', sessionId) // state sessionId 저장
          await dispatch('loadUserInfo', { vm, sessionId })
          // header set - first load
          vm.$https.defaultHeaders['ep-jsessionid'] = sessionId
        }
        console.log('response => ', res)
        return res
      } else {
        return err
      }
    },
    devLogin: async ({ dispatch, commit }, { vm, uid, pwd }) => {
      const body = { id: uid, password: pwd }
      //const [res, err] = await vm.$https.post("/common/v2/common/login-exclusive/id", body, null, "gateway"); //API-WE-공통서비스-029 (업무담당자 ID/Password 로그인) //API-WE-공통서비스-029 (업무담당자 ID/Password 로그인)
      const [res, err] = await vm.$https.post(
        '/common/v2/common/login-exclusive/sso',
        body,
        null,
        'gateway'
      )
      if (!err) {
        const { result = '', sessionId = '' } = res.data

        if (result === 'SUCCESS' && sessionId) {
          Cookies.set('sessionId', sessionId) // cookie 저장
          commit('setSessionId', sessionId) // state sessionId 저장
          await dispatch('loadUserInfo', { vm, sessionId })
          // header set - first load
          vm.$https.defaultHeaders['ep-jsessionid'] = sessionId
        }
        console.log('response => ', res)
        return res
      } else {
        return err
      }
    },
    logout: async ({ commit }, { vm }) => {
      await vm.$https.put(
        '/common/v2/common/login-exclusive/logout',
        null,
        null,
        'gateway'
      ) //API-WE-공통서비스-014 (로그아웃)
      Cookies.remove('sessionId')
      Cookies.remove('userInfo')
      commit('setSessionId', null)
      commit('setAuth', false)
      commit('setMenuList', [])
    },
    ssoLogin: async ({ dispatch, commit }, { vm, sessionId }) => {
      Cookies.set('sessionId', sessionId) // cookie 저장
      commit('setSessionId', sessionId) // state sessionId 저장
      await dispatch('loadUserInfo', { vm, sessionId })
      // header set - first load
      vm.$https.defaultHeaders['ep-jsessionid'] = sessionId
      // vm.$https._axiosBlob.defaults.headers['ep-jsessionid'] = sessionId
      // vm.$https._axiosForm.defaults.headers['ep-jsessionid'] = sessionId
    },
    loadUserInfo: async ({ commit, state }, { vm, sessionId }) => {
      if (state.userInfo !== null) return
      const sId = Cookies.get('sessionId')
      console.log(sId)
      if (sId) {
        sessionId = sId
      }

      const params = {
        sessionId: 'wexclusive-' + sessionId
      }
      console.log(params)
      //const [res, err] = await vm.$https.get('/common/v2/session/attributes', params, null, 'gateway')
      const [res, err] = await vm.$https.get(
        '/common/v2/session/attributes',
        params,
        null,
        'gateway'
      )
      if (!err) {
        commit('setAuth', true) // 인증 완료 여부 Flag
        console.log('response => ', res.data)
        const userInfo = res.data.session
        Cookies.set('userInfo', userInfo)
        commit('setUserInfo', userInfo)
      } else {
        Cookies.remove('sessionId')
        Cookies.remove('userInfo')
        commit('setSessionId', null)
        commit('setAuth', false)
      }
    },

    // eslint-disable-next-line no-unused-vars
    loadMenuList: async ({ commit, state }, { vm }) => {
      if(state.menuList.length>0) return
      const [res, err] = await vm.$https.get('/v2/exclusive/menu') // API-WE-업무담당자-003 (업무담당자 컨설턴트 메뉴 목록 조회)
      // const[res, err] = pubMenuList //퍼블리싱 화면 활성화시
      if (!err) {
        console.log('menuList => ', res.data)
        const menus = res.data // before customise menu
        
        const transData =
          res.data.map(items => {
            // 변수명 치환 용도
            const {
              screenUrlAddress: menuLink,
              upperMenuId: parentId,
              ...rest
            } = items
            return { menuLink, parentId, ...rest }
          }) || []

        const menuList = convertList(transData)
        
        // depth1 최상위 메뉴의 링크가 없어서 맞춰주는 용도
        menuList.some(items => {
          const child = items.children
          child.some(items2 => {
            if (items2.parentId === items.menuId) {
              items.menuLink =
                '/' +
                items2.menuLink.split('/')[1] +
                '/' +
                items2.menuLink.split('/')[2]
              return true
            }
          })
        })

        commit('setMenuList', menuList)
        commit('setOriginMenus', menus)
      }
    },

    loadBookMarkList: async ({ commit }, { vm }) => {
      // if(state.bookMarkList.length>0) return

      const [res, err] = await vm.$https.get('/v2/exclusive/bookmark') // API-WE-업무담당자-004 (업무담당자 컨설턴트 별 즐겨찾기 목록 조회)
      if (!err) {
        const transData =
          res.data.map(items => {
            // 변수명 치환 용도
            const {
              screenUrlAddress: menuLink,
              upperMenuId: parentId,
              ...rest
            } = items
            return { menuLink, parentId, ...rest }
          }) || []
        console.log(transData)
        // const bookMarkList = convertList(transData)
        commit('setBookMarkList', transData)
      }
    },

    // eslint-disable-next-line no-unused-vars
    loadAuthBtnList: async ({ commit, state }, { vm }) => {
      // if(state.authBtnList.length>0) return

      const [res, err] = await vm.$https.get(
        '/v2/exclusive/menu/button-authority'
      ) // API-WE-업무담당자-131 (전담 컨설턴트 메뉴별 버튼 권한 목록 조회)
      if (!err) {
        console.log('authBtnList => ', res.data)

        commit('setAuthBtn', res.data)
      }
    },

    loadBannerList: async ({ commit }, { vm }) => {
      const [res, err] = await vm.$https.get(
        '/common/v2/common/banners',
        { siteTypeCode: 'E' },
        null,
        'gateway'
      ) // API-WH-공통서비스-003 (배너 리스트 조회)
      if (!err) {
        console.log('banners => ', res.data)
        commit('setBanners', res.data)
      }
    },

    commonSupportLog: async ({ commit }, { vm, params }) => {
      if(!params) params = {}
      params.userNo = vm.$store.state.userInfo.eeno
      params.menuId = vm.$store.state.currMenuId
      params.siteTypeCode = 'M'
      params.chanScnCode = 'P'
      params.systemUserTypeCode = '05'
      // params.ipAddress = '10.17.170.136'
      if(!params.menuId) {
        let checkMemuId = new Promise((resolve, reject) => {
  
          function retry() {
            setTimeout( function() {
              params.menuId = vm.$store.state.currMenuId
              if(params.menuId) {
                resolve()
              } else {
                retry()
              }
            }, 200)
          }
          retry()
        })
        checkMemuId.then(() => {
          vm.$https.post(
            '/common/v2/common/support/wlog',
            params,
            null,
            'gateway'
          )
        })
      } else {
        vm.$https.post(
          '/common/v2/common/support/wlog',
          params,
          null,
          'gateway'
        )
      }
    }
  }
})
