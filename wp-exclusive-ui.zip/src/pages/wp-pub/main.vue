<template>
  <section>
    <div id="release-detail">

      <div>
        <table class="tbl-list">
          <caption>공통레이어</caption>
          <colgroup>
            <col style="width:3%" />
            <col style="width:7%" />
            <col style="width:60%" />
            <col style="width:20%" />
          </colgroup>
          <thead>
            <tr>
              <th>유형</th>
              <th>화면ID</th>
              <th>화면명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td align="center">LP</td>
              <td align="center">SO-ETC-001</td>
              <td><a href="/#/wp-pub/pages/SO-ETC-001" target="_blank">공통레이어 - 빠른결제요청</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">LP</td>
              <td align="center">SO-ETC-002</td>
              <td><a href="/#/wp-pub/pages/SO-ETC-002" target="_blank">공통레이어 - 차량실사진보기</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">LP</td>
              <td align="center">SO-ETC-007</td>
              <td><a href="/#/wp-pub/pages/SO-ETC-007" target="_blank">공통레이어 - 해약</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">LP</td>
              <td align="center">SO-ETC-011</td>
              <td><a href="/#/wp-pub/pages/SO-ETC-011" target="_blank">공통레이어 - 현금결제변경</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">LP</td>
              <td align="center">SO-ETC-012</td>
              <td><a href="/#/wp-pub/pages/SO-ETC-012" target="_blank">공통레이어 - 카드결제변경</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">LP</td>
              <td align="center">SO-ETC-013</td>
              <td><a href="/#/wp-pub/pages/SO-ETC-013" target="_blank">공통레이어 - 출고센터변경</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">LP</td>
              <td align="center">SO-ETC-014</td>
              <td><a href="/#/wp-pub/pages/SO-ETC-014" target="_blank">공통레이어 - 탁송지변경</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">LP</td>
              <td align="center">SO-ETC-019</td>
              <td><a href="/#/wp-pub/pages/SO-ETC-019" target="_blank">공통레이어 - 생산차변경</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">LP</td>
              <td align="center">SO-ETC-020</td>
              <td><a href="/#/wp-pub/pages/SO-ETC-020" target="_blank">공통레이어 - 재고차조회</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">LP</td>
              <td align="center">SO-ETC-023</td>
              <td><a href="/#/wp-pub/pages/SO-ETC-023" target="_blank">공통레이어 - 파츠변경</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">LP</td>
              <td align="center">SO-ETC-024</td>
              <td><a href="/#/wp-pub/pages/SO-ETC-024" target="_blank">공통레이어 - 주소검색</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">LP</td>
              <td align="center">SO-ETC-026</td>
              <td><a href="/#/wp-pub/pages/SO-ETC-026" target="_blank">공통레이어 - 고객조회</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">LP</td>
              <td align="center">SO-ETC-027</td>
              <td><a href="/#/wp-pub/pages/SO-ETC-027" target="_blank">공통레이어 - 업체조회</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">LP</td>
              <td align="center">SO-ETC-028</td>
              <td><a href="/#/wp-pub/pages/SO-ETC-028" target="_blank">공통레이어 - 법인번호입력</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">LP</td>
              <td align="center">SO-ETC-029</td>
              <td><a href="/#/wp-pub/pages/SO-ETC-029" target="_blank">공통레이어 - 공식지정인수점조회</a></td>
              <td></td>
            </tr>
          </tbody>
        </table>

        <table class="tbl-list">
          <caption>계약출고</caption>
          <colgroup>
            <col style="width:3%" />
            <col style="width:7%" />
            <col style="width:60%" />
            <col style="width:20%" />
          </colgroup>
          <thead>
            <tr>
              <th>유형</th>
              <th>화면ID</th>
              <th>화면명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td align="center">GP</td>
              <td align="center">SO-SHP-003</td>
              <td><a href="/#/wp-pub/pages/SO-SHP-003" target="_blank">계약출고 - 대고객계약출고상세조회</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">TP</td>
              <td align="center">SO-SHP-004</td>
              <td>계약출고 - 대고객계약출고상세조회 - 계약정보</td>
              <td></td>
            </tr>
            <tr>
              <td align="center">TP</td>
              <td align="center">SO-SHP-005</td>
              <td>계약출고 - 대고객계약출고상세조회 - 차량정보</td>
              <td></td>
            </tr>
            <tr>
              <td align="center">TP</td>
              <td align="center">SO-SHP-006</td>
              <td>계약출고 - 대고객계약출고상세조회 - 결제정보</td>
              <td></td>
            </tr>
            <tr>
              <td align="center">TP</td>
              <td align="center">SO-SHP-007</td>
              <td>계약출고 - 대고객계약출고상세조회 - 출고정보</td>
              <td></td>
            </tr>
            <tr>
              <td align="center">TP</td>
              <td align="center">SO-SHP-009</td>
              <td>계약출고 - 대고객계약출고상세조회 - 상태이력</td>
              <td></td>
            </tr>
            <tr>
              <td align="center">GP</td>
              <td align="center">SO-SHP-010</td>
              <td><a href="/#/wp-pub/pages/SO-SHP-010" target="_blank">계약출고 - 법인계약출고상세조회</a></td>
              <td></td>
            </tr>
          </tbody>
        </table>

        <table class="tbl-list">
          <caption>마이페이지</caption>
          <colgroup>
            <col style="width:3%" />
            <col style="width:7%" />
            <col style="width:60%" />
            <col style="width:20%" />
          </colgroup>
          <thead>
            <tr>
              <th>유형</th>
              <th>화면ID</th>
              <th>화면명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td align="center">GP</td>
              <td align="center">SO-MRT-003</td>
              <td><a href="/#/wp-pub/pages/SO-MRT-003" target="_blank">마이페이지수신업무 - 대고객마이페이지수신업무처리</a></td>
              <td></td>
            </tr>
          </tbody>
        </table>

        <table class="tbl-list">
          <caption>직원인증</caption>
          <colgroup>
            <col style="width:3%" />
            <col style="width:7%" />
            <col style="width:60%" />
            <col style="width:20%" />
          </colgroup>
          <thead>
            <tr>
              <th>유형</th>
              <th>화면ID</th>
              <th>화면명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td align="center">GP</td>
              <td align="center">SO-EMP-001</td>
              <td><a href="/#/wp-pub/pages/SO-EMP-001" target="_blank">직원인증 - 직원인증업무조회</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">GP</td>
              <td align="center">SO-EMP-002</td>
              <td><a href="/#/wp-pub/pages/SO-EMP-002" target="_blank">직원인증 - 직원인증업무처리</a></td>
              <td></td>
            </tr>
          </tbody>
        </table>

        <table class="tbl-list">
          <caption>지원업무</caption>
          <colgroup>
            <col style="width:3%" />
            <col style="width:7%" />
            <col style="width:60%" />
            <col style="width:20%" />
          </colgroup>
          <thead>
            <tr>
              <th>유형</th>
              <th>화면ID</th>
              <th>화면명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td align="center">GP</td>
              <td align="center">SO-SPT-001</td>
              <td><a href="/#/wp-pub/pages/SO-SPT-001" target="_blank">지원업무 - 계열사직원계약출고조회</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">GP</td>
              <td align="center">SO-SPT-005</td>
              <td><a href="/#/wp-pub/pages/SO-SPT-005" target="_blank">지원업무 - 전담DC품의조회</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">GP</td>
              <td align="center">SO-SPT-006</td>
              <td><a href="/#/wp-pub/pages/SO-SPT-006" target="_blank">지원업무 - 대형견적목록</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">GP</td>
              <td align="center">SO-SPT-007</td>
              <td><a href="/#/wp-pub/pages/SO-SPT-007" target="_blank">지원업무 - 대형견적상세조회 - 발송이력</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">TP</td>
              <td align="center">SO-SPT-008</td>
              <td>지원업무 - 대형견적상세조회 - 견적이력</td>
              <td></td>
            </tr>
            <tr>
              <td align="center">TP</td>
              <td align="center">SO-SPT-009</td>
              <td>직원인증 - 대형견적상세조회 - 계약이력</td>
              <td></td>
            </tr>         
          </tbody>
        </table>

        <table class="tbl-list">
          <caption>집계</caption>
          <colgroup>
            <col style="width:3%" />
            <col style="width:7%" />
            <col style="width:60%" />
            <col style="width:20%" />
          </colgroup>
          <thead>
            <tr>
              <th>유형</th>
              <th>화면ID</th>
              <th>화면명</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td align="center">GP</td>
              <td align="center">SO-STA-002</td>
              <td><a href="/#/wp-pub/pages/SO-STA-002" target="_blank">집계 - 회원통합조회 - 회원조회/결과</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">TP</td>
              <td align="center">SO-STA-003</td>
              <td>집계 - 회원통합조회 - 회원조회/결과 - 견적이력</td>
              <td></td>
            </tr>
            <tr>
              <td align="center">TP</td>
              <td align="center">SO-STA-004</td>
              <td>집계 - 회원통합조회 - 회원조회/결과 - 시승이력</td>
              <td></td>
            </tr>
            <tr>
              <td align="center">TP</td>
              <td align="center">SO-STA-005</td>
              <td>집계 - 회원통합조회 - 회원조회/결과 - 계약이력</td>
              <td></td>
            </tr>
            <tr>
              <td align="center">TP</td>
              <td align="center">SO-STA-006</td>
              <td>집계 - 회원통합조회 - 회원조회/결과 - 보유쿠폰</td>
              <td></td>
            </tr>
            <tr>
              <td align="center">TP</td>
              <td align="center">SO-STA-007</td>
              <td>집계 - 회원통합조회 - 회원조회/결과 - 문자발송이력</td>
              <td></td>
            </tr>
            <tr>
              <td align="center">GP</td>
              <td align="center">SO-STA-008</td>
              <td><a href="/#/wp-pub/pages/SO-STA-008" target="_blank">집계 - 엠버서더실적조회</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">GP</td>
              <td align="center">SO-STA-010</td>
              <td><a href="/#/wp-pub/pages/SO-STA-010" target="_blank">집계 - 쿠폰발급사용조회</a></td>
              <td></td>
            </tr>
            <tr>
              <td align="center">GP</td>
              <td align="center">SO-STA-011</td>
              <td><a href="/#/wp-pub/pages/SO-STA-011" target="_blank">집계 - 쿠폰발급사용상세조회</a></td>
              <td></td>
            </tr>
          </tbody>
        </table>

      </div>
    </div>
  </section>
  </template>
<script>
</script>
<style lang="scss" scoped>
  .tbl-list { 
    margin-bottom:20px; 
    caption {
      display:none;
    }
    td {
      color:#444;
    }
    a { 
      color:#000;
      border-bottom:1px solid #000;
      &:hover {
        border-color:#ff0000;
        color:#ff0000;
      }
    }
    tr:hover {
      td { background:#eee }
    }
  }
@import "~/assets/style/pages/main.scss";
@import "~/assets/style/pages/detail.scss";
</style>
