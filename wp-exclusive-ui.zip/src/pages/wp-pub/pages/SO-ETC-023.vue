<template>
  <section>
    <div id="release-detail">
      
      <so-etc023></so-etc023>
      
    </div>
  </section>
</template>
<script>
import SoEtc023 from '~/pages/wp-pub/components/popup/SO-ETC-023.vue'

export default {
  name: 'PopEtc023',
  layout: 'default',
  components: {
    SoEtc023,
  },
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
