<template>
  <section>
    <div id="release-detail">

      <so-etc029></so-etc029>

    </div>
  </section>
</template>
<script>
import SoEtc029 from '~/pages/wp-pub/components/popup/SO-ETC-029.vue'

export default {
  name: 'PopEtc029',
  layout: 'default',
  components: {
    SoEtc029,
  },
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
