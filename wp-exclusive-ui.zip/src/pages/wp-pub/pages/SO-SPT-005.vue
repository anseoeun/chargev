<template>
  <section>
    <div id="support">

      <div class="article-title">
        <el-button type="info">초기화</el-button>
        <div>
          <el-button type="primary">조회</el-button>
          <el-button type="primary" class="btn-excel">EXCEL 다운로드</el-button>
        </div>
      </div>
      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="8">
              <el-form-item label="기준년월">
                <el-date-picker type="date" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="계약담당자">
                <el-select>
                  <el-option label="지성민"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="국판 진행상태">
                <el-select>
                  <el-option label="전체"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="집계데이터 조회">
                <ul class="data-list">
                  <li><strong class="tit">전체</strong><span class="val"><strong>430</strong>건</span></li>
                  <li><strong class="tit">할인금액</strong><span class="val"><strong>1,000,000</strong>원</span></li>
                  <li><strong class="tit">매출취소금액</strong><span class="val"><strong>300,000</strong>원</span></li>
                  <li><strong class="tit">사용금액</strong><span class="val"><strong>2,500,000</strong>원</span></li>
                </ul>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <div class="box gap">
        <el-table :data="tableData">
          <el-table-column prop="data1" label="NO." width="80" align="center"></el-table-column>
          <el-table-column prop="data2" label="계약번호" width="129" align="center"></el-table-column>
          <el-table-column prop="data3" label="주계약자" width="155" align="center"></el-table-column>
          <el-table-column prop="data4" label="계약담당자" width="155" align="center"></el-table-column>
          <el-table-column prop="data5" label="출고일" width="150" align="center"></el-table-column>
          <el-table-column prop="data6" label="인수확정일" width="150" align="center"></el-table-column>
          <el-table-column prop="data7" label="제작증발급일" width="150" align="center"></el-table-column>
          <el-table-column prop="data8" label="할인금액" width="150" align="center"></el-table-column>
          <el-table-column prop="data9" label="할인적용일" width="150" align="center"></el-table-column>
          <el-table-column prop="data10" label="매출취소일" width="150" align="center"></el-table-column>
          <el-table-column prop="data11" label="판매진행상태" width="120" align="center"></el-table-column>
        </el-table>
      </div>

    </div>
  </section>
</template>

<script>
export default {
  layout: 'default',
  data() {
    return {
      tableData: [
        {
          data1: 34,
          data2: 'A2020022303',
          data3: '지성민',
          data4: '길인수',
          data5: '2021-11-11 11:11',
          data6: '2021-11-11 22:22',
          data7: '2021-11-11 33:33',
          data8: '150,000원',
          data9: '2021-11-11 33:33',
          data10: '2021-11-11 11:11',
          data11: '출고',
        },
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
