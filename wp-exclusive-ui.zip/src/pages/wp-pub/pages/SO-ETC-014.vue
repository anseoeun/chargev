<template>
  <section>
    <div id="release-detail">
      
      <so-etc014></so-etc014>
      
    </div>
  </section>
</template>
<script>
import SoEtc014 from '~/pages/wp-pub/components/popup/SO-ETC-014.vue'

export default {
  name: 'PopEtc014',
  layout: 'default',
  components: {
    SoEtc014,
  },
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
