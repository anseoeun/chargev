<template>
  <section>
    <div id="release-detail">

      <so-etc028></so-etc028>

    </div>
  </section>
</template>
<script>
import SoEtc028 from '~/pages/wp-pub/components/popup/SO-ETC-028.vue'

export default {
  name: 'PopEtc028',
  layout: 'default',
  components: {
    SoEtc028,
  },
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
