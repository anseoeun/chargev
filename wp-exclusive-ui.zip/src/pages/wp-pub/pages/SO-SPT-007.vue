<template>
  <section>
    <div id="support">
     
      <div class="article-title">
        <h-search :title="'대행견적번호'" />
        <div class="btn-group">
          <el-button type="primary">문자보내기</el-button>
          <el-button type="primary">이메일보내기</el-button>
        </div>
      </div>

      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="8">
              <el-form-item label="계약구분">개인</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="판매SPEC">AXJDAF C99 WW2 RPT</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="사번">E603438923</el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <div class="article tabs">
        <el-tabs type="card" stretch>
          <el-tab-pane label="발송이력(200)">
            <so-spt007></so-spt007>
          </el-tab-pane>

          <el-tab-pane label="견적이력(100)">
            <so-spt008></so-spt008>
          </el-tab-pane>

          <el-tab-pane label="계약이력(1)">
            <so-spt009></so-spt009>
          </el-tab-pane>
        </el-tabs>
      </div>     

    </div>
  </section>
</template>

<script>
import HSearch from '~/components/common/HSearch.vue'
import SoSpt007 from '~/pages/wp-pub/components/tab/SO-SPT-007.vue'
import SoSpt008 from '~/pages/wp-pub/components/tab/SO-SPT-008.vue'
import SoSpt009 from '~/pages/wp-pub/components/tab/SO-SPT-009.vue'

export default {
  layout: 'default',
  components: {
    HSearch,
    SoSpt007,
    SoSpt008,
    SoSpt009,
  },
  data() {
    return {
      
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
