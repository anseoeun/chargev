<template>
  <section>
    <div id="support">

      <div class="article-title">
        <el-button type="info">초기화</el-button>
        <el-button type="primary">조회</el-button>
      </div>
      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="8">
              <el-form-item label="이름">
                <el-input />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="생년월일">
                <el-date-picker type="date" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="휴대전화">
                <el-input />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <div class="article-title">
        <h2>조회결과</h2>
      </div>
      <div class="box">
        <el-table :data="tableData">
          <el-table-column prop="data1" label="이름" width="200" align="center"></el-table-column>
          <el-table-column prop="data2" label="생년월일" width="150" align="center"></el-table-column>
          <el-table-column prop="data3" label="소속" width="439" align="center"></el-table-column>
          <el-table-column prop="data4" label="할인율" width="150" align="center"></el-table-column>
          <el-table-column prop="data5" label="최근 구매계약번호" width="300" align="center"></el-table-column>
          <el-table-column prop="data6" label="출고일" width="150" align="center"></el-table-column>
          <el-table-column prop="data7" label="구입가능일" width="150" align="center"></el-table-column>
        </el-table>
      </div>

      <div class="article-title gap">
        <div>
          <el-date-picker type="date" />
          <span class="ex-txt">~</span>
          <el-date-picker type="date" />
          <el-radio-group v-model="searchDtRadio" class="tabBtn-case01 auto">
            <el-radio-button label="year1">1년</el-radio-button>
            <el-radio-button label="year3">3년</el-radio-button>
            <el-radio-button label="year5">5년</el-radio-button>
            <el-radio-button label="year10">10년</el-radio-button>
          </el-radio-group>
          <el-button type="primary" class="btn-small space">조회</el-button>
        </div>
      </div>
      <div class="box">
        <el-table :data="tableData2">
          <el-table-column label="차명" width="439" align="center">
            <template scope="item">
              <el-popover placement="top" trigger="hover">
                <ul>
                  <li>모델: AX1</li>
                  <li>외장컬러: 햄턴그레이</li>
                  <li>내장컬러: 블랙모노톤(블랙시트)</li>
                </ul>
                <span class="item-hover" slot="reference">AX1</span>
              </el-popover>
            </template>
          </el-table-column>
          <el-table-column prop="data2" label="계약번호" width="400" align="center"></el-table-column>
          <el-table-column prop="data3" label="출고일" width="150" align="center"></el-table-column>
          <el-table-column prop="data4" label="의무보유기간" width="150" align="center"></el-table-column>
          <el-table-column prop="data5" label="DC금액" width="200" align="center"></el-table-column>
          <el-table-column prop="data6" label="판매구분" width="200" align="center"></el-table-column>
        </el-table>
      </div>
      
    </div>
  </section>
</template>

<script>
export default {
  layout: 'default',
  data() {
    return {
      searchDtRadio: 'year3',
      tableData: [
        {
          data1: '지성민',
          data2: '780209',
          data3: '유젠 EC사업부',
          data4: '17%',
          data5: '',
          data6: '2020-02-02',
          data7: '2020-02-02',
        },
      ],
      tableData2: [
        {
          data1: 'AX1',
          data2: 'A301323020',
          data3: '2021-10-31',
          data4: '~2022-10-31',
          data5: '360,000원',
          data6: 'AX몰',
        },
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
