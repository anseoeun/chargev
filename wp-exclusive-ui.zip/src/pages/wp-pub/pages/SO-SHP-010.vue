<template>
  <section>
    <div id="release-detail">
      <div class="article-title">
        <h-search :title="'계약번호'" />        
        <div class="btn-group">
          <div>
            <el-button type="primary">전담DC품의</el-button>
            <el-button type="info">방문예약</el-button>
            <el-button type="primary">문자보내기</el-button>
            <el-button type="primary">견적보기</el-button>
            <el-button type="info">제작증 발급</el-button>
          </div>
          <div>
            <el-button type="primary">배정취소</el-button>
            <el-button type="info">결제 초기화</el-button>
            <el-button type="primary">해약</el-button>
            <el-button type="primary">결제항목 활성화</el-button>
            <el-button type="primary">서류요청</el-button>
          </div>
        </div>
      </div>
      
      <el-form ref="info" class="detail-form table-wrap">
        <el-row>
          <el-col :span="8">
            <el-form-item label="통합계약번호">T3720TM001530</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="계약자">삼성전자 (130111-9996247)</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="계약 담당자">노은정</el-form-item>
          </el-col>  
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="온라인 진행상태">결제처리중</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="국판 진행상태">배정(6),출고(1)</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="고객구분">
              <div class="select-client">
                <el-select v-model="client">
                  <el-option label="리스(캐피탈)" value=""></el-option>
                </el-select>
                <el-select v-model="client2">
                  <el-option label="없음" value=""></el-option>
                </el-select>
              </div>
              <el-button type="primary" class="btn-small">변경</el-button>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24" align="right">
            <el-form-item label="진행상황메모">
              <el-input v-model="memo" type="textarea" class="textarea" placeholder="최대 1,000자까지 입력하실 수 있습니다." />
              <el-button type="primary" class="btn-save">저장</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>

      <div class="box">
        <h-title title="구매차량목록" />
        <el-table :data="tableData" class="box">
          <el-table-column prop="data1" label="NO." width="60" align="center"></el-table-column>
          <el-table-column prop="data2" label="계약번호" width="200" align="center"></el-table-column>
          <el-table-column prop="data3" label="차량유형" width="150" align="center"></el-table-column>
          <el-table-column prop="data4" label="판매 SPEC" width="300" align="center"></el-table-column>
          <el-table-column prop="data5" label="과세 구분" width="120" align="center"></el-table-column>
          <el-table-column prop="data6" label="연세 유형" width="120" align="center"></el-table-column>
          <el-table-column prop="data7" label="온라인 진행상태" width="200" align="center"></el-table-column>
          <el-table-column prop="data8" label="판매 진행상태" width="200" align="center"></el-table-column>
          <el-table-column prop="data9" label="결제 진행상태" width="200" align="center"></el-table-column>
          <el-table-column prop="data10" label="서류심사 상태" width="200" align="center"></el-table-column>
          <el-table-column prop="data11" label="출고증 발급요청" width="200" align="center"></el-table-column>
          <el-table-column prop="data12" label="세금 계산서" width="200" align="center"></el-table-column>
        </el-table>
      </div>

      <div class="article tabs">
        <el-tabs type="card" stretch>
          <el-tab-pane label="계약정보">
            <so-shp004></so-shp004>
          </el-tab-pane>

          <el-tab-pane label="차량정보">
            <so-shp005></so-shp005>
          </el-tab-pane>

          <el-tab-pane label="결제정보">
            <so-shp006></so-shp006>
          </el-tab-pane>

          <el-tab-pane label="출고정보">
            <so-shp007></so-shp007>
          </el-tab-pane>

          <el-tab-pane label="상태이력">
            <so-shp008></so-shp008>
          </el-tab-pane>

          <el-tab-pane label="문자이력">
            <so-shp009></so-shp009>
          </el-tab-pane>
        </el-tabs>
      </div>
      
    </div>
  </section>
</template>

<script>
import HSearch from '~/components/common/HSearch.vue'
import SoShp004 from '~/pages/wp-pub/components/tab/SO-SHP-004.vue'
import SoShp005 from '~/pages/wp-pub/components/tab/SO-SHP-005.vue'
import SoShp006 from '~/pages/wp-pub/components/tab/SO-SHP-006.vue'
import SoShp007 from '~/pages/wp-pub/components/tab/SO-SHP-007.vue'
import SoShp008 from '~/pages/wp-pub/components/tab/SO-SHP-008.vue'
import SoShp009 from '~/pages/wp-pub/components/tab/SO-SHP-009.vue'

export default {
  name: 'ReleaseDetail',
  layout: 'default',
  components: {
    HSearch,
    SoShp004,
    SoShp005,
    SoShp006,
    SoShp007,
    SoShp008,
    SoShp009,
  },
  data() {
    return {
      memo: '',
      client: '',
      client2: '',
      tableData: [
        {
          data1: 1,
          data2: 'A334343549',
          data3: '생산주문',
          data4: '',
          data5: '면세',
          data6: '렌터카',
          data7: '결제처리중',
          data8: '배정',
          data9: '결제완료',
          data10: '심사중',
          data11: 'N',
          data12: '',
        }
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
