<template>
  <section>
    <div id="release-detail">
      
      <so-etc019></so-etc019>
      
    </div>
  </section>
</template>
<script>
import SoEtc019 from '~/pages/wp-pub/components/popup/SO-ETC-019.vue'

export default {
  name: 'PopEtc019',
  layout: 'default',
  components: {
    SoEtc019,
  },
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
