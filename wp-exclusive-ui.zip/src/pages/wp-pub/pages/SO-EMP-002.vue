<template>
  <section>
    <div id="staff">
      <div class="article-title">
        <h-search :title="'업무번호'" />
        <div class="btn-group">
          <div>
            <el-button type="primary">저장</el-button>
            <el-button type="primary">문자보내기</el-button>
            <!-- <el-button type="info">취소</el-button> -->
          </div>
        </div>
      </div>

      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="8">
              <el-form-item label="고객관리번호">
                  <el-input style="width:200px;" />
                  <el-button type="info" class="btn-small">조회</el-button>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="고객명">지성민</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="배우자">
                <el-input style="width:200px;" />
                <el-button type="info" class="btn-small">조회</el-button>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="생년월일">790229</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="이메일">dddd@email.net</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="휴대전화">010-1111-1111</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="업무번호">SRT10291038</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="진행상태" required>
                <div class="select-client">
                  <el-select>
                    <el-option label="완료"></el-option>
                  </el-select>
                  <el-select>
                    <el-option label="선택하세요"></el-option>
                  </el-select>
                </div>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="업무처리자">박혜진</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="승인일시">2021-01-08 12:11</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="구매가능일">2022-03-24 이후</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="인증 만료일" required>
                <el-date-picker type="date" />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="요청메모">
                <el-input type="textarea" />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <div class="article-title">
        <h2>직원 인증 정보</h2>
      </div>
      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="8">
              <el-form-item label="고객구분" required>
                <el-select>
                  <el-option label="[AG2] 관계사 직원"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="소속" required>
                <el-select>
                  <el-option label="새마을금고 3년미만"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="할인율">DC 8% 무이자 30개월</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="업체" required>
                <div class="select-client">
                  <el-select disabled>
                    <el-option label="관계회사" />
                  </el-select>
                  <el-select>
                    <el-option label="회사명" />
                  </el-select>
                </div>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="사번" required>
                <el-input />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="입사일" required>
                <el-date-picker type="date" />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      
      <div class="article-title gap">
        <h2>서류 심사 목록</h2>
        <el-button type="primary" class="btn-md" icon="el-icon-plus" />
      </div> 
      <div class="box">     
        <el-form class="detail-form table-wrap">
          <el-row>
            <el-col :span="8">
              <el-form-item label="구분">
                <el-select>
                  <el-option label="전체"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="소분류">
                <el-select>
                  <el-option label="전체"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="처리결과">
                <el-select>
                  <el-option label="전체"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-table :data="tableData" class="box append-box">
          <el-table-column prop="data1" label="NO." width="60" align="center">
            <el-button type="info" class="btn-small">-</el-button>
          </el-table-column>
          <el-table-column prop="data2" label="구분" width="310">
            <el-select>
              <el-option label="선택하세요" />
            </el-select>
          </el-table-column>
          <el-table-column prop="data3" label="소분류" width="319">
            <el-select>
              <el-option label="선택하세요" />
            </el-select>
          </el-table-column>
          <el-table-column prop="data4" label="스크래핑 결과" width="100" align="center" />
          <el-table-column prop="data5" label="추가서류 여부" width="100" align="center" />
          <el-table-column prop="data6" label="제출서류" width="150" align="center" show-overflow-tooltip>
            <!-- <el-button type="info" class="btn-small">등록</el-button> -->
            <el-button type="text" class="btn-small" icon="el-icon-document">202104_file</el-button>
          </el-table-column>
          <el-table-column prop="data7" label="요청일시" width="200" align="center" />
          <el-table-column prop="data8" label="등록일시" width="200" align="center" />
          <el-table-column prop="data9" label="처리일시" width="200" align="center" />
          <el-table-column prop="data10" label="처리결과" width="150" align="center">
            <el-select>
              <el-option label="대기" />
              <el-option label="접수" />
            </el-select>
          </el-table-column>
          <el-table-column prop="data11" label="진행상황메모" width="450">
            <el-input />
          </el-table-column>
        </el-table>
      </div>

      <div class="article-title">
        <h2>심사 대상 서류목록</h2>
        <el-button type="primary" class="btn-md" icon="el-icon-plus" />
      </div>
      <div class="box">
        <el-table :data="tableData2">
          <el-table-column prop="data1" label="NO." width="60" align="center" />
          <el-table-column prop="data2" label="구분" width="310" />
          <el-table-column prop="data3" label="소분류" width="319" />
          <el-table-column prop="data4" label="스크래핑 여부" width="100" align="center" />
          <el-table-column prop="data5" label="스크래핑 결과" width="100" align="center" />
          <el-table-column prop="data6" label="추가서류 여부" width="150" align="center" />
          <el-table-column prop="data7" label="요청일시" width="200" align="center" />
          <el-table-column prop="data8" label="상태변경일시" width="200" align="center" />
          <el-table-column prop="data9" label="상태" width="100" align="center" />
        </el-table>
      </div>

      <div class="article-title">
        <h2>직원인증 이력</h2>
      </div>
      <div class="box">
        <el-table :data="tableData3">
          <el-table-column prop="data1" label="NO." width="60" align="center"></el-table-column>
          <el-table-column prop="data2" label="요청일시" width="200" align="center"></el-table-column>
          <el-table-column prop="data3" label="처리일시" width="200" align="center"></el-table-column>
          <el-table-column prop="data4" label="소속" width="360"></el-table-column>
          <el-table-column prop="data5" label="할인률" width="319"></el-table-column>
          <el-table-column prop="data6" label="업무처리자" width="150" align="center"></el-table-column>
          <el-table-column prop="data7" label="진행상태" width="150" align="center"></el-table-column>
          <el-table-column prop="data8" label="직원여부" width="100" align="center"></el-table-column>
        </el-table>
      </div>

    </div>
  </section>
</template>

<script>
import HSearch from '~/components/common/HSearch.vue'
export default {
  layout: 'default',
  components: {
    HSearch,
  },
  data() {
    return {
      tableData: [
        {
          data1: 1,
          data2: '고객유형-직원',
          data3: '신분증(주민등록증 or 운전면허)',
          data4: 'Y',
          data5: 'Y',
          data6: '',
          data7: '-',
          data8: '-',
          data9: '-',
          data10: '재심사',
          data11: '사진 좀 잘 찍어주세요.',
        }
      ],
      tableData2: [
        {
          data1: 1,
          data2: '고객유형-직원',
          data3: '신분증(주민등록증 or 운전면허)',
          data4: 'N',
          data5: 'N',
          data6: 'Y',
          data7: '2021-01-22 16:00',
          data8: '2021-01-22 16:00',
          data9: '심사중',
        }
      ],
      tableData3: [
        {
          data1: 1,
          data2: '2020-02-21 16:44',
          data3: '2020-02-21 16:11',
          data4: '새마을금고 3년이상 ~ 5년미만',
          data5: 'DC 8% 무이자 3개월(1,000만원)',
          data6: '박혜진',
          data7: '완료',
          data8: 'N',
        }
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
.btn-md{
  min-width: 40px;
  height: 40px;
}
.append-box {
  .el-input, .el-select {
    margin:2px 0;
  }
}
</style>
