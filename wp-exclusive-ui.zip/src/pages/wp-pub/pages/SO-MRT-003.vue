<template>
  <section>
    <div id="process">      
      <div class="article-title">
        <h-search :title="'업무일련번호'" />
        <div class="btn-group">
          <div>
            <el-button type="primary">저장</el-button>
            <el-button type="primary">문자보내기</el-button>
          </div>
        </div>
      </div>

      <div class="box">
        <el-form class="detail-form table-wrap">
          <el-row>
            <el-col :span="8">
              <el-form-item label="계약번호">A3720TM001530</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="계약자">길인수 외1</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="계약담당자">노은정</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="온라인 진행상태">차량구매완료(미신고)</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="국판 진행상태">출고</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="고객구분">일반개인</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="계약완료일">2020-11-28 14:00</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="결제완료일">2020-11-28 14:00</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="출고일">2021-11-11</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="인도확정일">2021-02-02</el-form-item>
            </el-col>
            <el-col :span="16">
              <el-form-item label="제작증발급일">2021-02-26 15:44</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="업무유형">서류심사</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="업무진행상태">
                <el-select v-model="status">
                  <el-option label="접수" value=""></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="업무처리자">송정희</el-form-item>
            </el-col>
          </el-row>
        </el-form>        
      </div>
      
      <div class="box">     
        <div class="article-title">
          <h-title title="서류심사목록" />
          <el-button type="primary" class="btn-md" icon="el-icon-plus" />
        </div> 
        <el-form class="detail-form table-wrap">
          <el-row>
            <el-col :span="8">
              <el-form-item label="구분">
                <el-select v-model="type1">
                  <el-option label="전체" value="">전체</el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="소분류">
                <el-select v-model="type2">
                  <el-option label="전체" value="">전체</el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="처리결과">
                <el-select v-model="type3">
                  <el-option label="전체" value="">전체</el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-table :data="tableData" class="box">
          <el-table-column prop="data1" label="NO." width="60" align="center"></el-table-column>
          <el-table-column prop="data2" label="구분" width="300"></el-table-column>
          <el-table-column prop="data3" label="소분류" width="300"></el-table-column>
          <el-table-column prop="data4" label="스크래핑 결과" width="100" align="center"></el-table-column>
          <el-table-column prop="data5" label="추가서류 여부" width="100" align="center"></el-table-column>
          <el-table-column prop="data6" label="제출서류" width="200" align="center"></el-table-column>
          <el-table-column prop="data7" label="요청일시" width="200" align="center"></el-table-column>
          <el-table-column prop="data8" label="등록일시" width="200" align="center"></el-table-column>
          <el-table-column prop="data9" label="처리일시" width="200" align="center"></el-table-column>
          <el-table-column prop="data10" label="처리결과" width="200" align="center"></el-table-column>
          <el-table-column prop="data11" label="진행상황메모" width="500"></el-table-column>
        </el-table>
      </div>

      <div class="box">
        <h-title title="심사대상 서류목록" />
        <el-table :data="tableData2" class="box">
          <el-table-column prop="data1" label="NO." width="60" align="center"></el-table-column>
          <el-table-column prop="data2" label="구분" width="300"></el-table-column>
          <el-table-column prop="data3" label="소분류" width="300"></el-table-column>
          <el-table-column prop="data4" label="스크래핑 여부" width="100" align="center"></el-table-column>
          <el-table-column prop="data5" label="스크래핑 결과" width="100" align="center"></el-table-column>
          <el-table-column prop="data6" label="추가서류 여부" width="100" align="center"></el-table-column>
          <el-table-column prop="data7" label="요청일시" width="200" align="center"></el-table-column>
          <el-table-column prop="data8" label="처리일시" width="200" align="center"></el-table-column>
          <el-table-column prop="data9" label="상태" width="179" align="center"></el-table-column>
        </el-table>
      </div>
    
      <div class="article tabs">
        <el-tabs type="card" stretch>
          <el-tab-pane label="계약정보">
            <so-shp004></so-shp004>
          </el-tab-pane>

          <el-tab-pane label="차량정보">
            <so-shp005></so-shp005>
          </el-tab-pane>

          <el-tab-pane label="결제정보">
            <so-shp006></so-shp006>
          </el-tab-pane>

          <el-tab-pane label="출고정보">
            <so-shp007></so-shp007>
          </el-tab-pane>

          <el-tab-pane label="상태이력">
            <so-shp008></so-shp008>
          </el-tab-pane>

          <el-tab-pane label="문자이력">
            <so-shp009></so-shp009>
          </el-tab-pane>
        </el-tabs>
      </div>
    </div>
    
  </section>
</template>

<script>
import HTitle from '~/components/common/HTitle.vue'
import HSearch from '~/components/common/HSearch.vue'
import SoShp004 from '~/pages/wp-pub/components/tab/SO-SHP-004.vue'
import SoShp005 from '~/pages/wp-pub/components/tab/SO-SHP-005.vue'
import SoShp006 from '~/pages/wp-pub/components/tab/SO-SHP-006.vue'
import SoShp007 from '~/pages/wp-pub/components/tab/SO-SHP-007.vue'
import SoShp008 from '~/pages/wp-pub/components/tab/SO-SHP-008.vue'
import SoShp009 from '~/pages/wp-pub/components/tab/SO-SHP-009.vue'

export default {
  name: 'Process',
  layout: 'default',
  components: {
    HTitle,
    HSearch,
    SoShp004,
    SoShp005,
    SoShp006,
    SoShp007,
    SoShp008,
    SoShp009,
  },
  data() {
    return {
      status: '',
      type1: '',
      type2: '',
      type3: '',
      tableData: [
        {
          data1: 1,
          data2: '고객유형-직원',
          data3: '신분증(주민등록증 or 운전면허)',
          data4: '',
          data5: 'Y',
          data6: '',
          data7: '2021-01-22 16:00',
          data8: '2021-01-22 16:00',
          data9: '2021-01-22 16:00',
          data10: '재심사',
          data11: '사진 좀 잘 찍어주세요.',
        }
      ],
      tableData2: [
        {
          data1: 1,
          data2: '고객유형-직원',
          data3: '신분증(주민등록증 or 운전면허)',
          data4: 'N',
          data5: 'N',
          data6: 'Y',
          data7: '2021-01-22 16:00',
          data8: '2021-01-22 16:00',
          data9: '심사중',
        }
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
.btn-md{
  min-width: 40px;
  height: 40px;
}
@import '~/assets/style/pages/detail.scss';
</style>
