<template>
  <section>
    <div id="release-detail">
      
      <so-etc001></so-etc001>
      
    </div>
  </section>
</template>
<script>
import SoEtc001 from '~/pages/wp-pub/components/popup/SO-ETC-001.vue'

export default {
  name: 'PopEtc001',
  layout: 'default',
  components: {
    SoEtc001,
  },
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
