<template>
  <section>
    <div id="release-detail">
      
      <so-etc011></so-etc011>
      
    </div>
  </section>
</template>
<script>
import SoEtc011 from '~/pages/wp-pub/components/popup/SO-ETC-011.vue'

export default {
  name: 'PopEtc011',
  layout: 'default',
  components: {
    SoEtc011,
  },
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
