<template>
  <section>
    <div id="release-detail">

      <so-etc026></so-etc026>

    </div>
  </section>
</template>
<script>
import SoEtc026 from '~/pages/wp-pub/components/popup/SO-ETC-026.vue'

export default {
  name: 'PopEtc026',
  layout: 'default',
  components: {
    SoEtc026,
  },
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
