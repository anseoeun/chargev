<template>
  <section>
    <div id="release-detail">
      <div class="article-title">
        <h-search :title="'계약번호'" />        
        <div class="btn-group">
          <div>
            <el-button type="primary">전담DC품의</el-button>
            <el-button type="info">방문예약</el-button>
            <el-button type="primary">문자보내기</el-button>
            <el-button type="primary">견적보기</el-button>
            <el-button type="info">제작증 발급</el-button>
          </div>
          <div>
            <el-button type="primary">배정취소</el-button>
            <el-button type="info">결제 초기화</el-button>
            <el-button type="primary">해약</el-button>
            <el-button type="primary">결제항목 활성화</el-button>
            <el-button type="primary">서류요청</el-button>
          </div>
        </div>
      </div>
      
      <el-form ref="info" class="detail-form table-wrap">
        <el-row>
          <el-col :span="8">
            <el-form-item label="계약번호">A3720TM001530</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="계약자">길인수 외1</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="계약 담당자">노은정</el-form-item>
          </el-col>  
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="온라인 진행상태">계약완료</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="국판 진행상태">배정요청</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="고객구분">
              <el-select v-model="client">
                <el-option label="개인(일반)" value="1"></el-option>
                <el-option label="이용자명의리스트(개인사업)" value="2"></el-option>
              </el-select>
              <el-button type="primary" class="btn-small">변경</el-button>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="계약완료일">2020-11-28 17:00</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="배정요청일">2020-11-28 18:24</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="배정일">2021-01-29 15:33</el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="출고예정일">2020-12-31</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="출고일">2020-12-31 14:16</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="출고예시일">2월 4주차 이내</el-form-item>
          </el-col>
        </el-row>  
        <el-row>
          <el-col :span="24" align="right">
            <el-form-item label="진행상황메모">
              <el-input v-model="memo" type="textarea" class="textarea" placeholder="최대 1,000자까지 입력하실 수 있습니다." />
              <el-button type="primary" class="btn-save">저장</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>

      <div class="article tabs">
        <el-tabs type="card" stretch>
          <el-tab-pane label="계약정보">
            <so-shp004></so-shp004>
          </el-tab-pane>

          <el-tab-pane label="차량정보">
            <so-shp005></so-shp005>
          </el-tab-pane>

          <el-tab-pane label="결제정보">
            <so-shp006></so-shp006>
          </el-tab-pane>

          <el-tab-pane label="출고정보">
            <so-shp007></so-shp007>
          </el-tab-pane>

          <el-tab-pane label="상태이력">
            <so-shp008></so-shp008>
          </el-tab-pane>

          <el-tab-pane label="문자이력">
            <so-shp009></so-shp009>
          </el-tab-pane>
        </el-tabs>
      </div>
      
    </div>
  </section>
</template>

<script>
import HSearch from '~/components/common/HSearch.vue'
import SoShp004 from '~/pages/wp-pub/components/tab/SO-SHP-004.vue'
import SoShp005 from '~/pages/wp-pub/components/tab/SO-SHP-005.vue'
import SoShp006 from '~/pages/wp-pub/components/tab/SO-SHP-006.vue'
import SoShp007 from '~/pages/wp-pub/components/tab/SO-SHP-007.vue'
import SoShp008 from '~/pages/wp-pub/components/tab/SO-SHP-008.vue'
import SoShp009 from '~/pages/wp-pub/components/tab/SO-SHP-009.vue'

export default {
  name: 'ReleaseDetail',
  layout: 'default',
  components: {
    HSearch,
    SoShp004,
    SoShp005,
    SoShp006,
    SoShp007,
    SoShp008,
    SoShp009,
  },
  data() {
    return {
      memo: '',
      client: ''
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
