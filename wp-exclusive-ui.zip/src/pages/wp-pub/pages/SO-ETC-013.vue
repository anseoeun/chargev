<template>
  <section>
    <div id="release-detail">
      
      <so-etc013></so-etc013>
      
    </div>
  </section>
</template>
<script>
import SoEtc013 from '~/pages/wp-pub/components/popup/SO-ETC-013.vue'

export default {
  name: 'PopEtc013',
  layout: 'default',
  components: {
    SoEtc013,
  },
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
