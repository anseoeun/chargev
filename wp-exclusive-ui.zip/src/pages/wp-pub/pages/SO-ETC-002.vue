<template>
  <section>
    <div id="release-detail">
      
      <so-etc002></so-etc002>
      
    </div>
  </section>
</template>
<script>
import SoEtc002 from '~/pages/wp-pub/components/popup/SO-ETC-002.vue'

export default {
  name: 'PopEtc002',
  layout: 'default',
  components: {
    SoEtc002,
  },
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
