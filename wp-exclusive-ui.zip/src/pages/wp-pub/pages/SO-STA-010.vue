<template>
  <section>
    <div id="support">

      <div class="article-title">
        <el-button type="info">초기화</el-button>
        <div>
          <el-button type="primary">조회</el-button>
          <el-button type="primary" class="btn-excel">EXCEL 다운로드</el-button>
        </div>
      </div>
      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="24">
              <el-form-item label="발행일">
                <el-date-picker type="date" />
                <span class="ex-txt">~</span>
                <el-date-picker type="date" />
                <el-radio-group v-model="searchDtRadio" class="tabBtn-case01">
                  <el-radio-button label="lastDay">어제</el-radio-button>
                  <el-radio-button label="today">오늘</el-radio-button>
                  <el-radio-button label="day7">7일</el-radio-button>
                  <el-radio-button label="day30">30일</el-radio-button>
                  <el-radio-button label="month3">3개월</el-radio-button>
                  <el-radio-button label="month6">6개월</el-radio-button>
                  <el-radio-button label="year1">1년</el-radio-button>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="발급방식">
                <el-select>
                  <el-option label="전체"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="쿠폰명">
                <el-input />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="쿠폰번호">
                <el-input />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <div class="box gap">
        <el-table :data="tableData">
          <el-table-column prop="data1" label="쿠폰번호" width="120" align="center"></el-table-column>
          <el-table-column prop="data2" label="타겟번호" width="120" align="center"></el-table-column>
          <el-table-column prop="data3" label="발급방식" width="120" align="center"></el-table-column>
          <el-table-column prop="data4" label="쿠폰명" width="299" align="center"></el-table-column>
          <el-table-column prop="data5" label="다회사용여부" width="120" align="center"></el-table-column>
          <el-table-column prop="data6" label="대상차종" width="200" align="center"></el-table-column>
          <el-table-column prop="data7" label="할인율(금액)" width="130" align="center"></el-table-column>
          <el-table-column prop="data8" label="발행일시" width="130" align="center"></el-table-column>
          <el-table-column prop="data9" label="사용기한" width="300" align="center"></el-table-column>
        </el-table>
      </div>

    </div>
  </section>
</template>

<script>
export default {
  layout: 'default',
  data() {
    return {
      searchDtRadio: 'day30',
      tableData: [
        {
          data1: 'C182928492',
          data2: 'C182928492',
          data3: '다운로드',
          data4: '아무나 걸려라 무제한 쿠폰',
          data5: '무제한',
          data6: 'AX1',
          data7: '100,000원',
          data8: '2021-01-10 12:01',
          data9: '2021-01-10 12:01 ~ 2022-10-01 12:01',
        },
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
