<template>
  <section>
    <div id="support">

      <div class="article-title">
        <h-search :title="'쿠폰번호'" />
        <div class="btn-group">
          <el-button type="primary" class="btn-excel">EXCEL 다운로드</el-button>
        </div>
      </div>
      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="8">
              <el-form-item label="쿠폰번호">C0912019</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="발급방식">인증코드발급</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="쿠폰명">아무나걸려라 무제한사용쿠폰</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="타겟번호">M0912019</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="할인율(금액)">10,000원</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="사용기한">2021-01-01 00:00 ~ 2022-01-01 00:00</el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <div class="box gap">
        <el-table :data="tableData">
          <el-table-column prop="data1" label="인증코드" width="120" align="center"></el-table-column>
          <el-table-column prop="data2" label="발급여부" width="100" align="center"></el-table-column>
          <el-table-column prop="data3" label="발급일시" width="150" align="center"></el-table-column>
          <el-table-column prop="data4" label="사용여부" width="100" align="center"></el-table-column>
          <el-table-column prop="data5" label="사용일시" width="150" align="center"></el-table-column>
          <el-table-column prop="data6" label="고객구분" width="150" align="center"></el-table-column>
          <el-table-column prop="data7" label="고객관리번호" width="150" align="center"></el-table-column>
          <el-table-column prop="data8" label="고객명" width="169" align="center"></el-table-column>
          <el-table-column prop="data9" label="계약번호" width="150" align="center"></el-table-column>
          <el-table-column prop="data10" label="국판진행상태" width="150" align="center"></el-table-column>
          <el-table-column prop="data11" label="할인금액" width="150" align="center"></el-table-column>
        </el-table>
      </div>

    </div>
  </section>
</template>

<script>
import HSearch from '~/components/common/HSearch.vue'
export default {
  layout: 'default',
  components: {
    HSearch,
  },
  data() {
    return {
      searchDtRadio: 'day30',
      tableData: [
        {
          data1: 'D182928492',
          data2: 'Y',
          data3: '2021-02-02 11:11',
          data4: 'Y',
          data5: '2021-02-02 11:11',
          data6: '개인(일반)',
          data7: 'A109182293018',
          data8: '지성민',
          data9: 'A109182293018',
          data10: '출고',
          data11: '100,000',
        },
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
