<template>
  <section>
    <div id="staff">

      <div class="article-title">
        <el-button type="info">초기화</el-button>
        <div>
          <el-button type="primary">조회</el-button>
          <el-button type="primary">등록</el-button>
        </div>
      </div>

      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="24">
              <el-form-item label="신청일">
                <el-date-picker type="date" />
                <span class="ex-txt">~</span>
                <el-date-picker type="date" />
                <el-radio-group v-model="searchDtRadio" class="tabBtn-case01">
                  <el-radio-button label="lastDay">어제</el-radio-button>
                  <el-radio-button label="today">오늘</el-radio-button>
                  <el-radio-button label="day7">7일</el-radio-button>
                  <el-radio-button label="day30">30일</el-radio-button>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="이름">
                <el-input />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="생년월일">
                <el-date-picker type="date" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="고객관리번호">
                <el-input />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="업무번호">
                <el-input />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="진행상태">
                <el-select v-model="value" multiple collapse-tags>
                  <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>
                <el-checkbox class="space">전체</el-checkbox>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="업무처리자">
                <el-select v-model="value2" multiple collapse-tags>
                  <el-option
                    v-for="item in options2"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="집계데이터 조회">
                <ul class="data-list">
                  <li><strong class="tit">전체</strong><span class="val"><strong>430</strong>건</span></li>
                  <li><strong class="tit">대기</strong><span class="val"><strong>422</strong>건</span></li>
                  <li><strong class="tit">처리중</strong><span class="val"><strong>8</strong>건</span></li>
                  <li><strong class="tit">완료</strong><span class="val"><strong>0</strong>건</span></li>
                  <li><strong class="tit">실패</strong><span class="val"><strong>0</strong>건</span></li>
                </ul>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <div class="article-title gap">
        <div>
          <el-checkbox>전체선택</el-checkbox>
          <el-button type="primary">처리자 변경</el-button>
        </div>
      </div>
      <div class="box">
        <el-table :data="tableData">
          <el-table-column label="선택" width="60" align="center">
            <el-checkbox></el-checkbox>
          </el-table-column>
          <el-table-column prop="data1" label="NO." width="90" align="center" />
          <el-table-column prop="data2" label="업무번호" width="160" align="center">
            <el-button type="text">SRT000008773</el-button>
          </el-table-column>
          <el-table-column prop="data3" label="진행상태" width="100" align="center" />
          <el-table-column prop="data4" label="업무처리자" width="140" align="center" />
          <el-table-column prop="data5" label="고객관리번호" width="160" align="center" />
          <el-table-column prop="data6" label="이름" width="140" align="center" />
          <el-table-column prop="data7" label="생년월일" width="100" align="center" />
          <el-table-column prop="data8" label="소속" width="200" align="center" show-overflow-tooltip />
          <el-table-column prop="data9" label="업체" width="200" align="center" show-overflow-tooltip />
          <el-table-column prop="data10" label="사번" width="140" align="center" />
          <el-table-column prop="data11" label="입사일" width="120" align="center" />
          <el-table-column prop="data12" label="승인일시" width="140" align="center" />
          <el-table-column prop="data13" label="만료일" width="120" align="center" />
          <el-table-column prop="data14" label="구매가능일" width="120" align="center" />
        </el-table>
      </div>

    </div>
  </section>
</template>

<script>
export default {
  layout: 'default',
  data() {
    return {
      searchDtRadio: 'day30',
      options: [
        { value: '대기', label: '대기' },
        { value: '처리중', label: '처리중' },
        { value: '완료', label: '완료' },
        { value: '실패', label: '실패' },
      ],
      options2: [
        { value: '처리자1', label: '처리자1' },
        { value: '처리자2', label: '처리자2' },
      ],
      value: [],
      value2: [],
      tableData: [
        {
          data1: 430,
          data2: 'SRT000008773',
          data3: '처리중',
          data4: '박혜진',
          data5: 'A2020063400006',
          data6: '지성민',
          data7: '780228',
          data8: '새마을금고 3년미만',
          data9: '현대블루핸즈',
          data10: '19-754593',
          data11: '2019-01-13',
          data12: '2021-01-29 12:11',
          data13: '9999-12-31',
          data14: '2021-12-31 ~',
        },
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
