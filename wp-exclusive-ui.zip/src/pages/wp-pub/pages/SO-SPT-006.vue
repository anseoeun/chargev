<template>
  <section>
    <div id="support">

      <div class="article-title">
        <el-button type="info">초기화</el-button>
        <div>
          <el-button type="primary">조회</el-button>
          <el-button type="primary" class="btn-excel">EXCEL 다운로드</el-button>
        </div>
      </div>
      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="24">
              <el-form-item label="생성일">
                <el-date-picker type="date" />
                <span class="ex-txt">~</span>
                <el-date-picker type="date" />
                <el-radio-group v-model="searchDtRadio" class="tabBtn-case01">
                  <el-radio-button label="lastDay">어제</el-radio-button>
                  <el-radio-button label="today">오늘</el-radio-button>
                  <el-radio-button label="day7">7일</el-radio-button>
                  <el-radio-button label="day30">30일</el-radio-button>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="차종">
                <el-select>
                  <el-option label="전체"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="차명">
                <el-select>
                  <el-option label="전체"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="사번">
                <el-input />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <div class="box gap">
        <el-table :data="tableData">
          <el-table-column prop="data1" label="NO." width="80" align="center"></el-table-column>
          <el-table-column prop="data2" label="대행견적번호" width="140" align="center"></el-table-column>
          <el-table-column prop="data3" label="모델" width="439" align="center"></el-table-column>
          <el-table-column prop="data4" label="생성일" width="150" align="center"></el-table-column>
          <el-table-column prop="data5" label="발송일(최종)" width="150" align="center"></el-table-column>
          <el-table-column prop="data6" label="사번" width="140" align="center"></el-table-column>
          <el-table-column prop="data7" label="발송건수" width="110" align="center"></el-table-column>
          <el-table-column prop="data8" label="견적건수" width="110" align="center"></el-table-column>
          <el-table-column prop="data9" label="계약건수" width="110" align="center"></el-table-column>
          <el-table-column prop="data10" label="판매건수" width="110" align="center"></el-table-column>
        </el-table>
      </div>

    </div>
  </section>
</template>

<script>
export default {
  layout: 'default',
  data() {
    return {
      searchDtRadio: 'day30',
      tableData: [
        {
          data1: 30,
          data2: 'C0000001',
          data3: '그랜저 자가용 가솔린 3.3',
          data4: '2021-03-04 11:11',
          data5: '2021-03-04 11:11',
          data6: 'E0903045',
          data7: 200,
          data8: 12,
          data9: 1,
          data10: 0,
        },
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
