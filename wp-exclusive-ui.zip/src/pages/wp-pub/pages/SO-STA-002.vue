<template>
  <section>
    <div id="staff">

      <div class="article-title">
        <el-button type="info">초기화</el-button>
        <el-button type="primary">조회</el-button>
      </div>
      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="8">
              <el-form-item label="조회구분">
                <el-select>
                  <el-option label="회원정보"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="이메일">
                <el-input />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="고객관리번호">
                <el-input />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="이름" required>
                <el-input />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="생년월일">
                <el-date-picker type="date" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="휴대전화">
                <el-input />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <div class="article-title">
        <h2>조회결과</h2>
      </div>
      <el-table :data="tableData" class="box">
        <el-table-column prop="data1" label="이메일" width="309" align="center"></el-table-column>
        <el-table-column prop="data2" label="고객관리번호" width="200" align="center"></el-table-column>
        <el-table-column prop="data3" label="고객명" width="200" align="center"></el-table-column>
        <el-table-column prop="data4" label="생년월일" width="200" align="center"></el-table-column>
        <el-table-column prop="data5" label="휴대전화" width="200" align="center"></el-table-column>
        <el-table-column prop="data6" label="직원여부" width="200" align="center"></el-table-column>
        <el-table-column prop="data7" label="소속" width="230" align="center"></el-table-column>
      </el-table>

      <div class="article-title gap">
        <div>
          <el-select>
            <el-option label="2021년"></el-option>
          </el-select>
          <el-button type="primary" class="btn-small space">조회</el-button>
        </div>
      </div>

      <div class="article">
        <el-tabs type="card" stretch>
          <el-tab-pane label="견적이력(3건)">
            <so-sta003></so-sta003>
          </el-tab-pane>
          <el-tab-pane label="시승이력(3건)">
            <so-sta004></so-sta004>
          </el-tab-pane>
          <el-tab-pane label="계약이력(3건)">
            <so-sta005></so-sta005>
          </el-tab-pane>
          <el-tab-pane label="보유쿠폰(3건)">
            <so-sta006></so-sta006>
          </el-tab-pane>
          <el-tab-pane label="문자발송이력(3건)">
            <so-sta007></so-sta007>
          </el-tab-pane>
        </el-tabs>
      </div>

    </div>
  </section>
</template>

<script>
import SoSta003 from '~/pages/wp-pub/components/tab/SO-STA-003.vue'
import SoSta004 from '~/pages/wp-pub/components/tab/SO-STA-004.vue'
import SoSta005 from '~/pages/wp-pub/components/tab/SO-STA-005.vue'
import SoSta006 from '~/pages/wp-pub/components/tab/SO-STA-006.vue'
import SoSta007 from '~/pages/wp-pub/components/tab/SO-STA-007.vue'

export default {
  layout: 'default',
  components: {
    SoSta003,
    SoSta004,
    SoSta005,
    SoSta006,
    SoSta007,
  },
  data() {
    return {
      tableData: [
        {
          data1: 'mmm@email.net',
          data2: 'A0000000',
          data3: '지성민',
          data4: '780909',
          data5: '010-0000-0000',
          data6: '',
          data7: '',
        }
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
