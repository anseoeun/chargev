<template>
  <section>
    <div id="release-detail">

      <so-etc027></so-etc027>

    </div>
  </section>
</template>
<script>
import SoEtc027 from '~/pages/wp-pub/components/popup/SO-ETC-027.vue'

export default {
  name: 'PopEtc027',
  layout: 'default',
  components: {
    SoEtc027,
  },
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
