<template>
  <section>
    <div id="release-detail">
      
      <so-etc012></so-etc012>
      
    </div>
  </section>
</template>
<script>
import SoEtc012 from '~/pages/wp-pub/components/popup/SO-ETC-012.vue'

export default {
  name: 'PopEtc012',
  layout: 'default',
  components: {
    SoEtc012,
  },
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
