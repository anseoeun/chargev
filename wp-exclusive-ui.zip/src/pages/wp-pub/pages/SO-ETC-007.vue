<template>
  <section>
    <div id="release-detail">
      
      <so-etc007></so-etc007>
      
    </div>
  </section>
</template>
<script>
import SoEtc007 from '~/pages/wp-pub/components/popup/SO-ETC-007.vue'

export default {
  name: 'PopEtc007',
  layout: 'default',
  components: {
    SoEtc007,
  },
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
