<template>
  <section>
    <div id="release-detail">
      
      <so-etc020></so-etc020>
      
    </div>
  </section>
</template>
<script>
import SoEtc020 from '~/pages/wp-pub/components/popup/SO-ETC-020.vue'

export default {
  name: 'PopEtc020',
  layout: 'default',
  components: {
    SoEtc020,
  },
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
