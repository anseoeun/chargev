<template>
  <section>
    <div id="release-detail">
      
      <so-etc024></so-etc024>
      
    </div>
  </section>
</template>
<script>
import SoEtc024 from '~/pages/wp-pub/components/popup/SO-ETC-024.vue'

export default {
  name: 'PopEtc024',
  layout: 'default',
  components: {
    SoEtc024,
  },
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
