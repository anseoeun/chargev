<template>
  <section>
    <div id="support">

      <div class="article-title">
        <el-button type="info">초기화</el-button>
        <div>
          <el-button type="primary">조회</el-button>
          <el-button type="primary" class="btn-excel">EXCEL 다운로드</el-button>
        </div>
      </div>
      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="24">
              <el-form-item label="출고일">
                <el-date-picker type="date" />
                <span class="ex-txt">~</span>
                <el-date-picker type="date" />
                <el-radio-group v-model="searchDtRadio" class="tabBtn-case01">
                  <el-radio-button label="lastDay">어제</el-radio-button>
                  <el-radio-button label="today">오늘</el-radio-button>
                  <el-radio-button label="day7">7일</el-radio-button>
                  <el-radio-button label="day30">30일</el-radio-button>
                  <el-radio-button label="month3">3개월</el-radio-button>
                  <el-radio-button label="month6">6개월</el-radio-button>
                  <el-radio-button label="year1">1년</el-radio-button>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="리워드 적용여부">
                <el-select>
                  <el-option label="전체"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="16">
              <el-form-item label="국판진행상태">
                <el-select v-model="value" class="select-multiple" style="width:430px;" multiple filterable allow-create default-first-option>
                  <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>
                <el-checkbox>전체</el-checkbox>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="엠버서더">
                <el-input placeholder="고객관리번호 입력" />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="집계데이터 조회">
                <ul class="data-list">
                  <li><strong class="tit">전체</strong><span class="val"><strong>430</strong>건</span></li>
                  <li><strong class="tit">리워드 적용</strong><span class="val"><strong>430</strong>건</span></li>
                  <li><strong class="tit">리워드 대기</strong><span class="val"><strong>430</strong>건</span></li>
                </ul>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <div class="article-title gap">
        <div>
          <el-checkbox>전체선택</el-checkbox>
          <el-button type="primary">리워드 적용</el-button>
        </div>
      </div>
      <div class="box">
        <el-table :data="tableData">
          <el-table-column label="선택" width="80" align="center">
            <el-checkbox></el-checkbox>
          </el-table-column>
          <el-table-column prop="data1" label="No.1" width="80" align="center"></el-table-column>
          <el-table-column prop="data2" label="엠버서더" width="140" align="center"></el-table-column>
          <el-table-column prop="data3" label="계약구분" width="80" align="center"></el-table-column>
          <el-table-column prop="data4" label="계약번호" width="140" align="center"></el-table-column>
          <el-table-column prop="data5" label="계약자" width="140" align="center"></el-table-column>
          <el-table-column prop="data6" label="출고일" width="140" align="center"></el-table-column>
          <el-table-column prop="data7" label="인수확정일" width="140" align="center"></el-table-column>
          <el-table-column prop="data8" label="제작증발급일" width="140" align="center"></el-table-column>
          <el-table-column prop="data9" label="계약담당자" width="140" align="center"></el-table-column>
          <el-table-column prop="data10" label="국판진행상태" width="140" align="center"></el-table-column>
          <el-table-column prop="data11" label="온라인진행상태" width="140" align="center"></el-table-column>
          <el-table-column prop="data12" label="차대번호" width="140" align="center"></el-table-column>
          <el-table-column prop="data13" label="리워드" width="140" align="center"></el-table-column>
          <el-table-column prop="data14" label="취소사유" width="140" align="center"></el-table-column>
        </el-table>
      </div>

    </div>
  </section>
</template>

<script>
export default {
  layout: 'default',
  data() {
    return {
      searchDtRadio: 'day30',
      tableData: [
        {
          data1: 1,
          data2: '지성민',
          data3: '개인',
          data4: 'A343234234',
          data5: '길인수',
          data6: '2021-02-12',
          data7: '2021-02-12',
          data8: '2021-02-12',
          data9: '박혜진',
          data10: '출고',
          data11: '결제완료',
          data12: 'KADMFADSF',
          data13: '대기',
          data14: '취소사유코드',
        },
      ],
      options: [
        { value: '출고', label: '출고' },
        { value: '매출취소', label: '매출취소' },
        { value: '전시차입고취소', label: '전시차입고취소' },
        { value: '해약', label: '해약' },
        { value: '이관', label: '이관' },
      ],
      value: [],
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
