<template>
  <section>
    <div id="main">
      <section class="main-title">
        <h2>
          테스트1
        </h2>
      </section>
    </div>
  </section>
  </template>
<script>
</script>
<style lang="scss" scoped>
@import "~/assets/style/pages/main.scss";
</style>
