<template>
  <div>
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />

    <!-- 차량 실 사진 이미지 -->
    <el-dialog title="" :visible.sync="popVisibleDedicatedDC">
      <!-- Popup Contents -->
      <div class="block wrap-carousel">
        <el-carousel 
          ref="carousel"
          :autoplay="false" 
          arrow="never"
          indicator-position="none"
          @change="carouselChange"
        >
          <el-carousel-item v-for="item in 4" :key="item">
            <div class="img-carousel">
              <img src="https://ep.hmc.co.kr/contents/mainbanner/ep-main-purchase-procedure-KV.jpg" alt="" />              
            </div>
          </el-carousel-item>
        </el-carousel>
      </div>
      <div align="center">
        <el-button type="primary" class="btn-small" @click="onPrev">이전</el-button>
        <span class="space">{{ carouselIndex }} / {{ carouselTotal }}</span>        
        <el-button type="primary" class="btn-small space" @click="onNext">다음</el-button>
      </div>
    </el-dialog>
    
  </div>
</template>
<script>
export default {
  data() {
    return {
      popVisibleLoading: true,
      popVisibleDedicatedDC: true,
      carouselIndex: 1,
      carouselTotal: 4,
    }
  },
  methods: {
  	carouselChange(index){
  		this.carouselIndex = index+1
  	},
  	onPrev(){
    	this.$refs.carousel.prev()
    },
    onNext(){
    	this.$refs.carousel.next()
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
.wrap-carousel {
  position:relative;
  top:-30px;
}
.img-carousel {
  overflow:hidden;
  width:100%;
  img {
    width:100%;
    height:auto;
  }
}
</style>
