<template>
  <div>
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />

    <!-- 주소검색 팝업 -->
    <el-dialog title="주소검색" :visible.sync="popVisibleAddress">
      <!-- Popup Contents -->
      <div class="board-wrap">
        <el-form ref="info" class="detail-form">
          <el-row>
            <el-col :span="24">
              <el-form-item label="주소검색">
                <el-input v-model="input" placeholder="예) 헌릉로12, 양재동 231" />
                <el-button type="primary" class="btn-small">검색</el-button>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <ul class="note">
          <li>* 주민등록 상 주소(법인인 경우 사업자등록 상 주소)로 검색하고 선택해 주세요.</li>
          <li>* 주소 미확인으로 출고 후 구매 취소 발생 시 왕복탁송료 이외 부대비용은 본인 부담이니 이 점 반드시 유의하시기 바랍니다.</li>
        </ul>
        <div class="search-count">
          검색결과 : 1건 
        </div>
        <el-table :data="tableData" style="">
          <el-table-column prop="data1" label="우편번호" width="159" align="center"></el-table-column>
          <el-table-column prop="data2" label="주소" width="560" align="center"></el-table-column>
        </el-table>            
      </div>
    </el-dialog>
    
  </div>
</template>
<script>
export default {
  data() {
    return {
      popVisibleLoading: true,
      popVisibleAddress: true,
      input: '',
      tableData: [
        {
          data1: '015545',
          data2: '서울특별시 서초구 남부순환로 316길 (서초동, 서초동 코아아파트)',
        },
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
