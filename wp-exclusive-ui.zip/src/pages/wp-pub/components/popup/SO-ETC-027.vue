<template>
  <div>
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />

    <!-- 업체조회 팝업 -->
    <el-dialog title="업체조회" :visible.sync="popVisibleCompany">
      <!-- Popup Contents -->
      <div class="board-wrap">
        <el-form ref="info" class="detail-form">
          <el-row>
            <el-col :span="24">
              <el-form-item label="업체조회">
                <el-input v-model="searchText" placeholder="검색어를 입력하세요." />
                <el-button type="info" class="btn-small">초기화</el-button>
                <el-button type="primary" class="btn-small">검색</el-button>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>

        <div class="list-company">
          <el-radio-group v-model="radioCompany">
            <ul>
              <li><el-radio label="1">[A027A] 현대머티리얼(주)</el-radio></li>
              <li><el-radio label="2">[A028A] 현대종합특수강</el-radio></li>
              <li><el-radio label="3">[A029A] 현대스틸산업</el-radio></li>
              <li><el-radio label="4">[A021A] 현대머티리얼</el-radio></li>
              <li><el-radio label="5">[A022A] 현대건설</el-radio></li>
              <li><el-radio label="6">[A023A] 현대도시개발</el-radio></li>
              <li><el-radio label="7">[A024A] 현대에너지</el-radio></li>
              <li><el-radio label="8">[A025A] 현대위아터보</el-radio></li>
              <li><el-radio label="9">[A024A] 현대에너지</el-radio></li>
              <li><el-radio label="10">[A025A] 현대엔지니어링</el-radio></li>
              <li><el-radio label="11">[A027A] 현대머티리얼(주)</el-radio></li>
              <li><el-radio label="12">[A028A] 현대종합특수강</el-radio></li>
              <li><el-radio label="13">[A029A] 현대스틸산업</el-radio></li>
              <li><el-radio label="14">[A021A] 현대머티리얼</el-radio></li>
              <li><el-radio label="15">[A022A] 현대건설</el-radio></li>
              <li><el-radio label="16">[A023A] 현대도시개발</el-radio></li>
              <li><el-radio label="17">[A024A] 현대에너지</el-radio></li>
              <li><el-radio label="18">[A025A] 현대위아터보</el-radio></li>
              <li><el-radio label="19">[A024A] 현대에너지</el-radio></li>
              <li><el-radio label="20">[A025A] 현대엔지니어링</el-radio></li>
            </ul>
          </el-radio-group>

          <!--
          <div class="no-data">
            조회결과가 없습니다.
          </div>
          -->
        </div>
      </div>
      <!-- Popup Footer -->
      <template slot="footer">
        <div>
          <el-button type="info">취소</el-button>
          <el-button type="primary">선택</el-button>
        </div>
      </template>
    </el-dialog>

  </div>
</template>
<script>
export default {
  data() {
    return {
      popVisibleLoading: true,
      popVisibleCompany: true,
      searchText: '',
      radioCompany: '',
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
