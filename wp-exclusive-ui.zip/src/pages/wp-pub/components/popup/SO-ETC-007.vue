<template>
  <div>
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />

    <el-dialog title="해약처리" :visible.sync="popVisibleCancel">
      <!-- Popup Contents -->
      <div class="board-wrap">
        <table class="tbl-detail">
          <colgroup>
            <col style="width:20%;" />
            <col style="width:40%;" />
            <col style="width:40%;" />
          </colgroup>
          <thead>
            <tr>
              <th>구분</th>
              <th>변경 전</th>
              <th>변경 후</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th>온라인 계약상태</th>
              <td align="center">결제처리중</td>
              <td align="center">계약취소</td>
            </tr>
            <tr>
              <th>국판 계약상태</th>
              <td align="center">배정</td>
              <td align="center">배정취소</td>
            </tr>
            <tr>
              <th>처리자</th>
              <td colspan="2" align="center">지성민</td>
            </tr>
            <tr>
              <th>위약금처리</th>
              <td align="center">
                <el-radio v-model="rdo1" :label="1">예</el-radio>
                <el-radio v-model="rdo1" :label="2">아니오</el-radio>
              </td>
              <td align="center">10,000원</td>
            </tr>
            <tr>
              <th>왕복배송비 부과</th>
              <td align="center">
                <el-radio v-model="rdo2" :label="1">예</el-radio>
                <el-radio v-model="rdo2" :label="2">아니오</el-radio>
              </td>
              <td align="center">30,000원</td>
            </tr>
            <tr>
              <th>해약사유</th>
              <td colspan="2">
                <el-select v-model="slt1">
                  <el-option label="해약 사유를 선택하세요." value=""></el-option>
                </el-select>
                <el-input v-model="input1" placeholder="기타: 직접입력"></el-input>
              </td>
            </tr>
          </tbody>
        </table>
        <ul class="note">
          <li>※ 위약금 또는 왕복배송비 부과 시 해당 금액을 제외하고 환불처리가 가능합니다. (또는 추가 결제 필요)</li>
          <li>※ 해약처리 시 계약상태가 '변경 후' 상태로 변경되며, 결제금액이 없는 경우 즉시 해약처리가 완료됩니다.</li>
          <li>※ '계약취소(환불대기)' 상태에서 다시 한번 위약금 처리여부 및 해약사유를 입력하실 수 있으며, 해약완료 시 선택한 값으로 최종 적용됩니다.</li>
        </ul>
      </div>
      <!-- Popup Footer -->
      <template slot="footer">
        <div>
          <el-button type="info">취소</el-button>
          <el-button type="primary">확인</el-button>
        </div>
      </template>
    </el-dialog>
    
  </div>
</template>
<script>
export default {
  data() {
    return {
      popVisibleLoading: true,
      popVisibleCancel: true,
      rdo1: 2,
      rdo2: 2,
      slt1: '',
      input1: '',
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
