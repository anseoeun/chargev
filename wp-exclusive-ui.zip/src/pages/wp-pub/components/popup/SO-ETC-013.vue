<template>
  <div>
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />

    <el-dialog title="출고센터 변경" :visible.sync="popVisibleRelease">
      <!-- Popup Contents -->
      <div class="board-wrap">
        <table class="tbl-detail">
          <colgroup>
            <col style="width:20%;" />
            <col style="width:40%;" />
            <col style="width:40%;" />
          </colgroup>
          <thead>
            <tr>
              <th>구분</th>
              <th>변경 전</th>
              <th>변경 후</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th>출고센터</th>
              <td align="center">신갈출고센터</td>
              <td align="center">
                <el-select v-model="slt">
                  <el-option label="선택하세요" value=""></el-option>
                </el-select>
              </td>
            </tr>
            <tr>
              <th>탁송지</th>
              <td align="center" colspan="2">(11010) 경기도 수원시 영통구 매영로 310번길 12 555동</td>
            </tr>
            <tr>
              <th>탁송료</th>
              <td align="center">150,000원</td>
              <td align="center">200,000원</td>
            </tr>
            <tr>
              <th>차액</th>
              <td align="center"></td>
              <td align="center"><span class="difference">+50,000원</span></td>
            </tr>
          </tbody>
        </table>
      </div>
      <!-- Popup Footer -->
      <template slot="footer">
        <div>
          <el-button type="info">취소</el-button>
          <el-button type="primary">확인</el-button>
        </div>
      </template>
    </el-dialog>
    
  </div>
</template>
<script>
export default {
  data() {
    return {
      popVisibleLoading: true,
      popVisibleRelease: true,
      slt: '',
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
