<template>
  <div>
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />

    <!-- 공식 지정 인수점 조회 팝업 -->
    <el-dialog title="공식 지정 인수점 조회" :visible.sync="popVisibleSearch" width="700px">
      <!-- Popup Contents -->
      <div class="map-search">
        <el-form>
          <div class="search-top">
            <el-select v-model="locationSelect1" placeholder="시/도 선택">
              <el-option label="시/도 선택" />
            </el-select>
            <el-select v-model="locationSelect2" placeholder="시/군/구 선택" :disabled="true">
              <el-option label="시/군/구 선택" />
            </el-select>
            <el-button type="primary" class="btn-small">검색</el-button>
          </div>
        </el-form>

        <div class="search-result">
          <div class="search-list">

            <ul>
              <li>
                <div class="search-info">
                  <div class="title">
                    <span class="num">1</span>
                    <strong class="name">드라이빙 라운지 강남</strong>
                  </div>
                  <p>서울특별시 서초구 반포대로 64 (서초동, 문창빌딩 1층)</p>
                  <p>02-5959-9000 / 010-1234-1234</p>
                </div>
                <el-button type="text">선택</el-button>
              </li>
              <li>
                <div class="search-info">
                  <div class="title">
                    <span class="num">2</span>
                    <strong class="name">드라이빙 라운지 동대문</strong>
                  </div>
                  <p>서울특별시 서초구 반포대로 64 (서초동, 문창빌딩 1층)</p>
                  <p>02-5959-9000 / 010-1234-1234</p>
                </div>
                <el-button type="text">선택</el-button>
              </li>
              <li>
                <div class="search-info">
                  <div class="title">
                    <span class="num">3</span>
                    <strong class="name">드라이빙 라운지 역삼</strong>
                  </div>
                  <p>서울특별시 서초구 반포대로 64 (서초동, 문창빌딩 1층)</p>
                  <p>02-5959-9000 / 010-1234-1234</p>
                </div>
                <el-button type="text">선택</el-button>
              </li>
              <li>
                <div class="search-info">
                  <div class="title">
                    <span class="num">4</span>
                    <strong class="name">드라이빙 라운지 강남</strong>
                  </div>
                  <p>서울특별시 서초구 반포대로 64 (서초동, 문창빌딩 1층)</p>
                  <p>02-5959-9000 / 010-1234-1234</p>
                </div>
                <el-button type="text">선택</el-button>
              </li>
              <li>
                <div class="search-info">
                  <div class="title">
                    <span class="num">5</span>
                    <strong class="name">드라이빙 라운지 강남</strong>
                  </div>
                  <p>서울특별시 서초구 반포대로 64 (서초동, 문창빌딩 1층)</p>
                  <p>02-5959-9000 / 010-1234-1234</p>
                </div>
                <el-button type="text">선택</el-button>
              </li>
            </ul>

            <!-- 
            <div class="no-result">
              검색 결과가 없습니다.
            </div>
            -->

          </div>
        </div>
      </div>
    </el-dialog>

  </div>
</template>
<script>
export default {
  data() {
    return {
      popVisibleLoading: true,
      popVisibleSearch: true,
      locationSelect1: '',
      locationSelect2: ''
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
