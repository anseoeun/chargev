<template>
  <div>
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />

    <!-- 대형견적 차량선택 팝업 -->
    <el-dialog title="대형견적 차량선택 변경" :visible.sync="popVisibleStock" width="1100px">
      <!-- Popup Contents -->
      <div class="board-wrap">
        <el-tabs type="card" stretch>
          <el-tab-pane label="생산차">
            <table class="tbl-detail">
              <colgroup>
                <col style="width:20%" />
                <col style="width:80%" />
              </colgroup>
              <tbody>
                <tr>
                  <th>차종구분</th>
                  <td>
                    <el-select v-model="slt">
                      <el-option label="선택하세요" value=""></el-option>
                    </el-select>
                    <span class="car-price">0원</span>
                  </td>
                </tr>
                <tr>
                  <th>대표차</th>
                  <td>
                    <el-select v-model="slt" disabled>
                      <el-option label="선택하세요" value=""></el-option>
                    </el-select>
                    <span class="car-price">0원</span>
                  </td>
                </tr>
                <tr>
                  <th>판매모델</th>
                  <td>
                    <el-select v-model="slt" disabled>
                      <el-option label="선택하세요" value=""></el-option>
                    </el-select>
                    <span class="car-price">0원</span>
                  </td>
                </tr>
                <tr>
                  <th>외장색상</th>
                  <td>
                    <el-select v-model="slt" disabled>
                      <el-option label="선택하세요" value=""></el-option>
                    </el-select>
                    <span class="car-price">0원</span>
                  </td>
                </tr>
                <tr>
                  <th>내장색상</th>
                  <td>
                    <el-select v-model="slt" disabled>
                      <el-option label="선택하세요" value=""></el-option>
                    </el-select>
                    <span class="car-price">0원</span>
                  </td>
                </tr>
                <tr>
                  <th>선택품목</th>
                  <td>
                    <el-select v-model="slt" disabled>
                      <el-option label="선택하세요" value=""></el-option>
                    </el-select>
                    <span class="car-price">0원</span>
                  </td>
                </tr>
                <tr>
                  <th>파츠</th>
                  <td>
                    <el-select v-model="slt" disabled>
                      <el-option label="선택하세요" value=""></el-option>
                    </el-select>
                    <span class="car-price">0원</span>
                  </td>
                </tr>
                <tr>
                  <th>총 구입비</th>
                  <td align="right"><span class="car-price">0원</span></td>
                </tr>
                <tr>
                  <th>예상 출고일</th>
                  <td align="right"><span class="car-date">-</span></td>
                </tr>
              </tbody>
            </table>
          </el-tab-pane>

          <el-tab-pane label="일반재고/생산월할인">
            <el-form ref="info" class="detail-form">
              <el-row>
                <el-col :span="24">
                  <el-form-item label="차량구분">
                    <div class="select-car">
                      <el-select>
                        <el-option label="재고구분"></el-option>
                      </el-select>
                      <el-select disabled>
                        <el-option label="차종구분"></el-option>
                      </el-select>
                      <el-select disabled>
                        <el-option label="대표차"></el-option>
                      </el-select>
                      <el-select disabled>
                        <el-option label="판매모델"></el-option>
                      </el-select>
                      <el-select disabled>
                        <el-option label="외장색상"></el-option>
                      </el-select>
                      <el-select disabled>
                        <el-option label="내장색상"></el-option>
                      </el-select>
                    </div>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="24">
                  <el-form-item label="생산번호">
                    <el-input />
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
            <div class="btn-group">
              <el-button type="info">초기화</el-button>
              <el-button type="primary">조회</el-button>
            </div>
            <el-table :data="tableData">
              <el-table-column label="선택" width="50" align="center">
                <el-checkbox></el-checkbox>
              </el-table-column>
              <el-table-column prop="data1" label="차량명" width="300" align="center"></el-table-column>
              <el-table-column prop="data2" label="생산번호" width="150" align="center"></el-table-column>
              <el-table-column prop="data3" label="출고센터" width="180" align="center"></el-table-column>
              <el-table-column prop="data4" label="생산일" width="150" align="center"></el-table-column>
              <el-table-column prop="data5" label="차량구분" width="180" align="center"></el-table-column>
              <el-table-column prop="data6" label="차량할인" width="180" align="center"></el-table-column>
              <el-table-column prop="data7" label="주행거리" width="150" align="center"></el-table-column>
              <el-table-column prop="data8" label="차량상태(외관)" width="180" align="center"></el-table-column>
              <el-table-column prop="data9" label="차량상태(내관)" width="180" align="center"></el-table-column>
            </el-table>
          </el-tab-pane>

          <el-tab-pane label="기획전">
            <el-form ref="info" class="detail-form">
              <el-row>
                <el-col :span="24">
                  <el-form-item label="기획전">
                    <el-select v-model="slt">
                      <el-option label="선택하세요." value=""></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
            <div class="btn-group">
              <el-button type="info">초기화</el-button>
              <el-button type="primary">조회</el-button>
            </div>
            <el-table :data="tableData">
              <el-table-column label="선택" width="50" align="center">
                <el-checkbox></el-checkbox>
              </el-table-column>
              <el-table-column prop="data1" label="차량명" width="300" align="center"></el-table-column>
              <el-table-column prop="data2" label="생산번호" width="150" align="center"></el-table-column>
              <el-table-column prop="data3" label="출고센터" width="180" align="center"></el-table-column>
              <el-table-column prop="data4" label="생산일" width="150" align="center"></el-table-column>
              <el-table-column prop="data5" label="차량구분" width="180" align="center"></el-table-column>
              <el-table-column prop="data6" label="차량할인" width="180" align="center"></el-table-column>
              <el-table-column prop="data7" label="주행거리" width="150" align="center"></el-table-column>
              <el-table-column prop="data8" label="차량상태(외관)" width="180" align="center"></el-table-column>
              <el-table-column prop="data9" label="차량상태(내관)" width="180" align="center"></el-table-column>
            </el-table>
          </el-tab-pane>

        </el-tabs>
      </div>
      <!-- Popup Footer -->
      <template slot="footer">
        <div>
          <el-button type="info">취소</el-button>
          <el-button type="primary">선택</el-button>
        </div>
      </template>
    </el-dialog>
    
  </div>
</template>
<script>
export default {
  data() {
    return {
      popVisibleLoading: true,
      popVisibleStock: true,
      slt: '',
      tableData: [
        {
          data1: '모델/트림/외장컬러/엔진',
          data2: '생산번호',
          data3: '출고센터명',
          data4: '',
          data5: '모델명',
          data6: '차량할인계',
          data7: '주행거리',
          data8: '',
          data9: '',
        }
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
