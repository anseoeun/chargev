<template>
  <div>
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />

    <!-- 법인번호입력 팝업 -->
    <el-dialog title="법인번호 입력" :visible.sync="popVisibleCorpNumber">
      <!-- Popup Contents -->
      <div class="board-wrap">
        <el-form ref="info" class="detail-form">
          <el-row>
            <el-col :span="24">
              <el-form-item label="구분">
                <el-radio v-model="radioType" label="1">법인번호</el-radio>
                <el-radio v-model="radioType" label="2">주민등록번호</el-radio>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="입력">
                <el-input v-model="number" placeholder="숫자만 입력하세요" />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <ul class="note">
        <li>* 법인번호가 없는 사업자(단체)의 경우 대표자 주민등록번호를 기입하세요.</li>
      </ul>
      <!-- Popup Footer -->
      <template slot="footer">
        <div>
          <el-button type="info">취소</el-button>
          <el-button type="primary">확인</el-button>
        </div>
      </template>
    </el-dialog>

  </div>
</template>
<script>
export default {
  data() {
    return {
      popVisibleLoading: true,
      popVisibleCorpNumber: true,
      radioType: '',
      textNum: '',
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
