<template>
  <div>
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />

    <!-- 고객조회 팝업 -->
    <el-dialog title="고객조회" :visible.sync="popVisibleMember" class="popMember" width="1100px">
      <!-- Popup Contents -->
      <el-form ref="info" class="detail-form">
        <el-row>
          <el-col :span="8">
            <el-form-item label="조회구분">
              <el-select>
                <el-option label="회원정보" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="이메일">
              <el-input />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="고객관리번호">
              <el-input />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="이름" required>
              <el-input />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="생년월일">
              <el-date-picker type="date" v-model="date" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="휴대전화">
              <el-input />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>

      <div class="btn-group">
        <div class="right">
          <el-button type="info" class="btn-small">초기화</el-button>
          <el-button type="primary" class="btn-small">조회</el-button>
        </div>
      </div>

      <div class="article-title">
        <h2>조회결과</h2>
      </div>
      <el-table :data="tableData">
        <el-table-column label="선택" width="50" align="center">
          <el-radio />
        </el-table-column>
        <el-table-column prop="data1" label="이메일" width="200" align="center"></el-table-column>
        <el-table-column prop="data2" label="고객관리번호" width="150" align="center"></el-table-column>
        <el-table-column prop="data3" label="고객명" width="150" align="center"></el-table-column>
        <el-table-column prop="data4" label="생년월일" width="100" align="center"></el-table-column>
        <el-table-column prop="data5" label="휴대전화" width="150" align="center"></el-table-column>
        <el-table-column prop="data6" label="직원여부" width="100" align="center"></el-table-column>
        <el-table-column prop="data7" label="소속" width="200" align="center"></el-table-column>
      </el-table>

      <template slot="footer">
        <div>
          <el-button type="info">취소</el-button>
          <el-button type="primary">선택</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>
<script>
export default {
  data() {
    return {
      popVisibleLoading: true,
      popVisibleMember: true,
      date: '',
      tableData: [
        {
          data1: 'minor@uzen.net',
          data2: 'A202007643432',
          data3: '지성민',
          data4: '780228',
          data5: '010-****-6666',
          data6: 'N',
          data7: '-',
        }
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
