<template>
  <div>
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />

    <!-- 파츠변경 팝업 -->
    <el-dialog title="파츠 변경" :visible.sync="popVisibleCar" width="1100px">
      <!-- Popup Contents -->
      <div class="board-wrap">
        <table class="tbl-detail">
          <colgroup>
            <col style="width:16%" />
            <col style="width:42%" />
            <col style="width:42%" />
          </colgroup>
          <thead>
            <tr>
              <th>구분</th>
              <th>변경 전</th>
              <th>변경 후</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th>판매모델</th>
              <td>
                <span>AX 자가용 가솔린 3.3 CALLIGRAPHY A/T F/L</span>
                <span class="car-price">0원</span>
              </td>
              <td>
                <el-select disabled>
                  <el-option label="선택하세요"></el-option>
                </el-select>
                <span class="car-price">0원</span>
              </td>
            </tr>
            <tr>
              <th>트림</th>
              <td>Smart 원톤(인테리어디자인_블랙)</td>
              <td>
                <el-select disabled>
                  <el-option label="선택하세요"></el-option>
                </el-select>
              </td>
            </tr>
            <tr>
              <th>외장색상</th>
              <td>
                <span>미드나잇블랙</span>
                <span class="car-price">0원</span>
              </td>
              <td>
                <el-select disabled>
                  <el-option label="선택하세요"></el-option>
                </el-select>
                <span class="car-price">0원</span>
              </td>
            </tr>
            <tr>
              <th>내장색상</th>
              <td>
                <span>블랙모노톤(블랙시트)</span>
                <span class="car-price">0원</span>
              </td>
              <td>
                <el-select disabled>
                  <el-option label="선택하세요"></el-option>
                </el-select>
                <span class="car-price">0원</span>
              </td>
            </tr>
            <tr>
              <th>선택품목</th>
              <td colspan="2" class="multiple-wrap">

                <div class="multiple-inner">
                  <div  class="multiple-control">
                    <el-select v-model="value1" multiple placeholder="Select"  class="multiple-select">
                      <el-option
                        v-for="item in options"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                    <span class="multiple-price">0원</span>
                  </div>
                  <table class="tbl-detail">
                    <tbody>
                      <tr>
                        <td>
                          <strong>헤드업디스플레이</strong>
                          <span class="car-price">0원</span>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <strong>파킹어시스트</strong>
                          <span class="car-price">0원</span>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <strong>파노라마선루프</strong>
                          <span class="car-price">0원</span>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <strong>빌트인캠</strong>
                          <span class="car-price">0원</span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

              </td>
            </tr>
            <tr>
              <th>파츠</th>
              <td colspan="2" class="multiple-wrap">

                <div class="multiple-inner">
                  <div  class="multiple-control">
                    <el-select v-model="value2" multiple placeholder="Select"  class="multiple-select">
                      <el-option
                        v-for="item in options"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                    <span class="multiple-price">0원</span>
                  </div>
                  <table class="tbl-detail">
                    <tbody>
                      <tr>
                        <td>
                          <strong>빌트인 공기청정기</strong>
                          <span class="car-price">0원</span>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <strong>싱글 후석 엔터테이먼트 시스템</strong>
                          <span class="car-price">0원</span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

              </td>
            </tr>
            <tr>
              <th>총 구입비</th>
              <td><span class="car-price">3,503,555원</span></td>
              <td><span class="car-price">3,503,555원</span></td>
            </tr>
            <tr>
              <th>예상출고일</th>
              <td><span class="car-date">2021년 2월</span></td>
              <td><span class="car-date">2021년 2월</span></td>
            </tr>
          </tbody>
        </table>
      </div>
      <!-- Popup Footer -->
      <template slot="footer">
        <div>
          <el-button type="info">취소</el-button>
          <el-button type="primary">적용</el-button>
        </div>
      </template>
    </el-dialog>
    
  </div>
</template>
<script>
export default {
  data() {
    return {
      popVisibleLoading: true,
      popVisibleCar: true,
      options: [{
          value: '헤드업디스플레이2',
          label: '헤드업디스플레이2'
        }, {
          value: '파킹어시스트2',
          label: '파킹어시스트2'
        }, {
          value: '파노라마선루프1',
          label: '파노라마선루프1'
        }, {
          value: '파노라마선루프2',
          label: '파노라마선루프2'
        }, {
          value: '파노라마선루프3',
          label: '파노라마선루프3'
        }, {
          value: '빌트인캠1',
          label: '빌트인캠1'
        }, {
          value: '빌트인캠2',
          label: '빌트인캠2'
        }, {
          value: '빌트인캠3',
          label: '빌트인캠3'
        }],
        value1: [],
        value2: []
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
