<template>
  <div>
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />

    <el-dialog title="현금 결제 변경" :visible.sync="popVisibleChangeCash">
      <!-- Popup Contents -->
      <div class="board-wrap">
        <el-form ref="info" class="detail-form">
          <el-row>
            <el-col :span="24">
              <el-form-item label="결제자">김효중</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="요청자">지성민</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="결제금액">1,000,000원</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="환불계좌">
                <el-select>
                  <el-option label="은행"></el-option>
                </el-select>
                <el-input v-model="input1" placeholder="계좌번호" />
                <el-input v-model="input2" placeholder="예금주" />
                <el-button type="info" class="btn-small">확인</el-button>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="취소사유">
                <el-select>
                  <el-option label="선택하세요"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="취소금액">
                <el-radio v-model="rdo1" :label="1">전체취소</el-radio>
                <el-radio v-model="rdo1" :label="2">부분취소</el-radio>
                <el-input v-model="input3" placeholder="10,000,000"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <ul class="note">
          <li>※ 왕복탁송료 : 250,000원</li>
          <li>※ 차감 시 취소금액 : 10,000,000원</li>
        </ul>
      </div>
      <!-- Popup Footer -->
      <template slot="footer">
        <div>
          <el-button type="info">취소</el-button>
          <el-button type="primary">확인</el-button>
        </div>
      </template>
    </el-dialog>
    
  </div>
</template>
<script>
export default {
  data() {
    return {
      popVisibleLoading: true,
      popVisibleChangeCash: true,
      rdo1: 2,
      input1: '',
      input2: '',
      input3: '',
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
