<template>
  <div>
    <div class="car-info-box">
      <el-form ref="carinfobox" class="detail-form">
        <el-row>
          <el-col :span="6">
            <el-form-item label="차대번호">
              <div class="carInfo_content">KMHS381ABLU249022</div>           
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="판매 SPEC">
              <div class="carInfo_content">AXUSGFT3 CBB WW2 RTP</div>          
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="생산번호">
              <div class="carInfo_content">S1 249022</div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="생산일">
              <div class="carInfo_content">2019-10-25</div>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <el-form-item label="차량구분">
              <div class="carInfo_content">생산주문차량</div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="부활차 여부">
              <div class="carInfo_content">N</div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="전입신고일">
              <div class="carInfo_content">2020-02-20</div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="차량 보관장소">
              <div class="carInfo_content">보관장소</div>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6" class="rowspan-2">
            <el-form-item label="차량할인계">
              <div class="carInfo_content">0원</div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="차종기본">
              <div class="carInfo_content">0원</div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="재고(생산월)">
              <div class="carInfo_content">0원</div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="판촉">
              <div class="carInfo_content">0원</div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="전시">
              <div class="carInfo_content">0원</div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="한정재고">
              <div class="carInfo_content">0원</div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="특별재고">
              <div class="carInfo_content">0원</div>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <el-form-item label="주행거리">
              <div class="carInfo_content"></div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="차량상태(외관)">
              <div class="carInfo_content"></div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="차량상태(내관)">
              <div class="carInfo_content"></div>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="차량사진">
              <div class="carInfo_content">
                <el-button type="primary" class="btn-small">사진보기</el-button>
              </div>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="차량상태 세부내용">세부내용</el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div>
      <article class="article">
        <div class="article-title gap">
          <h2>주문차량정보</h2>
          <div class="right">
            <el-button type="primary">차량변경</el-button>
          </div>
        </div>
        <div class="accordion-table">
          <div class="accordion-headline">
            <div class="title">
              <span class="icon">생산주문차량</span>
              <strong>AX 자가용 가솔린 3.3 Calligraphy</strong>
              <span class="txt">헤드업디스플레이 외 옵션 3개</span>
            </div>
            <div class="price">40,835,681원</div>
          </div>
          <div class="vehicle-info">
            <div class="item">
              <div class="accordion-title">모델</div>
              <div class="accordion-content">AX 자가용 가솔린 3.3 CALLIGRAPHY A/T F/L</div>
              <div class="accordion-price">40,835,681원</div>
            </div>
            <div class="item" name="2">
              <div class="accordion-title">색상</div>
              <div class="accordion-inside divide">
                <table class="inside-container">
                  <tbody>
                    <tr class="inside-content">
                      <th class="inside-title"><div>외장</div></th>
                      <td class="inside-content-child"><div>미드나잇 블랙</div></td>
                      <td class="inside-price"><div>0원</div></td>
                    </tr>
                    <tr class="inside-content">
                      <th class="inside-title"><div>내장</div></th>
                      <td class="inside-content-child"><div>블랙모노톤(블랙시트)</div></td>
                      <td class="inside-price"><div>0원</div></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="item" name="3">
              <div class="accordion-title">옵션</div>
              <div class="accordion-inside">
                <div class="car-tab">
                  <el-tabs :tab-position="'left'">
                    <el-tab-pane label="선택품목">
                      <table class="inside-container">
                        <tbody>
                          <tr class="inside-content">
                            <td class="inside-content-child">헤드업디스플레이</td>
                            <td class="inside-price">920,197원</td>
                          </tr>
                          <tr class="inside-content">
                            <td class="inside-content-child">파킹어시스트</td>
                            <td class="inside-price">920,197원</td>
                          </tr>
                          <tr class="inside-content">
                            <td class="inside-content-child">파노라마선루프</td>
                            <td class="inside-price">1,920,197원</td>
                          </tr>
                          <tr class="inside-content">
                            <td class="inside-content-child">빌트인캠</td>
                            <td class="inside-price">920,197원</td>
                          </tr>                    
                        </tbody>
                      </table>
                    </el-tab-pane>
                    <el-tab-pane label="기본포함항목">
                      <div class="cate-basic">
                        <ul>
                          <li class="active">파워트레인/성능</li>
                          <li>지능형 안전기술</li>
                          <li>안전</li>
                          <li>외관</li>
                          <li>내장</li>
                          <li>시트</li>
                          <li>편의</li>
                          <li>멀티미디어</li>
                          <li>전체</li>
                        </ul>
                        <span class="price">0원</span>
                      </div>
                      <div class="list-basic">
                        <ul>
                          <li>- 6단 DCT</li>
                          <li>- 하이브리드 시스템(32w 모터, 리튬)</li>
                          <li>- 통합 주행모드</li>
                          <li>- 가솔린 1.6 하이브리드 엔진</li>
                          <li>- 멀티링크 서스펜션</li>
                        </ul>
                      </div>
                    </el-tab-pane>                    
                  </el-tabs>      
                </div>        
              </div>
            </div>
            <div class="item" name="4">
              <div class="accordion-title">파츠 <el-button type="primary" class="btn-small">변경</el-button></div>              
              <div class="accordion-inside divide">
                <table class="inside-container">
                  <tbody>
                    <tr class="inside-content">
                      <td class="inside-content-child">빌트인 공기청정기</td>
                      <td class="inside-price">540,000원</td>
                    </tr>
                    <tr class="inside-content">
                      <td class="inside-content-child">싱글 후석 엔터테인먼트 시스템(운전석)</td>
                      <td class="inside-price">540,000원</td>
                    </tr>                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <ul class="note">
          <li>·  차량의 판매가격은 할인 반영 전 옵션/패키지 가격을 포함한 가격입니다.</li>
          <li>·  견적서와 계약서의 차량정보는 다를 수 있습니다.</li>
        </ul>
      </article>
    </div>
  </div>
</template>
<script>

export default {
  data() {
    return {
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>