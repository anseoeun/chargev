<template>
  <div>
    
    <div class="box">
      <el-table :data="tableData">
        <el-table-column prop="data1" label="쿠폰번호" width="110" align="center"></el-table-column>
        <el-table-column prop="data2" label="타겟번호" width="110" align="center"></el-table-column>
        <el-table-column prop="data3" label="쿠폰명" width="229" align="center"></el-table-column>
        <el-table-column prop="data4" label="다회사용여부" width="120" align="center"></el-table-column>
        <el-table-column prop="data5" label="대상차종" width="150" align="center"></el-table-column>
        <el-table-column prop="data6" label="할인율(금액)" width="150" align="center"></el-table-column>
        <el-table-column prop="data7" label="발급일" width="150" align="center"></el-table-column>
        <el-table-column prop="data8" label="사용기한" width="300" align="center"></el-table-column>
        <el-table-column prop="data9" label="상태" width="120" align="center"></el-table-column>
        <el-table-column label="비고" width="100" align="center">
          <el-button type="primary" class="btn-small">문자발송</el-button>
        </el-table-column>
      </el-table>
    </div>

  </div>
</template>
<script>
export default {
  data() {
    return {
      tableData: [
        {
          data1: 'C0192012',
          data2: 'C0192012',
          data3: '아무나 걸려라 무제한 쿠폰',
          data4: '무제한',
          data5: 'AX1',
          data6: '100,000원',
          data7: '2020-01-01 13:11',
          data8: '2020-01-01 13:11 ~ 2022-01-01 13:14',
          data9: '사용 (1회)',          
        },
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>