<template>
  <div>

    <div class="box">
      <el-table :data="tableData" class="box">
        <el-table-column prop="data1" label="차량구분" width="229" align="center"></el-table-column>
        <el-table-column prop="data2" label="과세구분(유형)" width="200" align="center"></el-table-column>
        <el-table-column prop="data3" label="출고증발급요청(IP+P2)" width="200" align="center"></el-table-column>
        <el-table-column prop="data4" label="결제시작일" width="170" align="center"></el-table-column>
        <el-table-column prop="data5" label="결제기한" width="170" align="center"></el-table-column>
        <el-table-column prop="data6" label="결제일" width="170" align="center"></el-table-column>
        <el-table-column prop="data7" label="직원2차인증기한" width="200" align="center"></el-table-column>
        <el-table-column prop="data8" label="결제진행상태" width="200" align="center"></el-table-column>
      </el-table>
    </div>

    <div class="pay-info">
      <div class="total-price">
        <span class="price">총 결제금액 : 33,611,400원</span>
        <el-button type="primary">결제변경</el-button>
      </div>
      <div class="pay-step">

        <div class="item-step">
          <div class="title-step">
            <strong class="tit">총 판매금액</strong>
            <div class="price">5,033,400원</div>
          </div>
          <ul class="data-step">
            <li>
              <strong class="tit">차량대금</strong>
              <div class="price">49,980,000원</div>
            </li>
            <li>
              <strong class="tit">탁송료</strong>
              <div class="price">10,000원</div>
            </li>
            <li>
              <strong class="tit">단기의무보험료</strong>
              <div class="price">8,000원</div>
            </li>
            <li>
              <strong class="tit">할부인지대</strong>
              <div class="price">100,000원</div>
            </li>
          </ul>
        </div>

        <div class="item-step">
          <i class="el-icon-remove"></i>
          <div class="title-step">
            <strong class="tit">총 할인금액</strong>
            <div class="price">5,033,400원</div>
          </div>
          <ul class="data-step">
            <li>
              <strong class="tit">기본할인(계)</strong>
              <div class="price">1,980,000원</div>
              <div class="vw-detail">
                <dl class="vw">
                  <dt class="vw-title">일시불 3% 할인</dt>
                  <dd class="vw-price">1,472,100원</dd>
                </dl>
                <dl class="vw">
                  <dt class="vw-title">직원할인</dt>
                  <dd class="vw-price">1,100원</dd>
                </dl>
                <dl class="vw">
                  <dt class="vw-title">생산월할인</dt>
                  <dd class="vw-price">3,100원</dd>
                </dl>
                <dl class="vw">
                  <dt class="vw-title">기본조건</dt>
                  <dd class="vw-price">2,100원</dd>
                </dl>
              </div>
            </li>
            <li>
              <strong class="tit">쿠폰할인</strong>
              <div class="price">120,000원</div>
              <div class="vw-detail">
                <dl class="vw">
                  <dt class="vw-title">첫 구매할인</dt>
                  <dd class="vw-price">10,000원</dd>
                </dl>
                <dl class="vw">
                  <dt class="vw-title">쿠폰1</dt>
                  <dd class="vw-price">10,000원</dd>
                </dl>
                <dl class="vw">
                  <dt class="vw-title">쿠폰2</dt>
                  <dd class="vw-price">10,000원</dd>
                </dl>
              </div>
            </li>
            <li>
              <strong class="tit">추가할인(전담DC)</strong>
              <div class="price">120,000원</div>
            </li>
          </ul>
        </div>

        <div class="item-step">
          <i class="el-icon-remove"></i>
          <div class="title-step">
            <strong class="tit">포인트 결제</strong>
            <div class="price">33,400원</div>
          </div>
          <ul class="data-step">
            <li>
              <strong class="tit">M포인트</strong>
              <div class="price">
                <span>80,000원</span>
                <button type="button" class="btn-del"><i class="el-icon-error"></i></button>
              </div>
            </li>
            <li>
              <strong class="tit">블루멤버스</strong>
              <div class="price">
                <span>80,000원</span>
                <button type="button" class="btn-del"><i class="el-icon-error"></i></button>
              </div>
            </li>
            <li>
              <strong class="tit">세이브 오토</strong>
              <div class="price">
                <span>80,000원</span>
                <button type="button" class="btn-del"><i class="el-icon-error"></i></button>
              </div>
            </li>
            <li>
              <strong class="tit">블루멤버스 포인트 선사용</strong>
              <div class="price">
                <span>80,000원</span>
                <button type="button" class="btn-del"><i class="el-icon-error"></i></button>
              </div>
            </li>
            <li>
              <strong class="tit">한도상향</strong>
              <div class="price">
                <span>신청</span>
              </div>
            </li>
          </ul>
        </div>

        <div class="item-step">
          <i class="el-icon-remove"></i>
          <div class="title-step">
            <strong class="tit">감면세액</strong>
            <span class="price">334,400원</span>
          </div>
          <ul class="data-step">
            <li>
              <strong class="tit">개별소비세 면세</strong>
              <div class="price"><span>80,000원</span></div>
            </li>
          </ul>
        </div>
      </div>
    </div>

    <div class="article-title gap">
      <h2>결제내역</h2>
      <div class="right">
        <el-button type="primary">결제변경</el-button>
      </div>
    </div>

    <div class="box">
      <table class="tbl-list">
        <colgroup>
          <col style="width:33.333333%" />
          <col style="width:33.333333%" />
          <col style="width:33.333333%" />
        </colgroup>
        <thead>
          <tr>
            <th>요청금액(A)<i class="el-icon-remove"></i></th>
            <th>처리금액(B)<i class="el-icon-equal"></i></th>
            <th>미처리금액(C)</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td align="center">33,666,111원</td>
            <td align="center">33,666,111원</td>
            <td align="center">0원</td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="box">
      <table class="tbl-list">
        <colgroup>
          <col style="width:25%" />
          <col style="width:25%" />
          <col style="width:25%" />
          <col style="width:25%" />
        </colgroup>
        <thead>
          <tr>
            <th>요청금액(A)<i class="el-icon-remove"></i></th>
            <th>처리금액(B)<i class="el-icon-equal"></i></th>
            <th>미처리금액(C)</th>
            <th>위약금</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td align="center">33,666,111원</td>
            <td align="center">33,666,111원</td>
            <td align="center">0원</td>
            <td align="center">
              <span>340,000원</span>
              <el-button type="info" class="btn-small space">왕복 탁송료 계산</el-button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="box">
      <table class="tbl-list">
        <colgroup>
          <col style="width:7%" />
          <col style="width:7%" />
          <col style="width:6%" />
          <col style="width:14%" />
          <col style="width:6%" />
          <col style="width:7%" />
          <col style="width:7%" />
          <col style="width:6%" />
          <col style="width:6%" />
          <col style="width:7%" />
          <col style="width:7%" />
          <col style="width:6%" />
          <col style="width:6%" />
          <col style="width:6%" />
        </colgroup>
        <thead>
          <tr>
            <th rowspan="2" colspan="2">구분</th>
            <th colspan="3">결제방법</th>
            <th colspan="4">결제상태</th>
            <th colspan="4">취소상태(C)</th>
            <th rowspan="2">비고</th>
          </tr>
          <tr>
            <th>결제수단</th>
            <th>금융사</th>
            <th>명의자</th>
            <th>금액</th>
            <th>상태</th>
            <th>시작일시</th>
            <th>처리일시</th>
            <th>금액</th>
            <th>상태</th>
            <th>시작일시</th>
            <th>처리일시</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td align="center">선지급내역</td>
            <td align="center">계약금</td>
            <td align="center">현금</td>
            <td align="center">우리은행 1111-111-111111</td>
            <td align="center">지성민</td>
            <td align="center">1,110,000원</td>
            <td align="center">입금완료</td>
            <td align="center">2020-12-18 13:15</td>
            <td align="center">2020-12-18 13:15</td>
            <td align="center">10,000원</td>
            <td align="center">환불완료</td>
            <td align="center">2020-12-18 13:15</td>
            <td align="center">2020-12-18 13:15</td>
            <td align="center"><el-button type="primary" class="btn-small">변경</el-button></td>
          </tr>
          <tr>
            <td align="center">추가결제</td>
            <td align="center">탁송료</td>
            <td align="center">직원용 무이자할부</td>
            <td align="center">우리은행 1111-111-111111</td>
            <td align="center">지성민</td>
            <td align="center">1,110,000원</td>
            <td align="center">승인성공/심사전</td>
            <td align="center">2020-12-18 13:15</td>
            <td align="center">2020-12-18 13:15</td>
            <td align="center">10,000원</td>
            <td align="center">환불완료</td>
            <td align="center">2020-12-18 13:15</td>
            <td align="center">2020-12-18 13:15</td>
            <td align="center"><el-button type="primary" class="btn-small">변경</el-button></td>
          </tr>
        </tbody>
        <tfoot>
          <tr>
            <td align="center" colspan="5">소계</td>
            <td align="center" colspan="4">33,611,000원</td>
            <td align="center" colspan="4">0원</td>
            <td></td>
          </tr>
        </tfoot>
      </table>
    </div>

    <div class="article-title gap">
      <h2>적립예정 블루멤버스 포인트</h2>
    </div>

    <div class="box">
      <table class="tbl-list">
        <colgroup>
          <col style="width:25%" />
          <col style="width:25%" />
          <col style="width:25%" />
          <col style="width:25%" />
        </colgroup>
        <thead>
          <tr>
            <th>포인트 적립 대상</th>
            <th>적립율</th>
            <th>이번 구매로 인한 적립 예정 포인트</th>
            <th>포인트 선사용</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td align="center">길인수(90,000)</td>
            <td align="center">0.3%</td>
            <td align="center">6,111원</td>
            <td align="center">(-)150,000원</td>
          </tr>
        </tbody>
      </table>
    </div>



  </div>
</template>
<script>
export default {
  data() {
    return {
      tableData: [
        {
          data1: '생산주문차량',
          data2: '면세(장애인)',
          data3: 'N',
          data4: '2020-12-18 13:15',
          data5: '2020-12-31 16:55',
          data6: '',
          data7: '2021-01-16',
          data8: '결제신청',
        }
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
  @import '~/assets/style/pages/tab/ReleaseInfo.scss';
</style>