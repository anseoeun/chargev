<template>
  <div>
    
    <div class="article-title">
      <h2>출고정보</h2>
    </div>
    <div class="box">
      <table class="tbl-detail">
        <colgroup>
          <col style="width:13%" />
          <col style="width:20%" />
          <col style="width:13%" />
          <col style="width:20%" />
          <col style="width:13%" />
          <col style="width:20%" />
        </colgroup>
        <tbody>
          <tr>
            <th>출고센터</th>
            <td>
              <span>신갈출고센터</span>
              <el-button type="primary" class="btn-small space">변경</el-button>
            </td>
            <th>출고일 / 출고예정일</th>
            <td></td>
            <th>상태</th>
            <td></td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="article-title">
      <h2>인수정보</h2>
      <el-button type="primary">변경</el-button>
    </div>
    <div class="box">
      <table class="tbl-detail">
        <colgroup>
          <col style="width:13%" />
          <col style="width:20%" />
          <col style="width:13%" />
          <col style="width:20%" />
          <col style="width:13%" />
          <col style="width:20%" />
        </colgroup>
        <tbody>
          <tr>
            <th>인수유형</th>
            <td>배달탁송</td>
            <th>탁송지역</th>
            <td>서울특별시</td>
            <th>인수확정여부</th>
            <td>N</td>
          </tr>
          <tr>
            <th>등록대행 동의여부</th>
            <td>동의</td>
            <th>등록 진행상황</th>
            <td>없음</td>
            <th>번호판 끝자리 수</th>
            <td>짝수</td>
          </tr>
          <tr>
            <th>표준서비스 물품</th>
            <td>
              <div>
                <el-radio v-model="rdo1" :label="1">썬팅무료시공</el-radio>
                <el-radio v-model="rdo1" :label="2">브랜드KIT</el-radio>
              </div>
              <el-select>
                <el-option label="길인수" value=""></el-option>
              </el-select>
            </td>
            <th>등록 진행상황</th>
            <td>
              <el-radio v-model="rdo2" :label="1" disabled>등록대행</el-radio>
              <el-radio v-model="rdo2" :label="2">직접등록</el-radio>
            </td>
            <th>차량검수 패키지</th>
            <td>
              <el-radio v-model="rdo3" :label="1">신청</el-radio>
              <el-radio v-model="rdo3" :label="2">미신청</el-radio>
            </td>
          </tr>
          <tr>
            <th>인수자명</th>
            <td>
              <div>길인수</div>
              <el-button type="info" class="btn-small">썬팅장착점 선택</el-button>
              <el-button type="info" class="btn-small">블루핸즈 선택</el-button>
              <el-button type="info" class="btn-small">주소변경</el-button>
            </td>
            <th>인수자 연락처</th>
            <td>010-4444-2332</td>
            <th>용품점</th>
            <td>가든자동차용품점</td>
          </tr>
          <tr>
            <th>탁송지 주소</th>
            <td colspan="5">
              <div>(08655)</div>
              <div>서울시 관악구 조원로 64(신림동)</div>
              <div>8동 1층</div>
            </td>
          </tr>
          <tr>
            <th>기타 요청사항</th>
            <td colspan="5">
              <div>문 앞에 놓아주세요.</div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="article-title">
      <h2>탁송정보</h2>
    </div>
    <div class="box">
      <table class="tbl-detail">
        <colgroup>
          <col style="width:13%" />
          <col style="width:37%" />
          <col style="width:13%" />
          <col style="width:37%" />
        </colgroup>
        <tbody>
          <tr>
            <th>탁송사</th>
            <td></td>
            <th>탁송기사</th>
            <td><el-button type="info" class="btn-small">위치보기</el-button></td>
          </tr>
          <tr>
            <th>탁송경로(1차)</th>
            <td colspan="3"></td>
          </tr>
          <tr>
            <th>출발일시</th>
            <td></td>
            <th>도착예정일시</th>
            <td></td>
          </tr>
          <tr>
            <th>도착일시</th>
            <td></td>
            <th>인수일시</th>
            <td></td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="article-title">
      <h2>탁송료 변동이력</h2>
    </div>
    <div class="box">
      <el-table :data="tableData">
        <el-table-column prop="data1" label="온라인 진행상태" width="150" align="center"></el-table-column>
        <el-table-column prop="data2" label="탁송지" width="150" align="center"></el-table-column>
        <el-table-column prop="data3" label="출고센터" width="150" align="center"></el-table-column>
        <el-table-column prop="data4" label="변경 전 탁송료" width="150" align="center"></el-table-column>
        <el-table-column prop="data5" label="변경 후 탁송료" width="150" align="center"></el-table-column>
        <el-table-column prop="data6" label="지역" width="150" align="center"></el-table-column>
        <el-table-column prop="data7" label="처리일시" width="150" align="center"></el-table-column>
        <el-table-column prop="data8" label="처리자" width="200" align="center"></el-table-column>
        <el-table-column prop="data9" label="변경사유" width="289" align="center"></el-table-column>
      </el-table>
    </div>

  </div>
</template>
<script>
export default {
  data() {
    return {
      rdo1: 2,
      rdo2: 2,
      rdo3: 2,
      tableData: [
        {
          data1: '결제대기',
          data2: '서울시',
          data3: '시흥출고센터',
          data4: '200,000원',
          data5: '400,000원',
          data6: '+200,000원',
          data7: '2021-01-22 16:00',
          data8: '노윤정',
          data9: '최초입력',
        }
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>