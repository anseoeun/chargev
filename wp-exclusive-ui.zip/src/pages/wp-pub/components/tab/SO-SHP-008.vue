<template>
  <div>

    <h-title :title="'전담DC 품의 이력'" />
    <el-table :data="tableData">
      <el-table-column prop="data1" label="품의번호" width="150" align="center"></el-table-column>
      <el-table-column prop="data2" label="요청자" width="150" align="center"></el-table-column>
      <el-table-column prop="data3" label="사유" width="189" align="center"></el-table-column>
      <el-table-column prop="data4" label="요청일시" width="150" align="center"></el-table-column>
      <el-table-column prop="data5" label="요청금액" width="150" align="center"></el-table-column>
      <el-table-column prop="data6" label="처리일시" width="150" align="center"></el-table-column>
      <el-table-column prop="data7" label="승인금액" width="150" align="center"></el-table-column>
      <el-table-column prop="data8" label="승인여부" width="150" align="center"></el-table-column>
      <el-table-column prop="data9" label="할인적용일시" width="150" align="center"></el-table-column>
      <el-table-column prop="" label="할인적용상태" width="150" align="center">
        <el-button type="primary" class="btn-small">적용</el-button>
        <el-button type="info" class="btn-small">취소</el-button>
      </el-table-column>
    </el-table>

    <h-title :title="'판매 처리 이력'" />
    <el-table :data="tableData2">
      <el-table-column prop="data1" label="판매진행단계" width="200" align="center"></el-table-column>
      <el-table-column prop="data2" label="판매진행상태(온라인)" width="309" align="center"></el-table-column>
      <el-table-column prop="data3" label="국판진행상태" width="200" align="center"></el-table-column>
      <el-table-column prop="data4" label="출고예정일" width="200" align="center"></el-table-column>
      <el-table-column prop="data5" label="출고일" width="200" align="center"></el-table-column>
      <el-table-column prop="data6" label="처리일시" width="200" align="center"></el-table-column>
      <el-table-column prop="data7" label="처리자" width="230" align="center"></el-table-column>
    </el-table>

  </div>
</template>
<script>
import HTitle from '~/components/common/HTitle.vue'

export default {
  components: {
    HTitle,
  },
  data() {
    return {
      tableData: [
        {
          data1: 'A00002345',
          data2: '노윤정',
          data3: '출고센터변경',
          data4: '2020-12-18 12:44',
          data5: '400,000원',
          data6: '2020-12-18 12:44',
          data7: '100,000원',
          data8: '승인',
          data9: '',
        }
      ],
      tableData2: [
        {
          data1: '인수완료',
          data2: '차량인수완료(배달탁송)',
          data3: '출고요청',
          data4: '2020-12-18 12:44',
          data5: '2020-12-18 12:44',
          data6: '2020-12-18 12:44',
          data7: '지성민(E101010)',
        }
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>