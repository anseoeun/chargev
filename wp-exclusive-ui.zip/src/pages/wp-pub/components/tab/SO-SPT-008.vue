<template>
  <div>
    
    <div class="box">
      <el-table :data="tableData">
        <el-table-column prop="data1" label="견적번호" width="200" align="center"></el-table-column>
        <el-table-column prop="data2" label="사번" width="200" align="center"></el-table-column>
        <el-table-column prop="data3" label="모델" width="639" align="center"></el-table-column>
        <el-table-column prop="data4" label="견적일시" width="150" align="center"></el-table-column>
        <el-table-column prop="data5" label="최종수정일시" width="150" align="center"></el-table-column>
        <el-table-column prop="data6" label="계약번호" width="200" align="center"></el-table-column>
      </el-table>
    </div>   

  </div>
</template>
<script>
export default {
  data() {
    return {
      tableData: [
        {
          data1: 'U120120102',
          data2: 'E01210291',
          data3: '그랜저 자가용 가솔린',
          data4: '2020-01-01 13:44',
          data5: '2020-01-01 13:44',
          data6: 'A13209428',
        },
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>