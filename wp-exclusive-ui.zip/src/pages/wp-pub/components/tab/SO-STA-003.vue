<template>
  <div>
    
    <div class="box">
      <el-table :data="tableData">
        <el-table-column prop="data1" label="견적번호" width="120" align="center"></el-table-column>
        <el-table-column prop="data2" label="견적작성자" width="120" align="center"></el-table-column>
        <el-table-column prop="data3" label="모델" width="249" align="center"></el-table-column>
        <el-table-column prop="data4" label="트림" width="150" align="center"></el-table-column>
        <el-table-column prop="data5" label="외장컬러" width="150" align="center"></el-table-column>
        <el-table-column prop="data6" label="내장컬러" width="150" align="center"></el-table-column>
        <el-table-column prop="data7" label="가격" width="150" align="center"></el-table-column>
        <el-table-column prop="data8" label="견적일시" width="150" align="center"></el-table-column>
        <el-table-column prop="data9" label="최종수정일시" width="150" align="center"></el-table-column>
        <el-table-column prop="data10" label="계약번호" width="150" align="center"></el-table-column>
      </el-table>
    </div>   

  </div>
</template>
<script>
export default {
  data() {
    return {
      tableData: [
        {
          data1: 'U000000000',
          data2: '지성민',
          data3: '그랜저 자가용 가솔린',
          data4: 'Smart 원톤',
          data5: '미드나잇블랙',
          data6: '블랙모노톤(블랙시트)',
          data7: '10,000,000',
          data8: '2021-01-16 13:13',
          data9: '2021-01-16 13:13',
          data10: 'A2389374983',
        },
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>