<template>
  <div>
    
    <div class="box">
      <el-table :data="tableData">
        <el-table-column prop="data1" label="차명" width="399" align="center"></el-table-column>
        <el-table-column prop="data2" label="시승센터" width="200" align="center">
          <template scope="item">
            <el-popover placement="top" trigger="hover">
              <ul>
                <li>위치: 서울시 강동구 천호대로 현대모터프라자 3층</li>
                <li>전화번호: 02-456-1234</li>
              </ul>
              <span class="item-hover" slot="reference">성내중앙</span>
            </el-popover>
          </template>
        </el-table-column>
        <el-table-column prop="data3" label="시승서비스" width="200" align="center"></el-table-column>
        <el-table-column prop="data4" label="시승예약번호" width="200" align="center"></el-table-column>
        <el-table-column prop="data5" label="예약구분" width="170" align="center"></el-table-column>
        <el-table-column prop="data6" label="시승일시" width="200" align="center"></el-table-column>
        <el-table-column prop="data7" label="시승결과" width="170" align="center"></el-table-column>
      </el-table>
    </div>

  </div>
</template>
<script>
export default {
  data() {
    return {
      tableData: [
        {
          data1: 'AX / Inspriation / 파이어리 레드 / 가솔린 1.6',
          data2: '성내중앙',
          data3: '셀프시승',
          data4: '2039209103920',
          data5: '일반예약',
          data6: '2021-01-16 13:13~20:00',
          data7: '대기',
        },
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>