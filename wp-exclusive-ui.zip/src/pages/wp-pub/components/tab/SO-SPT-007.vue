<template>
  <div>
    
    <div class="box">
      <el-table :data="tableData">
        <el-table-column prop="data1" label="발송유형" width="100" align="center"></el-table-column>
        <el-table-column prop="data2" label="발송일시" width="150" align="center"></el-table-column>
        <el-table-column prop="data3" label="제목" width="300" align="center"></el-table-column>
        <el-table-column prop="data4" label="내용" width="150" align="center"></el-table-column>
        <el-table-column prop="data5" label="이름" width="150" align="center"></el-table-column>
        <el-table-column prop="data6" label="휴대전화번호" width="150" align="center"></el-table-column>
        <el-table-column prop="data7" label="이메일" width="240" align="center"></el-table-column>
        <el-table-column prop="data8" label="보낸사람" width="100" align="center"></el-table-column>
        <el-table-column prop="data9" label="발신번호" width="150" align="center"></el-table-column>
        <el-table-column prop="data10" label="발송상태" width="100" align="center"></el-table-column>
        <el-table-column prop="" label="비고" width="100" align="center">
          <el-button type="primary" class="btn-small">재발송</el-button>
        </el-table-column>
      </el-table>
    </div> 

    <div class="detail-view">
      <el-form ref="info" class="detail-form table-wrap">
        <el-row>
          <el-col :span="24">
            <el-form-item label="제목">
              <el-input />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="발송유형">문자</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="발송일시">2021-04-10 11:11</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="수신정보">010-4444-5555</el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="내용">
              <el-input v-model="memo" type="textarea" class="textarea" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="URL">
              <el-link type="primary">https://www.google.com/</el-link>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="btn-group">
        <el-button type="primary">발송</el-button>
      </div>
    </div>    

  </div>
</template>
<script>
export default {
  data() {
    return {
      tableData: [
        {
          data1: '문자',
          data2: '2021-05-05 11:11',
          data3: '대행견적 안내',
          data4: '상세보기',
          data5: '김효중',
          data6: '010-1111-1111',
          data7: '',
          data8: '길인수',
          data9: '02-111-11111',
          data10: '',         
        },
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>