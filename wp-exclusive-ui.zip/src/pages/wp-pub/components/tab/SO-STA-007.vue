<template>
  <div>
    
    <div class="box">
      <el-table :data="tableData">
        <el-table-column prop="data1" label="No." width="50" align="center"></el-table-column>
        <el-table-column prop="data2" label="이름" width="100" align="center"></el-table-column>
        <el-table-column prop="data3" label="휴대전화" width="150" align="center"></el-table-column>
        <el-table-column prop="data4" label="발송일시" width="150" align="center"></el-table-column>
        <el-table-column prop="data5" label="구분" width="100" align="center"></el-table-column>
        <el-table-column prop="data6" label="제목" width="200">
          <p class="text-omit">(광고) 아무나 걸려라 100,000원 할인 쿠폰 내일 종료될 예정</p>
        </el-table-column>
        <el-table-column label="본문" width="439">
          <p class="text-omit">보유하신 아무나 걸려라 아무나 걸려라 무제한 쿠폰 사용기한이 내일 종료될 예정입니다.</p>
        </el-table-column>
        <el-table-column prop="data8" label="보낸사람" width="100" align="center"></el-table-column>
        <el-table-column prop="data9" label="발신번호" width="150" align="center"></el-table-column>
        <el-table-column label="발송상태" width="100" align="center">
          <el-button type="primary" class="btn-small">재발송</el-button>
        </el-table-column>
      </el-table>
    </div>

  </div>
</template>
<script>
export default {
  data() {
    return {
      tableData: [
        {
          data1: 1,
          data2: '길인수',
          data3: '010-2222-4444',
          data4: '2020-10-23 13:15',
          data5: '쿠폰안내',
          data6: '',
          data7: '',
          data8: '시스템',
          data9: '02-3488-2000',          
        },
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>