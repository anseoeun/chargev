<template>
  <div>
    
    <div class="box">
      <el-table :data="tableData">
        <el-table-column prop="data1" label="차명" width="150" align="center"></el-table-column>
        <el-table-column prop="data2" label="계약구분" width="100" align="center"></el-table-column>
        <el-table-column prop="data3" label="계약번호" width="200" align="center"></el-table-column>
        <el-table-column prop="data4" label="계약시작일" width="120" align="center"></el-table-column>
        <el-table-column prop="data5" label="계약완료일" width="120" align="center"></el-table-column>
        <el-table-column prop="data6" label="출고일" width="120" align="center"></el-table-column>
        <el-table-column prop="data7" label="계약담당자" width="150" align="center"></el-table-column>
        <el-table-column prop="data8" label="판매진행상태" width="100" align="center"></el-table-column>
        <el-table-column prop="data9" label="온라인진행상태" width="100" align="center"></el-table-column>
        <el-table-column prop="data10" label="차대번호" width="200" align="center"></el-table-column>
        <el-table-column prop="data11" label="사전계약여부" width="100" align="center"></el-table-column>
        <el-table-column prop="data12" label="사번" width="150" align="center"></el-table-column>
        <el-table-column prop="data13" label="취소사유" width="200" align="center"></el-table-column>
      </el-table>
    </div>   

  </div>
</template>
<script>
export default {
  data() {
    return {
      tableData: [
        {
          data1: 'AX1',
          data2: '일반',
          data3: 'E01210291',
          data4: '2021-02-01',
          data5: '2021-02-01',
          data6: '2021-02-01',
          data7: '박혜진',
          data8: '배정',
          data9: '결제완료',
          data10: 'DAJFHADSJF12134',
          data11: 'N',
          data12: 'E540345',
          data13: '취소사유',
          
        },
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>