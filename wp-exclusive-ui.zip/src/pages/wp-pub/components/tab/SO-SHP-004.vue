<template>
  <div>
    <div class="article-title">
      <h2>계약자 정보 <span class="contractor">(ID: aaa@uzen.net, 길인수, H202020)</span></h2>
      <div class="right">
        <el-button type="primary">변경</el-button>
      </div>
    </div>
    <div class="box">
      <el-form class="detail-form table-wrap">
        <el-row>
          <el-col :span="8">
            <el-form-item label="구분">
              <span>주계약자</span>
              <el-button type="info" class="btn-small space">정보활용동의</el-button>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="고객관리번호">A3720TM001530</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="이름">
              <span>길인수</span>
              <el-checkbox checked class="private">개인사업자</el-checkbox>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="생년월일">1980-02-13 남자</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="휴대전화">
              <el-input />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="이메일">
              <el-input />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="주소">
              <el-input class="short" />
              <el-button type="primary" class="btn-small">주소검색</el-button>
              <el-input class="inp-addr" />
              <el-input class="inp-addr" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="사업자번호">
              <el-input class="short" />
              <el-button type="info" class="btn-small">휴폐업조회</el-button>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="상호">
              <el-input />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="대표자명">
              <el-input />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="업태">
              <el-input />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="종목">
              <el-input />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="구매담당">
              <el-input />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="box">
      <el-form class="detail-form table-wrap">
        <el-row>
          <el-col :span="8">
            <el-form-item label="구분">
              <span>공동명의자 (관계:가족)</span>
              <el-button type="info" class="btn-small space">정보활용동의</el-button>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="고객관리번호">A3720TM001530</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="이름">지성민</el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="생년월일">1980-02-13 남자</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="휴대전화">
              <el-input />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="이메일">
              <el-input />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="주소">
              <el-input class="short" />
              <el-button type="primary" class="btn-small">주소검색</el-button>
              <el-input class="inp-addr" />
              <el-input class="inp-addr" />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="box">
      <el-form class="detail-form table-wrap">
        <el-row>
          <el-col :span="8">
            <el-form-item label="구분">실차주정보</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="고객구분">
              <span>
                <el-radio :label="1" v-model="rdo1" disabled>개인</el-radio>
                <el-radio :label="2" v-model="rdo1" disabled>개인사업자</el-radio>
                <el-radio :label="3" v-model="rdo1" checked>법인</el-radio>
              </span>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="법인번호">
              <el-input />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="사업자번호">
              <el-input />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="상호">
              <el-input />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="이름">
              <el-input />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="주소">
              <el-input class="short" />
              <el-button type="primary" class="btn-small">주소검색</el-button>
              <el-input class="inp-addr" />
              <el-input class="inp-addr" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="업태">
              <el-input />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="종목">
              <el-input />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="구매담당 연락처">
              <el-input />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="article-title gap">
      <div>
        <h2 class="fl">서비스 가입</h2>
        <el-button type="info" class="btn-small space">정보 활용동의</el-button>
      </div>
      <div class="right">
        <el-button type="primary">변경</el-button>
      </div>
    </div>
    <div class="box">
      <el-form ref="service" class="detail-form table-wrap">
        <el-row>
          <el-col :span="8">
            <el-form-item label="블루멤버스">
              <span>
                <el-radio v-model="rdo2" :label="1" disabled>아니오</el-radio>
                <el-radio v-model="rdo2" :label="2">예</el-radio>
              </span>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="하이패스">
              <span>
                <el-radio v-model="rdo3" :label="1" disabled>아니오</el-radio>
                <el-radio v-model="rdo3" :label="2">예</el-radio>
              </span>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="보증제도">
              <el-select v-model="vouch">
                <el-option label="마일리지형(2년~8만)" value=""></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="표준 서비스물품">브랜드 KIT</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="등록대행 서비스">직접등록</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="차량검수 패키지">신청</el-form-item>
          </el-col>                  
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="중고차가격보장1">
              <span>
                <el-radio v-model="rdo4" :label="1">아니오</el-radio>
                <el-radio v-model="rdo4" :label="2">예</el-radio>
              </span>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="중고차가격보장2">
              <span>
                <el-radio v-model="rdo4" :label="1">아니오</el-radio>
                <el-radio v-model="rdo4" :label="2">예</el-radio>
              </span>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="중고차가격보장3">
              <span>
                <el-radio v-model="rdo4" :label="1" >아니오</el-radio>
                <el-radio v-model="rdo4" :label="2">예</el-radio>
              </span>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="어드벤티지프로그램1">
              <span>
                <el-radio v-model="rdo5" :label="1">아니오</el-radio>
                <el-radio v-model="rdo5" :label="2">예</el-radio>
              </span>
            </el-form-item>
          </el-col>
          <el-col :span="16">
            <el-form-item label="어드벤티지프로그램2">
              <span>
                <el-radio v-model="rdo6" :label="1">아니오</el-radio>
                <el-radio v-model="rdo6" :label="2">예</el-radio>
              </span>
            </el-form-item>
          </el-col>
        </el-row>        
      </el-form>
    </div>

    <div class="box">
      <h-title title="계약금 결제" />
      <el-form class="detail-form table-wrap">
        <el-row>
          <el-col :span="8">
            <el-form-item label="계약금">비대상</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="결제수단">없음</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="처리상태">대기</el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="납부기한">2020-12-24 14:00</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="납부일시">2020-12-24 14:00</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="환불일시">2020-12-24 14:00</el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="box">
      <h-title title="전자서명" />
      <el-table :data="tableData">
        <el-table-column prop="data1" label="차수" width="99" align="center"></el-table-column>
        <el-table-column prop="data2" label="이름" width="240" align="center"></el-table-column>
        <el-table-column prop="data3" label="수단" width="240" align="center"></el-table-column>
        <el-table-column prop="data4" label="구분" width="240" align="center"></el-table-column>
        <el-table-column prop="data5" label="계약완료 (변경)시각" width="240" align="center"></el-table-column>
        <el-table-column prop="data6" label="전자서명 요청시각" width="240" align="center"></el-table-column>
        <el-table-column label="전자서명 완료시각" width="240" align="center">
          <el-button type="primary" class="btn-small">전자서명 재전송</el-button>
        </el-table-column>
      </el-table>
    </div>

    <div class="box">
      <h-title title="상태별 일자" />
      <el-form class="detail-form table-wrap">
        <el-row>
          <el-col :span="8">
            <el-form-item label="계약서작성 시작일">2020-01-01 11:11</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="계약서 변경일">2020-01-01 11:11</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="매출 취소일">2020-01-01 11:11</el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="계약서작성 취소일">2020-01-01 11:11</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="계약 취소일">2020-01-01 11:11</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="계약 취소사유">
              <el-popover placement="top-start" title="계약취소사유" width="300" trigger="hover" content="타사 차량을 구매하려고 계약취소합니다. 뭘 사는지는 물어보지 마세요.">
                <span slot="reference">기타: 타사 차량을 구매하려고 계약취소합니다.</span>
              </el-popover>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="배정 요청일">2020-01-01 11:11</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="배정일">2020-01-01 11:11</el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="출고 예정일">2020-01-01 11:11</el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="box">
      <h-title title="심사대상 서류목록" />
      <el-table :data="tableData2">
        <el-table-column prop="data1" label="NO." width="89" align="center"></el-table-column>
        <el-table-column prop="data2" label="구분" width="320"></el-table-column>
        <el-table-column prop="data3" label="소분류" width="320"></el-table-column>
        <el-table-column prop="data4" label="스크래핑 여부" width="100" align="center"></el-table-column>
        <el-table-column prop="data5" label="스크래핑 결과" width="100" align="center"></el-table-column>
        <el-table-column prop="data6" label="추가서류 여부" width="100" align="center"></el-table-column>
        <el-table-column prop="data7" label="요청일시" width="200" align="center"></el-table-column>
        <el-table-column prop="data8" label="상태변경일시" width="200" align="center"></el-table-column>
        <el-table-column prop="data9" label="상태" width="110" align="center"></el-table-column>
      </el-table>
    </div>

    <div class="box">
      <h-title title="추천인 정보" />
      <el-form class="detail-form table-wrap">
        <el-row>
          <el-col :span="12">
            <el-form-item label="엠버서더">mmm@uzen.net</el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="추천 카마스터">이름:박창석, 소속:유젠, 사번:111111</el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

  </div>
</template>
<script>
import HTitle from '~/components/common/HTitle.vue'

export default {
  components: {
    HTitle,
  },
  data() {
    return {
      rdo1: 3,
      rdo2: 2,
      rdo3: 2,
      rdo4: 2,
      rdo5: 2,
      rdo6: 2,
      vouch: '',
      tableData: [
        {
          data1: '공동인증',
          data2: '길인수',
          data3: '주계약자',
          data4: '2020-01-20 14:00',
          data5: '2020-01-22 16:00',
          data6: '2021-01-20 15:00',
          data7: '2021-01-22 16:00',
        }
      ],
      tableData2: [
        {
          data1: 1,
          data2: '고객유형-직원',
          data3: '신분증(주민등록증 or 운전면허증)',
          data4: 'N',
          data5: '',
          data6: 'Y',
          data7: '2021-01-22 16:00',
          data8: '2021-01-22 16:00',
          data9: '완료',
        }
      ]
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>