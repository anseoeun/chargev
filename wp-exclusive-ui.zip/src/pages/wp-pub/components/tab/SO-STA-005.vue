<template>
  <div>
    
    <div class="box">
      <el-table :data="tableData">
        <el-table-column prop="data1" label="차명" width="119" align="center">
          <template scope="item">
            <el-popover placement="top" trigger="hover">
              <ul>
                <li>모델: AX1</li>
                <li>외장컬러: 햄턴그레이</li>
                <li>내장컬러: 블랙모노톤(블랙시트)</li>
              </ul>
              <span class="item-hover" slot="reference">AX1</span>
            </el-popover>
          </template>
        </el-table-column>
        <el-table-column prop="data2" label="고객구분" width="120" align="center"></el-table-column>
        <el-table-column prop="data3" label="계약번호" width="180" align="center"></el-table-column>
        <el-table-column prop="data4" label="계약완료일" width="120" align="center"></el-table-column>
        <el-table-column prop="data5" label="결제완료일" width="120" align="center"></el-table-column>
        <el-table-column prop="data6" label="출고일" width="120" align="center"></el-table-column>
        <el-table-column prop="data7" label="제작증발급일" width="120" align="center"></el-table-column>
        <el-table-column prop="data8" label="계약담당자" width="120" align="center"></el-table-column>
        <el-table-column prop="data9" label="판매진행상태" width="120" align="center"></el-table-column>
        <el-table-column prop="data10" label="온라인진행상태" width="120" align="center"></el-table-column>
        <el-table-column prop="data11" label="차대번호" width="180" align="center"></el-table-column>
        <el-table-column prop="data12" label="사전계약여부" width="100" align="center"></el-table-column>
      </el-table>
    </div>

  </div>
</template>
<script>
export default {
  data() {
    return {
      tableData: [
        {
          data1: 'AX1',
          data2: '일반',
          data3: 'A1093984021',
          data4: '2020-02-21',
          data5: '2021-02-23',
          data6: '2021-01-16',
          data7: '2021-01-16',
          data8: '박혜진',
          data9: '배정',
          data10: '결제완료',
          data11: 'KDFAJSDF12123',
          data12: 'N',
        },
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>