<template>
  <div>
    <h-title title="문자이력" />
    문자이력 탭내용
  </div>
</template>
<script>
import HTitle from '~/components/common/HTitle.vue'

export default {
  components: {
    HTitle,
  },
  data() {
    return {
      
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '~/assets/style/pages/detail.scss';
</style>