<template>
  <section>
    <div id="main">
      <section class="main-title">
        <h2>
          금일 업무 <span>{{ totalWork.allCount }}</span
          >건
        </h2>
        <div>
          <router-link to="/total/total" class="link">
            업무 집계 조회 &gt;
          </router-link>
        </div>
      </section>
      <div class="alramContentArea">
        <el-row>
          <el-col :span="12" class="alramContentWrap1">
            <el-row>
              <el-col :span="8" class="alramContent">
                <div>OB</div>
                <div style="cursor: pointer">
                  <span @click="goPage('ob')">
                    {{ totalWork.obCount }}
                  </span>
                </div>
              </el-col>
              <el-col :span="8" class="alramContent">
                <div>고객센터이관</div>
                <div style="cursor: pointer">
                  <span @click="goPage('cs')">
                    {{ totalWork.customerCenterCount }}
                  </span>
                </div>
              </el-col>
              <el-col :span="8" class="alramContent">
                <div>마이페이지수신</div>
                <div style="cursor: pointer">
                  <span @click="goPage('mypage')">
                    {{ totalWork.myPageCount }}
                  </span>
                </div>
              </el-col>
            </el-row>
          </el-col>
          <el-col :span="12" class="alramContentWrap2">
            <el-row>
              <el-col :span="8" class="alramContent">
                <div>접수</div>
                <div>
                  <span>{{ totalWork.acceptCount }}</span>
                </div>
              </el-col>
              <el-col :span="8" class="alramContent">
                <div>진행중</div>
                <div>
                  <span>{{ totalWork.progressCount }}</span>
                </div>
              </el-col>
              <el-col :span="8" class="alramContent">
                <div>종결</div>
                <div>
                  <span>{{ totalWork.endCount }}</span>
                </div>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
      </div>
      <div class="contentArea">
        <el-row>
          <el-col :span="16" class="banner">
            <div class="imgContent">
              <img
                v-if="banners && banners.length > 0 && banners[0].filePathName"
                :src="customBannerUrl(banners[0].filePathName)"
                :alt="banners[0].bannerTitle"
              />
              <img v-else src="~@/assets/images/main_banner.jpg" alt="" />
            </div>
            <div class="title">
              <p>{{ imgtxt }}</p>
              <h1>{{ imgTitle }}</h1>
            </div>
          </el-col>
          <el-col :span="8" class="contentsBox">
            <main-box
              :alram-type="'B'"
              :table-title-type="'A'"
              :table-title="'공지사항'"
              :table-content="'A'"
              :table-link="'/wp/notice/manager'"
              :table-datas.sync="noticeList"
            />
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8" class="contentsBox">
            <main-box
              :alram-type="'A'"
              :progress-num="
                parseInt(workInfo.customerImportantProgressCount) || 0
              "
              :not-read-num="
                parseInt(workInfo.customerImportantUnconfirmCount) || 0
              "
              :table-title-type="'B'"
              :table-title1="'고객센터이관'"
              :table-title2="'긴급알림'"
              :table-link="'/wp/cs/reception'"
              :table-datas.sync="csImportList"
            />
          </el-col>
          <el-col :span="8" class="contentsBox">
            <main-box
              :alram-type="'A'"
              :progress-num="
                parseInt(workInfo.customerNormalProgressCount) || 0
              "
              :not-read-num="
                parseInt(workInfo.customerNormalUnconfirmCount) || 0
              "
              :table-title-type="'A'"
              :table-title="'고객센터이관 일반알림'"
              :table-link="'/wp/cs/reception'"
              :table-datas.sync="csNormalList"
            />
          </el-col>
          <el-col :span="8" class="contentsBox">
            <main-box
              :alram-type="'A'"
              :progress-num="parseInt(workInfo.myPageProgressCount) || 0"
              :not-read-num="parseInt(workInfo.myPageUnconfirmCount) || 0"
              :table-title-type="'A'"
              :table-title="'마이페이지  수신업무'"
              :table-link="'/wp/mypage-reception/reception'"
              :table-datas.sync="myPageList"
            />
          </el-col>
        </el-row>
      </div>
    </div>
    <el-dialog
      custom-class="message"
      :visible.sync="duplicateUserAlert"
      width="30%"
      :center="true"
    >
      <span>{{
        userInfo && userInfo.eeNm + "가(이) 새로운 환경에서 로그인 되었습니다."
      }}</span>
      <br />
      <span>다른 환경의 접속은 연결이 끊어집니다.</span>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="duplicateUserAlert = false">
          확인
        </el-button>
      </span>
    </el-dialog>
  </section>
</template>

<script>
import MainBox from '~/components/common/MainBox.vue';
import { mapState } from 'vuex';

export default {
  name: 'Main',
  layout: 'default',
  components: {
    MainBox
  },
  data() {
    return {
      duplicateUserAlert: false,
      totalWork: {
        // 모든 집계 정보
        allCount: 0, // 금일전체건수
        customerCenterCount: 0, // 고객센터이관업무 건수
        myPageCount: 0, // 마이페이지 건수
        obCount: 0, // OB 건수
        acceptCount: 0, // 접수 건수
        progressCount: 0, // 진행중 건수
        endCount: 0 // 종결 건수
      },
      workInfo: {
        // 업무별 알림 건수
        customerImportantProgressCount: '', // 고객센터이관 긴급 진행중건수
        customerImportantUnconfirmCount: '', // 고객센터이관 긴급 읽지않는건수
        customerNormalProgressCount: '', // 고객센터이관 일반 진행중건수
        customerNormalUnconfirmCount: '', // 고객센터이관 일반 읽지않는건수
        myPageProgressCount: '', // 마이페이지수신업무 진행중건수
        myPageUnconfirmCount: '' // 마이페이지수신업무 읽지않는건수
      },
      noticeList: [], // 공지사항 목록
      csImportList: [], // 고객센터이관 긴급알림 목록
      csNormalList: [], // 고객센터이관 일반알림 목록
      myPageList: [], // 마이페이지 목록
      imgtxt: '',
      imgTitle: ''
    }
  },
  computed: {
    ...mapState(['consultants', 'userInfo', 'banners'])
  },
  created() {
    this.$store.dispatch('loadBannerList', { vm: this })
  },
  mounted() {
    this.songpa()
    this.checkedDuplicateUser() // 중복 로그인 체크 - alert
    this.getTotalWorkCount()
    this.getTotalDataList()
  },
  methods: {
    goPage(pgNm) {
      // 업무별 페이지 이동
      switch (pgNm) {
      case 'ob':
        // location.hash = '/ob/reception'
        this.$router.push('/wp/ob/reception')
          break;
      case 'cs':
        // location.hash = '/cs/reception'
        this.$router.push('/wp/cs/reception')
          break;
      case 'mypage':
        // location.hash = '/mypage-reception/reception'
        this.$router.push('/wp/mypage-reception/reception')
          break;
      }
    },
    customBannerUrl(suffixUrl) {
      let preffixUrl = 'https://ep.hmc.co.kr';
      if (['stg', 'dev'].includes(process.env.VUE_APP_PROFILE)) {
        preffixUrl = 'https://tep.hmc.co.kr';
      }
      return preffixUrl + suffixUrl
    },
    async getTotalWorkCount() {
      const [res, err] = await this.$https.get(
        '/v2/exclusive/main/total-work-count'
      ) // API-WE-업무담당자-005 (메인화면 집계 정보 조회)
      if (!err) {
        this.totalWork = res.data
      }

      const [res1, err1] = await this.$https.get(
        '/v2/exclusive/main/work-count'
      ) // API-WE-업무담당자-009 (메인화면 업무 알림 건수 조회)
      if (!err1) {
        this.workInfo = res1.data
      }
    },
    async getTotalDataList() {
      const [res, err] = await this.$https.get('/v2/exclusive/main/notice') // API-WE-업무담당자-008 (메인화면 공지사항 조회)
      if (!err) {
        res.data.sort((a, b) => {
          // 오름차순(중요가 최상단)
          return a.noticeGradeCode < b.noticeGradeCode
            ? -1
            : a.noticeGradeCode < b.noticeGradeCode
              ? 1
              : 0
        })

        res.data = res.data.map(items => {
          const convertObj = {
            path: '',
            title: items.noticeTitle || '',
            date: items.regDate || '',
            content: items.noticeContents || '',
            state: items.noticeConfirmDate !== null ? 'success' : 'fail',
            titleP: items.noticeGradeCode === 'A' ? 'important' : '',
            noticeNumber: items.noticeSerialNumber || ''
          }
          items = convertObj
          return items
        })

        this.noticeList = res.data
      }

      this.getWorkData('customerImport') // 고객센터이관 긴급
      this.getWorkData('customerNormal') // 고객센터이관 일반
      this.getWorkData('myPage') // 마이페이지 수신업무
    },
    async getWorkData(type) {
      let params = { searchType: '' }
      switch (type) {
      case 'customerImport':
        params.searchType = 10 // 긴급알림 코드
          break;
      case 'customerNormal':
        params.searchType = 20 // 일반알림 코드
          break;
      case 'myPage':
        params.searchType = 30 // 수신업무 코드
          break;
      }

      const [res, err] = await this.$https.get(
        '/v2/exclusive/main/work',
        params
      ) // API-WE-업무담당자-007 (메인화면 업무 목록 조회) - 고객센터고객센터 일반알림
      if (!err) {
        switch (type) {
        case 'customerImport':
        case 'customerNormal':
          res.data = res.data.map(items => {
            const convertObj = {
              path: {
                name: 'cs-process',
                params: { workSerialNumber: items.workAssignNumber }
              },
              title: items.counselTitleName || '', // 제목
              date: items.regDate || '', // 등록일시
              name: items.contractorName || '', // 고객이름
              contract: items.onlineStatusName || '', // 판매진행상태
              state: items.noticeConfirmYn === 'Y' ? 'success' : 'fail' // 알림확인여부
            }
              items = convertObj
              return items
            })

            if (type === 'customerImport') {
            this.csImportList = res.data // 긴급알림 코드
            } else if (type === 'customerNormal') {
            this.csNormalList = res.data // 일반알림 코드
            }
          break
          case 'myPage':
          res.data = res.data.map(items => {
            const convertObj = {
              path: {
                name: 'wp-mypage-reception-process',
                params: { workSerialNumber: items.workAssignNumber }
              },
              title: items.workProcessResultName || '', // 유형/처리결과
              date: items.transferDate || '', // 파일업로드일시
              name: items.contractorName || '', // 고객이름
              contract: items.onlineStatusName || '', // 판매진행상태
              state: items.noticeConfirmYn === 'Y' ? 'success' : 'fail' // 알림확인여부
            }
              items = convertObj
              return items
            })
            this.myPageList = res.data // 수신업무 코드
            break;
        }
      }
    },
    checkedDuplicateUser() {
      // 중복 로그인 사용자 체크 - alert
      this.duplicateUserAlert = this.$route.params
        ? this.$route.params.duplicateYn === 'Y'
        : false
    },
    //구매상담신청현황 (송파대로) 권한에 따라 메인 접근 불가능 (임시)
    songpa() {
      console.log(this.userInfo)
      // if(this.userInfo && this.userInfo.exclusiveUseAuthGroupId === 'M0004') {
      if (
        this.userInfo &&
        (this.userInfo.eeno === '2710017' || this.userInfo.eeno === '9063718')
      ) {
        this.$router.push('/wp/support/songpa')
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import "~/assets/style/pages/main.scss";
</style>
