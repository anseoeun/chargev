<template>
  <section>
    <div id="login">
      <div class="loginWrap">
        <h1 class="logo" />
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'SsoLogin',
  layout: 'fullpage',
  data() {
    return {
      msg: '',
      alertVisible: false,
      alertLogoutVisible: false
    }
  },
  mounted() {
    this.fetchLogin()
  },
  methods: {
    async fetchLogin() {
      const [res, err] = await this.$https.get('/v1/exclusive/sso/userInfo')
      if(!err) {
        if(res.data) {
          const { sessionId = '' } = res.data
          this.$store.dispatch('ssoLogin', {vm: this, sessionId }).then(() => {
            this.$router.push('/main')
          })
        }
      } else {
        console.log('error => ', err)
      }
    }
  }
}
</script>