<template>
  <section>
    <div id="total">
      <div class="btn-wrap">
        <div class="side">
          <el-button 
            type="info"
            @click="resetSearchForm"
          >
            초기화 test
          </el-button>
        </div>
        <div class="excel">
          <el-button 
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            @click="getTotalList"
          >
            조회
          </el-button>
          <el-button
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            class="excel"
            @click="downloadExcel"
          >
            Excel 다운로드
          </el-button>
        </div>
      </div>
      <el-form
        ref="ruleForm"
        :model="ruleForm"
        class="detail-form"
      >
        <el-row>
          <el-col :span="24">
            <el-form-item label="기간">
              <el-date-picker
                v-model="ruleForm.sumStartYmd"
                type="date"
              />
              <span class="ex-txt">~</span>
              <el-date-picker 
                v-model="ruleForm.sumEndYmd" 
                type="date"
              />
              <el-radio-group
                v-model="searchDtRadio"
                class="tabBtn-case01"
                @change="onChangeSearchDtRadio"
              >
                <el-radio-button label="prevDay">
                  전일
                </el-radio-button>
                <el-radio-button label="today">
                  오늘
                </el-radio-button>
                <el-radio-button label="day7">
                  7일
                </el-radio-button>
                <el-radio-button label="day30">
                  30일
                </el-radio-button>   
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="처리자">
              <el-select
                v-model="ruleForm.exclusiveUserId"
                placeholder="전체"
              >
                <el-option
                  v-for="{ sysUserNo, sysUserNm } in userInfo.exclusiveUseAuthGroupId === 'M0001' ? consultants.filter((items) => { return items.useAuthId === 'M0001' }) : consultants"
                  :key="sysUserNo"
                  :value="sysUserNo"
                  :label="sysUserNm"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>

      <el-table
        :data="totalList"
        empty-text="조회 결과가 존재하지 않습니다."
      >
        <el-table-column
          label="컨설턴트"
          prop="exclusiveUserName"
        />
        <el-table-column
          label="업무유형"
        >
          <el-table-column
            label="OB 업무"
            prop="obCount"
          />
          <el-table-column
            label="고객센터이관"
            prop="csCount"
          />
          <el-table-column
            label="마이페이지"
            prop="mpCount"
          />
          <el-table-column
            label="계"
            prop="workTypeTotalCount"
          >
            <template slot-scope="props">
              <span class="textBlue">{{ props.row.workTypeTotalCount }}</span>
            </template>
          </el-table-column>
        </el-table-column>
        <el-table-column
          label="처리결과"
        >
          <el-table-column
            label="접수"
            prop="acceptCount"
          />
          <el-table-column
            label="진행중"
            prop="progressCount"
          />
          <el-table-column
            label="종결"
            prop="endCount"
          />
          <el-table-column
            label="계"
            prop="processResultTotalCount"
          >
            <template slot-scope="props">
              <span class="textBlue">{{ props.row.processResultTotalCount }}</span>
            </template>
          </el-table-column>
        </el-table-column>
      </el-table>
      
      <p class="note">
        {{ note }}
      </p>
    </div>
  </section>
</template>

<script>
import { mapGetters } from 'vuex'
import moment from 'moment'

export default {
  name: 'Total',
  layout: 'default',  
  data() {
    return {
      note: '* 기간내의 계약, 출고, 해약, 매출취소 건수로 업무유형 및 처리결과 값이랑 상관관계 없음.',
      ruleForm: {
        sumStartYmd: moment(), // 집계시작기간
        sumEndYmd: moment(), // 집계종료기간
        exclusiveUserId: '' // 업무담당자사원번호
      },
      searchDtRadio: 'today',  // 오늘
      totalList: []  // 집계 목록
    }
  },
  computed: {
    ...mapGetters(['userInfo']),
    consultants: function() {
      const consultants = this.$store.state.consultants.slice()
      if(consultants && consultants.length > 0) {
        consultants.unshift( { 'useAuthId': '', 'sysUserNo': '', 'sysUserNm': '전체', 'opsNm': '' } )
      }
      return consultants
    }
  },
  mounted() {    
    this.$store.dispatch('loadConsultants', {vm: this})
  },
  methods: {
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    async getTotalList() { // 집계 목록 조회
      const params = { 
        ...this.ruleForm,
        sumStartYmd: moment(this.ruleForm.sumStartYmd).format('YYYYMMDD'),
        sumEndYmd: moment(this.ruleForm.sumEndYmd).format('YYYYMMDD'),        
      }
      const [res, err] = await this.$https.get('/v1/exclusive/total', params) // API-E-업무담당자-082 (집계 목록 조회)

      if(!err) {
        console.log(res)
        if(res.data && res.data.length > 0) {
          this.totalList = res.data
        } else {
          this.totalList = []
        }
      } else {
        this.totalList = []
        console.erro(err)
      }
    },
    resetSearchForm() {
      Object.assign(this.$data.ruleForm, this.$options.data().ruleForm)
      this.searchDtRadio = 'today'
    },
    onChangeSearchDtRadio(val) {
      switch(val) {
      case 'prevDay':
        this.ruleForm.sumStartYmd = moment().subtract('days', 1)
        this.ruleForm.sumEndYmd = moment().subtract('days', 1)
        break
      case 'today':
        this.ruleForm.sumStartYmd = moment()
        this.ruleForm.sumEndYmd = moment()
        break
      case 'day7':
        this.ruleForm.sumStartYmd = moment().subtract('days', 7)
        this.ruleForm.sumEndYmd = moment()
        break
      case 'day30':
        this.ruleForm.sumStartYmd = moment().subtract('days', 30)
        this.ruleForm.sumEndYmd = moment()
        break
      }
    },
    async downloadExcel() {
      const params = { 
        ...this.ruleForm,
        sumStartYmd: moment(this.ruleForm.sumStartYmd).format('YYYYMMDD'),
        sumEndYmd: moment(this.ruleForm.sumEndYmd).format('YYYYMMDD'),        
      }
      
      const [res,err] = await this.$https.getb('/v1/exclusive/total-excel', params)
      if(!err) {
        const blob = new Blob([res], {type : res.Type })
        const nowDate = moment().format('YYYYMMDD_HHmm') 
        if(window.navigator.msSaveOrOpenBlob) {
          // IE11
          window.navigator.msSaveOrOpenBlob(blob, '집계엑셀조회_' + nowDate + '.xlsx') 
        } else {            
          // IE11 외 브라우저
          const blobURL = window.URL.createObjectURL(blob)
          const tempLink = document.createElement('a')
          
          tempLink.href = blobURL        
                
          tempLink.setAttribute('download', '집계엑셀조회_' + nowDate + '.xlsx')
          document.body.appendChild(tempLink)        
          tempLink.click()
          document.body.removeChild(tempLink)        
          window.URL.revokeObjectURL(blobURL)
        }
      } else {
        console.error(err)
        this.tableData = null
      }
    }
  }

}
</script>

<style lang="scss" scoped>
@import '~/assets/style/pages/total.scss';
</style>
