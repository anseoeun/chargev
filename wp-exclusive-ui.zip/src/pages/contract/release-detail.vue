<template>
  <section>
    <div id="release-detail">
      <div class="article-title">
        <h-search
          v-model="contractNumber"
          :title="'계약번호'"
          :on-click="searchContract"
          :active-button="isValidAuthBtn('authSelect')"
          @enter="searchContract"
          @keydown.native.tab="onAddZero(contractNumber)"
        />
        <div class="btn-group">
          <div>
            <el-button
              v-if="isValidAuthBtn('authExclusive') && (isAuth || userInfo.eeno === info.consultantId)"
              type="primary"
              :disabled="!contractNumber || (info.onlineStatusCode!='0320' && info.onlineStatusCode!='0330')"
              @click="popShow.reservedCenterPop = true"
            >
              방문예약
            </el-button>
            <el-button
              v-if="isValidAuthBtn('authExclusive') && (isAuth || userInfo.eeno === info.consultantId)"
              type="primary"
              :disabled="!contractNumber"
              @click="openPopSms()"
            >
              문자보내기
            </el-button>
            <el-button
              v-if="isValidAuthBtn('authSelect')"
              type="primary"
              :disabled="!contractNumber"
              @click="estimationView"
            >
              견적보기
            </el-button>
            <el-button
              v-if="isValidAuthBtn('authExclusive') && (isAuth || userInfo.eeno === info.consultantId) && showBtnCarMakeCertification"
              type="primary"
              :disabled="!contractNumber"
              @click="issueCarCertification"
            >
              제작증 발급
            </el-button>
          </div>
          <div>
            <el-button
              v-if="isValidAuthBtn('authExclusive') && (isAuth || userInfo.eeno === info.consultantId)"
              type="primary"
              :disabled="!contractNumber"
              @click="checkPaymentInitPop = true"
            >
              결제 초기화
            </el-button>
            <el-button
              v-if="isValidAuthBtn('authExclusive') && (isAuth || userInfo.eeno === info.consultantId)"
              type="primary"
              :disabled="!contractNumber"
              @click="alertVisibleCancelPayAsk = true"
            >
              해약
            </el-button>
            <el-button
              v-if="isValidAuthBtn('authPayment') && (isAuth || userInfo.eeno === info.consultantId)"
              type="primary"
              :disabled="!info.contractNumber"
              @click="popVisibleActivatePay = true"
            >
              결제항목 활성화
            </el-button>
            <el-button
              v-if="isValidAuthBtn('authExclusive') && (isAuth || userInfo.eeno === info.consultantId)"
              type="primary"
              :disabled="!contractNumber"
              @click="popVisibleRequestPaper = true"
            >
              서류요청
            </el-button>
          </div>
        </div>
      </div>

      <h-relese-info
        :info="info"
      />
      <div class="article">
        <el-tabs
          v-model="activeName"
          type="card"
          stretch
          @tab-click="handleTabClick"
        >
          <el-tab-pane
            label="계약정보"
            name="first"
          >
            <contract-info
              :contract-number.sync="contractNumber"
              :contract-data.sync="contractData"
              :sign-data.sync="signData"
              :status-date-data.sync="statusDateData"
              :user-info-data.sync="userInfo"
              :paper-review-data.sync="paperReviewData"
              :active-user-flag.sync="activeFlag"
            />
          </el-tab-pane>
          <el-tab-pane
            label="차량정보"
            name="second"
          >
            <car-info
              ref="CarInfo"
              :contract-number.sync="contractNumber"
              :active-user-flag.sync="activeFlag"
              @data="getCarProductionNumber"
            />
            <!-- <car-info
              :car-info-data.sync="carInfoData"
              :choice-option-names.sync="choiceOptionNames"
              :tuix-option-names.sync="tuixOptionNames"
            /> -->
          </el-tab-pane>
          <el-tab-pane
            label="결제정보"
            name="third"
          >
            <pay-info
              :pay-info-data.sync="payInfoData"
              :pay-amount-list.sync="payAmountList"
              :pay-detail.sync="payDetail"
              :user-info-data.sync="userInfo"
              :contract-info-data.sync="info"
              :active-user-flag.sync="activeFlag"
              @refresh="onRefresh($event, 'pay')"
            />
          </el-tab-pane>
          <el-tab-pane
            label="출고정보"
            name="fourth"
          >
            <release-info
              :release-info-data.sync="releaseInfoData"
              :release-center-data.sync="releaseCenterData"
              :release-takeover-data.sync="releaseTakeoverData"
              :release-consign-data.sync="releaseConsignData"
              :contract-info-data.sync="info"
              :release-regist-agency-data.sync="releaseRegistAgencyData"
            />
          </el-tab-pane>
          <el-tab-pane
            label="상태이력"
            name="fifth"
          >
            <status-history
              ref="StatusHistory"
              :contract-number.sync="contractNumber"
            />
            <!-- 상태이력 화면 컴포넌트화로 인한 주석처리 <A936507> -->
            <!-- <status-history
              :data.sync="statusTabData"
            /> -->
          </el-tab-pane>
          <el-tab-pane
            label="문자이력"
            name="sixth"
          >
            <sms-history
              ref="SmsHistory"
              :contract-number.sync="contractNumber"
            />
            <!-- <sms-history
              :data.sync="messageTabData"
              @refresh="onRefresh($event, 'sms')"
            /> -->
          </el-tab-pane>
        </el-tabs>
      </div>

      <loading
        :pop-visible.sync="popVisibleLoading"
        @close="popVisibleLoading = false"
      />

      <!-- 조회결과없음 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="alertNoData"
      >
        <!-- Message -->
        조회 결과가 없습니다.

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="info"
            @click="alertNoData = false"
          >
            확인
          </el-button>
        </template>
      </el-dialog>

      <!-- 해약 팝업 -->
      <el-dialog
        :center="false"
        custom-class="message cancellation"
        :visible.sync="alertVisibleCancelPayAsk"
        width="550px"
      >
        <!-- Message -->
        <i class="el-icon-info"></i>
        <p>
          해약처리를 진행하시겠습니까? <br />
          아래 3단계를 진행해주세요. <br />
          <br />
        </p>
        <p style="text-align: left">
          ① 해약버튼 클릭 -> 결제취소(환불대기) 상태 변경됨 <br />
          ② 결제취소 처리 -> 할부,카드,포인트 취소 <br />
          ③ 해약버튼 클릭 -> 해약처리 완료 <br />
        </p>
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="info"
            @click="alertVisibleCancelPayAsk = false"
          >
            아니요
          </el-button>
          <el-button
            type="primary"
            @click="canclePay"
          >
            예
          </el-button>
        </template>
      </el-dialog>

      <!-- 결제 초기화 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="checkPaymentInitPop"
      >
        <!-- Message -->
        결제 초기화를 진행하시겠습니까?

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="info"
            @click="checkPaymentInitPop = false"
          >
            아니요
          </el-button>
          <el-button
            type="primary"
            @click="doPaymentInit"
          >
            예
          </el-button>
        </template>
      </el-dialog>

      <!-- 해약 진행 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="alertVisibleCancelPayConfirm"
      >
        <!-- Message -->
        결제 해약을 진행하시겠습니까?

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="info"
            @click="alertVisibleCancelPayConfirm = false"
          >
            아니요
          </el-button>
          <el-button
            type="primary"
            @click="alertVisibleCancelPayConfirm = false"
          >
            예
          </el-button>
        </template>
      </el-dialog>

      <!-- 결제항목 활성화 -->
      <el-dialog
        title="결제항목 활성화"
        :visible.sync="popVisibleActivatePay"
        @close="closeActivatePayPop"
      >
        <div
          class="btn-wrap"
          style="margin: 0px;"
        >
          <div class="side"></div>
          <div class="main">
            <el-button
              type="primary"
              @click="activationSend"
            >
              전송
            </el-button>
            <el-button
              type="primary"
              class="btn-s"
              icon="el-icon-plus"
              @click="onActRowAdd"
            />
          </div>
        </div>
        <div
          class="board-wrap"
          style="padding-top: 10px;"
        >
          <el-table
            :data="activationlist"
          >
            <el-table-column
              prop="rowNum"
              label="NO."
              align="center"
            >
              <template slot-scope="props">
                <el-button
                  type="primary"
                  class="btn-s"
                  icon="el-icon-minus"
                  @click="onActRowDelete(props.row.rowNum)"
                />
              </template>
            </el-table-column>

            <el-table-column
              prop="addStlRqTypeCd"
              label="항목"
              align="center"
            >
              <template slot-scope="props">
                <el-select
                  v-model="props.row.addStlRqTypeCd"
                  placeholder="결제항목"
                >
                  <el-option
                    v-for="{ value, label } in commonCodes.T023 && commonCodes.T023.slice(1, commonCodes.T023.length)"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
              </template>
            </el-table-column>
            <el-table-column
              prop="stlRqAmt"
              label="결제대상금액"
            >
              <template slot-scope="props">
                <el-input
                  v-model="props.row.stlRqAmt"
                />
              </template>
            </el-table-column>
            <el-table-column
              prop="date"
              label="요청일시"
              align="center"
            >
              <template slot-scope="props">
                <span>{{ props.row.date }}</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <!-- Popup Footer -->
        <!-- <template slot="footer">
          <el-button
            type="primary"
            @click="popVisibleActivatePay = false"
          >
            전송
          </el-button>
        </template> -->
      </el-dialog>

      <!-- 추가서류요청 -->
      <el-dialog
        title="추가서류요청"
        :visible.sync="popVisibleRequestPaper"
        width="1300px"
        @close="closeRequestPop"
      >
        <div
          class="board-wrap"
          style="padding-top: 10px;"
        >
          <div class="transformBox">
            <div class="left">
              <h-title
                :title="'서류목록'"
              />
              <div class="transformContentWrap">
                <div
                  class="transformContent"
                  style="height: 370px"
                >
                  <p
                    v-for="(items) in documentTargets"
                    :key="items.neceDocTargNo"
                    :title="items.neceDocTargNm"
                    class="p-chk"
                    @click="getDocList($event, items)"
                  >
                    {{ items.neceDocTargNm }}
                  </p>
                  <!-- 선택 되었을때  -->
                  <!-- class="p-chk is-chlick" class에 is-chlic 추가 해주세요. -->
                </div>
                <div
                  v-if="documentList.length > 0"
                  class="transformContent"
                  style="height: 370px"
                >
                  <el-checkbox
                    v-for="({ neceDocNo, neceDocNm }, idx) in documentList"
                    :key="neceDocNo"
                    v-model="checkedDocList[idx]"
                    :value="neceDocNo"
                    :label="neceDocNm"
                  />
                </div>
                <div
                  v-else
                  class="transformContent"
                  style="height: 370px"
                >
                  <p class="p-chk">
                    서류목록이 없습니다.
                  </p>
                </div>
              </div>
            </div>
            <div class="btn-wrap">
              <div class="btns">
                <div>
                  <el-button
                    type="primary"
                    @click="addDocList"
                  >
                    추가
                  </el-button>
                </div>
                <div></div>
                <el-button
                  type="info"
                  @click="delDocList"
                >
                  삭제
                </el-button>
              </div>
            </div>
            <div class="right">
              <h-title
                :title="'요청서류'"
              />

              <el-table
                :data="requestDocList"
                max-height="150px"
                @select="selRequestDocList"
                @select-all="selRequestDocList"
              >
                <el-table-column
                  label="선택"
                  type="selection"
                  width="80px"
                />
                <el-table-column
                  label="구분"
                  prop="neceDocTargNm"
                  align="center"
                />
                <el-table-column
                  label="서류이름"
                  prop="neceDocNm"
                  align="center"
                />
              </el-table>
              <h-title
                :title="'고객알림'"
              />
              <el-input
                v-model="needPapersSubject"
                type="textarea"
              />
            </div>
          </div>
        </div>
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="primary"
            @click="docSend"
          >
            고객전송
          </el-button>
        </template>
      </el-dialog>


      <!-- 문자보내기 팝업 -->
      <el-dialog
        title="문자보내기"
        :visible.sync="popVisibleSMS"
        width="1100px"
      >
        <!-- Popup Contents -->
        <div class="board-wrap sandmessage">
          <h-title :title="'수신자 정보'" />
          <el-form
            ref="contractData"
            :model="contractData"
            class="detail-form"
          >
            <el-row>
              <el-col :span="9">
                <el-form-item label="수신자명">
                  <!-- {{ contractData.contractorInfo && contractData.contractorInfo.length > 0 ? contractData.contractorInfo[0].customerName : '' }} -->
                  <el-select v-model="contractorNames" multiple placeholder="수신자명">
                    <el-option
                      v-for="item in contractData.contractorInfo"
                      :key="item.customerName"
                      :label="item.customerName"
                      :value="item.customerName">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="15">
                <el-form-item label="휴대전화번호">
                  <!-- {{ contractData.contractorInfo && contractData.contractorInfo.length > 0 ? contractData.contractorInfo[0].customerMobile : '' }} -->
                  {{ contractorHpTns() }}
                </el-form-item>
              </el-col>
              <!-- <el-col :span="7">
                <el-form-item label="발송일시" />
              </el-col> -->
            </el-row>
          </el-form>
          <h-title :title="'발신내용'" />
          <el-form
            ref="ruleFormpopup"
            :model="ruleFormpopup"
            class="detail-form"
          >
            <el-row>
              <el-col :span="24">
                <el-form-item label="제목">
                  <el-input
                    v-model="ruleFormpopup.title"
                    class="mms-title"
                    @blur="ruleFormpopup.title = $event.target.value"
                  />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item label="내용">
                  <el-input
                    v-model="ruleFormpopup.text"
                    type="textarea"
                    @blur="ruleFormpopup.text = $event.target.value"
                  />
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="info"
            @click="initRuleFormPop"
          >
            초기화
          </el-button>
          <el-button
            type="primary"
            @click="sendSms"
          >
            전송
          </el-button>
        </template>
      </el-dialog>
      <!-- message Popup -->
      <pop-message
        :pop-visible.sync="alertMessagePop"
        :pop-message.sync="alertMessage"
        @confirm="alertMessagePop = false"
        @close="alertMessagePop = false"
      />

      <!-- 방문예약하기 팝업 -->
      <reserved-center-popup
        :pop-show.sync="popShow"
        :contract-number="contractNumber"
        :info="info"
        @alertMsg="(msg) => { alertMessage = msg; alertMessagePop = true; }"
      />
      <!-- //방문예약하기 팝업 -->
    </div>
  </section>
</template>

<script>
import HSearch from '~/components/common/HSearch.vue'
import HReleseInfo from '~/components/common/HReleseInfo.vue'
import HTitle from '~/components/common/HTitle.vue'
import ContractInfo from '~/components/tab/ContractInfo.vue'
import CarInfo from '~/components/tab/CarInfo.vue'
import PayInfo from '~/components/tab/PayInfo.vue'
import ReleaseInfo from '~/components/tab/ReleaseInfo.vue'
import StatusHistory from '~/components/tab/StatusHistory.vue'
import SmsHistory from '~/components/tab/SmsHistory.vue'
import Loading from '~/components/popup/Loading.vue'
import PopMessage from '~/components/popup/PopMessage.vue'
import ReservedCenterPopup from '~/components/popup/ReservedCenterPopup'
import { mapState, mapGetters } from 'vuex'
import moment from 'moment'

export default {
  name: 'ReleaseDetail',
  layout: 'default',
  components: {
    HSearch,
    HReleseInfo,
    HTitle,
    ContractInfo,
    CarInfo,
    PayInfo,
    ReleaseInfo,
    StatusHistory,
    SmsHistory,
    Loading,
    PopMessage,
    ReservedCenterPopup
  },
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      isAuth: process.env.VUE_APP_AUTH === 'true', // 권한 패스용
      popVisibleLoading: false,
      activeFlag: false, // 탭에서 조건별 활성화되어야 하는 버튼 제어 플래그
      alertNoData: false,
      checkPaymentInitPop: false,
      alertVisibleCancelPayAsk: false,
      alertVisibleCancelPayConfirm: false,
      popShow: {
        reservedCenterPop: false
      },
      popVisibleSMS: false,
      popVisibleEstimation: false,
      popVisibleActivatePay: false,
      popVisibleRequestPaper: false,
      agreePop: false,
      active:[],
      activeName: 'first',
      popactiveName: 'pop-first',
      popactiveName1: 'pop-first',
      ruleFormpopup:{
        title: '',
        text: ''
      },
      documentList: [], // 서류목록
      checkedDocList: [], // 서류목록 체크 여부
      requestDocList: [], // 요청서류목록
      selNeceDocInfo: { // 선택한 서류대상 정보
        neceDocTargNo: '', // 필요서류대상번호
        neceDocTargNm: '' // 필요서류대상명
      },
      selRequestDoc: [], // 선택한 요청 서류목록
      needPapersSubject: '', // 추가요청내용
      activationlist: [], // 결제기능 활성화 목록
      addKeyActPayIdx: 0, // 결제항목 활성화 목록 인덱스
      info: {},
      contractData: {},
      signData: [],
      statusDateData: {},
      paperReviewData: [],
      //carInfoData: {},
      //choiceOptionNames: '',
      //tuixOptionNames: '',
      carProductionNumber: '',
      payInfoData: {},
      payAmountList: [],
      payDetail: {},
      releaseInfoData: {},
      releaseCenterData: {},
      releaseTakeoverData: {},
      releaseConsignData: {},
      releaseRegistAgencyData: {},
      // 상태이력 화면 컴포넌트화로 인한 주석처리 <A936507>
      //statusTabData: { sale: [], sales: [], payment:[], consultant:[], papers:[], electron: [], point: [], apiLog : []},
      //messageTabData: [],
      isCertificationRequestValidDate: false, // 제작증발급 요청일시 유효성 여부(true: 발급가능, false: 발급불가능)
      contractNumber: null, // 계약번호
      commonCodes: {},
      contractorNames: []  // 선택한 계약자명
    }
  },
  computed: {
    ...mapState({
      documentTargets: state => state.documentTargets.filter((items) => { return items.neceDocTargNm !== '전체'}), // 전체 항목 제외
    }),
    ...mapGetters(['userInfo']),
  },
  async created() {
    await this.loadCommonCode()
  },
  mounted() {
    this.$store.dispatch('loadDocumentTargets', {vm: this})

    this.contractNumber = sessionStorage.getItem('contractNumber') || '' // 새창으로 넘어오는 경우

    if(this.$route.params.contractNumber) { // route 이동으로 넘어오는 경우 * params이 있을 경우에만 셋팅
      this.contractNumber = this.$route.params.contractNumber
    }

    if(this.contractNumber) {
      this.getInfoData()
      this.getContractTabData()//first tab
    }

    sessionStorage.removeItem('contractNumber')

  },
  methods: {
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null
      switch(systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {vm: this, codeTypeCode: codeType})
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {vm: this, codeTypeCode: codeType})
        break
      }
      return res
    },
    async loadCommonCode() {
      const [ccT023] = await Promise.all([
        this.fetchCommonCodeData('E', 'T023') // 결제항목
      ])

      this.commonCodes = { ...ccT023 }
    },
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    onAddZero(contractNumber) {
      let resultString = ''
      if(contractNumber.length > 6) {
        const frontString = contractNumber.substring(0,7)
        const backString = contractNumber.substring(7)

        resultString = resultString.concat(frontString)
        resultString = resultString.concat(backString.length >= 6 ? backString : Array.from({length: 6 - backString.length}, () => 0).join('') + backString)
      }

      if(!resultString) { resultString = contractNumber }
      this.contractNumber = resultString
    },
    estimationView() { // 견적보기
      let preffixUrl = 'http://10.7.137.110/dev/casper'
      if (['stg', 'dev', 'prod'].includes(process.env.VUE_APP_PROFILE)) {
        preffixUrl = process.env.VUE_APP_BASEURL_FRONT
      }

      if(this.contractData && this.contractData.estimationUrl) {
        window.open(preffixUrl + '/estimation/detail?estimationUrl=' + this.contractData.estimationUrl)
      } else {
        this.alertMessage = '해당 계약 건은 견적이력이 없습니다.'
        this.alertMessagePop = true

        return false
      }

    },
    async getInfoData() {
      this.popVisibleLoading = true
      // API-E-업무담당자-013 (계약출고상세조회)
      const [res, err] = await this.$https.post('/v2/exclusive/contract-detail', { contractNumber: this.contractNumber })
      if(!err) {
        if(!res.data) { // 상세보기 - 조회 결과 없음 팝업 노출
          const beforeContractNumber = this.contractNumber
          const beforeActiveName = this.activeName
          Object.assign(this.$data, this.$options.data())
          this.contractNumber = beforeContractNumber // 이전 계약번호 유지
          this.activeName = beforeActiveName // 이전 탭 상태 유지
          this.alertNoData = true
          return
        }
        console.log(this.info)
        this.info = res.data
        if(this.info.consultantId && this.info.consultantId === this.userInfo.eeno) { // 사용자 사번과 계약건의 업무담당자이 같을 경우
          this.activeFlag = true
        }

        this.getCarTabData()
        this.popVisibleLoading = false
      } else {
        this.popVisibleLoading = false
        console.error(err)
      }
    },
    searchContract(value) {
      this.popShow.reservedCenterPop = false
      if(!this.isValidAuthBtn('authSelect')) { // 권한없을경우 동작 x
        return
      }

      if(!value) {
        this.alertMessage = '계약번호를 입력해주세요.'
        this.alertMessagePop = true
        return
      } else {
        value = value.trim() // 공백 제거
      }

      this.contractNumber = value
      this.getInfoData()
      this.getContractTabData()
      this.handleTabClick({name: this.activeName})
    },
    handleTabClick(tab) {
      if(tab.name==='first') this.getContractTabData()
      else if(tab.name==='second') this.getCarTabData()
      else if(tab.name==='third') this.getPaymentTabData()
      else if(tab.name==='fourth') this.getReleaseTabData()
      else if(tab.name==='fifth') this.getStatusTabData()
      else if(tab.name==='sixth') this.getMessageTabData()
    },
    async getContractTabData() {
      if(!this.contractNumber) return

      //계약자 정보 + 서비스가입 + 계약금 결제
      // API-E-업무담당자-014 (계약정보조회)
      // if(Object.keys(this.contractData).length===0) {
      const [res1, err1] = await this.$https.post('/v2/exclusive/work/contract', { contractNumber: this.contractNumber })
      if(!err1) {
        console.log('/work/contract/', res1.data)
        if(!res1.data) { return }
        this.contractData = res1.data

        const contractorInfo = this.contractData && this.contractData.contractorInfo
        this.contractorNames = contractorInfo && contractorInfo.length ? contractorInfo.map((items) => { return items.customerName }) : []
      } else {
        console.error(err1)
      }
      //}

      // API-E-업무담당자-015 (전자서명목록 조회)
      // if(Object.keys(this.signData).length===0) {
      const [res2, err2] = await this.$https.post('/v2/exclusive/work/electron', { contractNumber: this.contractNumber })
      if(!err2) {
        console.log('/work/electron/', res2.data)
        this.signData = res2.data
      } else {
        console.error(err2)
      }
      //}

      //상태별 일자
      // if(Object.keys(this.statusDateData).length===0) {
      const [res3, err3] = await this.$https.get('/v2/exclusive/work/state-day/'+this.contractNumber)
      if(!err3) {
        console.log('/work/state-day/', res3.data)
        if (res3 && res3.data) {
          this.statusDateData = res3.data
        }
      } else {
        console.error(err3)
      }
      //}

      //서류심사 목록
      // if(Object.keys(this.paperReviewData).length===0) {
      const [res4, err4] = await this.$https.get('/v2/exclusive/work/contract/papers/'+this.contractNumber)
      if(!err4) {

        console.log('/work/contract/papers/', res4.data)
        this.paperReviewData = res4.data.map((el, idx) => {
          el.papersNameList = (el.papersNameList && el.papersNameList.join(', ')) || ''
          el.no = idx+1
          return el
        })
      } else {
        console.error(err4)
      }
      //}

    },
    async getCarTabData() {
      if(!this.contractNumber) return

      this.$refs.CarInfo.getCarInfoData();

      // API-E-업무담당자-019 (차량정보 조회)
      // if(Object.keys(this.carInfoData).length===0) {
      // const [res1, err1] = await this.$https.post('/v2/exclusive/work/car', { contractNumber: this.contractNumber })
      // if(!err1) {
      //   console.log('/work/car/', res1.data)
      //   if(res1.data) {
      //     this.carInfoData = res1.data
      //     let choiceOptionNameAry = [], tuixOptionNameArr = [], tuixOptionTotalPrice = 0

      //     this.carInfoData.choiceOptionInfo && this.carInfoData.choiceOptionInfo.map(el => {
      //       choiceOptionNameAry.push(el.carOptionName)
      //       if(el.carOptionDeailName !== null) {
      //         el.carOptionDeailNameAry = el.carOptionDeailName.split('+')
      //       }
      //     })
      //     this.choiceOptionNames = choiceOptionNameAry.join(', ')

      //     this.carInfoData.tuixOptionInfo && this.carInfoData.tuixOptionInfo.map(el => {
      //       tuixOptionTotalPrice += el.carOptionPrice
      //       tuixOptionNameArr.push(el.carOptionName)
      //       if(el.carOptionDeailName !== null) {
      //         el.carOptionDeailNameAry = el.carOptionDeailName.split('+')
      //       }
      //     })
      //     this.tuixOptionNames = tuixOptionNameArr.join(', ')
      //     this.carInfoData = { ...this.carInfoData, tuixOptionTotalPrice: tuixOptionTotalPrice }

      //     console.log(this.carInfoData)
      //   }
      // } else {
      //   console.error(err1)
      // }
      // }

    },
    getCarProductionNumber(pdNumber) {
      this.carProductionNumber = pdNumber
    },
    async getPaymentTabData() {
      if(!this.contractNumber) return

      // API-E-업무담당자-020 (결제정보 조회)
      // if(Object.keys(this.payInfoData).length===0) {
      const [res1, err1] = await this.$https.post('/v2/exclusive/work/payment', { contractNumber: this.contractNumber })
      if(!err1) {
        console.log('/work/payment/', res1.data)
        this.payInfoData = res1.data
      } else {
        console.error(err1)
      }
      // }

      // API-E-업무담당자-021 (결제금액 조회)
      // if(this.payAmountList.length===0) {
      const [res2, err2] = await this.$https.post('/v2/exclusive/work/payment-amount', { contractNumber: this.contractNumber })
      if(!err2) {
        console.log('/work/payment-amount/', res2.data)
        this.payInfoData.totalPrice = 0
        let totalDiscount = 0, totalPoint = 0, totalDiscountRate = 0, totalPointRate = 0

        this.payAmountList = []
        if(res2.data) {
          this.payAmountList.push({name: '차량금액', content: '', price: (res2.data.carPrice ? res2.data.carPrice.toLocaleString() + '원' : '0원'), pointState: '', background: '', type: ''})
          this.payAmountList.push({name: '탁송료', content: '', price: (res2.data.deliveryPrice ? res2.data.deliveryPrice.toLocaleString() + '원' : '0원'), pointState: '', background: '', type: ''})
          this.payAmountList.push({name: '단기의무보험료', content: '', price: (res2.data.insurancePayment ? res2.data.insurancePayment.toLocaleString() + '원' : '0원'), pointState: '', background: '', type: ''})
          if(res2.data.greenTaxFreePrice) {
            //2020.03.03 친환경면세 => 개소세면세
            this.payAmountList.push({name: '개소세면세', content: '', price: (res2.data.greenTaxFreePrice ? res2.data.greenTaxFreePrice.toLocaleString() + '원' : '0원'), pointState: '', background: '', type: ''})
          }
          //총 할인
          res2.data.discountInfo && res2.data.discountInfo.map((el) => {
            totalDiscount += el.discountPrice
            totalDiscountRate += el.discountRate || 0
          })
          res2.data.pointInfo && res2.data.pointInfo.map((el) => { //총 포인트
            if(el.pointUseStateCode === 'S') { // 처리 완료 상태
              totalPoint += el.usePoint
            }
          })
          if(res2.data.totalTcpRate){
            totalPointRate=res2.data.totalTcpRate
          }

          //총 할인금액 % = 할인금액% + 당사분담금액 포인트%
          totalDiscountRate += totalPointRate || 0

          this.payAmountList.push({name: '총 할인금액', content: '', percent: (totalDiscountRate ? totalDiscountRate.toFixed(1) + '%' : '0%'), price: (totalDiscount.toLocaleString() + '원'), pointState: '', background: 'red', type: ''})

          res2.data.discountInfo && res2.data.discountInfo.map((el, idx, ary) => {
            this.payAmountList.push({name: (idx===0 || el.discountTypeName!==ary[idx-1].discountTypeName  ? el.discountTypeName : ''), content: el.discountContents!==null ? el.discountContents : el.discountName, percent: (el.discountRate ? el.discountRate + '%' : ''), price: (el.discountPrice ? (el.discountPrice.toLocaleString() + '원') : ''), pointState: '', background: '', type: ''})
          })



          this.payAmountList.push({name: '총 포인트 금액', content: '', percent: (totalPointRate ? totalPointRate.toFixed(1) + '%' : '0%'), price: (totalPoint.toLocaleString() + '원'), pointState: '', background: 'red', type: ''})

          res2.data.pointInfo && res2.data.pointInfo.map((el, idx) => {
            let payType = ''
            if(el.pointCode === 'HC' && el.saveAutoPointYn) {
              payType  = 'save-auto' // API-E-결제서비스-027 (세이브오토 취소 처리)
            } else if(el.pointCode === 'HC' && !el.saveAutoPointYn) {
              payType  = 'm-point' // API-E-결제서비스-025 (M포인트 취소 처리)
            } else if(el.pointCode === 'OH') {
              payType  = 'blue-point' // API-E-결제서비스-026 (블루멤버스 포인트 취소 처리)
            }

            this.payAmountList.push({name: (idx===0  ? '포인트' : ''), content: el.pointName || '', price: (el.usePoint ? (el.usePoint.toLocaleString() + '원') : ''), pointState: el.pointUseState || '', background: '', type: 'button', payType: payType, useCompleteYn: el.useCompleteYn, customerManagementNumber: el.customerManagementNumber })
          })

          this.payInfoData.totalPoint = totalPoint || 0
          this.payInfoData.totalPrice = (res2.data.carPrice || 0) + (res2.data.deliveryPrice || 0) + (res2.data.insurancePayment || 0) - totalDiscount - totalPoint - (res2.data.greenTaxFreePrice || 0)
          this.payInfoData.totalPrice4Mypage = (res2.data.carPrice || 0) + (res2.data.deliveryPrice || 0) + (res2.data.insurancePayment || 0) - totalDiscount - (res2.data.greenTaxFreePrice || 0)
        }
      } else {
        console.error(err2)
      }
      // }

      // API-E-업무담당자-022 (결제내역 상세조회)
      // if(Object.keys(this.payDetail).length===0) {
      const [res3, err3] = await this.$https.post('/v2/exclusive/work/payment-details', { contractNumber: this.contractNumber })
      if(!err3) {
        console.log('/work/payment/', res3.data)
        res3.data.installmentInfo && res3.data.installmentInfo.map(el => {
          el.advancePayment = el.advancePayment ? el.advancePayment.toLocaleString()+'원' : '-'
          el.installmentPrincipal = el.installmentPrincipal ? el.installmentPrincipal.toLocaleString()+'원' : '-'
          el.monthlyPaymentTotal = el.monthlyPaymentTotal ? el.monthlyPaymentTotal.toLocaleString()+'원' : '-'
        })
        res3.data.cardInfo && res3.data.cardInfo.map(el => {
          el.cardPaymentPrice = el.cardPaymentPrice ? el.cardPaymentPrice.toLocaleString()+'원' : '-'
        })

        res3.data.paymentInfo && res3.data.paymentInfo.map(el => {
          let payType = ''
          if(el.paymentTypeCode === '20') {
            payType  = 'card' // API-E-결제서비스-023 (카드 취소 처리)
          } else if(el.paymentTypeCode === '10') {
            payType  = 'installment' // API-E-결제서비스-024 (할부 취소 처리)
          } else if(el.paymentTypeCode === '30') {
            payType  = 'cash' // cash 현금은 별도 처리 방식
          }
          el.payType = payType
        })

        res3.data.additionPaymentInfo && res3.data.additionPaymentInfo.map(el => {
          let payType = ''
          if(el.paymentTypeCode === '20') {
            payType  = 'card' // API-E-결제서비스-023 (카드 취소 처리)
          } else if(el.paymentTypeCode === '10') {
            payType  = 'installment' // API-E-결제서비스-024 (할부 취소 처리)
          } else if(el.paymentTypeCode === '30') {
            payType  = 'cash' // cash 현금은 별도 처리 방식
          }
          el.payType = payType
        })

        this.payDetail = res3.data

        const { blueMembersRate, blueMembersPrearrangementPoint, blueMembersPoint, blueMembersContents } = res3.data
        this.payDetail.blueInfo = [ { blueMembersRate : (blueMembersRate ? Number(blueMembersRate).toFixed(1) : '-'), blueMembersPrearrangementPoint : blueMembersPrearrangementPoint ? Number(blueMembersPrearrangementPoint).toLocaleString() : '-', blueMembersPoint : blueMembersPoint ? Number(blueMembersPoint).toLocaleString() : '-', blueMembersContents } ]
      } else {
        console.error(err3)
      }
      // }

    },
    async getReleaseTabData() {
      if(!this.contractNumber) return

      //출고정보
      // if(Object.keys(this.releaseInfoData).length===0) {
      const [res1, err1] = await this.$https.get('/v2/exclusive/work/delivery/'+this.contractNumber)
      if(!err1) {
        console.log('/work/delivery/', res1.data)
        this.releaseInfoData = res1.data
      } else {
        console.error(err1)
      }
      // }

      //출고센터진행정보
      // if(Object.keys(this.releaseCenterData).length===0) {
      const [res2, err2] = await this.$https.get('/v2/exclusive/work/delivery-state/'+this.contractNumber)
      if(!err2) {
        console.log('/work/delivery-state/', res2.data)
        this.releaseCenterData = res2.data
      } else {
        console.error(err2)
      }
      // }

      // API-E-업무담당자-032 (인수정보 조회)
      // if(Object.keys(this.releaseTakeoverData).length===0) {
      const [res3, err3] = await this.$https.post('/v2/exclusive/work/take-over', { contractNumber: this.contractNumber })
      if(!err3) {
        console.log('/work/take-over/', res3.data)
        this.releaseTakeoverData = res3.data
      } else {
        console.error(err3)
      }
      // }

      //탁송정보
      // if(Object.keys(this.releaseConsignData).length===0) {
      const [res4, err4] = await this.$https.get('/v2/exclusive/work/consign/'+this.contractNumber)
      if(!err4) {
        console.log('/work/consign/', res4.data)
        this.releaseConsignData = res4.data
      } else {
        console.error(err4)
      }
      // }

      //등록대행정보 조회 (API-E-전담컨설턴트-034)
      // if(Object.keys(this.releaseRegistAgencyData) && Object.keys(this.releaseRegistAgencyData).length===0) {
      const [res5, err5] = await this.$https.get('/v2/exclusive/work/regist-agency/'+this.contractNumber)
      if(!err5) {
        this.releaseRegistAgencyData = res5.data
      } else {
        console.error(err5)
      }
      // }

    },
    async getStatusTabData() {
      if(!this.contractNumber) return

      //API-WE-업무담당자-035 (판매처리이력 조회)
      this.$refs.StatusHistory.getSaleHistory();

      //API-WE-업무담당자-036 (매출변경이력 조회)
      this.$refs.StatusHistory.getSalesHistory();

      //API-WE-업무담당자-037 (결제변경이력 조회)
      this.$refs.StatusHistory.getPaymentHistory();

      // API-WE-업무담당자-129 (포인트신청이력 조회)
      this.$refs.StatusHistory.getPointHistory();

      //API-WE-업무담당자-038 (업무담당자처리이력 조회)
      this.$refs.StatusHistory.getConsultantHistory();
      
      //API-WE-업무담당자-040 (서류심사이력 조회)
      this.$refs.StatusHistory.getPaperHistory();
      
      //API-WE-업무담당자-041 (전자서명이력 조회)
      this.$refs.StatusHistory.getSignHistory();
      
      //API-WE-업무담당자-133 (국판 호출 로그 이력 조회)
      this.$refs.StatusHistory.getApiHistory();      

      //API-WE-업무담당자-147 (계약 변경 이력 조회)
      this.$refs.StatusHistory.getChangeHistory();


      // 상태이력 화면 컴포넌트화로 인한 주석처리 <A936507>
      //API-E-업무담당자-035 (판매처리이력 조회)
      // if(this.statusTabData.sale.length===0) {
      // const [res1, err1] = await this.$https.post('/v2/exclusive/work/history/sale', { contractNumber: this.contractNumber })
      // if(!err1) {
      //   console.log('/work/history/sale/', res1.data)
      //   this.statusTabData.sale = res1.data.map((el) => {
      //     return {
      //       ...el,
      //       deliveryPrearrangedDate: el.deliveryPrearrangedDate ? moment(el.deliveryPrearrangedDate).format('YYYY-MM-DD') : '',          }
      //   })
      // } else {
      //   console.error(err1)
      // }
      // }

      //API-E-업무담당자-036 (매출변경이력 조회)
      // if(this.statusTabData.sales.length===0) {
      // const [res2, err2] = await this.$https.get('/v2/exclusive/work/history/sales/' + this.contractNumber)
      // if(!err2) {
      //   console.log('/work/history/sales/', res2.data)
      //   this.statusTabData.sales = res2.data.map((el) => {
      //     return {
      //       ...el,
      //       carPrice: el.carPrice && (el.carPrice*1).toLocaleString()+' 원',
      //       discountPrice: el.discountPrice && (el.discountPrice*1).toLocaleString()+' 원',
      //       usePoint: el.usePoint && (el.usePoint*1).toLocaleString(),
      //       salePrice: el.salePrice && (el.salePrice*1).toLocaleString()+' 원',
      //       contractPrice: el.contractPrice && (el.contractPrice*1).toLocaleString()+' 원',
      //       installmentPrincipal: el.installmentPrincipal && (el.installmentPrincipal*1).toLocaleString()+' 원',
      //       cardPaymentPrice: el.cardPaymentPrice && (el.cardPaymentPrice*1).toLocaleString()+' 원',
      //       tax: el.tax && (el.tax*1).toLocaleString()+' 원',
      //     }
      //   })
      // } else {
      //   console.error(err2)
      // }
      // }

      //API-E-업무담당자-037 (결제변경이력 조회)
      // if(this.statusTabData.payment.length===0) {
      // const [res3, err3] = await this.$https.post('/v2/exclusive/work/history/payment', { contractNumber: this.contractNumber })
      // if(!err3) {
      //   console.log('/work/history/payment/', res3.data)
      //   this.statusTabData.payment = res3.data.map((el) => {
      //     return {
      //       ...el,
      //       paymentPrice: el.paymentPrice ? (el.paymentPrice*1).toLocaleString()+'원' : '',
      //       paymentContents: el.paymentTypeCode !== '30' ? el.paymentContents : (el.virtualAccount ? el.paymentContents + '\n - 계좌번호: ' + el.virtualAccount : el.paymentContents),
      //       refundPrice: el.refundPrice ? (el.refundPrice*1).toLocaleString()+'원' : ''
      //     }
      //   })
      // } else {
      //   console.error(err3)
      // }

      // API-E-업무담당자-129 (포인트신청이력 조회)
      // const [res4, err4] = await this.$https.post('/v2/exclusive/work/history/point', { contractNumber: this.contractNumber })
      // if(!err4) {
      //   console.log('/work/history/point/', res4.data)
      //   this.statusTabData.point = res4.data.map((items, idx) => {
      //     return {
      //       ...items,
      //       no: idx + 1,
      //       pointUsePrice: items.pointUsePrice.toLocaleString() + '원', // 포인트 사용금액
      //       partnerAssignmentPrice: items.partnerAssignmentPrice.toLocaleString() + '원', // 제휴사분담금액
      //       companyAssignmentPrice: items.companyAssignmentPrice.toLocaleString() + '원' // 당사분담금액
      //     }
      //   })
      // } else {
      //   console.error(err4)
      // }

      //API-E-업무담당자-038 (업무담당자처리이력 조회)
      // if(this.statusTabData.consultant.length===0) {
      // const [res5, err5] = await this.$https.get('/v2/exclusive/work/history/consultant/'+this.contractNumber)
      // if(!err5) {
      //   console.log('/work/history/consultant/', res5.data)
      //   this.statusTabData.consultant = res5.data
      // } else {
      //   console.error(err5)
      // }
      // }

      //API-E-업무담당자-040 (서류심사이력 조회)
      // if(this.statusTabData.papers.length===0) {
      // const [res6, err6] = await this.$https.get('/v2/exclusive/work/history/papers/'+this.contractNumber)
      // if(!err6) {
      //   console.log('/work/history/papers/', res6.data)
      //   this.statusTabData.papers = res6.data.map((el, idx) => {
      //     return {
      //       ...el,
      //       no : idx+1,
      //       papersNameListStr : el.papersNameList.join(', ')
      //     }
      //   })
      // } else {
      //   console.error(err6)
      // }
      // }

      //API-E-업무담당자-041 (전자서명이력 조회)
      // if(this.statusTabData.electron.length===0) {
      // const [res7, err7] = await this.$https.get('/v2/exclusive/work/history/electron/'+this.contractNumber)
      // if(!err7) {
      //   console.log('/work/history/electron/', res7.data)
      //   this.statusTabData.electron = res7.data
      // } else {
      //   console.error(err7)
      // }
      // }

      //API-E-업무담당자-133 (국판 호출 로그 이력 조회)
      // if(this.statusTabData.apiLog.length===0) {
      // const [res8, err8] = await this.$https.get('/v2/exclusive/work/history/apilog/'+this.contractNumber)
      // if(!err8) {
      //   // console.log('/work/history/apilog/', res8.data)
      //   this.statusTabData.apiLog = res8.data && res8.data.map((el, idx) => {
      //     return {
      //       ...el,
      //       no : res8.data.length - idx,
      //       siteConnectTime: el.siteConnectTime? el.siteConnectTime.split('.')[0]:null
      //     }
      //   })

      //   console.log('/work/history/apilog/', this.statusTabData.apiLog)
      // } else {
      //   console.error(err8)
      // }
      // }
    },
    async getMessageTabData() {
      if(!this.contractNumber) return

      this.$refs.SmsHistory.getSmsHistoryData()

      //API-E-업무담당자-042 (문자발송목록 조회)
      // if(this.messageTabData.length===0) {
      // const [res, err] = await this.$https.post('/v2/exclusive/work/history/sms', { contractNumber: this.contractNumber, pageNo : '1', pageSize: '100' })
      // if(!err) {
      //   console.log('/work/history/sms/', res.data)
      //   this.messageTabData = res.data.list && res.data.list.map((el, idx) => {
      //     return {
      //       ...el,
      //       no : idx+1,
      //     }
      //   })
      // } else {
      //   console.error(err)
      // }
      // }

    },
    closeActivatePayPop() { // 결제항목 활성화 팝업 닫을시 데이터 초기화
      this.activationlist = [] // init
    },
    closeRequestPop() { // 추가서류요청 팝업 닫을시 데이터 초기화
      this.selRequestDoc = [], this.documentList = [], this.requestDocList = [], this.checkedDocList = [], this.needPapersSubject = '' // init
    },
    onActRowAdd() { // 결제기능 활성화 목록 추가
      // addStlRqScnCd 추가결제요청구분코드(T019 - 01: 추가결제, 02: 결제취소)
      const { contractNumber: saleCnttNo, employeeId: rqEeno } = this.info // 판매계약번호, 요청사원번호
      this.activationlist.push({ rowNum: this.addKeyActPayIdx++, saleCnttNo, rqEeno, addStlRqScnCd: '01', date: moment().format('YYYY-MM-DD HH:mm') }) // addRow
    },
    onActRowDelete(key) {
      const idx = this.activationlist.findIndex((item) => item.rowNum === key)
      if (idx > -1) this.activationlist.splice(idx, 1) // 일치하는 row 삭제
    },
    async activationSend() { // 결제항목 활성화
      let sucCnt = 0 // 활성화 카운팅
      this.activationlist.map(async (items) => {
        const params = { ...items, rltdStlNos: items.rowNum }
        console.log(params)
        if(params.addStlRqTypeCd && params.stlRqAmt) { // 추가한 결제항목 활성화 목록중에서 항목, 결제대상금액을 입력한 row만 활성화 처리
          const [res, err] = await this.$https.get('payment/v2/payment/provision/activation', params, null, 'gateway') // API-E-결제서비스-019 (결제항목 활성화 처리)

          if(!err) {
            console.log(res)
            sucCnt++
            if(this.activationlist.length === sucCnt) {
              this.popVisibleActivatePay = false
              this.alertMessage = '고객님, 추가 결제 안내가 전송되었습니다.\n마이페이지에서 확인요청 드립니다.'
              this.alertMessagePop = true
            }
          } else {
            console.error(err)
          }
        }
      })
    },
    async getDocList($event, items) { // 서류 심사 목록
      // class all delete and self add
      Array.from($event.target.parentElement.children).map((items) => { items.classList.remove('is-chlick') })
      $event.target.classList.add('is-chlick')

      const { neceDocTargNo = '', neceDocTargNm = '' } = items
      if(!neceDocTargNo) {
        this.alertMessage = '서류목록을 확인해주세요.'
        this.alertMessagePop = true
        return false
      }
      const [res, err] = await this.$https.get('/v2/exclusive/contract/papers', { neceDocTargNo: neceDocTargNo }) //API-E-업무담당자-047 (필요서류목록 조회)
      if (!err) {
        console.log(res)
        this.documentList = res.data

        this.checkedDocList = [] // init list
        this.documentList.map((items, idx) => { // init checkYN
          items.neceDocTargNo = neceDocTargNo
          items.neceDocTargNm = neceDocTargNm
          this.checkedDocList[idx] = false
        })

        this.selNeceDocInfo = items // 선택한 필요서류대상
      }
    },
    addDocList() { // 추가서류요청 팝업 - 추가 버튼
      let addList = this.documentList.filter((items, idx) => {
        //items.
        return this.checkedDocList[idx] ? items : null
      })
      if(addList.length > 0) { // 체크한 서류 목록이 있을 경우

        this.requestDocList.map((items) => {
          addList.map((items2, idx) => { // 요청 서류 중복 제거
            // 필요서류대상번호, 필요서류번호가 모두 일치할 경우 추가하려는 서류목록에서 삭제
            if(items.neceDocTargNo === items2.neceDocTargNo && items.neceDocNo === items2.neceDocNo) {
              addList.splice(idx, 1)
            }
          })
        })

        if(addList.length > 0) { // 서류 중복 데이터 제거 후 남은 서류 목록이 있는지 다시 확인
          this.selRequestDoc = [] // 요청 서류 목록이 변경되므로 기존 선택되어있던 목록도 초기화
          this.requestDocList = [ ...this.requestDocList, ...addList ]
        } else {
          this.alertMessage = '요청서류에 등록되어 있습니다.'
          this.alertMessagePop = true
        }
      } else {
        this.alertMessage = '서류목록을 선택해주세요.'
        this.alertMessagePop = true
        return false
      }
    },
    delDocList() { // 추가서류요청 팝업 - 삭제 버튼
      if(this.selRequestDoc.length > 0) { // 삭제하려는 서류 목록이 있을경우
        this.selRequestDoc.map((items) => {
          this.requestDocList.map((items2, idx) => { // 요청 서류 제거
            // 필요서류대상번호, 필요서류번호가 모두 일치할 경우 추가하려는 서류목록에서 삭제
            if(items.neceDocTargNo === items2.neceDocTargNo && items.neceDocNo === items2.neceDocNo) {
              this.requestDocList.splice(idx, 1)
            }
          })
        })
      }
    },
    selRequestDocList(data) { // 요청서류 - 선택한 서류 목록
      this.selRequestDoc = data
    },
    async docSend() { // 추가서류요청 팝업 - 고객전송 버튼
      const { eeno: customerNumber } = this.userInfo // 세션사원번호
      const { contractNumber: saleContractNumber } = this.info // 계약번호
      const needPapersSubject = this.needPapersSubject // 추가요청내용
      const contractInfo = this.contractData.contractorInfo.filter((items) => { return items.contractorTypeCode === '01' }) // 주계약자 정보

      const { customerManagementNumber: customerManageNumber } = contractInfo[0]

      const paramList = this.requestDocList.map((items) => {
        const { neceDocTargNo: needPapersSubjectNumber = '', neceDocNo: needPapersNumber = '' } = items
        return { needPapersSubjectNumber, needPapersNumber, customerNumber, needPapersSubject, saleContractNumber, customerManageNumber }
      })

      if(paramList.length > 0) {
        console.log(paramList)
        const [res, err] = await this.$https.post('/v2/exclusive/contract/addition-papers', paramList) // API-E-업무담당자-048 (추가서류요청 저장)

        if(!err) {
          console.log(res)
          this.alertMessage = '서류가 추가되었습니다.'
          this.alertMessagePop = true
          this.getStatusTabData()
        } else {
          console.error(err)
        }

        this.popVisibleRequestPaper = false // 팝업 닫기
      } else {
        this.alertMessage = '서류를 추가해주세요.'
        this.alertMessagePop = true
      }
    },
    initRuleFormPop() { // 초기화 버튼
      Object.assign(this.$data.ruleFormpopup, this.$options.data().ruleFormpopup)
    },
    async canclePay() { // 해약 팝업 - 계약취소
      const contractNumber = this.contractNumber
      const body = { contractNumber }
      const [res, err] = await this.$https.post('/v2/exclusive/contract/cancel', body) // API-E-업무담당자-126 (차량계약 상태변경 - 계약취소(고객), 계약취소(환불대기))

      if(!err) {
        if(res.rspStatus && res.rspStatus.rspCode === '0000') {
          this.alertMessage = res.data.resultMessage || '시스템 오류 입니다.\n관리자에게 문의하세요.'
          this.alertMessagePop = true
        }
        this.getInfoData() // refresh
        this.getContractTabData() // 계약정보 탭 refresh
        this.getStatusTabData() // 상태이력 탭 refresh
      } else {
        this.alertMessage = err.rspMessage || '시스템 오류 입니다.\n관리자에게 문의하세요.'
        this.alertMessagePop = true
      }
      this.alertVisibleCancelPayAsk = false
      // this.alertVisibleCancelPayConfirm = true
    },
    async sendSms() {
      let customersInfo = []
      const contractorInfo = this.contractData && this.contractData.contractorInfo
      const targetContractorInfo = contractorInfo && contractorInfo.filter((items) => {
        return this.contractorNames.includes(items.customerName)
      })

      targetContractorInfo.map((items) => {
        customersInfo.push({
          sendChannelCode: '003', // 발송경로 구분 코드 - 업무담당자
          saleContractNo: this.contractNumber || '', // 판매계약번호
          customerMgmtNo: items.customerManagementNumber || '', // 고객관리번호
          customerUniqueNo: this.userInfo.eeno || '', // 고객고유번호
          messageTitle: this.ruleFormpopup.title, // 제목
          messageContents: this.ruleFormpopup.text, // 내용
          receiverTel: items.customerMobile, // 수신자전화번호
          receiverName: items.customerName // 수신자명
        })
      })

      const [result1, result2] = await Promise.all(
        customersInfo.map((items) => {
          return this.$https.post('/v2/exclusive/common/sms-send', items) // API-E-공통서비스-023 (문자 보내기)
        })
      )

      // 1명의 계약자에게만 발송하는 경우
      if (!result2) {
        const [res1, err1] = result1
        if (!err1) {
          if(res1.rspStatus && res1.rspStatus.rspCode === '0000') {
            // this.popVisible05 = false // 팝업 닫기
            this.alertMessage = '문자가 전송되었습니다.'
            this.alertMessagePop = true
          }
        }
      }

      // 주계약자 및 공동명의자 모두 발송하는 경우
      if (result1 && result2) {
        const [res1, err1] = result1
        const [res2, err2] = result2

        // 모두 전송되었을 경우
        if (!err1 && !err2) {
          if(res1.rspStatus && res1.rspStatus.rspCode === '0000' &&
            res2.rspStatus && res2.rspStatus.rspCode === '0000') {
            // this.popVisible05 = false // 팝업 닫기
            this.alertMessage = '문자가 전송되었습니다.'
            this.alertMessagePop = true
          }
        }
      }
      this.getMessageTabData() // reload
      this.popVisibleSMS = false // 팝업 닫기
    },
    openPopSms() { // 문자보내기 팝업 노출
      // ※ 출고일 장기 경과 데이터 이관으로 고객정보 부재가 발생하는 케이스가 생김.
      // 고객 데이터에 따른 안내팝업 처리
      // 고객관리번호는 필수값이 아니라 체크안함. 고객정보의 수신자 전화번호와 수신자명은 필수값 임으로 체크
      let customerMobile = '', customerName = ''

      if (this.contractData && this.contractData.contractorInfo[0]) {
        ({ customerMobile, customerName } = this.contractData.contractorInfo[0])
      }

      if (!customerMobile || !customerName) { // 고객정보가 없을 경우
        this.alertMessage = '출고일 장기 경과건으로 고객 데이터가 없습니다.\n데이터 복원후 진행해주세요.'
        this.alertMessagePop = true
      } else {
        this.popVisibleSMS = true
        Object.assign(this.ruleFormpopup, this.$options.data().ruleFormpopup)
      }
    },
    onRefresh(flag, tab) {
      if(flag) {
        switch(tab) {
        case 'contract':
          this.getContractTabData()
          break
        case 'car':
          this.getCarTabData()
          break
        case 'pay':
          this.getPaymentTabData()  // 결제정보탭 reload
          break
        case 'release':
          this.getReleaseTabData()
          break
        case 'status':
          this.getStatusTabData()
          break
        case 'sms':
          this.getMessageTabData()
          break
        }
      }
    },
    showBtnCarMakeCertification() {
      const { carMakeCertificateIssueYn } = this.contractData // 계약정보
      const { makeDocumentIssueDate } = this.statusDateData // 상태별일자 정보
      const isCertificationRequestValidDate = moment().isSameOrBefore(moment(makeDocumentIssueDate, 'YYYYMMDD').add(14, 'days')) // 제작증 발급 요청일시에 대한 발급가능 여부에 대한 유효성 여부

      //자동차제작증 재출력 / 자동차제작증 발급
      const flag = carMakeCertificateIssueYn === 'Y' ? isCertificationRequestValidDate : true

      // 0600: 차량 인수 완료 (직접인수), 0610: 차량 인수 완료(배달탁송), 0710: 차량 구매 완료, 0800: 차량 구매 완료(미신고) , 0810: 차량 구매 완료(미신고)
      const statusCheck = ['0600', '0610', '0710', '0800', '0810'].includes(this.onlineContractState)
      //
      return (statusCheck && flag)
    },
    async issueCarCertification() { // 제작증 발급 action
    //자동차제작증 발급
      if (this.$mq === 'mobile') {
        this.alertMessage = '제작증은 PC에서만 출력 가능합니다.'
        this.alertMessagePop = true
        return
      }


      this.getContractTabData().then(async () => { // 재조회 후 호출
        let canOpenOZReport = false // ozReport open YN
        const carProductionNumber = this.carProductionNumber // 차량정보
        //const { carProductionNumber } = this.carInfoData
        const { carMakeCertificateIssueYn } = this.contractData // 계약정보
        const { contractNumber } = this.info // 계약출고상세 정보
        const { makeDocumentIssueDate } = this.statusDateData // 상태별일자 정보

        this.isCertificationRequestValidDate = moment().isSameOrBefore(moment(makeDocumentIssueDate, 'YYYYMMDD HH:mm').add(14, 'days')) // 제작증 발급 요청일시에 대한 발급가능 여부에 대한 유효성 여부
        if(carMakeCertificateIssueYn !== 'Y') { // 최초 발급하는 경우
          const params = { contractNumber, carProductionNumber }
          //API-E-구매서비스-047 (자동차제작증 발급 사전체크)
          let [res, err] = await this.$https.get('/purchase/v2/purchase/proof-document/car-document/check', params, null, 'gateway')
          console.log(res)
          if(!err) {
            if(res.data && res.data.checkValue === '00000') { // 발급 가능할경우
              const params2 = { contractNumber, issueBranchNumber: contractNumber.substring(0, 3) }
              //API-E-구매서비스-017 (자동차 제작증 발급)
              const [res2, err2] = await this.$https.get('/purchase/v2/purchase/proof-document/car-document/issue', params2, null, 'gateway')

              if(!err2) {
                if (res2.data.resultValue === 'COMPLETE') {
                  // const params3 = { contractNumber }
                  // //API-E-구매서비스-068 (수입인지 발행 조회)
                  // // eslint-disable-next-line no-unused-vars
                  // const [res3, err3] = await this.$https.get('/purchase/v2/purchase/proof-document/revenue-stamp/issue', params3, null, 'gateway')
                  //
                  // if (!err3) {
                  canOpenOZReport = true
                  // } else {
                  //   this.alertMessage = '수입인지가 발행되지 않았습니다.'
                  //   this.alertMessagePop = true
                  // }
                } else {
                  this.alertMessage = `제작증 발급이 거부되었습니다.${res2.rspStatus ? '(' + res2.rspStatus.rspCode + ')' : ''}`
                  this.alertMessagePop = true
                }
              }
            } else {
              this.alertMessage = `지금은 제작증 발급이 불가능합니다.(${res.data && res.data.checkValue})`
              this.alertMessagePop = true
            }
          }
        } else if (carMakeCertificateIssueYn === 'Y' && this.isCertificationRequestValidDate) {
          canOpenOZReport = true //발급일로부터 14일이내 재출력 가능
        } else {
          this.alertMessage = '발급 가능일이 경과되었습니다.\n(차량제작증발급일 + 14Day (최초발급일 포함 15일))'
          this.alertMessagePop = true
        }

        //오즈레포트 호출
        if (canOpenOZReport) {
          // API-E-구매서비스-005(자동차 제작증 정보 조회)
          const params = { contractNumber }
          const params2 = { saleCnttNo: contractNumber }
          const [resR1, errR1] = await this.$https.get('/purchase/v2/purchase/proof-document/car-document', params, null, 'gateway')
          if (!errR1) {
            if (resR1 && resR1.data && resR1.data.salecnttno && resR1.data.salecnttno.length > 0) {
              // eslint-disable-next-line no-unused-vars
              Object.entries(resR1.data).forEach(([k, v]) => {
                if (v === null) resR1.data.k = ''
              })
              sessionStorage.setItem('formDataCarCertificate', JSON.stringify(resR1))
            } else {
              sessionStorage.removeItem('formDataCarCertificate')
            }
          } else {
            sessionStorage.removeItem('formDataCarCertificate')
          }
          // API-E-구매서비스-020(저공해차 증명서 조회)
          const [resR2, errR2] = await this.$https.get('/purchase/v2/purchase/proof-document/low-pollution-car', params2, null, 'gateway')
          if (!errR2) {
            if (resR2 && resR2.data && resR2.data.carDesignation && resR2.data.carDesignation.length > 0) {
              // eslint-disable-next-line no-unused-vars
              Object.entries(resR2.data).forEach(([k, v]) => {
                if (v === null) resR2.data.k = ''
              })
              sessionStorage.setItem('formDataLowPollutionCar', JSON.stringify(resR2))
            } else {
              sessionStorage.removeItem('formDataLowPollutionCar')
            }
          } else {
            sessionStorage.removeItem('formDataLowPollutionCar')
          }
          // API-E-구매서비스-027(영수증 정보 조회)
          const [resR3, errR3] = await this.$https.get('/purchase/v2/purchase/proof-document/car/receipts-voucher', params2, null, 'gateway')
          if (!errR3) {
            if (resR3 && resR3.data && resR3.data.taxinvoiceNumber && resR3.data.taxinvoiceNumber.length > 0) {
              // eslint-disable-next-line no-unused-vars
              Object.entries(resR3.data).forEach(([k, v]) => {
                if (v === null) resR3.data.k = ''
              })
              sessionStorage.setItem('formDataCarReceiptsVoucher', JSON.stringify(resR3))
            } else {
              sessionStorage.removeItem('formDataCarReceiptsVoucher')
            }
          } else {
            sessionStorage.removeItem('formDataCarReceiptsVoucher')
          }
          setTimeout(() => {
            const win = window.open('/report/carProductionCertificate/index.html', '_blank')
            win.focus()
          }, 200)

          //API-E-구매서비스-096 (차량 구매 완료 처리) - 양지수
          // 자동차제작증 발급 완료 -> 자동차 구매 완료 (상태코드 UPDATE!)
          const [resR4, errR4] = await this.$https.post('/purchase/v2/purchase/proof-document/car-document/complete', params, null,'gateway' )
        }
      })

      // this.$nuxt.$loading.finish()
    },
    async doPaymentInit(){
      const [res, err] = await this.$https.post('purchase/v2/purchase/contract/contract-info/payment-init/' + this.contractNumber, null, null, 'gateway')

      if(!err) {
        console.log(res)
        if(res.rspStatus && res.rspStatus.rspCode === '0000') {
          this.alertMessage = '결제 초기화되었습니다.'
          this.alertMessagePop = true
          this.getInfoData()
        }
      } else {
        console.error(err)
      }
      this.checkPaymentInitPop=false
    },
    contractorHpTns() {
      const contractorInfo = this.contractData && this.contractData.contractorInfo
      const targetContractorInfo = contractorInfo && contractorInfo.filter((items) => {
        return this.contractorNames.includes(items.customerName)
      })
      return targetContractorInfo && targetContractorInfo.map((items) => { return items.customerMobile + (items.contractorTypeName ? ('(' + items.contractorTypeName + ')') : '') }).join(', ')
    }
  }
}
</script>
<style lang="scss" scoped>
/deep/.el-icon-info {
  font-size: 34px;
  color: #002b5e;
  padding-bottom: 10px;
}
@import '~/assets/style/pages/detail.scss';

</style>
