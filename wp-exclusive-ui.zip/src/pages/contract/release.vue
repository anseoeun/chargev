<template>
  <section>
    <div id="release">
      <div class="btn-wrap">
        <div class="side">
          <el-button
            type="info"
            @click="resetSearchCond"
          >
            초기화
          </el-button>
        </div>
        <div class="main">
          <el-button
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            @click="onSearch(1)"
          >
            조회
          </el-button>
          <el-button
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            class="excel"
            @click="downloadExcel"
          >
            Excel 다운로드
          </el-button>
        </div>
      </div>
      <div class="board-wrap">
        <el-form
          ref="ruleForm"
          :model="ruleForm"
          class="detail-form table-wrap"
        >
          <el-row>
            <el-col :span="24">
              <el-form-item
                label="구분"
                prop="searchDateType"
                required
                align=""
              >
                <el-select
                  v-model="ruleForm.searchDateType"
                >
                  <el-option
                    v-for="{ value, label } in commonCodes.U019 && commonCodes.U019.slice(1, commonCodes.U019.length)"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
                <el-date-picker
                  v-model="ruleForm.searchFromDt"
                  type="date"
                  :clearable="false"
                  style="margin-left: 10px;"
                />
                <span
                  class="ex-txt"
                  style="margin:0 10px;"
                >~</span>
                <el-date-picker
                  v-model="ruleForm.searchEndDt"
                  type="date"
                  :clearable="false"
                />
                <el-radio-group
                  v-model="searchDtRadio"
                  class="tabBtn-case01"
                  @change="onChangeSearchDtRadio"
                >
                  <el-radio-button label="lastDay">
                    전일
                  </el-radio-button>
                  <el-radio-button label="today">
                    오늘
                  </el-radio-button>
                  <el-radio-button label="day7">
                    7일
                  </el-radio-button>
                  <el-radio-button label="day30">
                    30일
                  </el-radio-button>
                  <el-radio-button label="month3">
                    3개월
                  </el-radio-button>
                  <el-radio-button label="month6">
                    6개월
                  </el-radio-button>
                  <el-radio-button label="month12">
                    1년
                  </el-radio-button>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item
                label="임직원몰 진행상태"
                prop="onlineStatus"
              >
                <el-select
                  v-model="ruleForm.onlineStatus"
                  multiple
                  collapse-tags
                  placeholder="전체"
                  @change="onChangeMultiSelect($event,'online')"
                >
                  <!-- commonCodes.T010 -->
                  <el-option
                    v-for="{ value, label } in commonCodes.T010 && commonCodes.T010.slice(1)"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
                <el-checkbox
                  v-model="onlineSelectedVal"
                  style="margin-left: 8px;"
                  @change="selectedAll($event,'online')"
                >
                  전체
                </el-checkbox>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item
                label="레거시 진행상태"
                prop="legacyStatus"
              >
                <el-select
                  v-model="ruleForm.legacyStatus"
                  multiple
                  collapse-tags
                  placeholder="전체"
                  @change="onChangeMultiSelect($event,'legacy')"
                >
                  <el-option
                    v-for="{ value, label } in LegacyCommonCodes.C013 && LegacyCommonCodes.C013.slice(1)"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
                <el-checkbox
                  v-model="legacySelectedVal"
                  style="margin-left: 8px;"
                  @change="selectedAll($event,'legacy')"
                >
                  전체
                </el-checkbox>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item
                label="업무담당자"
                prop="consultantId"
              >
                <el-select
                  v-model="ruleForm.consultantId"
                  placeholder="전체"
                  multiple
                  collapse-tags
                  @change="onChangeMultiSelect($event,'consultant')"
                >
                  <el-option
                    v-for="{ sysUserNo, sysUserNm } in consultants && consultants.slice(1)"
                    :key="sysUserNo"
                    :value="sysUserNo"
                    :label="sysUserNm"
                  />
                </el-select>
                <el-checkbox
                  v-model="consultantSelectedVal"
                  style="margin-left: 8px;"
                  @change="selectedAll($event,'consultant')"
                >
                  전체
                </el-checkbox>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item
                label="계약번호"
                prop="contractId"
              >
                <el-input
                  v-model="ruleForm.contractId"
                  @keydown.native.tab="onAddZero(ruleForm.contractId)"
                  @keyup.native.enter="getData"
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item
                label="계약자명"
                prop="contractEmployeeName"
              >
                <el-input
                  v-model="ruleForm.contractEmployeeName"
                  @blur="ruleForm.contractEmployeeName = $event.target.value"
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item
                label="계약자 사번"
                prop="contractEmployeeId"
              >
                <el-input v-model="ruleForm.contractEmployeeId" />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item
                label="차종"
                prop="carTypeCode"
              >
                <el-select
                  v-model="ruleForm.carTypeCode"
                  placeholder="전체"
                  @change="onChangeTypeCars"
                >
                  <el-option
                    v-for="{ carTypeCode, carTypeName } in carTypes"
                    :key="carTypeCode"
                    :value="carTypeCode"
                    :label="carTypeName"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="16">
              <el-form-item
                label="차명"
                prop="carCode"
              >
                <el-select
                  v-model="ruleForm.carCode"
                  placeholder="전체"
                >
                  <el-option
                    v-for="{ repnCarCode, repnCarName } in selTypeCars"
                    :key="repnCarCode"
                    :value="repnCarCode"
                    :label="repnCarName"
                  />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <article class="article">
        <div class="article-title title01">
          <!-- TODO: 다중선택으로 변경시 주석해제 -->
          <!-- <el-checkbox
            v-model="checked"
            label="전체선택"
            @change="toggleSelectionAll"
          /> -->
          <el-button
            v-if="isValidAuthBtn('authExclusive')"
            type="primary"
            @click="changeReleaseDate"
          >
            출고예정일 변경
          </el-button>

          <el-button
            v-if="isValidAuthBtn('authExclusive')"
            type="primary"
            @click="changePaymentDate"
          >
            결제기한일 연기
          </el-button>
        </div>
        <el-table
          :data="tableData"
          style="width: 100%"
          empty-text="조회된 조회결과가 존재하지 않습니다."
          max-height="1136"
          @sort-change="sortChange"
        >
          <el-table-column
            label="선택"
            prop="isSelected"
            align="center"
            width="50"
            fixed
          >
            <template slot-scope="scope">
              <el-checkbox
                v-model="scope.row.isSelected"
                @change="onChange($event, scope.row)"
                @click.native.stop
              />
            </template>
          </el-table-column>
          <el-table-column
            prop="no"
            label="NO."
            align="center"
            width="50"
            fixed
          />
          <el-table-column
            label="계약정보"
            width="330"
            fixed
          >
            <el-table-column
              label="계약번호"
              prop="contractNumber"
              width="150"
              align="center"
              sortable="custom"
            >
              <template slot-scope="props">
                <a
                  class="link"
                  href="/#/contract/release-detail"
                  target="_blank"
                  @click="$utils.setSessionStorage({ contractNumber: props.row.contractNumber })"
                >
                  {{ props.row.contractNumber | capitalize }}
                </a>
              </template>
            </el-table-column>
            <el-table-column
              label="계약자명"
              prop="contractorName"
              width="100"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="사번"
              prop="employeeId"
              width="100"
              align="center"
              sortable="custom"
            />
          </el-table-column>
          <el-table-column
            label="판매 진행상태"
            width="300"
            fixed
          >
            <el-table-column
              label="임직원몰"
              prop="onlineStatusName"
              width="200"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="레거시"
              prop="legacyStatusName"
              width="100"
              align="center"
              sortable="custom"
            />
          </el-table-column>
          <el-table-column
            label="차량정보"
            width="450"
          >
            <el-table-column
              label="재고구분"
              prop="stockType"
              width="100"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="판매코드"
              prop="carSaleCode"
              width="150"
              align="center"
              sortable="custom"
            >
              <template slot-scope="props">
                <el-tooltip
                  placement="bottom"
                  effect="light"
                >
                  <div slot="content">
                    <el-row>
                      <el-col :span="6">
                        차종
                      </el-col>
                      <el-col :span="18">
                        {{ props.row.saleModelName }}
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="6">
                        옵션
                      </el-col>
                      <el-col :span="18">
                        {{ props.row.optionName }}
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="6">
                        외, 내장 칼라
                      </el-col>
                      <el-col :span="18">
                        {{ `외장(${props.row.exteriorColorName || ''}), 내장(${props.row.interiorColorName || ''})` }}
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="6">
                        TUIX
                      </el-col>
                      <el-col :span="18">
                        {{ props.row.tuixName }}
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="6">
                        가격
                      </el-col>
                      <el-col :span="18">
                        {{ props.row.carPrice && (props.row.carPrice.toLocaleString() +'원') }}
                      </el-col>
                    </el-row>
                  </div>
                  <el-button type="text">
                    {{ props.row.carSaleCode }}
                  </el-button>
                </el-tooltip>
              </template>
            </el-table-column>
            <el-table-column
              label="칼라"
              prop="carColor"
              width="100"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="TUIX"
              prop="csptCode"
              width="100"
              align="center"
              sortable="custom"
            />
          </el-table-column>

          <el-table-column
            label="출고센터"
            prop="deliveryCenterCode"
            width="100"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="인수유형"
            prop="acquisitionTypeCode"
            width="100"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="탁송지"
            prop="deliveryPlace"
            width="200"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="계약시작일"
            prop="contractDate"
            width="100"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="계약완료일"
            prop="contractCompletionDate"
            width="100"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="배정 요청일"
            prop="assignRequestDate"
            width="100"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="배정일"
            prop="assignDate"
            width="100"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="결제기한일"
            prop="payExpireDate"
            width="150"
            align="center"
          />
          <el-table-column
            label="결제시작일"
            prop="payStartDate"
            width="150"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="결제완료일"
            prop="payEndDate"
            width="150"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="출고일/출고예정일"
            prop="releaseOrExpectDate"
            width="150"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="제작증 발급일"
            prop="craftCertificateDate"
            width="100"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="해약/매취일"
            prop="cancelDate"
            width="100"
            align="center"
            sortable="custom"
          />

          <el-table-column
            label="결제 정보"
            width="1600"
          >
            <el-table-column
              label="차량가격"
              prop="carPrice"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="계약금"
              prop="contractPrice"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="할인액"
              prop="discountPrice"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="포인트"
              prop="usePoint"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="감면액"
              prop="taxReduction"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="탁송료"
              prop="deliveryPrice"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="의무보험료"
              prop="insurancePayment"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="할부유형"
              prop="installmentType"
              width="100"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="할부금"
              prop="installment"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="카드 결제액"
              prop="cardPayment"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="현금 입금액"
              prop="cashPayment"
              width="150"
              align="center"
              sortable="custom"
            />
          </el-table-column>
          <el-table-column
            label="업무담당자"
            width="400"
          >
            <el-table-column
              label="사번"
              prop="consultantId"
              width="100"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="성명"
              prop="consultantName"
              width="80"
              align="center"
              sortable="custom"
            />
          </el-table-column>
        </el-table>
        <div class="btn-wrap">
          <div class="side"></div>
          <div class="pagination">
            <v-pagination
              v-if="tableData.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch"
            />
          </div>
          <div class="main"></div>
        </div>
      </article>

      <!-- 조회결과없음 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="alertNoData"
        :width="pupWidth"
      >
        <!-- Message -->
        조회 결과가 없습니다.

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="primary"
            @click="alertNoData = false"
          >
            확인
          </el-button>
        </template>
      </el-dialog>

      <!-- 출고예정일 변경 팝업 -->
      <el-dialog
        title="출고예정일 변경"
        :visible.sync="popReleaseDate"
      >
        <!-- Popup Contents -->
        <div class="board-wrap changeDate">
          <el-form
            ref="ruleFormpopup"
            class="detail-form"
          >
            <el-row>
              <el-col :span="24">
                <el-form-item label="변경 후">
                  <el-date-picker
                    v-model="dateAfter"
                    type="date"
                    :clearable="false"
                  />
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
          <article class="article">
            <h-table
              :table-type="'DefultTable'"
              :table-header="popupTableHeader"
              :table-datas="multipleSelection"
            />
          </article>
        </div>
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="info"
            @click="popReleaseDate = false"
          >
            취소
          </el-button>
          <el-button
            type="primary"
            @click="saveReleaseDate"
          >
            저장
          </el-button>
        </template>
      </el-dialog>

      <!-- 결제기한일 연기 팝업 -->
      <el-dialog
        title="결제기한일 연기"
        :visible.sync="popPaymentDate"
      >
        <!-- Popup Contents -->
        <div class="board-wrap changeDate">
          <el-form
            ref="ruleFormpopup"
            class="detail-form"
          >
            <el-row>
              <el-col :span="32">
                <el-form-item label="변경 후">
                  <el-date-picker
                    v-model="paymentAfter"
                    type="datetime"
                    :clearable="false"
                  />
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
          <article class="article">
            <h-table
              :table-type="'DefultTable'"
              :table-header="popupPaymentTableHeader"
              :table-datas="multipleSelection"
            />
          </article>
        </div>
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="info"
            @click="popPaymentDate = false"
          >
            취소
          </el-button>
          <el-button
            type="primary"
            @click="onSavePaymentDate"
          >
            저장
          </el-button>
        </template>
      </el-dialog>

      <loading
        :pop-visible.sync="popVisibleLoading"
        @close="popVisibleLoading = false"
      />
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import { mapState } from 'vuex'
import moment from 'moment'
import HTable from '~/components/common/HTable.vue'
import Loading from '~/components/popup/Loading.vue'
import PopMessage from '~/components/popup/PopMessage.vue'

export default {
  name: 'Release',
  layout: 'default',
  components: {
    HTable,
    Loading,
    PopMessage
  },
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      onlineSelectedVal: false,
      legacySelectedVal: false,
      consultantSelectedVal: false,
      pupWidth: '550px',
      popVisibleLoading: false,
      singleSelRow: null,
      tableData: [],
      multipleSelection: [],
      popReleaseDate: false,
      popPaymentDate:false,
      alertNoData: false,
      // alertContinueChange: false,
      checked:false,
      searchDtRadio: 'today',
      ruleForm: {
        searchDateType: '10',
        searchFromDt: moment(),
        searchEndDt: moment(),
        onlineStatus: [],
        legacyStatus: [],
        consultantId: [],
        contractId: '',
        contractEmployeeName: '',
        contractEmployeeId: '',
        carTypeCode: 'all', // 차종
        carCode: 'all' // 차명
      },
      code: [
        { value: 'all',  label: '전체' }
      ],
      selTypeCars: [
        { repnCarCode: 'all', repnCarName: '전체'}
      ],
      dateAfter: moment(),
      paymentAfter: moment(),
      popupTableHeader: [
        {
          label: '계약번호',
          prop: 'contractNumber',
          align: 'center'
        },
        {
          label: '변경 전',
          prop: 'releaseExpectDate',
          align: 'center'
        }
      ],
      popupPaymentTableHeader: [
        {
          label: '계약번호',
          prop: 'contractNumber',
          align: 'center'
        },
        {
          label: '변경 전(결제시작일)',
          prop: 'payStartDate',
          align: 'center'
        }
      ],
      commonCodes: {},
      LegacyCommonCodes: {},
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      },
      sortInfo: {
        order: '',
        prop: ''
      },
    }

  },
  computed: {
    ...mapState({
      userInfo: state => state.userInfo
    }),
    carTypes: function() {
      const carTypes = this.$store.state.carTypes
      if(carTypes && carTypes.length > 0) {
        carTypes.shift()
        carTypes.unshift({ 'carTypeCode': 'all', 'carTypeName': '전체' })
      }
      return carTypes
    },
    // allTypeCars: function() {
    //   const allTypeCars = this.$store.state.allTypeCars['all']
    //   if(allTypeCars && allTypeCars.length > 0) {
    //     allTypeCars.unshift({ 'carCode': 'all', 'carName': '전체' })
    //   }
    //   return allTypeCars
    // },
    consultants: function() {
      const consultants = this.$store.state.consultants.slice()
      if(consultants && consultants.length > 0) {
        consultants.unshift( { 'useAuthId': '', 'sysUserNo': '', 'sysUserNm': '전체', 'opsNm': '' } )
      }
      return consultants
    }

  },
  async created() {
    await this.loadCommonCode()
  },
  mounted() {
    this.$store.dispatch('loadConsultants', {vm: this})
    this.$store.dispatch('loadAllTypeCars', {vm: this})
  },
  methods: {
    sortChange(props) {
      const { prop, order } = props

      let convertOrder = ''

      if (order === 'descending') {
        convertOrder = 'desc'
      } else if (order === 'ascending') {
        convertOrder = 'asc'
      }

      this.sortInfo = { prop, order: convertOrder }
      this.getData()
    },
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null
      switch(systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {vm: this, codeTypeCode: codeType})
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {vm: this, codeTypeCode: codeType})
        break
      }
      return res
    },
    async loadCommonCode() {
      const [ccU019, ccT010, ccC013] = await Promise.all([
        this.fetchCommonCodeData('E', 'U019'), // 구분
        this.fetchCommonCodeData('E', 'T010'), // 임직원몰 진행상태
        this.fetchCommonCodeData('C', 'C013') // 레거시 진행상태
      ])
      this.commonCodes = { ...ccU019, ...ccT010 }
      this.LegacyCommonCodes = { ...ccC013 }
      this.initRuleFormStatus()

    },
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    onAddZero(contractNumber) {
      let resultString = ''
      if(contractNumber.length > 6) {
        const frontString = contractNumber.substring(0,7)
        const backString = contractNumber.substring(7)

        resultString = resultString.concat(frontString)
        resultString = resultString.concat(backString.length >= 6 ? backString : Array.from({length: 6 - backString.length}, () => 0).join('') + backString)
      }

      if(!resultString) { resultString = contractNumber }
      this.ruleForm.contractId = resultString
    },
    resetSearchCond() {
      Object.assign(this.ruleForm, this.$options.data().ruleForm)
      this.searchDtRadio = 'today'
    },
    onSearch(page) {
      if(!this.isValidAuthBtn('authSelect')) { // 권한없을경우 동작 x
        return
      }

      this.$data.pageInfo.page = page
      this.getData()
    },
    initRuleFormStatus() {
      if(this.ruleForm.legacyStatus && this.ruleForm.legacyStatus.length === 0) { // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false,'legacy')
      }
      if(this.ruleForm.onlineStatus && this.ruleForm.onlineStatus.length === 0) { // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false,'online')
      }
      if(this.ruleForm.consultantId && this.ruleForm.consultantId.length === 0) { // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false,'consultant')
      }
    },
    selectedAll(e,type) {
      if(type==='online'){
        if(e) {
          this.ruleForm.onlineStatus = this.commonCodes.T010.slice(1).map((items) => {
            return items.value
          }) || []
        } else {
          this.ruleForm.onlineStatus = []
        }
      }else if(type==='legacy'){
        if(e) {
          this.ruleForm.legacyStatus = this.LegacyCommonCodes.C013.slice(1).map((items) => {
            return items.value
          }) || []
        } else {
          this.ruleForm.legacyStatus = []
        }
      }else if(type==='consultant'){
        if(e) {
          this.ruleForm.consultantId = this.consultants.slice(1).map((items) => {
            return items.sysUserNo
          }) || []
        } else {
          this.ruleForm.consultantId = []
        }
      }
    },
    onChangeMultiSelect(data,type) {
      if(type==='online'){
        if(data.length === this.commonCodes.T010.slice(1).length) {
          this.onlineSelectedVal = true
        } else {
          this.onlineSelectedVal = false
        }
      }else if(type==='legacy'){
        if(data.length === this.LegacyCommonCodes.C013.slice(1).length) {
          this.legacySelectedVal = true
        } else {
          this.legacySelectedVal = false
        }
      }else if(type==='consultant'){
        if(data.length === this.consultants.slice(1).length) {
          this.consultantSelectedVal = true
        } else {
          this.consultantSelectedVal = false
        }
      }
    },
    async getData() {
      //날짜 포맷 API형식에 맞추기
      const searchFromDt = moment(this.ruleForm.searchFromDt).format('YYYYMMDD')
      const searchEndDt = moment(this.ruleForm.searchEndDt).format('YYYYMMDD')
      if(!this.ruleForm.searchFromDt || !this.ruleForm.searchEndDt) {
        this.alertMessage = '날짜는 필수입력사항입니다.'
        this.alertMessagePop = true
        return false
      }
      if(searchEndDt-searchFromDt>10000){
        this.alertMessage = '최대 조회 가능기간은 1년입니다.'
        this.alertMessagePop = true
        return false
      }

      this.initRuleFormStatus()

      const { page, size } = this.$data.pageInfo

      const params = {
        ...this.ruleForm,
        carCode: this.ruleForm.carCode !== 'all' ? this.ruleForm.carCode : '',
        carTypeCode: this.ruleForm.carTypeCode !== 'all' ? this.ruleForm.carTypeCode : '',
        // legacyStatus: this.ruleForm.legacyStatus !== 'all' ? this.ruleForm.legacyStatus : '',
        // onlineStatus: this.ruleForm.onlineStatus !== 'all' ? this.ruleForm.onlineStatus : '',
        searchFromDt,
        searchEndDt,
        pageNo: page,
        pageSize: size,
        sortingId: this.sortInfo.prop,
        sortingType: this.sortInfo.order
      }
      this.popVisibleLoading = true
      // API-E-업무담당자-010 (계약출고현황)
      const [res,err] = await this.$https.post('/v1/exclusive/contract', params)
      if(!err) {
        if(!res.data || !res.data.list || res.data.list.length===0) {
          this.tableData = []
        } else {
          this.tableData = res.data.list.map((el, idx) => {
            return {
              ...el,
              no : res.data.total - res.data.endRow + res.data.list.length - idx,
              isSelected: false,
              carPrice: el.carPrice && (el.carPrice*1).toLocaleString(),
              contractPrice: el.contractPrice && (el.contractPrice*1).toLocaleString(),
              discountPrice: el.discountPrice && (el.discountPrice*1).toLocaleString(),
              usePoint: el.usePoint && (el.usePoint*1).toLocaleString(),
              taxReduction: el.taxReduction && (el.taxReduction*1).toLocaleString(),
              deliveryPrice: el.deliveryPrice && (el.deliveryPrice*1).toLocaleString(),
              insurancePayment: el.insurancePayment && (el.insurancePayment*1).toLocaleString(),
              cashPayment: el.cashPayment && (el.cashPayment*1).toLocaleString(),
              installment: el.installment && (el.installment*1).toLocaleString(),
              cardPayment: el.cardPayment && (el.cardPayment*1).toLocaleString(),
              depositAmount: el.depositAmount && (el.depositAmount*1).toLocaleString(),
              releaseDate: el.releaseDate ? (moment(el.releaseDate).format('YYYY-MM-DD')) : (el.releaseExpectedDate && moment(el.releaseExpectedDate).format('YYYY-MM-DD')),
              contractDate: el.contractDate && moment(el.contractDate).format('YYYY-MM-DD'),
              contractCompletionDate: el.contractCompletionDate && moment(el.contractCompletionDate).format('YYYY-MM-DD'),
              assignRequestDate: el.assignRequestDate && moment(el.assignRequestDate).format('YYYY-MM-DD'),
              assignDate: el.assignDate && moment(el.assignDate).format('YYYY-MM-DD'),
              craftCertificateDate: el.craftCertificateDate && moment(el.craftCertificateDate).format('YYYY-MM-DD'),
              cancelDate: el.cancelDate && moment(el.cancelDate).format('YYYY-MM-DD'),
              carSaleCode: el.carSaleCode || '코드없음'
            }
          })

          this.$data.pageInfo = {
            ...this.$data.pageInfo,
            total: res.data.total
          }

          console.log('/v1/exclusive/contract', this.tableData)
        }
        this.popVisibleLoading = false
      } else {
        this.popVisibleLoading = false
        console.error(err)
      }
    },
    async downloadExcel() {

      this.initRuleFormStatus()

      const params = {
        ...this.ruleForm,
        carCode: this.ruleForm.carCode !== 'all' ? this.ruleForm.carCode : '',
        carTypeCode: this.ruleForm.carTypeCode !== 'all' ? this.ruleForm.carTypeCode : '',
        // legacyStatus: this.ruleForm.legacyStatus !== 'all' ? this.ruleForm.legacyStatus : '',
        onlineStatus: this.ruleForm.onlineStatus !== 'all' ? this.ruleForm.onlineStatus : '',
        searchFromDt: moment(this.ruleForm.searchFromDt).format('YYYYMMDD'),
        searchEndDt: moment(this.ruleForm.searchEndDt).format('YYYYMMDD')
      }

      // API-E-업무담당자-011 (계약출고현황 목록 엑셀저장)
      const [res,err] = await this.$https.post('/v1/exclusive/contract-excel', params, null, null, { responseType: 'blob' })
      if(!err) {
        const blob = new Blob([res], {type : res.Type })
        const nowDate = moment().format('YYYYMMDD_HHmm')
        if(window.navigator.msSaveOrOpenBlob) {
          // IE11
          window.navigator.msSaveOrOpenBlob(blob, '계약출고현황목록_' + nowDate + '.xlsx')
        } else {
          // IE11 외 브라우저
          const blobURL = window.URL.createObjectURL(blob)
          const tempLink = document.createElement('a')

          tempLink.href = blobURL

          tempLink.setAttribute('download', '계약출고현황목록_' + nowDate + '.xlsx')
          document.body.appendChild(tempLink)
          tempLink.click()
          document.body.removeChild(tempLink)
          window.URL.revokeObjectURL(blobURL)
        }
      } else {
        console.error(err)
        this.tableData = null
      }
    },
    onChangeSearchDtRadio(val) {
      if(val==='lastDay') {
        this.ruleForm.searchFromDt = moment().subtract('days', 1)
        this.ruleForm.searchEndDt = moment().subtract('days', 1)
      } else if(val==='today') {
        this.ruleForm.searchFromDt = moment()
        this.ruleForm.searchEndDt = moment()
      } else if(val==='day7') {
        this.ruleForm.searchFromDt = moment().subtract('days', 7)
        this.ruleForm.searchEndDt = moment()
      } else if(val==='day30') {
        this.ruleForm.searchFromDt = moment().subtract('days', 30)
        this.ruleForm.searchEndDt = moment()
      } else if(val==='month3') {
        this.ruleForm.searchFromDt = moment().subtract('months', 3)
        this.ruleForm.searchEndDt = moment()
      } else if(val==='month6') {
        this.ruleForm.searchFromDt = moment().subtract('months', 6)
        this.ruleForm.searchEndDt = moment()
      } else if(val==='month12') {
        this.ruleForm.searchFromDt = moment().subtract('months', 12)
        this.ruleForm.searchEndDt = moment()
      }
    },
    onChange(val, row) {
      this.tableData.filter((items) => { return items.no !== row.no }).map((items) => { items.isSelected = false })
    },
    toggleSelectionAll() {
      if(this.checked) {
        this.tableData.map((items) => { items.isSelected = true })
      }
      else {
        this.tableData.map((items) => { items.isSelected = false })
      }
    },
    changeReleaseDate() {
      this.multipleSelection = this.tableData.filter((items) => {
        return items.isSelected === true
      })

      if(this.multipleSelection.length===0) {
        this.alertMessage = '계약을 먼저 선택해주세요.'
        this.alertMessagePop = true
      } else {
        this.popReleaseDate = true
      }
    },
    changePaymentDate() {
      this.multipleSelection = this.tableData.filter((items) => {
        return items.isSelected === true
      })

      if(this.multipleSelection.length===0) {
        this.alertMessage = '계약을 먼저 선택해주세요.'
        this.alertMessagePop = true
      } else {
        this.popPaymentDate = true
      }
    },
    async saveReleaseDate() {
      const body = this.multipleSelection.map(el => {
        return { contractNumber: el.contractNumber, deliveryExpectedDate: moment(this.dateAfter).format('YYYYMMDD') }
      })

      if(body.length === 0) {
        this.alertMessage = '변경 할 목록이 없습니다.'
        this.alertMessagePop = true
      } else {
        console.log(body)
        const [res, err] = await this.$https.post('/purchase/v1/purchase/contract/due-date', body[0], null, 'gateway') // TODO: 다중선택으로 변경시 body[0] => body로 변경
        if(!err) {
          console.log(res)
          this.alertMessage = '변경되었습니다.'
          this.alertMessagePop = true
          // this.alertContinueChange = false
          this.popReleaseDate = false

          this.multipleSelection.map((el) => {
            el.releaseExpectDate = moment(this.dateAfter).format('YYYY-MM-DD')
          })
        } else {
          console.error(err)
        }
      }
    },
    async onSavePaymentDate() {
      const body = this.multipleSelection.map(el => {
        return {saleCnttNo: el.contractNumber, vbgStlStrtDtm: moment(this.paymentAfter).format('YYYYMMDDHHMMSS')}
      })

      if (body.length === 0) {
        this.alertMessage = '변경 할 목록이 없습니다.'
        this.alertMessagePop = true
      } else {
        console.log(body)
        const [res, err] = await this.$https.post('/payment/v1/payment/payment-start-date', body[0], null, 'gateway') // TODO: 다중선택으로 변경시 body[0] => body로 변경
        if (!err) {
          console.log(res)
          this.alertMessage = '변경되었습니다.'
          this.alertMessagePop = true
          this.popPaymentDate = false

          this.multipleSelection.map((el) => {
            el.payStartDate = moment(this.paymentAfter).format('YYYY-MM-DD HH:mm')
          })
        } else {
          console.error(err)
        }
      }
    },
    async onChangeTypeCars(carTypeCode) { // 차종별 해당 차명 목록 추출
      this.ruleForm.carCode = 'all'
      const [res, err] = await this.$https.get('/v1/exclusive/contract/repncarCode', {carTypeCode})
      if (err) {
        console.log('err', err)
        return
      }

      this.selTypeCars = res.data.map((items) => {
        return {repnCarName: items.repnCarName, repnCarCode: items.repnCarCode}
      })
      this.selTypeCars.unshift({'repnCarName': '전체', 'repnCarCode': 'all'})
      // res.data && res.data.map((items) => { return { label: items.codeName, value: items.code } })

    }
  }
}
</script>


<style lang="scss" scoped>
@import '~/assets/style/pages/release.scss';
</style>
