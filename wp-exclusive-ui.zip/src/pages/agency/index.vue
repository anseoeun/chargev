<template>
  <section>
    <div id="agency">
      <!-- 추가된 부분 입니다.  -->
      <div class="btn-wrap">
        <div class="side">
          <el-button 
            type="info"
            @click="resetSearchCond"
          >
            초기화
          </el-button>
        </div>
        <div class="main">
          <el-button
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            @click="onSearch(1)"
          >
            조회
          </el-button>
          <router-link
            v-if="isValidAuthBtn('authSysManage')"
            to="/agency/create"
            class="el-button el-button--primary"
          >
            등록
          </router-link>
        </div>
      </div>
      <div class="board-wrap">
        <el-form 
          ref="searchForm"
          :inline="true"
          :model="searchForm" 
          class="detail-form"
        > 
          <el-row>
            <el-col :span="12">
              <el-form-item label="정보">
                <el-select
                  v-model="searchForm.cityCode"
                  @change="onChangeCityCode(searchForm.cityCode)"
                >
                  <el-option
                    v-for="{ value, label } in cityCodeList"
                    :key="value"
                    :value="value"
                    :label="value === '' ? `광역시/도 ${label}` : label"
                  />
                </el-select>
                <el-select
                  v-model="searchForm.guCode"
                  placeholder=""
                >
                  <el-option
                    v-for="{ value, label } in realGuCodeList"
                    :key="value"
                    :value="value"
                    :label="value === '' ? `시/군/구 ${label}` : label"
                  />
                </el-select>
                <el-select
                  v-model="searchForm.status"
                  placeholder=""
                >
                  <el-option
                    v-for="{ value, label } in statusCodeList"
                    :key="value"
                    :value="value"
                    :label="value === '' ? `상태 ${label}` : label"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col
              :span="12"
              class="left-col"
            >
              <el-form-item label="">
                <el-radio
                  v-model="searchForm.condition"
                  label="01"
                >
                  행정사명
                </el-radio>
                <el-radio
                  v-model="searchForm.condition"
                  label="02"
                >
                  대표자명
                </el-radio>
                <el-input
                  v-model="searchForm.keyword"
                  placeholder="행정사명 입력"
                  @keyup.native.enter="onSearch(1)"
                />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
    
      <article class="article">
        <div class="article-title">
          <h2>행정사 조회</h2>
        </div>
        <div class="board-wrap">
          <el-table
            :data="agencyList"
          >
            <el-table-column
              prop="rowIndex"
              label="No."
              width="80"
              align="center"
            />
            <el-table-column
              label="기본정보"
            >
              <el-table-column 
                prop="firmName"
                label="업체명/개인사업자명"
              >
                <template slot-scope="props">
                  <span v-if="!props.row.isEdit">{{ props.row.firmName }}</span>
                  <el-input
                    v-else
                    v-model="props.row.firmName"
                  />
                </template>
              </el-table-column>
              <el-table-column
                prop="jurisdictionArea"
                label="관할 지역"
                required
              >
                <template slot-scope="props">
                  <span v-if="!props.row.isEdit">{{ props.row.jurisdictionArea }}</span>
                  <el-input
                    v-else
                    v-model="props.row.jurisdictionArea"
                  />
                </template>
              </el-table-column>
              <el-table-column
                label="주소"
              >
                <template slot-scope="props">
                  <span v-if="!props.row.isEdit">{{ (props.row.firmAdress1 || '') + " " + (props.row.firmAdress2 || '') }}</span>
                  <el-input
                    v-else
                    v-model="props.row.firmAdress1"
                  />
                </template>
              </el-table-column>
              <el-table-column
                label="전화번호"
                align="center"
              >
                <template slot-scope="props">
                  <span v-if="!props.row.isEdit">{{ props.row.firmTel }}</span>
                  <el-input
                    v-else
                    v-model="props.row.firmTel"
                  />
                </template>
              </el-table-column>
            </el-table-column>
            <el-table-column
              label="추가 정보(관리용)"
            >
              <el-table-column 
                prop="representativeName"
                label="대표자명"
                align="center"
              >
                <template slot-scope="props">
                  <span v-if="!props.row.isEdit">{{ props.row.representativeName }}</span>
                  <el-input
                    v-else
                    v-model="props.row.representativeName"
                  />
                </template>
              </el-table-column>
              <el-table-column
                prop="representativeTel"
                label="대표자 전화번호"
                align="center"
                required
              >
                <template slot-scope="props">
                  <span v-if="!props.row.isEdit">{{ props.row.representativeTel }}</span>
                  <el-input
                    v-else
                    v-model="props.row.representativeTel"
                  />
                </template>
              </el-table-column>
              <el-table-column
                porp="memo"
                label="메모"
              >
                <template slot-scope="props">
                  <span v-if="!props.row.isEdit">{{ props.row.memo }}</span>
                  <el-input
                    v-else
                    v-model="props.row.memo"
                  />
                </template>
              </el-table-column>
            </el-table-column>
            <el-table-column
              prop="openYn"
              label="상태"
              align="center"
            >
              <template slot-scope="props">
                <span
                  v-if="props.row.openYn === 'Y'"
                  class="blue"
                >
                  공개
                </span>
                <span
                  v-if="props.row.openYn === 'N'"
                  class="red"
                >
                  비공개
                </span>
              </template>
            </el-table-column>
            <el-table-column
              prop="openStartDate"
              label="공개시작일"
              align="center"
            >
              <template slot-scope="props">
                <span
                  v-if="props.row.openYn"
                >
                  {{ props.row.openStartDate }}
                </span>
              </template>
            </el-table-column>
            <el-table-column
              v-if="isValidAuthBtn('authSysManage')"
              width="120"
              class-name="action"
              label="관리"
            >
              <template slot-scope="props">
                <span v-if="!props.row.isEdit">
                  <el-button
                    type="text"
                    @click="onEdit(props)"
                  >
                    수정
                  </el-button>
                  <el-button
                    type="text"
                    @click="onDelete(props)"
                  >
                    삭제
                  </el-button>
                </span>
                <span v-else>
                  <el-button
                    type="text"
                    @click="onSave(props)"
                  >
                    저장
                  </el-button>
                  <el-button
                    type="text"
                    @click="onCancel(props)"
                  >
                    취소
                  </el-button>
                </span>
              </template>
            </el-table-column>
          </el-table>
          <div class="pagination">
            <v-pagination
              v-if="agencyList.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch"
            />
          </div>
          <el-dialog
            :visible.sync="popVisibleDel"
            width="500px"
          >
            <template slot="title">
              해당 데이터가 삭제됩니다.
              <br>
              정말 삭제하시겠습니까?
            </template>
            <!-- Popup Footer -->
            <template slot="footer">
              <el-button
                type="info"
                @click="popVisibleDel = false"
              >
                취소
              </el-button>
              <el-button
                type="primary"
                @click="deleteAgency"
              >
                확인
              </el-button>
            </template>
          </el-dialog>
        </div>
      </article>
    </div>
  </section>
</template>

<script>
import moment from 'moment'

export default {
  data() {
    return {
      popVisibleDel: false,
      selRow: {},
      searchForm: {
        cityCode: '', //  시도 코드
        guCode: '', // 시군구 코드
        status: '', // 공개여부
        condition: '01', // 검색조건
        keyword: '' // 검색어
      },
      realGuCodeList: [{ label: '선택', value: '' }],
      agencyList: [], // 행정사(등록대행업체) 목록
      pageInfo: { // paging info
        page: 1,
        size: 10,
        total: 0
      },
      commonCodes: {}
    }
  },
  computed: {
    cityCodeList: function() {
      const cityCodeList = this.commonCodes.Z028
      if(cityCodeList && cityCodeList.length > 0) {
        cityCodeList.shift()
        cityCodeList.unshift({ 'value': '', 'label': '선택' })
      }
      return cityCodeList
    },
    guCodeList: function() {
      const guCodeList = this.commonCodes.Z029
      if(guCodeList && guCodeList.length > 0) {
        guCodeList.shift()
        guCodeList.unshift({ 'value': '', 'label': '선택' })
      }
      return guCodeList
    },
    statusCodeList: function() {
      const statusCodeList = this.commonCodes.Z074
      if(statusCodeList && statusCodeList.length > 0) {
        statusCodeList.shift()
        statusCodeList.unshift({ 'value': '', 'label': '선택' })
      }
      return statusCodeList
    }
  },
  async created() {
    await this.loadCommonCode()
  },
  mounted() {
    this.onSearch(1)
  },
  methods: {
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null
      switch(systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {vm: this, codeTypeCode: codeType})
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {vm: this, codeTypeCode: codeType})
        break
      }
      return res
    },
    async loadCommonCode() {
      const [ccZ028, ccZ029, ccZ074] = await Promise.all([
        this.fetchCommonCodeData('E', 'Z028'), // 시코드
        this.fetchCommonCodeData('E', 'Z029'), // 구코드
        this.fetchCommonCodeData('E', 'Z074'), // 상태코드
      ])
      
      this.commonCodes = { ...ccZ028, ...ccZ029, ...ccZ074 }
    },
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    onChangeCityCode(val) {
      this.searchForm.guCode = ''
      const cityCode = val
      const guCodeList = this.guCodeList.filter((items) => {
        return items.value && items.value.substring(0,2) === cityCode
      })
      guCodeList.unshift({ 'value': '', 'label': '선택' })
      this.realGuCodeList = guCodeList
    },
    resetSearchCond() {
      Object.assign(this.searchForm, this.$options.data().searchForm)
      this.onSearch(1)
    },
    async getAgencyList() { // 행정사(등록대행업체)
      const { page, size } = this.$data.pageInfo
      const { guCode = '', cityCode = '', status: openYn = '', condition: searchCondition = '', keyword: searchKeyword = '' } = this.searchForm

      const param = { 
        guCode: guCode,
        cityCode: cityCode,
        openYn: openYn,
        searchCondition,
        searchKeyword,
        pageNo: page,
        pageSize: size
      }

      const [res, err] = await this.$https.get('/v1/exclusive/setting/registration-firms', param)

      if(!err) {
        console.log(res)  

        res.data.list.map((items, idx) => {
          items.openStartDate = items.openStartDate ? moment(items.openStartDate).format('YYYY-MM-DD') : ''
          items.rowIndex = res.data.total - res.data.endRow + res.data.list.length - idx
        })
        this.agencyList = res.data.list

      } else {
        console.error(err)
      }

      this.$data.pageInfo = {
        ...this.$data.pageInfo,
        total: res.data.total
      }
    },

    onSearch(page) { // search
      this.$data.pageInfo.page = page
      this.getAgencyList() // 조회
    },

    onEdit(props) { // 수정화면으로 이동
      const { row } = props
      row.isEdit = true
      // location.hash='/agency/_id?firmSn=' + row.firmSn
      this.$router.push('/agency/_id?firmSn=' + row.firmSn)
    },

    onDelete(props) { // 삭제
      this.popVisibleDel = true
      this.selRow = props
      console.log(this.selRow)
    },

    onSave(props) {
      const { row, $index } = props
      console.log({ ...row })
      row.isEdit = false
      this.cachedList[$index] = { ...row }
    },

    onCancel(props) {
      const { row, $index } = props
      Object.keys(row).forEach(key => {
        props.row[key] = this.cachedList[$index][key]
      })
      row.isEdit = false
    },

    async deleteAgency() { // 행정사 삭제
      const { firmSn } = this.selRow.row

      const [res, err] = await this.$https.delete('/common/v1/common/exclusive/setting/registration-firm/' + firmSn, null, null, null, 'gateway')

      if(!err) {
        console.log(res)
        this.agencyList.splice(this.selRow.$index, 1)
        this.popVisibleDel = false
      } else {
        console.error(err)
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/agency.scss';
</style>
