<template>
  <section>
    <div id="agency">
      <div class="btn-wrap">
        <div class="side" />
        <div class="main">
          <el-button 
            v-if="isValidAuthBtn('authSysManage')"
            type="primary"
            @click="onSave"
          >
            수정
          </el-button>
          <el-button 
            type="info"
            @click="onCancle"
          >
            취소
          </el-button>
        </div>
      </div>
      <article class="article">
        <div class="article-title">
          <h2>기본 정보</h2>
          <!-- 추가하였습니다. -->
          <span class="required-value">필수값</span>
        </div>
        <el-form
          ref="ruleForm"
          :model="ruleForm"
          class="detail-form"
        >
          <el-row>
            <el-col :span="6">
              <el-form-item
                label="행정사명"
                required
              >
                <el-input 
                  v-model="ruleForm.firmName" 
                  placeholder="행정사명을 입력하세요."
                  @blur="ruleForm.firmName = $event.target.value"
                />
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item
                label="구분"
                required
              >
                <el-select 
                  v-model="ruleForm.firmTypeCode"
                  placeholder="구분"
                >
                  <el-option
                    v-for="{ value, label } in commonCodes.Z026"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item
                label="상태"
                required
              >
                <el-select 
                  v-model="ruleForm.openYn"
                  placeholder="선택"
                  @change="onChange"
                >
                  <el-option
                    v-for="{ value, label } in statusCodeList"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col 
              v-if="visibleOpenDate"
              :span="6"              
            >
              <el-form-item
                label="공개시작일"
                required
              >
                <el-date-picker
                  v-model="ruleForm.openStartDate"
                  type="date"
                  :clearable="false"
                />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col 
              :span="24"
            >
              <el-form-item
                label="관할 지역"
                required
              >
                <div
                  v-for="(items, idx) in ruleForm.jurisdictionAreaList"
                  :key="`jurisdiction-${idx}`"
                  class="jurisdiction-content"
                >
                  <el-select 
                    v-model="items.cityCode"
                    placeholder="광역시/도"
                    @change="onChangeCityCode(items.cityCode, idx)"
                  >
                    <el-option
                      v-for="{ value, label } in cityCodeList"
                      :key="value"
                      :value="value"
                      :label="value === '' ? `광역시/도 ${label}` : label"
                    />
                  </el-select>
                  <el-select 
                    v-model="items.guCode"
                    placeholder="시/군/구"
                  >
                    <el-option
                      v-for="{ value, label } in realGuCodeList[idx]"
                      :key="value"
                      :value="value"
                      :label="value === '' ? `시/군/구 ${label}` : label"
                    />
                  </el-select>
                  <el-input 
                    v-model="items.additionalDetail" 
                    placeholder="지역 상세정보를 입력하세요(예: 전 지역, 특정 '동')"
                    @blur="items.additionalDetail = $event.target.value"
                  />
                  <el-button
                    v-if="!items.isAdd"
                    type="primary"
                    class="btn-md"
                    icon="el-icon-plus"
                    @click="onJurisdictionRowAdd"
                  />
                  <el-button
                    v-else
                    type="primary"
                    class="btn-md"
                    icon="el-icon-minus"
                    @click="onJurisdictionRowDel(idx)"
                  />
                </div>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item
                label="주소"
              >
                <div class="table-content-address">
                  <el-input 
                    v-model="ruleForm.zipCode" 
                    style="width: 140px;"
                    placeholder="우편번호"
                    readonly="readonly"
                  />
                  <el-button 
                    type="info"
                    @click="visibleAddr = true"
                  >
                    우편번호 검색
                  </el-button>
                  <el-input 
                    v-model="ruleForm.firmAdress1" 
                    placeholder="주소"
                    readonly="readonly"
                  />
                  <el-input 
                    v-model="ruleForm.firmAdress2" 
                    placeholder="상세 주소"                    
                    @blur="ruleForm.firmAdress2 = $event.target.value"
                  />
                </div>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col 
              :span="24"
            >
              <el-form-item
                label="전화번호"
                required
              >
                <div
                  v-for="(items, idx) in ruleForm.telList"
                  :key="`tel-${idx}`"
                >
                  <el-input 
                    v-model="items.tel1" 
                    style="width: 140px" 
                  />
                  -
                  <el-input 
                    v-model="items.tel2" 
                    style="width: 140px" 
                  />
                  -
                  <el-input 
                    v-model="items.tel3" 
                    style="width: 140px" 
                  />
                  <el-button
                    v-if="!items.isAdd"
                    type="primary"
                    class="btn-md"
                    icon="el-icon-plus"
                    @click="onTelRowAdd('nor')"
                  />
                  <el-button
                    v-else
                    type="primary"
                    class="btn-md"
                    icon="el-icon-minus"
                    @click="onTelRowDel(idx, 'nor')"
                  />
                </div>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </article>
      <article class="article">
        <div class="article-title">
          <h2>추가 정보(관리용)</h2>
        </div>
        <el-form
          ref="ruleForm"
          :model="ruleForm"
          class="detail-form"
        >
          <el-row>
            <el-col :span="24">
              <el-form-item
                label="대표자명"
              >
                <el-input 
                  v-model="ruleForm.representativeName" 
                  style="width: 140px"
                  @blur="ruleForm.representativeName = $event.target.value"
                />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col 
              :span="24"
            >
              <el-form-item
                label="대표자 전화번호"
              >
                <div
                  v-for="(items, idx) in ruleForm.representativeTelList"
                  :key="`repTel-${idx}`"
                >
                  <el-input 
                    v-model="items.tel1" 
                    style="width: 140px" 
                  />
                  -
                  <el-input 
                    v-model="items.tel2" 
                    style="width: 140px" 
                  />
                  -
                  <el-input 
                    v-model="items.tel3" 
                    style="width: 140px" 
                  />
                  <el-button
                    v-if="!items.isAdd"
                    type="primary"
                    class="btn-md"
                    icon="el-icon-plus"
                    @click="onTelRowAdd('rep')"
                  />
                  <el-button
                    v-else
                    type="primary"
                    class="btn-md"
                    icon="el-icon-minus"
                    @click="onTelRowDel(idx, 'rep')"
                  />
                </div>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item
                label="메모"
              >
                <el-input 
                  v-model="ruleForm.memo" 
                  type="textarea"
                  @blur="ruleForm.memo = $event.target.value"
                />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </article>
      <pop-location
        v-model="addr"
        type="zip"
        :visible="visibleAddr"
        @select="onAddrSelect"
        @close="visibleAddr = false"
      />
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>
<script>
import PopLocation from '~/components/popup/PopLocation.vue'
import PopMessage from '~/components/popup/PopMessage.vue'
import moment from 'moment'

export default {
  components: {
    PopLocation,
    PopMessage
  },

  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      firmSn: '', // 업체 일련번호
      visibleOpenDate: false,
      visibleAddr: false,
      ruleForm: {
        firmName: '', // 등록대행업체 명
        firmTypeCode: 'all', // 업체구분코드
        representativeName: '', // 대표차 명
        memo: '', // 메모
        openYn: '', // 공개여부
        openStartDate: '', // 공개 시작일자
        zipCode: '', // 우편번호
        firmAdress1: '', // 업체주소1
        firmAdress2: '', // 업체주소2
        jurisdictionAreaList: new Array(1).fill().map(() => ({ 
          cityCode: '', // 광역시/도 구분코드
          guCode: '', // 시/군/구 구분 코드
          additionalDetail: '' // 관할지역 추가내용
        })), // 관할지역 리스트
        telList: new Array(1).fill().map(() => ({ 
          telSn: '', // 전화번호 일련번호
          representativeYn: 'N', // 대표자전화번호여부
          tel1: '', // 지역번호
          tel2: '', // 앞자리번호
          tel3: '' // 뒷자리 번호
        })), // 전화번호 리스트
        representativeTelList: new Array(1).fill().map(() => ({ 
          telSn: '', // 전화번호 일련번호
          representativeYn: 'Y', // 대표자전화번호여부
          tel1: '', // 지역번호
          tel2: '', // 앞자리번호
          tel3: '' // 뒷자리 번호
        })) // 대표자 전화번호 리스트
      },
      realGuCodeList: [[{label: '선택', value: ''}]],
      code: {
        status: [
          { value: '', label: '선택' },
          { value: 'Y', label: '공개' },
          { value: 'N', label: '비공개' }
        ]
      },
      commonCodes: {}
    }
  },
  computed: {
    cityCodeList: function() {
      const cityCodeList = this.commonCodes.Z028
      if(cityCodeList && cityCodeList.length > 0) {
        cityCodeList.shift()
        cityCodeList.unshift({ 'value': '', 'label': '선택' })
      }
      return cityCodeList
    },
    guCodeList: function() {
      const guCodeList = this.commonCodes.Z029
      if(guCodeList && guCodeList.length > 0) {
        guCodeList.shift()
        guCodeList.unshift({ 'value': '', 'label': '선택' })
      }
      return guCodeList
    },
    statusCodeList: function() {
      const statusCodeList = this.commonCodes.Z074
      if(statusCodeList && statusCodeList.length > 0) {
        statusCodeList.shift()
        statusCodeList.unshift({ 'value': '', 'label': '선택' })
      }
      return statusCodeList
    }
  },
  async created() {
    await this.loadCommonCode()
  },
  mounted() {
    this.firmSn = this.$route.query.firmSn

    if(this.firmSn) {
      this.timeout = setTimeout(() => {
        this.getAgencyInfo(this.firmSn)
      }, 300)
    }
  },
  destoryed() {
    clearTimeout(this.timeout)
  },
  methods: {
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null
      switch(systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {vm: this, codeTypeCode: codeType})
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {vm: this, codeTypeCode: codeType})
        break
      }
      return res
    },
    async loadCommonCode() {
      const [ccZ026, ccZ028, ccZ029, ccZ074] = await Promise.all([
        this.fetchCommonCodeData('E', 'Z026'), // 구분
        this.fetchCommonCodeData('E', 'Z028'), // 시코드
        this.fetchCommonCodeData('E', 'Z029'), // 구코드
        this.fetchCommonCodeData('E', 'Z074'), // 상태코드
      ])
      
      this.commonCodes = { ...ccZ026, ...ccZ028, ...ccZ029, ...ccZ074 }
    },
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    onChangeCityCode(val, idx) {
      let selGuCode = ''
      const cityCode = val
      const guCodeList = this.guCodeList.filter((items) => {
        return items.value && items.value.substring(0,2) === cityCode
      })
      guCodeList.unshift({ 'value': '', 'label': '선택' })

      guCodeList.some((items) => {
        if(items.value === this.ruleForm.jurisdictionAreaList[idx].guCode) {
          selGuCode = items.value
          return true
        }
      })

      this.ruleForm.jurisdictionAreaList[idx].guCode = selGuCode
      this.realGuCodeList[idx] = guCodeList
    },
    onAddrSelect(juso) {
      const { roadAddr, zipNo } = juso
      this.ruleForm.zipCode = zipNo
      this.ruleForm.firmAdress1 = roadAddr
    },
    onJurisdictionRowAdd() { // 관할 지역 추가 버튼
      this.ruleForm.jurisdictionAreaList.push({ cityCode: '', guCode: '', additionalDetail: '', isAdd: true })
      this.realGuCodeList[this.ruleForm.jurisdictionAreaList.length-1] = [{ 'value': '', 'label': '선택' }]
      console.log(this.ruleForm)
    },
    onJurisdictionRowDel(idx) {
      console.log(idx)
      this.ruleForm.jurisdictionAreaList.splice(idx, 1)
    },
    onTelRowAdd(type) { // 전화번호
      if(type === 'nor') { // 일반
        this.ruleForm.telList.push({ telSn: '', representativeYn: 'N', tel1: '', tel2: '', tel3: '', isAdd: true })
      } else if(type === 'rep') { // 대표자
        this.ruleForm.representativeTelList.push({ telSn: '', representativeYn: 'Y', tel1: '', tel2: '', tel3: '', isAdd: true })
      }
      
    },
    onTelRowDel(idx, type) {
      console.log(idx)
      if(type === 'nor') { // 일반
        this.ruleForm.telList.splice(idx, 1)
      } else if(type === 'rep') { // 대표자
        this.ruleForm.representativeTelList.splice(idx, 1)
      }      
    },
    onChange(e) {
      if(e === 'Y') { // 공개
        this.visibleOpenDate = true
        this.ruleForm.openStartDate = moment() // default: 오늘날짜
      } else { // 공개외
        this.visibleOpenDate = false
      }
    },
    async onSave() {
      console.log(this.ruleForm)
      if(!this.ruleForm.firmName) { // 행정사명
        this.alertMessage = '행정사명을 입력해주세요.'
        this.alertMessagePop = true
        return false
      }

      if(!this.ruleForm.firmTypeCode) { // 구분
        this.alertMessage = '구분을 선택해주세요.'
        this.alertMessagePop = true
        return false
      }

      if(!this.ruleForm.openYn) {
        this.alertMessage = '상태를 선택해주세요.'
        this.alertMessagePop = true
        return false
      }

      if(this.ruleForm.openYn === 'Y' && !this.ruleForm.openStartDate) {
        this.alertMessage = '공개시작일을 입력해주세요.'
        this.alertMessagePop = true
        return false
      }

      let bResult = false
      this.ruleForm.jurisdictionAreaList.some((items) => {
        if(!items.cityCode || !items.guCode) {
          bResult = true
          return true
        }
      })

      if(bResult) {
        this.alertMessage = '관할 지역를 확인해주세요.'
        this.alertMessagePop = true
        return false
      }
      
      let tbResult = false
      this.ruleForm.telList.some((items) => { // 전화번호 list validation check
        if(!items.tel1 || !items.tel2 || !items.tel3) {
          tbResult = true
          return true
        }
      })

      if(tbResult) {
        this.alertMessage = '전화번호를 확인해주세요.'
        this.alertMessagePop = true
        return false
      }

      const { telList, representativeTelList } = this.ruleForm

      const totalTelList = telList.concat(representativeTelList)

      totalTelList.map((items, idx) => {
        const keys = Object.keys(items)
        keys.map((items2) => { items[items2] = items[items2] || '' })
        items.telSn = ''+(idx+1)
      })
      const param = {
        firmName: this.ruleForm.firmName || '', 
        representativeName:  this.ruleForm.representativeName || '', 
        memo: this.ruleForm.memo || '', 
        openYn: this.ruleForm.openYn || '',
        zipCode: this.ruleForm.zipCode || '',
        firmAdress1: this.ruleForm.firmAdress1 || '',
        firmAdress2: this.ruleForm.firmAdress2 || '',
        jurisdictionAreaList: this.ruleForm.jurisdictionAreaList,
        firmTypeCode: this.ruleForm.firmTypeCode === 'all' ? '' : this.ruleForm.firmTypeCode,
        openStartDate: this.ruleForm.openStartDate ? moment(this.ruleForm.openStartDate).format('YYYYMMDD') : '',
        telList: totalTelList
      }
      console.log(param)
      const [res, err] = await this.$https.put('common/v1/common/exclusive/setting/registration-firm/'+this.firmSn, param, null, 'gateway') // API-E-업무담당자-121 (등록대행업체 정보 수정)
      
      if(!err) {
        if(res.rspStatus && res.rspStatus.rspCode === '0000') {
          this.alertMessage = '수정되었습니다.'
          this.alertMessagePop = true
          this.$router.push('/agency')
        }
      } else {
        console.error(err)
      }
    },
    onCancle() {
      this.$router.go(-1)
    },
    async getAgencyInfo(firmSn) { // 업체 일련번호별 정보 조회
      if(!firmSn) return
      
      // API-E-업무담당자-122 (등록대행업체 상세조회)
      const [res, err] = await this.$https.post('/v1/exclusive/setting/registration-firm', { firmSn })

      if(!err) {
        let representativeTelList = res.data.telList.filter((items) => {
          return items.representativeYn === 'Y'
        })

        representativeTelList.map((items, idx) => { if(idx > 0) { items.isAdd = true } })

        let telList = res.data.telList.filter((items) => {
          return items.representativeYn === 'N'
        })
        telList.map((items, idx) => { if(idx > 0) { items.isAdd = true } })

        if(res.data.openYn === 'Y') {
          this.visibleOpenDate = true 
        }

        if(telList && telList.length === 0) {
          telList = this.ruleForm.telList
        }
        
        if(representativeTelList && representativeTelList.length === 0) {
          representativeTelList = this.ruleForm.representativeTelList
        }

        if(res.data.jurisdictionAreaList && res.data.jurisdictionAreaList.length > 0) {
          this.ruleForm.jurisdictionAreaList = res.data.jurisdictionAreaList
          res.data.jurisdictionAreaList.map((items, idx) => {
            if(idx > 0) { items.isAdd = true }
            this.onChangeCityCode(items.cityCode, idx)
          })
        }

        this.ruleForm = {
          ...res.data,
          openStartDate: res.data.openStartDate ? moment(res.data.openStartDate) : '',
          telList: telList,
          representativeTelList: representativeTelList
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~/assets/style/pages/agency.scss';
</style>
