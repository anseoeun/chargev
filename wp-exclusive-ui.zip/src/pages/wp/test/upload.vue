<template>
  <section>
    <h1>image upload test</h1>
    <hr><br><br>

    <el-upload
      ref="upload"
      list-type="picture-card"
      thumbnail-mode="true"
      action="https://jsonplaceholder.typicode.com/posts/"
      :auto-upload="false"
      :file-list="fileList"
      :on-preview="handlePreview"
      :on-remove="handleRemoved"
    >
      <i
        slot="default"
        class="el-icon-plus"
      />
      <div
        slot="file"
        slot-scope="{file}"
      >
        <img
          class="el-upload-list__item-thumbnail"
          :src="file.url"
          alt=""
        >
        <span class="el-upload-list__item-actions">
          <span
            class="el-upload-list__item-preview"
            @click="preview(file)"
          >
            <i class="el-icon-zoom-in" />
          </span>
          <span
            v-if="!disabled"
            class="el-upload-list__item-delete"
            @click="remove(file)"
          >
            <i class="el-icon-delete" />
          </span>
        </span>
      </div>
    </el-upload>

    <div style="margin:10px">
      <el-button
        size="medium"
        type="primary"
        @click="submitUpload"
      >
        업로드
      </el-button>
    </div>

    <el-dialog :visible.sync="dialogVisible">
      <img
        width="100%"
        :src="dialogImageUrl"
        alt=""
      >
    </el-dialog>
  </section>
</template>

<script>
export default {
  name: 'Upload',
  layout: 'default',
  data() {
    return {
      fileList: [{name: 'food.jpeg', url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'}],
      dialogImageUrl: '',
      dialogVisible: false,
      disabled: false
    }
  },
  methods: {
    remove(file) {
      console.log('hi1', file, this.fileList)
      this.fileList = this.fileList.filter(el => el.uid !== file.uid)
    },
    preview(file) {
      this.dialogImageUrl = file.url
      this.dialogVisible = true
    },
    handleRemoved(file, fileList) {
      console.log('hi2', file, fileList)
    },
    handlePreview(file) {
      console.log(file)
    },
    submitUpload() {
      console.log(this.$refs.upload)
      this.$refs.upload.submit()
    }
  }
}
</script>