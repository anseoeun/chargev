<template>
  <section>
    <div id="general">
      <div class="btn-wrap">
        <div class="side">
          <el-button type="primary">
            초기화
          </el-button>
        </div>
        <div class="main">
          <el-button type="primary">
            조회
          </el-button>
          <el-button type="primary">
            등록
          </el-button>
        </div>
      </div>
      <el-form
        ref="info"
        :model="info"
        class="detail-form"
      >
        <el-row>
          <el-col :span="24">
            <el-form-item label="등록일">
              <el-date-picker v-model="info.date1" />
              <span class="ex-txt">~</span>
              <el-date-picker v-model="info.date2" />
              <el-radio-group
                v-model="tabPosition"
                class="tabBtn-case01"
              >
                <el-radio-button label="1년" />
                <el-radio-button label="3년" />
                <el-radio-button label="5년" />
                <el-radio-button label="10년" />
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="게시여부">
              <el-select
                v-model="info.post"
                placeholder="전체"
              >
                <el-option
                  v-for="{ value, label } in code.post"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="내용">
              <el-select
                v-model="info.content"
                placeholder="전체"
                style="margin-right: 10px;"
              >
                <el-option
                  v-for="{ value, label } in code.content"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
              <el-input
                v-model="info.seach"
                class="seach-input"
              />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-table :data="list">
        <el-table-column
          label="파일"
          prop="file"
          align="center"
          width="100"
        >
          <template slot-scope="scope">
            <span v-if="scope.row.file === 'Y'">
              <i class="file_img" />
            </span>
            <span v-else />
          </template>
        </el-table-column>
        <el-table-column
          label="구분"
          prop="col1"
          align="center"
        >
          <template slot-scope="scope">
            <span
              v-if="scope.row.col1 === 'iportant'"
              class="text-red"
            >
              중요
            </span>
            <span v-else>일반</span>
          </template>
        </el-table-column>
        <el-table-column
          label="제목"
          prop="col2"
          width="500"
        />
        <el-table-column
          label="등록자"
          prop="col3"
          align="center"
        />
        <el-table-column
          label="등록일시"
          prop="col4"
          align="center"
        >
          <template slot-scope="scope">
            <router-link
              to="/"
              class="link"
            >
              {{ scope.row.col4 }}
            </router-link>
          </template>
        </el-table-column>
        <el-table-column
          label="게시기간"
          prop="col5"
          align="center"
        />
        <el-table-column
          label="공개여부"
          prop="col6"
          align="center"
        >
          <template slot-scope="scope">
            <span v-if="scope.row.col6 === 'Y'">공개</span>
            <span v-else>비공개</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </section>
</template>

<script>
export default {
  name: 'General',
  layout: 'default',
  data() {
    return {
      tabPosition: 'left',
      info:{
        date1: null,
        date2: null,
        post:{},
        content:{},
        seach:null
      },
      code:{
        post:[
          {value: 'post1', label:'전체'}
        ],
        content:[
          {value: 'content1', label:'전체'}
        ]
      },
      list:[
        {
          file: 'Y',
          col1: 'iportant',
          col2: '2019년 신차 구입 시 고객혜택 관련하여 공지합니다.',
          col3: '홍길동',
          col4: '2019-01-09 12:00',
          col5: '2019-01-01 ~ 2019-01-30',
          col6: 'Y'
        },
        {
          file: 'N',
          col1: 'N',
          col2: '2019년 신차 구입 시 고객혜택 관련하여 공지합니다.',
          col3: '홍길동',
          col4: '2019-01-09 12:00',
          col5: '2019-01-01 ~ 2019-01-30',
          col6: 'N'
        }
      ]
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~/assets/style/pages/notice.scss';
</style>

