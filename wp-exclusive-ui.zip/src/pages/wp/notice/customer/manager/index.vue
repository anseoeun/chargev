<template>
  <section>
    <div id="manager">
      <div class="btn-wrap">
        <div class="side">
          <el-button type="info" @click="resetSearchForm">
            초기화
          </el-button>
        </div>
        <div class="main">
          <el-button
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            @click="onSearch(1)"
          >
            조회
          </el-button>
          <el-button
            v-if="isValidAuthBtn('authManage')"
            type="primary"
            @click="goRegi"
          >
            등록
          </el-button>
        </div>
      </div>
      <el-form ref="searchForm" :model="searchForm" class="detail-form">
        <el-row>
          <el-col :span="24">
            <el-form-item label="등록일">
              <el-date-picker v-model="searchForm.noticeStartDt" type="date" />
              <span class="ex-txt">~</span>
              <el-date-picker v-model="searchForm.noticeEndtDt" type="date" />
              <el-radio-group
                v-model="tabPosition"
                class="tabBtn-case01"
                @change="onChangeSearchDtRadio"
              >
                <el-radio-button label="prevDay">
                  전일
                </el-radio-button>
                <el-radio-button label="today">
                  오늘
                </el-radio-button>
                <el-radio-button label="day7">
                  7일
                </el-radio-button>
                <el-radio-button label="day30">
                  30일
                </el-radio-button>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col
            v-if="userInfo.exclusiveUseAuthGroupId === 'M0002'"
            :span="12"
          >
            <el-form-item label="게시여부">
              <el-select v-model="searchForm.noticeYn" placeholder="전체">
                <el-option
                  v-for="{ value, label } in code.post"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col
            v-if="userInfo.exclusiveUseAuthGroupId === 'M0002'"
            :span="12"
          >
            <el-form-item label="내용">
              <el-select
                v-model="searchForm.searchType"
                placeholder="전체"
                style="margin-right: 10px;"
              >
                <el-option
                  v-for="{ value, label } in code.content"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
              <el-input v-model="searchForm.searchText" />
            </el-form-item>
          </el-col>
          <el-col v-else :span="24">
            <el-form-item label="내용">
              <el-select
                v-model="searchForm.searchType"
                placeholder="전체"
                style="margin-right: 10px;"
              >
                <el-option
                  v-for="{ value, label } in code.content"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
              <el-input v-model="searchForm.searchText" />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-table
        :data="noticeList"
        max-height="450"
        empty-text="조회 결과가 존재하지 않습니다."
        @row-click="handleRowClick"
      >
        <el-table-column
          prop="rowIndex"
          label="No."
          width="80"
          align="center"
        />
        <el-table-column label="파일" prop="fileYn" align="center" width="100">
          <template slot-scope="scope">
            <span v-if="scope.row.fileYn === 'Y'">
              <i class="file_img" />
            </span>
            <span v-else />
          </template>
        </el-table-column>
        <el-table-column
          label="구분"
          prop="noticeGrade"
          align="center"
          width="100"
        >
          <template slot-scope="scope">
            <!-- <span
              v-if="scope.row.col1 === 'iportant'"
              class="text-red"
            >
              중요
            </span>
            <span v-else>일반</span> -->
            <span v-if="scope.row.noticeGrade">
              {{ scope.row.noticeGrade }}
            </span>
          </template>
        </el-table-column>
        <el-table-column label="제목" prop="noticeTitle" />
        <el-table-column
          label="등록자"
          prop="userName"
          align="center"
          width="100"
        />
        <el-table-column
          label="등록일시"
          prop="regDate"
          align="center"
          width="240"
        />
        <el-table-column
          label="게시기간"
          prop="noticeDt"
          align="center"
          width="240"
        />
        <el-table-column
          v-if="userInfo.exclusiveUseAuthGroupId === 'M0002'"
          label="공개여부"
          prop="noticeYn"
          align="center"
          width="100"
        >
          <template slot-scope="scope">
            <span v-if="scope.row.noticeYn === 'Y'">공개</span>
            <span v-else>비공개</span>
          </template>
        </el-table-column>
      </el-table>
      <div class="btn-wrap">
        <div class="side" />
        <div class="pagination">
          <v-pagination
            v-if="noticeList.length"
            :page.sync="pageInfo.page"
            :size="pageInfo.size"
            :total="pageInfo.total"
            @page-change="onSearch"
          />
        </div>
        <div class="main" />
      </div>
    </div>
  </section>
</template>

<script>
import { mapGetters } from "vuex";
import moment from "moment";

export default {
  name: "Manager",
  layout: "default",
  data() {
    return {
      tabPosition: "day30",
      searchForm: {
        // 검색조건
        noticeStartDt: moment().subtract("day", 30), // 등록일 - 이전
        noticeEndtDt: moment(), // 등록일 - 현재
        searchType: "", // 조회 종류
        searchText: "", // 조회 내용
        noticeYn: "" // 게시여부
      },
      info: {
        date1: null,
        date2: null,
        post: {},
        content: {},
        seach: null,
        selO: "10"
      },
      code: {
        // TODO: 공통 코드에 존재한다면 추후에 교체
        post: [
          { value: "", label: "전체" },
          { value: "Y", label: "공개" },
          { value: "N", label: "비공개" }
        ],
        content: [
          { value: "", label: "전체" },
          { value: "10", label: "제목" },
          { value: "20", label: "본문" },
          { value: "30", label: "제목+본문" },
          { value: "40", label: "첨부파일명" }
        ]
      },
      noticeList: [], // 공지사항 목록
      pageInfo: {
        // paging info
        page: 1,
        size: 10,
        total: 0
      }
    };
  },
  computed: {
    ...mapGetters(["userInfo"])
  },
  watch: {
    $route: "fetchData"
  },
  created() {
    this.fetchData();
  },
  mounted() {
    this.$store.dispatch("loadUserInfo", { vm: this });
    this.onSearch(1);
  },
  methods: {
    fetchData() {
      if (
        this.$route.query.ruleDate &&
        this.$route.query.ruleDate === "today"
      ) {
        this.searchForm.noticeStartDt = moment();
        this.searchForm.noticeEndDt = moment();
      }
    },
    isValidAuthBtn(authId) {
      // 버튼별 권한 체크
      let bResult = false; // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || [];
      if (currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some(items => {
          if (items.btnId === authId) {
            bResult = true;
            return true;
          }
        });
      }
      return bResult;
    },
    goRegi() {
      // location.hash = '/notice/manager/write'
      this.$router.push("/notice/manager/write");
    },
    async getNoticeList() {
      const { page, size } = this.$data.pageInfo;
      const params = {
        pageNo: page,
        pageSize: size,
        ...this.searchForm,
        noticeStartDt: moment(this.searchForm.noticeStartDt).format("YYYYMMDD"),
        noticeEndtDt: moment(this.searchForm.noticeEndtDt).format("YYYYMMDD"),
        useAuthGroupId: this.userInfo.exclusiveUseAuthGroupId || ""
      };

      const [res, err] = await this.$https.get("/v2/exclusive/notice", params); //API-E-업무담당자-084 (공지사항 목록 조회)

      if (!err) {
        this.noticeList = res.data.list;

        // 게시기간 커스터마이징
        this.noticeList.map((items, idx) => {
          (items.noticeDt =
            moment(items.noticeStartDt).format("YYYY-MM-DD") +
            " ~ " +
            moment(items.noticeEndtDt).format("YYYY-MM-DD")),
            (items.rowIndex =
              res.data.total - res.data.endRow + this.noticeList.length - idx);
        });

        this.$data.pageInfo = {
          ...this.$data.pageInfo,
          total: res.data.total
        };
      }
    },
    onSearch(page) {
      if (!this.isValidAuthBtn("authSelect")) {
        // 권한없을경우 동작 x

        console.log("this!!");
        // return
      }

      this.$data.pageInfo.page = page;
      this.getNoticeList();
    },
    resetSearchForm() {
      Object.assign(this.$data.searchForm, this.$options.data().searchForm);
      this.tabPosition = "day30";
    },
    onChangeSearchDtRadio(val) {
      console.log(val);
      switch (val) {
        case "prevDay":
          this.searchForm.noticeStartDt = moment().subtract("days", 1);
          this.searchForm.noticeEndtDt = moment().subtract("days", 1);
          break;
        case "today":
          this.searchForm.noticeStartDt = moment();
          this.searchForm.noticeEndtDt = moment();
          break;
        case "day7":
          this.searchForm.noticeStartDt = moment().subtract("days", 7);
          this.searchForm.noticeEndtDt = moment();
          break;
        case "day30":
          this.searchForm.noticeStartDt = moment().subtract("days", 30);
          this.searchForm.noticeEndtDt = moment();
          break;
      }
    },
    handleRowClick(val) {
      console.log("handleRowClick", val.noticeSerialNumber);
      this.$router.push({
        name: "notice-manager-detail",
        params: { noticeSerialNumber: val.noticeSerialNumber }
      });
    }
  }
};
</script>

<style lang="scss" scoped>
@import "~/assets/style/pages/notice.scss";
</style>
