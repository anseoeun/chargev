<template>
  <section>
    <div id="release">
      <div class="article-title">
        <el-button type="primary">초기화</el-button>
        <el-button
          type="primary"
          v-if="isValidAuthBtn('authSelect')"
          @click="getOneData"
          >조회</el-button
        >
      </div>
      <div class="box">
        <el-form
          ref="info"
          class="detail-form table-wrap"
          @submit.prevent.native
        >
          <el-row>
            <el-col :span="8">
              <el-form-item label="이름">
                <el-input v-model="customerSearchForm.mbrNm"
                @keyup.native.enter="getOneData"
                @blur="customerSearchForm.mbrNm = $event.target.value"
                 />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="생년월일">
                <el-date-picker
                  type="date"
                  v-model="customerSearchForm.brdyYmd"
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="휴대전화">
                <el-input v-model="customerSearchForm.hpTn" @keyup.native.enter="getOneData" />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <!--  <el-form
        class="detail-form"
        @submit.prevent.native
      >
        <el-row>
          <el-col :span="24">
            <el-form-item
              label="사번"
              :class="conpanyNum"
            >
              <el-input
                v-model="ruleForm.employeeNumber"
                class="conpanyNumInput"
                @keyup.enter.native="getOneData"
              />
              <el-button
                v-if="isValidAuthBtn('authSelect')"
                type="primary"
                @click="getOneData"
              >
                조회
              </el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form> -->
      <article class="article">
        <h-title :title="'조회결과'" />
        <h-table
          :table-type="'DefultTable'"
          :table-header="onerowHeader"
          :table-datas="onerowdata"
          class="seach_result"
          :height="100"
        />
        <!-- 직원계약출고 목록 테이블 -->
        <div class="article-title gap">
          <div>
            <el-form :model="dateInfo" class="search-form">
              <el-row>
                <el-col :span="24">
                  <el-date-picker v-model="dateInfo.regStartDate" type="date" />
                  <span class="ex-txt"> ~ </span>
                  <el-date-picker v-model="dateInfo.regEndDate" type="date" />
                  <el-radio-group
                    v-model="searchDtRadio"
                    class="tabBtn-case01"
                    @change="onChangeSearchDtRadio"
                  >
                    <el-radio-button label="1year">
                      1년
                    </el-radio-button>
                    <el-radio-button label="3years">
                      3년
                    </el-radio-button>
                    <el-radio-button label="5years">
                      5년
                    </el-radio-button>
                    <el-radio-button label="10years">
                      10년
                    </el-radio-button>
                  </el-radio-group>

                  <el-button
                    v-if="isValidAuthBtn('authSelect')"
                    type="primary"
                    class="btn-small space"
                    @click="onSearch(1)"
                  >
                    조회
                  </el-button>
                </el-col>
              </el-row>
            </el-form>
          </div>
        </div>
        <div class="box">
          <el-table
            :data="contractListData"
            max-height="450"
            empty-text="조회 결과가 존재하지 않습니다."
          >
            <el-table-column
              label="판매모델코드"
              prop="saleCarCtyNo"
              align="center"
              width="300"
            />
             <!--  <template slot-scope="props">
                <el-tooltip placement="bottom" effect="light">
                  <div slot="content">
                    <el-row>
                      <el-col :span="24">
                        {{ props.row.saleCarCtyNo }}
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="6" class="tooltip-title">
                        {{ toolTipContent.ttCarNameM }}
                      </el-col>
                      <el-col :span="18">
                        {{ props.row.saleModelName }}
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="6" class="tooltip-title">
                        {{ toolTipContent.ttCarColorT }}
                      </el-col>
                      <el-col :span="18" class="tooltip-title">
                        {{ props.row.exteriorColorName }}
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="6">
                        {{ toolTipContent.ttCarColor2T }}
                      </el-col>
                      <el-col :span="18">
                        {{
                          !props.row.realityInteriorColorName
                            ? props.row.interiorColorName
                            : props.row.realityInteriorColorName
                        }}
                      </el-col>
                    </el-row>
                  </div>
                  <el-button type="text">
                    {{ props.row.representativeCarName | capitalize }}
                  </el-button>
                </el-tooltip>
              </template>  -->
            <el-table-column
              label="계약번호"
              prop="cnttNo"
              align="center"
              width="250"
            >
              <template slot-scope="scope">
                <router-link
                  :to="{
                    name: 'contract-release-detail',
                    params: { contractNumber: scope.row.cnttNo }
                  }"
                  class="link"
                >
                  {{ scope.row.cnttNo }}
                </router-link>
              </template>
            </el-table-column>
            <el-table-column
              label="출고일"
              sortable
              prop="whotDt"
              align="center"
              width="250"
            />
            <el-table-column
              label="의무보유기간"
              prop="dutyHoldPeriod"
              align="center"
              width="350"
            />
            <el-table-column
              label="직원할인여부"
              prop="eeDcYn"
              align="center"
              width="150"
            />
            <el-table-column
              label="판매구분"
              prop="saleType"
              align="center"
              width="235"
            />
          </el-table>
        </div>
        <!-- <div class="btn-wrap">
          <div class="side" />
          <div class="pagination">
            <v-pagination
              v-if="contractListData.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch"
            />
          </div>
          <div class="main" />
        </div> -->
      </article>
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import HTitle from "~/components/common/HTitle.vue";
import HTable from "~/components/common/HTable.vue";
import PopMessage from "~/components/popup/PopMessage.vue";
import moment from "moment";

export default {
  name: "Release",
  layout: "default",
  components: {
    HTitle,
    HTable,
    PopMessage
  },
  data() {
    return {
      alertMessage: "",
      alertMessagePop: false,
      conpanyNum: "conpanyNum",
      searchDtRadio: "3years",
      ruleForm: {
        searchStartDate: "",
        searchEndDate: ""
      },
      customerSearchForm: {
        mbrNm: "",
        brdyYmd: "",
        hpTn: ""
      },
      dateInfo: {
        regStartDate: moment().subtract("years", 3),
        regEndDate: moment().subtract()
      },
      onerowdata: [],
      onerowHeader: [
        {
          label: "고객관리번호",
          type: "",
          prop: "csmrMgmtNo",
          align: "center"
        },
        {
          label: "이름",
          type: "",
          prop: "mbrNm",
          align: "center"
        },
        {
          label: "생년월일",
          type: "",
          prop: "brdyYmd",
          width: 150,
          align: "center"
        },
        {
          label: "소속",
          type: "",
          prop: "division",
          align: "center"
        },
        {
          label: "할인율",
          type: "",
          prop: "dcRate",
          align: "center"
        }
      ],
      toolTipContent: {
        ttCarNameM: "모델",
        ttCarColorT: "외장컬러",
        ttCarColor2T: "내장컬러"
      },
      selectedCustomer: [],
      contractListData: [],
      pageInfo: {
        // paging info
        page: 1,
        size: 20,
        total: 0
      }
    };
  },
  methods: {
    isValidAuthBtn(authId) {
      // 버튼별 권한 체크
      let bResult = false; // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || [];
      if (currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some(items => {
          if (items.btnId === authId) {
            bResult = true;
            return true;
          }
        });
      }
      return bResult;
    },
    onSearch(page) {
      if (!this.isValidAuthBtn("authSelect")) {
        // 권한없을경우 동작 x
        return;
      }

      this.$data.pageInfo.page = page;
      this.getAlldata();
    },
    async getOneData() {
      if (!this.isValidAuthBtn("authSelect")) {
        // 권한없을경우 동작 x
        return;
      }

      if (
        this.customerSearchForm.mbrNm === "" &&
        this.customerSearchForm.brdyYmd === "" &&
        this.customerSearchForm.hpTn === ""
      ) {
        this.alertMessage = "검색정보를 입력해주세요.";
        this.alertMessagePop = true;
        return;
      } else if (
        (this.customerSearchForm.mbrNm != "" &&
          this.customerSearchForm.brdyYmd === "") ||
        (this.customerSearchForm.mbrNm === "" &&
          this.customerSearchForm.brdyYmd != "")
      ) {
        this.alertMessage = "이름과 생년월일을 함께 입력해주세요.";
        this.alertMessagePop = true;
        return;
      }

      //검색결과 회원 리스트
      this.customerInfoList = [];
      /* this.customerSearchForm.brdyYmd = this.$moment(
        this.customerSearchForm.brdyYmd
      ).format("YYYYMMDD"); */

      const hInfoParams = {
        mbrNm: this.customerSearchForm.mbrNm,
        brdyYmd: this.$moment(
        this.customerSearchForm.brdyYmd
      ).format("YYYYMMDD"),
        hpTn: this.customerSearchForm.hpTn.replace(/-/gi, '')
      };

      console.log(hInfoParams)

      //params 빈값 제거
      Object.keys(hInfoParams).forEach(
        k =>
          !hInfoParams[k] &&
          hInfoParams[k] !== undefined &&
          delete hInfoParams[k]
      );

      //현대닷컴 고객정보
      const [res1, err1] = await this.$https.post(
        "/customer-info/v2/customer-info/hdot/customerInfo",
        hInfoParams,
        null,
        "gateway"
      );

      if (err1 || res1.data.customerInfo === null) return;

      if(res1.data.customerInfo.length > 0){
      //고객 검색결과 가공용 정보
        const [res2, err2] = await this.$https.post(
          "/v2/customer-center/wmall-employee-dc/customer",
          res1.data.customerInfo,
          null,
          "cscenter"
        );

        if (err2 || res2.data === null) return;

        this.onerowdata = [...res2.data];

        if (this.onerowdata === 0) return;

        if (this.onerowdata.length === 1) {
          // 한건이면 자동으로 아래 상세 표현
          this.isSearchBtn = true;
          this.selectedCustomer = this.onerowdata[0];
          this.getAlldata();
        }
      }

      //   this.getAlldata();
    },
    async getAlldata() {
      this.contractListData = [];
      if (
        this.customerSearchForm.mbrNm === "" &&
        this.customerSearchForm.brdyYmd === "" &&
        this.customerSearchForm.hpTn === ""
      ) {
        this.alertMessage = "검색정보를 입력해주세요.";
        this.alertMessagePop = true;
      } else if (
        (this.customerSearchForm.mbrNm != "" &&
          this.customerSearchForm.brdyYmd === "") ||
        (this.customerSearchForm.mbrNm === "" &&
          this.customerSearchForm.brdyYmd != "")
      ) {
        this.alertMessage = "이름과 생년월일을 함께 입력해주세요.";
        this.alertMessagePop = true;
      } else if (!this.dateInfo.regStartDate || !this.dateInfo.regEndDate) {
        this.alertMessage = "날짜는 필수입력 사항입니다.";
        this.alertMessagePop = true;
      } else {
        const tempstart = moment(this.dateInfo.regStartDate);
        const tempend = moment(this.dateInfo.regEndDate);

        const daycheck = moment.duration(tempend.diff(tempstart)).asDays();

        if (daycheck < 0) {
          this.alertMessage = "시작 기간 및 종료 기간을 확인해주세요.";
          this.alertMessagePop = true;
          return;
        }

        const params = {
          searchStartDate : this.$moment(
          this.dateInfo.regStartDate
        ).format("YYYYMMDD"),
          searchEndDate : this.ruleForm.searchEndDate = this.$moment(
          this.dateInfo.regEndDate
        ).format("YYYYMMDD"),
          csmrMgmtNo : this.selectedCustomer.csmrMgmtNo,
        }
      /*   const params = {
          ...this.pageInfo,
          ...this.ruleForm,
          customerUniqueNo: this.selectedCustomer.customerUniqueNo
        };
 */
        // API-E-업무담당자-073 (직원계약출고 목록조회)
        const [res, err] = await this.$https.post(
          "/v2/customer-center/wmall-employee-dc/contract",
          params,
          null,
          "cscenter"
        );
        console.log("params", params);

        if (!err) {
          if (!res.data || res.data.length === 0) {
            this.contractListData = [];
          } else {
            this.contractListData = [...res.data];

           /*  if (this.pageInfo.total === 0) {
              this.pageInfo.pageNo = 1;
              this.pageInfo.pageSize = 20;
            } */

            /*    if (this.ruleForm.searchStartDate.length === 8)
              this.ruleForm.searchStartDate = this.$moment(
                this.ruleForm.searchStartDate
              ).format("YYYY-MM-DD");

            if (this.ruleForm.searchEndDate.length === 8)
              this.ruleForm.searchEndDate = this.$moment(
                this.ruleForm.searchEndDate
              ).format("YYYY-MM-DD"); */
            /* 
            this.contractListData = res.data.list.map((el, idx) => {
              return {
                ...el,
                no:
                  res.data.total - res.data.endRow + res.data.list.length - idx,
                purchaseAvailableDate: el.purchaseAvailableDate
                  ? el.purchaseAvailableDate.slice(0, 10)
                  : "",
                cancelDate: el.cancelDate ? el.cancelDate.slice(0, 10) : "",
                saleCancelDate: el.saleCancelDate
                  ? el.saleCancelDate.slice(0, 10)
                  : ""
              };
            });

            this.$data.pageInfo = {
              ...this.$data.pageInfo,
              total: res.data.total
            }; */
            console.log("table: ", this.contractListData);
          }
        } else {
          console.error(err);
          this.contractListData = [];
        }
      }
    },
    onChangeSearchDtRadio(val) {
      if (val === "1year") {
        this.dateInfo.regStartDate = moment().subtract("years", 1);
        this.dateInfo.regEndDate = moment();
      } else if (val === "3years") {
        this.dateInfo.regStartDate = moment().subtract("years", 3);
        this.dateInfo.regEndDate = moment();
      } else if (val === "5years") {
        this.dateInfo.regStartDate = moment().subtract("years", 5);
        this.dateInfo.regEndDate = moment();
      } else if (val === "10years") {
        this.dateInfo.regStartDate = moment().subtract("years", 10);
        this.dateInfo.regEndDate = moment();
      }
    }
  }
};
</script>

<style lang="scss" scoped>
@import "~/assets/style/pages/support/release.scss";
</style>
