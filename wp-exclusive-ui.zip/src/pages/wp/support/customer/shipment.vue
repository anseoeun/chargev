<template>
  <section>
    <div id="shipment">
      <div class="btn-wrap">
        <div class="side">
          <el-button
            type="info"
            @click="resetCond"
          >
            초기화
          </el-button>
        </div>

        <div class="excel">
          <el-button
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            @click="onSearch(1)"
          >
            조회
          </el-button>
          <el-button
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            class="excel"
            @click="downloadExcel"
          >
            Excel 다운로드
          </el-button>
        </div>
      </div>
      <el-form
        ref="ruleForm"
        :model="ruleForm"
        class="detail-form"
      >
        <el-row>
          <el-col :span="6">
            <el-form-item label="기준연월">
              <el-date-picker
                v-model="ruleForm.standardYearMonthDay"
                type="month"
              />
            </el-form-item>
          </el-col>
          <el-col :span="18">
            <el-form-item label="" />
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <el-form-item label="업무담당자">
              <el-select
                v-model="ruleForm.consultantId"
                placeholder="전체"
              >
                <el-option
                  v-for="{ sysUserNo, sysUserNm } in authConsultants"
                  :key="sysUserNo"
                  :value="sysUserNo"
                  :label="sysUserNm"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="TAX구분">
              <el-select
                v-model="ruleForm.taxTypeCode"
                placeholder="전체"
              >
                <el-option
                  v-for="{ value, label } in LegacyCommonCodes.C030 && LegacyCommonCodes.C030.slice(1)"
                  :key="value"
                  :value="value"
                  :label="value+' '+label"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="진행상태">
              <el-select
                v-model="ruleForm.statusCode"
                placeholder="전체"
              >
                <el-option
                  v-for="{ value, label } in commonCodes.T024"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>

      <el-table
        :data="tableList"
        max-height="450"
        empty-text="조회 결과가 존재하지 않습니다."
      >
        <el-table-column
          label="TAX 구분"
          prop="taxTypeCode"
          width="100"
          align="center"
        />
        <el-table-column
          label="계약번호"
          prop="contractId"
          width="200"
          align="center"
        >
          <template slot-scope="props">
            <a
              class="link"
              href="/#/support/duty-free"
              target="_blank"
              @click="$utils.setLocalStorage({ contractNumber: props.row.contractId })"
            >
              {{ props.row.contractId }}
            </a>
          </template>
        </el-table-column>
        <el-table-column
          label="주계약자"
          prop="contractorName"
          width="150"
          align="center"
        />
        <el-table-column
          label="이메일"
          prop="contractorEmail"
          width="150"
          align="center"
        />
        <el-table-column
          label="출고일"
          prop="releaseDate"
          width="170"
          align="center"
        />
        <el-table-column
          label="제작증 발급일"
          prop="certificateIssueDate"
          width="170"
          align="center"
        />
        <el-table-column
          label="진행상태"
          prop="statusName"
          align="center"
        />
        <el-table-column
          label="접수일자"
          prop="submitDate"
          width="170"
          align="center"
        />
        <el-table-column
          label="업무담당자"
          prop="consultantName"
          width="150"
          align="center"
        />
      </el-table>
      <div class="btn-wrap">
        <div class="side"></div>
        <div class="pagination">
          <v-pagination
            v-if="tableList.length"
            :page.sync="pageInfo.page"
            :size="pageInfo.size"
            :total="pageInfo.total"
            @page-change="onSearch"
          />
        </div>
        <div class="main"></div>
      </div>
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import moment from 'moment'
import { mapState } from 'vuex'
import PopMessage from '~/components/popup/PopMessage.vue'

export default {
  name: 'Shipment',
  layout: 'default',
  components: {
    PopMessage
  },
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      ruleForm:{
        standardYearMonthDay:moment(),
        consultantId: '',
        taxTypeCode: '',
        statusCode:'all',
      },
      tableList:[],
      commonCodes: {},
      LegacyCommonCodes: {},
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      }
    }
  },
  computed:{
    ...mapState(['authConsultants', 'userInfo']),

    authConsultants: function() {
      const authConsultants = this.$store.state.authConsultants.slice()
      if(authConsultants && authConsultants.length > 0) {
        authConsultants.unshift( { 'useAuthId': '', 'sysUserNo': '', 'sysUserNm': '전체', 'opsNm': '' } )
      }
      return authConsultants
    }
  },
  async created() {
    await this.loadCommonCode()
  },
  mounted(){
    this.$store.dispatch('loadAuthConsultants', {vm: this})
    this.$store.dispatch('loadUserInfo', { vm: this})
  },
  methods:{
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null
      switch(systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {vm: this, codeTypeCode: codeType})
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {vm: this, codeTypeCode: codeType})
        break
      }
      return res
    },
    async loadCommonCode() {
      const [ccT024, ccC030] = await Promise.all([
        this.fetchCommonCodeData('E', 'T024'),
        this.fetchCommonCodeData('C', 'C030')
      ])
      this.commonCodes = { ...ccT024 }
      this.LegacyCommonCodes = { ...ccC030 }
    },
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    resetCond(){
      Object.assign(this.ruleForm,this.$options.data().ruleForm)
    },
    onSearch(page) {
      this.$data.pageInfo.page = page
      this.getShipmentList()
    },
    async getShipmentList(){

      if(!this.ruleForm.standardYearMonthDay){
        this.alertMessage = '기간은 필수 기입 사항입니다.'
        this.alertMessagePop = true
        return
      }

      const { page, size } = this.$data.pageInfo

      const params = {
        pageNo: page,
        pageSize: size,
        standardYearMonthDay:moment(this.ruleForm.standardYearMonthDay).format('YYYYMM'),
        consultantId: this.ruleForm.consultantId,
        taxTypeCode:this.ruleForm.taxTypeCode,
        statusCode:this.ruleForm.statusCode==='all'?'':this.ruleForm.statusCode,

      }

      const [res, err] = await this.$https.post('/v2/exclusive/support/tax-free-list-customer', params)

      if(!err){
        if(!res.data.list||res.data.list.length===0){
          this.tableList = []
        }else{
          this.tableList=res.data.list.map((el)=>{
            return {
              ...el
            }
          })

          this.$data.pageInfo = {
            ...this.$data.pageInfo,
            total: res.data.total
          }

        }

      }else{
        console.error(err)
        this.tableList = []
      }

    },
    async downloadExcel() {
      const params = {
        standardYearMonthDay:moment(this.ruleForm.standardYearMonthDay).format('YYYYMM'),
        consultantId: this.ruleForm.consultantId,
        taxTypeCode:this.ruleForm.taxTypeCode,
        statusCode:this.ruleForm.statusCode==='all'?'':this.ruleForm.statusCode,
        postponeYn:this.ruleForm.postponeYn==='all'?'':this.ruleForm.postponeYn,
      }

      const [res,err] = await this.$https.post('/v2/exclusive/support/tax-free-excel-customer', params, null, null, { responseType: 'blob' })
      if(!err) {
        const blob = new Blob([res], {type : res.Type })
        const nowDate = moment().format('YYYYMMDD_HHmm')
        if(window.navigator.msSaveOrOpenBlob) {
          // IE11
          window.navigator.msSaveOrOpenBlob(blob, '대고객 면세반출조회목록_' + nowDate + '.xlsx')
        } else {
          // IE11 외 브라우저
          const blobURL = window.URL.createObjectURL(blob)
          const tempLink = document.createElement('a')

          tempLink.href = blobURL

          tempLink.setAttribute('download', '대고객 면세반출조회목록_' + nowDate + '.xlsx')
          document.body.appendChild(tempLink)
          tempLink.click()
          document.body.removeChild(tempLink)
          window.URL.revokeObjectURL(blobURL)
        }
      } else {
        console.error(err)
      }
    },
  }
}
</script>

<style lang="scss" scoped>
  ::v-deep.detail-form{
    margin: 20px 0;
  }
</style>


