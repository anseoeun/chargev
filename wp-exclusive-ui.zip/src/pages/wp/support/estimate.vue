<template>
  <section>
    <div id="support">

      <div class="article-title">
        <el-button 
          type="primary"
          @click="resetSearchCond"
        >
          초기화
        </el-button>
        <div>
          <el-button type="primary" @click="getEstimateData">조회</el-button>
          <el-button type="primary" @click="openPopup">등록</el-button>
        </div>
      </div>
      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="24">
              <el-form-item label="생성일">
                <el-date-picker 
                  v-model="searchForm.estStartDtm"
                  type="date" />
                <span class="ex-txt">~</span>
                <el-date-picker 
                  v-model="searchForm.estEndDtm"
                  type="date" />
                <el-radio-group 
                    v-model="searchForm.searchDtRadio" 
                    class="tabBtn-case01"
                    @change="onChangeSearchDtRadio"
                >
                  <el-radio-button label="lastDay">어제</el-radio-button>
                  <el-radio-button label="today">오늘</el-radio-button>
                  <el-radio-button label="day7">7일</el-radio-button>
                  <el-radio-button label="day30">30일</el-radio-button>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="차종">
                <el-select
                    v-model="searchForm.carTypeCode"
                    placeholder="전체"
                    @change="onChangeCarType"
                >
                  <el-option 
                    v-for="{ carTypeCode, carTypeName } in carTypes"
                    :key="carTypeCode"
                    :value="carTypeCode"
                    :label="carTypeName"
                    ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="차명">
                <el-select
                    v-model="searchForm.carCode"
                    placeholder="전체"
                >
                  <el-option
                    v-for="{ repnCarCode, repnCarName, disabled } in selTypeCars"
                    :key="repnCarCode"
                    :value="repnCarCode"
                    :label="repnCarName"
                    :disabled="disabled"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="사번">
                <el-input 
                 v-model="searchForm.exrsCnstEeno"
                 @keyup.native.enter="getEstimateData"
                />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <div class="box gap">
        <el-table 
          :data="estimateInfo"
          empty-text="조회된 결과가 존재하지 않습니다."
        >
          <el-table-column prop="no" label="NO." width="80" align="center"></el-table-column>
          <el-table-column prop="carEstNo" label="대행견적번호" width="140" align="center">
            <template slot-scope="props">
              <a
                class="link"
                href="#"
                @click="estimatePopup('detail', props.row.estShareUrl)"
              >
                {{ props.row.carEstNo }}
              </a>
            </template>
          </el-table-column>
          <el-table-column prop="saleMdlNm" label="모델" width="439" align="center"></el-table-column>
          <el-table-column prop="estDtm" label="생성일" width="150" align="center"></el-table-column>
          <el-table-column prop="sendDtm" label="발송일(최종)" width="150" align="center"></el-table-column>
          <el-table-column prop="exrsCnstEeno" label="사번" width="140" align="center"></el-table-column>
          <el-table-column prop="msgCnt" label="발송건수" width="110" align="center">
            <template slot-scope="props">
              <a
                  class="link"
                  href="/#/wp/support/estimate-detail"
                  target="_blank"
                  @click="
                   $utils.setLocalStorage({estimateNumber: props.row.carEstNo, activeName: 'message'})
                  "
                > 
                  {{ props.row.msgCnt }}
                </a>
              </template>
          </el-table-column>
          <el-table-column prop="estCnt" label="견적건수" width="110" align="center">
            <template slot-scope="props">
              <a
                  class="link"
                  href="/#/wp/support/estimate-detail"
                  target="_blank"
                  @click="
                   $utils.setLocalStorage({estimateNumber: props.row.carEstNo, activeName: 'estimate'})
                  "
                > 
                  {{ props.row.estCnt }}
                </a>
              </template>
          </el-table-column>
          <el-table-column prop="contractCnt" label="계약건수" width="110" align="center"><template slot-scope="props">
              <a
                  class="link"
                  href="/#/wp/support/estimate-detail"
                  target="_blank"
                  @click="
                   $utils.setLocalStorage({estimateNumber: props.row.carEstNo, activeName: 'contract'})
                  "
                > 
                  {{ props.row.contractCnt }}
                </a>
              </template>
          </el-table-column>
          <el-table-column prop="saleCnt" label="판매건수" width="110" align="center"> </el-table-column>
        </el-table>
        <div class="btn-wrap">
          <div class="side"></div>
          <div class="pagination">
            <v-pagination
              v-if="estimateInfo.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch"
            />
          </div>
          <div class="main"></div>
        </div>
      </div>
      <loading
        :pop-visible.sync="popVisibleLoading"
        :close-on-click-modal="false"
        @close="popVisibleLoading = false"
      />
      <pop-message
        :pop-visible.sync="alertMessagePop"
        :pop-message.sync="alertMessage"
        @confirm="alertMessagePop = false"
        @close="alertMessagePop = false"
      />

    <el-dialog title="대행견적 차량선택 변경" :visible.sync="popVisibleStock" width="1100px">
      <estimate-popup 
        ref="estimatePop"
        @loading="popVisible"
        />
      <!-- Popup Footer -->
      <template slot="footer">
        <div>
          <el-button type="info" @click="popVisibleStock = false">취소</el-button>
          <el-button type="primary" @click="oneClickDisable($event, doEstimate)">선택</el-button>
        </div>
      </template>
    </el-dialog>
    </div>
  </section>
</template>

<script>
import moment from 'moment'
import { mapGetters } from 'vuex'
import Loading from '~/components/popup/Loading.vue'
import PopMessage from '~/components/popup/PopMessage.vue'
import estimatePopup from '~/components/popup/AgencyEstimatePopup.vue'
export default {
  components: {
    Loading,
    PopMessage,
    estimatePopup,
  },
  layout: 'default', 
  data() {
    return {
      popVisibleLoading: false, // 로딩 활성화 여부
      popVisibleStock: false, // 대행견적 등록 버튼
      alertMessage: '',
      alertMessagePop: false,
      searchForm : {
        estStartDtm: moment().subtract('days', 30),
        estEndDtm: moment(),
        carMdlCd: '',
        exrsCnstEeno: '',
        carTypeCode: 'all', // 차종
        carCode: 'all', // 차명
        searchDtRadio: 'day30',
      },
      selTypeCars: [{ repnCarCode: 'all', repnCarName: '전체' }],
      estimateInfo: [],
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      },
      popupTest: '',
    }
  },
  computed: {
    ...mapGetters(['userInfo']),
    carTypes: function() {
      const carTypes = this.$store.state.carTypes
      if(carTypes && carTypes.length > 0) {
        carTypes.shift()
        carTypes.unshift({ 'carTypeCode': 'all', 'carTypeName': '전체' })
      }
      return carTypes
    },
  },
  mounted() {
    this.$store.dispatch('loadAllTypeCars', {vm: this})
  },
  methods: {
    async getEstimateData() {
      /**대행견적 데이터 조회 */
      this.popVisibleLoading = true //로딩 활성화

      const { page, size } = this.$data.pageInfo
      const params = {
        pageNo: page,
        pageSize: size,
        estStartDtm: moment(this.searchForm.estStartDtm).format('YYYYMMDD'),
        estEndDtm: moment(this.searchForm.estEndDtm).format('YYYYMMDD'),
        carTypeCode: this.searchForm.carTypeCode !== 'all' ? this.searchForm.carTypeCode : '',
        carCode: this.searchForm.carCode !== 'all' ? this.searchForm.carCode : '',
        exrsCnstEeno: this.searchForm.exrsCnstEeno,
      }

      const [res, err] = await this.$https.post('/v2/exclusive/support/agency-estimate', params)
      if(!err){ 
        if(res.data && res.data.list) {
          this.estimateInfo = res.data.list.map((el, idx) => {
            return{
              ...el,
              no : res.data.total - res.data.endRow + res.data.list.length - idx,
              isSelected: false,
              carEstNo: el.carEstNo,
              saleMdlNm: el.saleMdlNm,
              estShareUrl: el.estShareUrl,
              estDtm: el.estDtm,
              sendDtm: el.sendDtm,
              exrsCnstEeno: el.exrsCnstEeno,
              estCnt: el.estCnt,
              contractCnt: el.contractCnt,
              saleCnt: el.saleCnt,
              msgCnt: el.msgCnt,
            }
          })
          this.$data.pageInfo = {
            ...this.$data.pageInfo,
            total: res.data.total
          }
        }
      }else{
        console.error('/support/agency-estimate ERROR ::: '+err)
      }
      this.popVisibleLoading = false //로딩 활성화

    },
    async onChangeCarType(carTypeCode) {
    /**선택한 차종에 따른 대표차 조회 */
      this.searchForm.carCode = 'all'

      let arr = []
      const params={
        imageSectionCode: '01',
        siteTypeCode: 'W',
        carTypeCode: carTypeCode,
        carPurposeCode: '',
        menuTypeCode:'',
      }
      const [res, err] = await this.$https.get('/product/v2/product/car/type/purpose', params, null, 'gateway')
      if(!err) {
        if(res.data && res.rspStatus.rspCode === '0000') {
          arr = res.data.map((items) => {
            return {
              repnCarCode: items.carCode,
              repnCarName: items.carName, 
              disabled: items.carAbbreviation === 'AX' ? false : true 
            }
          })
          arr.unshift({ 'repnCarCode': 'all', 'repnCarName': '전체' })
        }
      }else {
        console.error('exclusive :: /product/v2/product/car/type/purpose ERROR !! '+err)
      }

      this.selTypeCars = arr
    },
    async doEstimate() {
      /**대행견적 등록 - 차량선택 후 가견적 API 조회 */
      const selectedCarInfo = this.$refs.estimatePop.selectedCarInfo
      const carPriceInfo = this.$refs.estimatePop.carPriceInfo
      const activeTab = this.$refs.estimatePop.activeTab

      let params = null
      if(activeTab === 'product') { //생산차
        if(!selectedCarInfo.interiorColorCode) {
          this.alertMessage = '차종구분~내장색상 까지는 필수값입니다.'
          this.alertMessagePop = true
          
          return
        }else {
          let optionMixCode = selectedCarInfo.optionMixCode.join(',')
          let tuixOptionCode = selectedCarInfo.tuixOptionCode.join(',')
          let tuixOptionData = selectedCarInfo.tuixOptionData.join(',')

          if(tuixOptionData) {
            tuixOptionCode  = selectedCarInfo.tuixOptionCode.length  ? tuixOptionCode + ','+ tuixOptionData : tuixOptionData
          }

          
          console.log('tuixOptionCode ::: ' +tuixOptionCode)

          const { repnCar, saleModelCode, interiorColorCode, exteriorColorCode, realityInteriorColorCode } = selectedCarInfo
          const { carPrice } = carPriceInfo

          console.log('repnCar: '+repnCar+', '+'saleModelCode: '+saleModelCode+', '+'interiorColorCode: '+interiorColorCode+', '+'exteriorColorCode: '+exteriorColorCode+', '+'realityInteriorColorCode: '+realityInteriorColorCode)
          console.log('carPrice: '+carPrice)

          params = {
            carCode: repnCar, //대표차코드(4자리)
            carPrice, //차량가격
            saleModelCode, //판매모델코드
            optionMixCode, //옵션조합코드
            tuixOptionCode, //파츠조합코드
            interiorColorCode, //내장색상코드
            exteriorColorCode, //외장색상코드
            realityInteriorColorCode, //내장색상코드
            exrsCnstEeno: this.userInfo.eeno, //전담사원번호
            estimationTypeCode:'EX', //견적구분코드
            estimationStoreSectionCode:'10', //견적저장구획코드(10:가견적,20:견적최종저장)
            estimationCarTypeCode:'50', //견적차량유형코드(10:일반재고,20:할인재고,30:전시재고,40:판촉재고,50:생산차량)
            systemTypeCode:'W' //사이트구분코드
          }
        }
      }else { //일반재고차, 기획전
        if(!selectedCarInfo.preEstimateInfo) {
          this.alertMessage = '차량을 선택하세요.'
          this.alertMessagePop = true
          
          return
        }else {
          params = selectedCarInfo.preEstimateInfo
        }
      }

      /**가견적 시행 API */
      const [res, err] = await this.$https.post('/estimation/v2/estimation/temporary-storage', params, null, 'gateway')
      if(!err) {
        if(res.data && res.data.estimationUrl){  
          /** 가견적 시행 후 견적내기(FO) 페이지 오픈 */
          this.estimatePopup('estimate',res.data.estimationUrl)
        }
      }else {
        console.error('/estimation/v2/estimation/temporary-storage ERROR ::: '+err)
      }
    },
    estimatePopup(type, url) {
      /**공유견적보기(FO) 팝업 오픈 */
      let preffixUrl = 'http://10.7.137.110/dev/casper'
      if (['stg', 'dev', 'prod'].includes(process.env.VUE_APP_PROFILE)) {
        preffixUrl = process.env.VUE_APP_BASEURL_FRONT
      }

      let fullUrl = ''
      if(type === 'share') {
        fullUrl = preffixUrl + '/estimation/share?estimationUrl='+url
      }else if(type === 'detail') {
        fullUrl = preffixUrl + '/estimation/detail?estimationUrl='+url
      }else {
        fullUrl = preffixUrl+ '/estimation/exclusive?estimationUrl='+url
      }
      
      let width = 1400
      let height = 1000
      let clientWidth = document.body.clientWidth
      let clientHeight = document.body.clientHeight
      let winX = window.screenX || window.screenLeft || 0
      let winY = window.screenY || window.screenTop || 0
      let left = winX + (clientWidth - width) / 2
      let top = winY + (clientHeight - height) / 2

      let browser = window.navigator.userAgent.toLowerCase()
      if(browser.indexOf('trident') !== -1 ) { //IE의 경우
        console.log('Internet Explorer')
        fullUrl = '/#/wp/support/agency-estimate?estimationUrl='+url
      }

      //window 팝업 오픈
      this.popupTest = window.open(fullUrl, 'popup', 'top='+top+ ',left='+left+ ',width='+width+ ',height='+height+ ', scrollbars=yes, status=no, menubar=no, toolbar=no')

      window.addEventListener('message', this.refresh)
    },
    refresh(e) {
      console.log(e)
      
      window.removeEventListener('message', this.refresh)
      
      this.alertMessage = '견적이 저장되었습니다.'
      this.alertMessagePop = true
      
      this.popVisibleStock = false

      this.popupTest.close()

      //this.getEstimateData()
    },
    onSearch(page) {
      /** 페이지 이동 */
      this.$data.pageInfo.page = page
      this.getEstimateData()
    },
    openPopup() {
      this.popVisibleStock = true
      this.timeout = setTimeout(() => {
        this.$refs.estimatePop.resetSelectedData('all')
        this.$refs.estimatePop.activeTab = 'product'
      }, 0)
    },
    onChangeSearchDtRadio(val) {
      /** 대행견적 생성일 조건 설정(어제,오늘,7일,30일) */
      if(val==='lastDay') {
        this.searchForm.estStartDtm = moment().subtract('days', 1)
        this.searchForm.estEndDtm = moment().subtract('days', 1)
      } else if(val==='today') {
        this.searchForm.estStartDtm = moment()
        this.searchForm.estEndDtm = moment()
      } else if(val==='day7') {
        this.searchForm.estStartDtm = moment().subtract('days', 7)
        this.searchForm.estEndDtm = moment()
      } else if(val==='day30') {
        this.searchForm.estStartDtm = moment().subtract('days', 30)
        this.searchForm.estEndDtm = moment()
      }
    },
    resetSearchCond(){
      /** 검색조건 초기화 */
      Object.assign(this.searchForm, this.$options.data().searchForm)
    },
    popVisible(val) {
      this.popVisibleLoading = val
    },
    oneClickDisable(event, clickEvent, ...args) {
      if(event.target.disabled === true){
        retrun
      }

      event.target.disabled = true

      try {
        clickEvent(...args)
      } catch {}
      setTimeout(() => {
        event.target.disabled = false
      }, 2000)
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
