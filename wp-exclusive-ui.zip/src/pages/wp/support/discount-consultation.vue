<template>
  <section>
    <div id="support">
      <div class="article-title">
        <el-button
          type="primary"
          @click="resetSearchCond"
        >
        초기화
        </el-button>
        <div>
          <el-button
            type="primary"
            @click="onSearch(1)"
          >
          조회
          </el-button>
          <el-button
            type="primary"
            class="btn-excel"
            @click="downloadExcel"
            >
            EXCEL 다운로드
            </el-button>
        </div>
      </div>
      <div class="box">
        <el-form ref="info" :model="ruleForm" class="detail-form table-wrap">
        <el-row>
          <el-col :span="8">
            <el-form-item label="기준년월">
              <el-date-picker
                v-model="ruleForm.searchFromDt"
                format="yyyy-MM"
                value-format="yyyy-MM"
                type="date"
                :clearable="false"
              /> 
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="계약담당자">
              <el-select
              v-model="ruleForm.managerId"
              >
              <el-option
                v-for="{ sysUserNo, sysUserNm } in authConsultants && authConsultants.slice(1)"
                :key="sysUserNo"
                :value="sysUserNo"
                :label="sysUserNm"
              />
              </el-select>
            </el-form-item>
          </el-col>
          <!-- 7/8 전담 SB v2.9 삭제 -->
          <!-- <el-col :span="8">
            <el-form-item
              label="국판 진행상태"
            >
              <el-select
                v-model="ruleForm.legacyStatus"
                style="max-width: 160px;"
                placeholder="전체"
              >
                <el-option
                  v-for="{ value, label } in LegacyCommonCodes.C013 && LegacyCommonCodes.C013.slice(1)"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col> -->
        </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="집계데이터 조회">
                <ul class="data-list">
                  <li><strong class="tit">전체</strong><span class="val"><strong>{{ countData.totalCount || 0 }}</strong>건</span></li>
                  <li><strong class="tit">할인금액</strong><span class="val"><strong>{{ countData.discountAmt || 0 }}</strong>원</span></li>
                  <li><strong class="tit">매출취소금액</strong><span class="val"><strong>{{ countData.cancelAmt || 0 }}</strong>원</span></li>
                  <li><strong class="tit">사용금액</strong><span class="val"><strong>{{ countData.useAmt || 0 }}</strong>원</span></li>
                </ul>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

       <!--여긴되나?    --> 
      <div class="box gap">
        <el-table :data="tableData">
          <el-table-column prop="no" label="NO." width="80" align="center"></el-table-column>
          <el-table-column
            label="계약번호"
            prop="contractNumber"
            width="129"
            align="center">
            <!-- 법인이 아닌경우 -->
                <template
                  v-if="tableData.customerType !== 'CA1' && tableData.customerType !== 'CL2'"
                  slot-scope="props"
                  >
                  <a
                    class="link"
                    href="/#/wp/contract/customer/release-detail"
                    target="_blank"
                    @click="
                      $utils.setLocalStorage({
                        contractNumber: props.row.contractNumber
                      })
                    "
                  >
                    {{ props.row.contractNumber | capitalize }}
                  </a>
              </template>
              <template
                v-else
                slot-scope="props"
                >
                  <a
                    class="link"
                    href="/#/wp/contract/corporation/release-detail"
                    target="_blank"
                    @click="
                      $utils.setSessionStorage({
                        contractNumber: props.row.contractNumber
                      })
                    "
                  >
                    {{ props.row.contractNumber | capitalize }}
                  </a>
              </template>
            </el-table-column>
          <el-table-column prop="contractorName" label="주계약자" width="155" align="center"></el-table-column>
          <el-table-column prop="managerName" label="계약담당자" width="155" align="center"></el-table-column>
          <el-table-column prop="releaseDate" label="출고일" width="150" align="center"></el-table-column>
          <el-table-column prop="acqDscnDtm" label="인수확정일" width="150" align="center"></el-table-column>
          <el-table-column prop="craftCertificateDate" label="제작증발급일" width="150" align="center"></el-table-column>
          <el-table-column prop="csetAmt" sortable="custom" label="할인금액" width="150" align="center"></el-table-column>
          <el-table-column prop="dcAplDtm" label="할인적용일" width="150" align="center"></el-table-column>
          <el-table-column prop="carCancelDtm" label="매출취소일" width="150" align="center"></el-table-column>
          <el-table-column prop="legacyStatusName" label="판매진행상태" width="120" align="center"></el-table-column>
        </el-table>
      </div>

    </div>
  </section>
</template>

<script>
import moment from 'moment'
import { mapState } from 'vuex'
// import Loading from '~/components/popup/Loading.vue'
// import PopMessage from '~/components/popup/PopMessage.vue'

export default {
  name: 'Reception',
  layout: 'default',
  // components:{
  //   Loading,
  //   PopMessage
  // },
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      workSelectedVal: false,
      legacySelectedVal: false,
      authConsultantselectedVal: false,
      popVisibleLoading: false,
      alertNoData: false,
      consultantPop: false,
      checked: false,
      tableData: [],
      // commonCodes: {},
      LegacyCommonCodes : {},
      ruleForm:{
        searchFromDt: moment().format('YYYY-MM'),
        managerId: '',                  // 업무처리자
        // legacyStatus: []                // 국판진행상태
        legacyStatus: ''                // 국판진행상태
      },
      countData: {
        totalCount: 0,
        discountAmt: 0,      // 할인금액
        cancelAmt: 0,    // 매출취소금액
        useAmt: 0        // 사용금액(할인금액 - 매출취소금액)
      },
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      }
    }
  },
  computed: {
    ...mapState(['authConsultants', 'userInfo']),
    authConsultants: function() {
      const authConsultants = this.$store.state.authConsultants.slice()
      if(authConsultants && authConsultants.length > 0) {
        authConsultants.unshift( { 'useAuthId': '', 'sysUserNo': '', 'sysUserNm': '전체', 'opsNm': '' } )
      }
      return authConsultants
    }
  },
  async created() {
    await this.loadCommonCode()
  },
  mounted() {
    this.$store.dispatch('loadAuthConsultants', {vm: this})
  },
  methods: {
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null
      switch(systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {vm: this, codeTypeCode: codeType})
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {vm: this, codeTypeCode: codeType})
        break
      }
      return res
    },
    async loadCommonCode() {
      const [ccC013] = await Promise.all([
        this.fetchCommonCodeData('C', 'C013') // 레거시 진행상태
      ])

      this.LegacyCommonCodes = { ...ccC013 }

      this.initRuleFormStatus()
    },
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      
      }
      return bResult
    },
    resetSearchCond() {
      Object.assign(this.ruleForm, this.$options.data().ruleForm)
    },
    selectedAll(e,type) {
      if(type==='legacy'){
        if(e) {
          this.ruleForm.legacyStatus = this.LegacyCommonCodes.C013.slice(1).map((items) => {
            return items.value
          }) || []
        } else {
          this.ruleForm.legacyStatus = []
        }
      }else if(type==='consultant'){
        if(e) {
          this.ruleForm.consultantId = this.consultants.slice(1).map((items) => {
            return items.sysUserNo
          }) || []
        } else {
          this.ruleForm.consultantId = []
        }
      }
    },
    onSearch(page) {
      // if(!this.isValidAuthBtn('authSelect')) { // 권한없을경우 동작 x
      //   return
      // }
      this.$data.pageInfo.page = page
      this.getData()
    },
    async getData() {
      var searchFromDt = moment(this.ruleForm.searchFromDt).format('YYYY-MM')

      if(!searchFromDt) {
        this.alertMessage = '날짜는 필수입력사항입니다.'
        this.alertMessagePop = true
        return false
      }

      this.initRuleFormStatus()

      const { page: pageNo, size: pageSize } = this.$data.pageInfo

      const params = {
        ...this.ruleForm,
        searchFromDt: searchFromDt,
        searchEndDt: searchFromDt,
        pageNo,
        pageSize
      }      
      
      this.popVisibleLoading = true
    
      const [res,err] = await this.$https.post('/v2/exclusive/support/dc-consult-list', params)

      if(!err) {
        if(!res.data || res.data.length===0) {
          this.tableData = []
        } else {
          this.tableData = res.data.list.map((el, idx) => {
            return {
              ...el,
              no : idx+1,
              isSelected: false,
              csetAmt: el.csetAmt.toLocaleString() + '원',
              payExpireDate: el.payExpireDate ? moment(el.payExpireDate).format('YYYY-MM-DD') : '',
              progressExpireDate: el.progressExpireDate ? moment(el.progressExpireDate).format('YYYY-MM-DD') : '',
              bold: el.noticeConfirmYn !== 'Y' ? 'bold' : ''
            }
          })
        }

        this.$data.pageInfo = {
          ...this.$data.pageInfo,
          total: res.data.total
        }
        console.log('/dc-consult-list', this.tableData)
        this.popVisibleLoading = false
      } else {
        console.error(err)
        this.tableData = []
        this.popVisibleLoading = false
      }

      const [res2,err2] = await this.$https.get('/v2/exclusive/support/dc-consult-count', params)

      if(!err2) {
        if(!res2.data) {
          Object.assign(this.$data.countData, this.$options.data().countData)
          return
        }

        this.countData = {
          totalCount : res2.data.totalCount,
          discountAmt : res2.data.discountAmt.toLocaleString(),
          cancelAmt : res2.data.cancelAmt.toLocaleString(),
          useAmt : res2.data.useAmt.toLocaleString()
        }
        console.log('/support/dc-consult-count', this.countData)
      } else {
        console.error(err2)
      }
    
    },
    async downloadExcel() {

      this.initRuleFormStatus()

      const params = {
        ...this.ruleForm,
        searchFromDt: this.ruleForm.searchFromDt,
        // searchEndDt: this.ruleForm.searchFromDt
      }

      // API-WX-업무담당자-?? (전담 DC 품의 목록 엑셀저장)
      const [res,err] = await this.$https.post('/v2/exclusive/support/dc-consult-excel', params, null, null, { responseType: 'blob' })
      if(!err) {
        const blob = new Blob([res], {type : res.Type })
        const nowDate = moment().format('YYYYMMDD_HHmm')
        if(window.navigator.msSaveOrOpenBlob) {
          // IE11
          window.navigator.msSaveOrOpenBlob(blob, '전담DC품의엑셀저장_' + nowDate + '.xlsx')
        } else {
          // IE11 외 브라우저
          const blobURL = window.URL.createObjectURL(blob)
          const tempLink = document.createElement('a')

          tempLink.href = blobURL

          tempLink.setAttribute('download', '전담DC품의엑셀저장_' + nowDate + '.xlsx')
          document.body.appendChild(tempLink)
          tempLink.click()
          document.body.removeChild(tempLink)
          window.URL.revokeObjectURL(blobURL)
        }
      } else {
        console.error(err)
        this.tableData = null
      }
    },
    // onChangeMultiSelect(data, type) {
    //   if(type === 'legacy') { // 레거시 진행상태
    //     if(data.length === this.LegacyCommonCodes.C013.slice(1).length) {
    //       this.legacySelectedVal = true
    //     } else {
    //       this.legacySelectedVal = false
    //     }
    //   }
    // },
    initRuleFormStatus() {
      if(this.ruleForm.legacyStatus && this.ruleForm.legacyStatus.length === 0) { // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false, 'legacy')
      }
    },
    initRuleFormPop() {
      Object.assign(this.$data.ruleFormpopup, this.$options.data().ruleFormpopup)
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
