<template>
  <section>
    <div id="support">
     
      <div class="article-title">
        <h-search 
            v-model="estimateNumber"
            :title="'대행견적번호'"
            :on-click="searchEstimate"
            @enter="searchEstimate"
        />
        <div class="btn-group">
          <el-button type="primary" @click="popVisibleSMS = true">문자보내기</el-button>
          <el-button type="primary" @click="popVisibleEmail = true">이메일보내기</el-button>
        </div>
      </div>

      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="12">
              <el-form-item label="판매SPEC">{{ estimateInfo.saleSpecCd }}</el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="사번">{{ estimateInfo.exrsCnstEeno }}</el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <div class="article tabs">
        <el-tabs 
            v-model="activeName"
            type="card" 
            stretch
            @tab-click="handleTabClick"
        >
          <el-tab-pane name="message" :label="`발송이력(${estimateInfo.msgCnt})`">
            <messageHistory
              ref="message"
              :estimate-number="estimateNumber"
              :estimate-url="estimateInfo.estShareUrl"
              @reloadData="getEstimateDetail"
            />
          </el-tab-pane>

          <el-tab-pane name="estimate" :label="`견적이력(${estimateInfo.estCnt})`">
            <estimateHistory 
              ref="estimate"
              :estimate-number="estimateNumber"
            />
          </el-tab-pane>

          <el-tab-pane name="contract" :label="`계약이력(${estimateInfo.contractCnt})`">
            <contractHistory
              ref="contract"
              :estimate-number="estimateNumber"
            />
          </el-tab-pane>
        </el-tabs>
      </div> 

      <el-dialog
        title="문자보내기"
        :visible.sync="popVisibleSMS"
        width="1100px"
      >
        <!-- Popup Contents -->
        <div class="board-wrap sandmessage">
          <h-title :title="'수신자 정보'" />
          <el-form
            ref="contractData"
            :model="ruleFormpopup"
            class="detail-form"
          >
            <el-row>
              <el-col :span="9">
                <el-form-item label="받는 사람">
                  <el-input
                    v-model="ruleFormpopup.receiverName"
                    class="mms-title"
                  />
                </el-form-item>
              </el-col>
              <el-col :span="15">
                <el-form-item label="휴대전화번호">
                  <el-input
                    v-model="ruleFormpopup.receiverMobile"
                    class="mms-title"
                  />
                </el-form-item>
              </el-col>
            </el-row>
          <h-title :title="'발신내용'" />
            <el-row>
              <el-col :span="24">
                <el-form-item label="제목">
                  <el-input
                    v-model="ruleFormpopup.title"
                    class="mms-title"
                    @blur="ruleFormpopup.title = $event.target.value"
                  />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item label="내용">
                  <el-input
                    v-model="ruleFormpopup.text"
                    type="textarea"
                    @blur="ruleFormpopup.text = $event.target.value"
                  />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item label="URL">
                  {{ estimateInfo.estShareUrl }}
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="primary"
            @click="oneClickDisable($event, initRuleFormPop)"
          >
            초기화
          </el-button>
          <el-button
            type="primary"
            @click="oneClickDisable($event, sendSms)"
          >
            전송
          </el-button>
        </template>
      </el-dialog>
      <el-dialog
        title="이메일 보내기"
        :visible.sync="popVisibleEmail"
        width="650px"
      >
        <!-- Popup Contents -->
        <div class="board-wrap sandmessage">
          <h-title :title="'수신자 정보'" />
          <el-form
            ref="contractData"
            :model="ruleFormpopup"
            class="detail-form"
          >
            <el-row>
              <el-col :span="24">
                <el-form-item label="받는 사람">
                  <el-input
                    v-model="ruleFormpopup.receiverName"
                    class="mms-title"
                  />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item label="이메일 주소">
                  <el-input
                    v-model="ruleFormpopup.receiverEmail"
                    class="mms-title"
                  />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item label="휴대폰번호">
                  <el-input
                    v-model="ruleFormpopup.receiverMobile"
                    class="mms-title"
                  />
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="primary"
            @click="initRuleFormPop"
          >
            초기화
          </el-button>
          <el-button
            type="primary"
            @click="oneClickDisable($event, sendEmail)"
          >
            전송
          </el-button>
        </template>
      </el-dialog>       
      <pop-message
        :pop-visible.sync="alertMessagePop"
        :pop-message.sync="alertMessage"
        @confirm="alertMessagePop = false"
        @close="alertMessagePop = false"
      />
      <loading
        :pop-visible.sync="popVisibleLoading"
        :close-on-click-modal="false"
        @close="popVisibleLoading = false"
      />
    </div>
  </section>
</template>

<script>
import HSearch from '~/components/common/HSearch.vue'
import HTitle from '~/components/common/HTitle.vue'
import PopMessage from '~/components/popup/PopMessage.vue'
import estimateHistory from '~/components/tab/Estimate/EstimateHistory.vue'
import contractHistory from '~/components/tab/Estimate/ContractHistory.vue'
import messageHistory from '~/components/tab/Estimate/MessageHistory.vue'
import Loading from '~/components/popup/Loading.vue'

export default {
  layout: 'default',
  components: {
    HSearch,
    HTitle,
    PopMessage,
    messageHistory,
    estimateHistory,
    contractHistory,
    Loading,
  },
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      popVisibleLoading: false, // 로딩 활성화 여부
      activeName: 'sms',
      popVisibleSMS: false,
      popVisibleEmail: false,
      estimateNumber: null,
      estimateInfo: {
        saleSpecCd: null,
        exrsCnstEeno: null,
        estShareUrl: null,
        msgCnt:0,
        estCnt:0,
        contractCnt:0,
      },
      ruleFormpopup:{
        receiverName: '',
        receiverMobile: '',
        receiverEmail: '',
        title: '',
        text:'',
      },
    }
  },
  mounted() {
    this.estimateNumber = localStorage.getItem('estimateNumber') || ''
    this.activeName = localStorage.getItem('activeName')

    if(this.estimateNumber) {
      this.getEstimateDetail(this.estimateNumber)
      this.handleTabClick({name: this.activeName})
    }

  },
  methods: {
    searchEstimate(estimateNumber) {
      this.getEstimateDetail(estimateNumber)
    },
    async getEstimateDetail(estimateNumber) {
      if(!estimateNumber) return

      let arr = []
      const [res, err] = await this.$https.get('/v2/exclusive/support/estimate-detail/'+estimateNumber)
      if(!err) {
        if(res.data) {
          arr = res.data
        }
      }else { 
        console.error('exclusive :: /v2/exclusive/support/estimate-detail ERROR !! '+err)
      }
      this.estimateInfo = arr

      this.handleTabClick({name: this.activeName})
    },
    handleTabClick(tab) {
      if(tab.name === 'message') this.getMessageTabData()
      else if(tab.name === 'estimate') this.getEstimateTabData()
      else if(tab.name === 'contract') this.getContractTabData()
    },
    async getMessageTabData() {
      if (!this.estimateNumber) return

      await this.$refs.message.getMessageHistory()
    },
    async getEstimateTabData() {
      if (!this.estimateNumber) return

      await this.$refs.estimate.getEstimateHistory()
    },
    async getContractTabData() {
      if (!this.estimateNumber) return

      await this.$refs.contract.getContractHistory()
    },
    initRuleFormPop() {
      Object.assign(this.$data.ruleFormpopup, this.$options.data().ruleFormpopup)
    },
    async sendSms() {
      if(!this.ruleFormpopup.receiverName || !this.ruleFormpopup.receiverMobile){
        this.alertMessage = '수신자정보를 입력해주세요.'
        this.alertMessagePop = true
        return
      }
      const params = {
        messageTypeCode: 'SMS',
        messageTitle: this.ruleFormpopup.title,
        messageContents: this.ruleFormpopup.text +'\n'+ this.estimateInfo.estShareUrl,
        adresseeMobile: this.ruleFormpopup.receiverMobile,
        adresseeName: this.ruleFormpopup.receiverName,
        estimateNumber: this.estimateNumber
      }
      
      this.popVisibleLoading = true
      const [res, err] = await this.$https.post('/v2/exclusive/support/estimate/sendMessage', params)
      if(!err) {
        if(res.rspStatus && res.rspStatus.rspCode === '0000'){
          this.alertMessage = '문자가 전송되었습니다.'
          this.alertMessagePop = true
        }
      } else {
        console.error('exclusive :: /v2/exclusive/support/estimate/sendMessage ERROR !! '+err)
      }

      
      this.popVisibleLoading = false
      this.getEstimateDetail(this.estimateNumber) // reload
      this.initRuleFormPop() //초기화
      this.popVisibleSMS = false // 팝업 닫기
      
    },
    async sendEmail() {
      if(!this.ruleFormpopup.receiverEmail || !this.ruleFormpopup.receiverMobile){
        this.alertMessage = '이메일주소와 휴대전화번호는 필수입니다.'
        this.alertMessagePop = true
        return
      } 

      const params = {
        messageTypeCode: 'EMAIL',
        channelCode: '003',
        adresseeEmail: this.ruleFormpopup.receiverEmail,
        adresseeName: this.ruleFormpopup.receiverName,
        estimateNumber: this.estimateNumber,
        messageTemplateId:'EF-EST_001',
        estShareUrl: this.estimateInfo.estShareUrl,
      }

      
      this.popVisibleLoading = true
      const [res, err] = await this.$https.post('/v2/exclusive/support/estimate/sendMessage', params)
      if(!err) {
        if(res.rspStatus && res.rspStatus.rspCode === '0000'){
          this.alertMessage = '이메일이 전송되었습니다.'
          this.alertMessagePop = true

          //이메일 전송 안내 알림톡 발송
          this.$utils.sendMessageAll(this, {
            messageTemplateId: 'wp_1201014',
            sendChannelCode: '003',
            receiverName: this.ruleFormpopup.receiverName,
            receiverTel: this.ruleFormpopup.receiverMobile,
            fileGroupSerialNo: ''
          })
        }
        this.getEstimateDetail(this.estimateNumber) // reload
        this.initRuleFormPop() //초기화
        this.popVisibleEmail = false // 팝업 닫기
      } else {
        console.error('exclusive :: /v2/exclusive/support/estimate/sendMessage ERROR !! '+err)
      }
      this.popVisibleLoading = false
    },
    oneClickDisable(event, clickEvent, ...args) {
      if(event.target.disabled === true){
        retrun
      }

      event.target.disabled = true

      try {
        clickEvent(...args)
      } catch {}
      setTimeout(() => {
        event.target.disabled = false
      }, 2000)
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
