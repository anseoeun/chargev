<template>
  <div></div>
</template>

<script>
export default {
  created() {
    this.loadingPage()
  },
  methods: {
    loadingPage() {
      let preffixUrl = 'http://10.7.137.110/dev/casper'
      if (['stg', 'dev', 'prod'].includes(process.env.VUE_APP_PROFILE)) {
        preffixUrl = process.env.VUE_APP_BASEURL_FRONT
      }
      
      let estimationUrl = this.$route.query.estimationUrl
      window.location.href = preffixUrl+'/estimation/exclusive?estimationUrl='+estimationUrl
    }
  }
}

</script>
<style lang="scss" scoped>
</style>
