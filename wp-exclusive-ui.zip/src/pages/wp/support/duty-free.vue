<template>
  <section>
    <div id="duty-free">
      <div class="article-title">
        <h-search
          v-model="contractNumber"
          :title="'계약번호'"
          :on-click="searchContract"
          :active-button="isValidAuthBtn('authSelect')"
          @enter="searchContract"
          @keydown.native.tab="onAddZero(contractNumber)"
        />
        <div class="btn-group">
          <div>
            <el-button
              v-if="isValidAuthBtn('authExclusive') && originStatusCode !== 'CP'"
              type="primary"
              @click="oneClickDisable($event, onSave)"
            >
              저장
            </el-button>
            <el-button
              v-if="isValidAuthBtn('authExclusive')"
              type="primary"
              @click="oneClickDisable($event, openPopSms())"
            >
              문자보내기
            </el-button>
            <el-button
              v-if="isValidAuthBtn('authExclusive') && originStatusCode !== 'CP'"
              type="primary"
              @click="oneClickDisable($event, reSend)"
            >
              전자서명재전송
            </el-button>
            <el-button
              v-if="isValidAuthBtn('authSelect')"
              type="primary"
              @click="goList"
            >
              목록
            </el-button>
          </div>
        </div>
      </div>
      <div class="search">
        <h3>
          심사결과
        </h3>
        <el-select
          v-model="taxFreeInfo.statusCode"
          placeholder="처리결과 선택"
          style="line-height: 30px; margin-left: 8px;"
          :disabled="['CP', 'EC'].includes(originStatusCode)"
        >
          <el-option
            v-for="{ value, label } in commonCodes.T024"
            :key="value"
            :value="value"
            :label="label"
            :disabled="['CP', 'NA'].includes(value) || (['EF', 'EP'].includes(originStatusCode) && value === 'EW')"
          />
        </el-select>
        <h3 style="margin-left: 24px;">
          연기구분
        </h3>
        <span style="line-height: 30px; margin-left: 8px;">{{ taxFreeInfo.postponeYn }}</span>
      </div>
      <h-title title="면세 구입자 (신고인) 인적사항" />
      <el-form
        v-for="(items, idx) in taxFreeInfo.groupPurchaseMemberList && taxFreeInfo.groupPurchaseMemberList.filter((items) => { return items.relationPersonTypeCode === '01' })"
        :key="`member-${idx}`"
        class="detail-form"
        :style="`margin-top: ${24*idx}px;`"
      >
        <el-row>
          <el-col :span="12">
            <el-form-item label="성명">
              <el-input
                v-model="items.contractorName"
                disabled
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="주민등록번호">
              <el-input
                :value="items.residentRegistrationNumber.substring(0,6)"
                disabled
                style="max-width: 290px;"
              />
              <span class="ex-txt">-</span>
              <el-input
                :value="items.residentRegistrationNumber.substring(6)"
                disabled
                style="max-width: 290px;"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="휴대전화">
              <el-input
                v-model="items.mobilePhoneNumber"
                disabled
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="주소">
              <el-input
                v-model="items.contractorAddress"
                disabled
                style="max-width: inherit;"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12" />
        </el-row>
      </el-form>

      <h-title
        v-if="taxFreeInfo.groupPurchaseMemberList && taxFreeInfo.groupPurchaseMemberList.filter((items) => { return items.relationPersonTypeCode !== '01' }).length > 0"
        title="공동등록자 인적사항"
      />
      <el-form
        v-for="(items, idx) in taxFreeInfo.groupPurchaseMemberList && taxFreeInfo.groupPurchaseMemberList.filter((items) => { return items.relationPersonTypeCode !== '01' })"
        :key="`publicMember-${idx}`"
        class="detail-form"
        :style="`margin-top: ${24*idx}px;`"
      >
        <el-row>
          <el-col :span="12">
            <el-form-item label="성명">
              <el-input
                v-model="items.contractorName"
                disabled
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="주민등록번호">
              <el-input
                :value="items.residentRegistrationNumber.substring(0,6)"
                style="max-width: 290px;"
                disabled
              />
              <span class="ex-txt">-</span>
              <el-input
                :value="items.residentRegistrationNumber.substring(6)"
                style="max-width: 290px;"
                disabled
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="관계">
              <el-input
                v-model="items.contractorRelationName"
                disabled
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="주소">
              <el-input
                v-model="items.contractorAddress"
                disabled
                style="max-width: inherit;"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12" />
        </el-row>
      </el-form>
      <h-title title="면세신고" />
      <el-form
        ref="taxFreeInfo"
        :model="taxFreeInfo"
        class="detail-form detailInfo"
      >
        <el-row>
          <el-col :span="12">
            <el-form-item label="증서구분">
              <el-select
                v-model="taxFreeInfo.taxFreeTypeCode"
                placeholder="증서구분"
                disabled
              >
                <el-option
                  v-for="{ value, label } in LegacyCommonCodes.G036"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="장애등급">
              <el-select
                v-model="taxFreeInfo.taxFreeDisabilityCode"
                placeholder="장애등급"
              >
                <el-option
                  v-for="{ value, label } in taxFreeCommonCode(taxFreeInfo.taxFreeTypeCode)"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="증빙서류">
              <el-select
                v-model="taxFreeInfo.taxFreePaperCode"
                placeholder="증빙서류"
              >
                <el-option
                  v-for="{ value, label } in LegacyCommonCodes.G038"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="발급기관">
              <el-input v-model="taxFreeInfo.issueOrg" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item
              v-if="taxFreeInfo.taxFreeTypeCode === '1'"
              label="장애등록일"
            >
              <el-date-picker
                v-model="taxFreeInfo.disableRegDate"
                type="date"
                :clearable="false"
              />
            </el-form-item>
            <el-form-item
              v-else-if="['2','7','8'].includes(taxFreeInfo.taxFreeTypeCode)"
              label="보훈번호"
            >
              <el-input v-model="taxFreeInfo.managementNumber" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="발급일">
              <el-date-picker
                v-model="taxFreeInfo.issueDate"
                :clearable="false"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="직업">
              <el-select
                v-model="taxFreeInfo.taxFreeOccupationCode"
                placeholder="직업"
              >
                <el-option
                  v-for="{ value, label } in LegacyCommonCodes.G006"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="구입목적">
              <el-select
                v-model="taxFreeInfo.purchasePurposeCode"
                placeholder="구입목적"
              >
                <el-option
                  v-for="{ value, label } in LegacyCommonCodes.G039"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="자동차 등록번호">
              <el-input v-model="taxFreeInfo.carRegistNumber" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="자동차 등록일">
              <el-date-picker
                v-model="taxFreeInfo.carRegistDate"
                type="date"
                :clearable="false"
              />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <!-- 추가되었습니다.  -->
      <h-title title="서류 증빙" />
      <el-form
        v-if="taxFreeInfo.taxFreeReleaseAttachFilesList && taxFreeInfo.taxFreeReleaseAttachFilesList.length > 0"
        class="detail-form evidence"
      >
        <el-row
          v-for="(items, idx) in taxFreeInfo.taxFreeReleaseAttachFilesList"
          :key="`taxFile-${idx}`"
        >
          <el-col :span="4">
            <div class="evidence-col">
              {{ items.neceDocNm }}
            </div>
          </el-col>
          <el-col :span="14">
            <div
              v-if="items.fileGroupSerialNumber"
              class="evidence-col">
              {{ items.attcFilNm }}
            </div>
            <div v-else class="evidence-col">
              서류 미제출
            </div>
          </el-col>
          <el-col :span="6">
            <div class="evidence-col btn-contents">
              <el-button
                :type="`${!items.fileGroupSerialNumber ? 'info' : 'primary'}`"
                :disabled="!items.fileGroupSerialNumber"
                @click="getFileData(items.fileGroupSerialNumber)"
              >
                파일 다운로드
              </el-button>
            </div>
          </el-col>
        </el-row>
      </el-form>
      <el-form
        v-else
      >
        <el-row>
          <el-col :span="24">
            <div class="evidence-col">
              서류 미제출
            </div>
          </el-col>
        </el-row>
      </el-form>
      <!-- 추가되었습니다.  -->
      <h-title title="심사 회신" />
      <el-form
        ref="taxFreeInfo"
        :model="taxFreeInfo"
        class="detail-form"
      >
        <el-row>
          <el-col :span="24">
            <el-form-item
              label="내용"
            >
              <span slot="label">내용<br />(50자이내)</span>
              <el-input
                v-model="taxFreeInfo.docJudgeContents"
                maxlength="50"
                type="textarea"
                @blur="taxFreeInfo.docJudgeContents = $event.target.value"
              />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <h-title title="심사 회신 이력" />
      <el-table
        :data="docJudgeList"
        max-height="450"
        empty-text="조회 결과가 존재하지 않습니다."
      >
        <el-table-column
          label="NO."
          prop="rowNum"
          width="80"
          align="center"
        />
        <el-table-column
          label="고객요청일"
          prop="customerRequestDate"
          align="center"
        />
        <el-table-column
          label="업무담당자처리일시"
          prop="processedDate"
          align="center"
        />
        <el-table-column
          label="상태"
          prop="statusName"
          align="center"
        />
        <el-table-column
          label="심사 회신 내용"
          prop="docJudgeContents"
          align="center"
        >
          <template slot-scope="props">
            <el-tooltip
              placement="bottom"
              effect="light"
            >
              <div slot="content">
                {{ props.row.docJudgeContents }}
              </div>
              <el-button type="text">
                {{ props.row.docJudgeContents && props.row.docJudgeContents.length > 10 ? props.row.docJudgeContents.slice(0, 10) : props.row.docJudgeContents }}
              </el-button>
            </el-tooltip>
          </template>
        </el-table-column>
        <el-table-column
          label="처리자"
          prop="managerName"
          align="center"
        />
      </el-table>


      <!-- 문자보내기 팝업 -->
      <el-dialog
        title="문자보내기"
        :visible.sync="popVisible05"
        width="1100px"
      >
        <!-- Popup Contents -->
        <div class="board-wrap sandmessage">
          <h-title :title="'수신자 정보'" />
          <el-form
            class="detail-form"
          >
            <el-row>
              <el-col :span="9">
                <el-form-item label="수신자명">
                  <!-- {{ customerData.contractorName }} -->
                  <el-select v-model="contractorNames" multiple placeholder="수신자명">
                    <el-option
                      v-for="item in contractorInfo"
                      :key="item.contractorName"
                      :label="item.contractorName"
                      :value="item.contractorName">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="15">
                <el-form-item label="휴대전화번호">
                  <!-- {{ inputPhoneNumber(customerData.mobilePhoneNumber) }} -->
                  {{ contractorHpTns() }}
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="발송일시">
                  {{ customerData.sendDate }}
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
          <h-title :title="'발신내용'" />
          <el-form
            ref="ruleFormData"
            :model="ruleFormData"
            class="detail-form"
          >
            <el-row>
              <el-col :span="24">
                <el-form-item label="제목">
                  <el-input
                    v-model="ruleFormData.title"
                    class="mms-title"
                    @blur="ruleFormData.title = $event.target.value"
                  />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item label="내용">
                  <el-input
                    v-model="ruleFormData.contents"
                    type="textarea"
                    @blur="ruleFormData.contents = $event.target.value"
                  />
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="info"
            @click="initRuleForm"
          >
            초기화
          </el-button>
          <el-button
            type="primary"
            @click="oneClickDisable($event, sendSms)"
          >
            전송
          </el-button>
        </template>
      </el-dialog>
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import HSearch from '~/components/common/HSearch.vue'
import HTitle from '~/components/common/HTitle.vue'
import moment from 'moment'
import PopMessage from '~/components/popup/PopMessage.vue'

export default {
  name: 'DutyFree',
  layout: 'default',
  components:{
    HTitle,
    PopMessage,
    HSearch
  },
  data(){
    return {
      alertMessage: '',
      alertMessagePop: false,
      contractNumber: '', // 판매계약번호
      taxFreeVisible: true, // true: 장애등록일 active, false: 보훈번호 active
      originStatusCode: '', // 심사결과 상태코드 - 변경이전
      taxFreeInfo: {
        statusCode: ''
      }, // 면세반출 정보
      docJudgeList: [], // 면세 심사 이력 목록
      popVisible05:false,
      customerData: {
        contractorName: '',
        mobilePhoneNumber: '',
        sendDate: ''
      }, // 주계약자 정보(수신자)
      contractorInfo: [], // 계약자 정보(주계약자, 공동명의자)
      ruleFormData: { // 발신내용 들어가는 항목
        title: '',
        contents: '',
        category: ''
      },
      fileData: null,
      commonCodes: {},
      LegacyCommonCodes: {},
      contractorNames: []  // 선택한 계약자명
    }
  },
  async created() {
    await this.loadCommonCode()
  },
  mounted() {
    this.contractNumber = sessionStorage.getItem('contractNumber') || '' // 새창으로 넘어오는 경우

    if(this.$route.params.contractNumber) { // route 이동으로 넘어오는 경우 * params이 있을 경우에만 셋팅
      this.contractNumber = this.$route.params.contractNumber
    }

    if(this.contractNumber) {
      this.getData(this.contractNumber)
      this.getHistoryList()
    }
    sessionStorage.removeItem('contractNumber')
  },
  methods: {
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null
      switch(systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {vm: this, codeTypeCode: codeType})
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {vm: this, codeTypeCode: codeType})
        break
      }
      return res
    },
    async loadCommonCode() {
      const [ccT024, ccT026, ccT027, ccT028, ccT029, ccG036, ccG038, ccG006, ccG039] = await Promise.all([
        this.fetchCommonCodeData('E', 'T024'), // 구분
        this.fetchCommonCodeData('E', 'T026'), // 장애인
        this.fetchCommonCodeData('E', 'T027'), // 국가유공자
        this.fetchCommonCodeData('E', 'T028'), // 민주화운동부상자
        this.fetchCommonCodeData('E', 'T029'), // 고업체후유증환자

        this.fetchCommonCodeData('C', 'G036'), // 증서구분
        this.fetchCommonCodeData('C', 'G038'), // 증빙서류
        this.fetchCommonCodeData('C', 'G006'), // 직업
        this.fetchCommonCodeData('C', 'G039') // 구입목적
      ])

      this.commonCodes = { ...ccT024, ...ccT026, ...ccT027, ...ccT028, ...ccT029 }
      this.LegacyCommonCodes = { ...ccG036, ...ccG038, ...ccG006, ...ccG039 }

      const ccdKeys = Object.keys(this.commonCodes)
      const lccdKeys = Object.keys(this.LegacyCommonCodes)

      if(ccdKeys.length > 0) ccdKeys.map((keys) => { this.commonCodes[keys].splice(0, 1) }) // `전체` 선택항목 제거
      if(lccdKeys.length > 0) lccdKeys.map((keys) => { this.LegacyCommonCodes[keys].splice(0, 1) }) // `전체` 선택항목 제거
    },
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    inputPhoneNumber(phoneNum) {
      if(!phoneNum) return phoneNum
      return phoneNum.replace(/(^02.{0}|^01.{1}|[0-9]{3})([0-9]+)([0-9]{4})/, '$1-$2-$3') || ''
    },
    initRuleForm() { // 문자보내기 팝업 - 초기화
      Object.assign(this.ruleFormData, this.$options.data().ruleFormData)
    },
    taxFreeCommonCode(val) {
      let list = []
      switch(val) {
      case '1': // 장애인
        list = this.commonCodes.T026
        break
      case '2': // 국가유공자
        list = this.commonCodes.T027
        break
      case '7': // 민주화운동부상자
        list = this.commonCodes.T028
        break
      case '8': // 고엽제후유증환자
        list = this.commonCodes.T029
        break
      }
      return list
    },
    goList() { // 목록
      // location.hash = '/support/shipment'
      this.$router.push('/support/shipment')
    },
    searchContract(value) {
      if(!this.isValidAuthBtn('authSelect')) { // 권한없을경우 동작 x
        return
      }

      if(!value) {
        this.alertMessage = '계약번호를 입력해주세요.'
        this.alertMessagePop = true
        return
      } else {
        value = value.trim() // 공백 제거
      }

      this.contractNumber = value
      this.getData(this.contractNumber)
      this.getHistoryList()
    },
    onAddZero(contractNumber) {
      let resultString = ''
      if(contractNumber.length > 6) {
        const frontString = contractNumber.substring(0,7)
        const backString = contractNumber.substring(7)

        resultString = resultString.concat(frontString)
        resultString = resultString.concat(backString.length >= 6 ? backString : Array.from({length: 6 - backString.length}, () => 0).join('') + backString)
      }

      if(!resultString) { resultString = contractNumber }
      this.contractNumber = resultString
    },
    async getData(contractNumber) { // 면세 신고 정보
      if(!contractNumber) return

      const [res,err] = await this.$https.post('/v2/exclusive/support/tax-free-detail', { contractNumber: this.contractNumber })

      if(!err) {
        if(res.data) {
          this.taxFreeInfo = {
            ...res.data,
            carRegistDate: res.data && res.data.carRegistDate ? moment(res.data.carRegistDate) : '', // 자동차 등록일
            issueDate: res.data && res.data.issueDate ? moment(res.data.issueDate) : '', // 발급일
            disableRegDate: res.data && res.data.disableRegDate ? moment(res.data.disableRegDate) : '', // 장애등록일
            docJudgeContents: ''
          }

          if(this.taxFreeInfo.groupPurchaseMemberList && this.taxFreeInfo.groupPurchaseMemberList.length > 0) {
            this.customerData = this.taxFreeInfo.groupPurchaseMemberList.filter((items) => { return items.relationPersonTypeCode === '01' })[0]
            this.contractorInfo = this.taxFreeInfo.groupPurchaseMemberList
            this.contractorNames = this.contractorInfo && this.contractorInfo.length ? this.contractorInfo.map((items) => { return items.contractorName }) : []
          }

          if(this.taxFreeInfo) {
            this.originStatusCode = this.taxFreeInfo.statusCode || ''
          }
        } else {
          // Object.assign(this.taxFreeInfo, this.$options.data().taxFreeInfo)
          Object.assign(this.$data, this.$options.data())
        }
        console.log(res)
      }else {
        console.error(err)
        Object.assign(this.$data, this.$options.data())
      }
    },
    async getHistoryList() {
      if(!this.contractNumber) return

      const [res, err] = await this.$https.post('/v2/exclusive/support/tax-free-history', { contractNumber: this.contractNumber })

      if(!err) {
        this.docJudgeList = res.data.map((items, idx) => {
          items.rowNum = res.data.length - idx
          return items
        })

        console.log(this.docJudgeList)
      }
    },
    async reSend() { // 전자서명재전송
      const contractList = this.taxFreeInfo.groupPurchaseMemberList.filter((items) => { return items.relationPersonTypeCode === '01' }) // 주계약자
      const { contractNumber } = this.taxFreeInfo

      let body = new URLSearchParams()
      body.append('contractNumber', contractNumber)
      body.append('customerManagementNumber', contractList[0].contractorId || '')

      const [res, err] = await this.$https.post('purchase/v2/purchase/contract/electronic-signature/request-repeat/tax-free', body, null, 'gateway')

      if(!err) {
        this.alertMessage = '저장되었습니다.'
        this.alertMessagePop = true
        console.log(res)
      }
    },
    async onSave() { // 저장
      const contractList = this.taxFreeInfo.groupPurchaseMemberList.filter((items) => { return items.relationPersonTypeCode === '01' }) // 주계약자

      const { mobilePhoneNumber: mobileNumber = '' , contractorName: customerName = '', contractorId: customerNumber = '' } = contractList[0]

      const body = {
        ...this.taxFreeInfo,
        issueDate: this.taxFreeInfo.issueDate ? moment(this.taxFreeInfo.issueDate).format('YYYYMMDD') : '',
        disableRegDate: this.taxFreeInfo.disableRegDate ? moment(this.taxFreeInfo.disableRegDate).format('YYYYMMDD') : '',
        carRegistDate: this.taxFreeInfo.carRegistDate ? moment(this.taxFreeInfo.carRegistDate).format('YYYYMMDD') : '',
        mobileNumber,
        customerName,
        customerNumber,
        groupPurchaseMemberList: [],
        taxFreeReleaseAttachFilesList: []

      }

      console.log(body)
      const [res, err] = await this.$https.post('/v2/exclusive/support/tax-free', body)
      if(!err) {
        this.alertMessage = '저장되었습니다.'
        this.alertMessagePop = true
        this.getData(this.contractNumber)
        this.getHistoryList()
        console.log(res)
      }
    },
    async sendSms() {
      let customersInfo = []
      const contractorInfo = this.contractorInfo
      const targetContractorInfo = contractorInfo && contractorInfo.filter((items) => {
        return this.contractorNames.includes(items.contractorName)
      })

      targetContractorInfo.map((items) => {
        customersInfo.push({
          sendChannelCode: '003', // 발송경로 구분 코드 - 업무담당자
          saleContractNo: this.taxFreeInfo.contractNumber || '', // 판매계약번호
          customerMgmtNo: items.contractorId || '', // 고객관리번호
          messageTitle: this.ruleFormData.title, // 제목
          messageContents: this.ruleFormData.contents, // 내용
          receiverTel: items.mobilePhoneNumber, // 수신자전화번호
          receiverName: items.contractorName // 수신자명
        })
      })

      const [result1, result2] = await Promise.all(
        customersInfo.map((items) => {
          return this.$https.post('common/v2/common/notification/sms', items, null, 'gateway')
        })
      )

      // 1명의 계약자에게만 발송하는 경우
      if (!result2) {
        const [res1, err1] = result1
        if (!err1) {
          if(res1.rspStatus && res1.rspStatus.rspCode === '0000') {
            this.popVisible05 = false // 팝업 닫기
            this.alertMessage = '문자가 전송되었습니다.'
            this.alertMessagePop = true
          }
        }
      } 

      // 주계약자 및 공동명의자 모두 발송하는 경우
      if (result1 && result2) {
        const [res1, err1] = result1
        const [res2, err2] = result2
        
        // 모두 전송되었을 경우
        if (!err1 && !err2) {
          if(res1.rspStatus && res1.rspStatus.rspCode === '0000' &&
            res2.rspStatus && res2.rspStatus.rspCode === '0000') {
            this.popVisible05 = false // 팝업 닫기
            this.alertMessage = '문자가 전송되었습니다.'
            this.alertMessagePop = true
          }
        }
      }

      this.popVisible05 = false // 팝업 닫기
    },
    openPopSms() { // 문자보내기 팝업 노출
      // ※ 출고일 장기 경과 데이터 이관으로 고객정보 부재가 발생하는 케이스가 생김.
      // 고객 데이터에 따른 안내팝업 처리
      // 고객관리번호는 필수값이 아니라 체크안함. 고객정보의 수신자 전화번호와 수신자명은 필수값 임으로 체크
      let mobilePhoneNumber = '', contractorName = ''

      if (this.contractorInfo && this.contractorInfo.length) {
        ({ contractorName, mobilePhoneNumber } = this.contractorInfo[0])
      }

      if (!mobilePhoneNumber || !contractorName) { // 고객정보가 없을 경우
        this.alertMessage = '출고일 장기 경과건으로 고객 데이터가 없습니다.\n데이터 복원후 진행해주세요.'
        this.alertMessagePop = true
      } else {
        this.popVisible05 = true
        Object.assign(this.ruleFormData, this.$options.data().ruleFormData)
      }
    },
    async getFileData(fileSeq) {
      const [res, err] = await this.$https.get('common/v2/common/file/inquiry/' + fileSeq, null, null, 'gateway')

      if(!err) {
        this.fileData = res.data
        this.fileDown()
      }
    },
    async fileDown() { // 첨부파일 다운로드
      const { fileSn, fileGroupSn, fileName, fileExtentions } = this.fileData[0]
      const [res, err] = await this.$https.getb('common/v2/common/file/download/'+ fileGroupSn  + '/' + fileSn, null, null, 'gateway')

      if(!err) {
        const blob = new Blob([res], {type : fileExtentions })
        if(window.navigator.msSaveOrOpenBlob) {
          // IE11
          window.navigator.msSaveOrOpenBlob(blob, fileName)
        } else {
          // IE11 외 브라우저
          const blobURL = window.URL.createObjectURL(blob)
          const tempLink = document.createElement('a')

          tempLink.href = blobURL

          tempLink.setAttribute('download', fileName)
          document.body.appendChild(tempLink)
          tempLink.click()
          document.body.removeChild(tempLink)
          window.URL.revokeObjectURL(blobURL)
        }
        console.log(res)
      }
    },
    contractorHpTns() {
      const contractorInfo = this.contractorInfo
      const targetContractorInfo = contractorInfo && contractorInfo.filter((items) => {
        return this.contractorNames.includes(items.contractorName)
      })
      return targetContractorInfo && targetContractorInfo.map((items) => { return this.inputPhoneNumber(items.mobilePhoneNumber) + (items.contractorRelationName ? ('(' + items.contractorRelationName + ')') : '') }).join(', ')
    },
    oneClickDisable(event, clickEvent, ...args) {
      if(event.target.disabled === true){
        retrun
      }

      event.target.disabled = true

      try {
        clickEvent(...args)
      } catch {}
      setTimeout(() => {
        event.target.disabled = false
      }, 2000)
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~/assets/style/pages/support/duty-free.scss';
</style>
