<template>
  <section>
    <div id="main">
      <section class="main-title">
        <h2>
          금일 업무 <span>{{ totalWork.allCount }}</span
          >건
        </h2>
        <div>
          <router-link to="/total/total" class="link">
            업무 집계 조회 &gt;
          </router-link>
        </div>
      </section>
      <div class="alramContentArea">
        <el-row>
          <el-col :span="12" class="alramContentWrap1">
            <el-row>
              <el-col :span="9" class="alramContent">
                <div style="padding-right:10px">OB</div>
                <div style="cursor: pointer">
                   대고객 : <span @click="goPage('cusob')">
                    {{ totalWork.customerObCount }}
                  </span>
                   /법인 : <span @click="goPage('copob')">
                    {{ totalWork.coporationObCount }}
                  </span>
                </div>
              </el-col>
              <el-col :span="4" class="alramContent">
                <div>직원인증</div>
                <div style="cursor: pointer">
                  <span @click="goPage('ec')">
                    {{ totalWork.ecCount }}
                  </span>
                </div>
              </el-col>
              <el-col :span="11" class="alramContent">
                <div style="padding-right:10px">마이페이지수신</div>
                <div style="cursor: pointer">
                   대고객 : <span @click="goPage('cusmypage')">
                    {{ totalWork.customerMyPageCount }}
                  </span>
                  /법인 : <span @click="goPage('copmypage')">
                    {{ totalWork.coporationMyPageCount }}
                  </span>
                </div>
              </el-col>
            </el-row>
          </el-col>
          <el-col :span="12" class="alramContentWrap2">
            <el-row>
              <el-col :span="8" class="alramContent">
                <div>접수</div>
                <div>
                  <span>{{ totalWork.acceptCount }}</span>
                </div>
              </el-col>
              <el-col :span="8" class="alramContent">
                <div>진행중</div>
                <div>
                  <span>{{ totalWork.progressCount }}</span>
                </div>
              </el-col>
              <el-col :span="8" class="alramContent">
                <div>종결</div>
                <div>
                  <span>{{ totalWork.endCount }}</span>
                </div>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
      </div>
      <div class="contentArea">
        <el-row>
          <el-col :span="16" class="bulletin-board">
            <div class="top-div">
              <span class="t-red">{{ statusInfo.month }}</span>월 목표(<span class="t-red">{{ statusInfo.monthGoalCnt }}</span>)
              <div class="right">
                정상 진도율<span class="date"><span class="t-red">{{ statusInfo.workingDayNo }}</span>/<span class="t-red">{{ statusInfo.totalWorkingDay }}</span></span><span class="per">(<span class="t-red">{{ statusInfo.workingDayRatio }}</span>)</span>
              </div>
            </div>
            <div class="board">
              <table>
                <colgroup>
                  <col style="width:11.1111%"/>
                  <col style="width:11.1111%"/>
                  <col style="width:11.1111%"/>
                  <col style="width:11.1111%"/>
                  <col style="width:11.1111%"/>
                  <col style="width:11.1111%"/>
                  <col style="width:11.1111%"/>
                  <col style="width:11.1111%"/>
                  <col style="width:11.1111%"/>
                </colgroup>
                <thead>
                  <tr>
                    <th rowspan="3">구분</th>
                    <th colspan="4">계약</th>
                    <th colspan="4">출고</th>
                  </tr>
                  <tr>
                    <th rowspan="2" class="none-brr">일</th>
                    <th class="none-brl"></th>
                    <th rowspan="2" class="none-brr">월</th>
                    <th class="none-brl"></th>
                    <th rowspan="2" class="none-brr">일</th>
                    <th class="none-brl"></th>
                    <th rowspan="2" class="none-brr">월</th>
                    <th class="none-brl"></th>
                  </tr>
                  <tr>
                    <th>%</th>
                    <th>%</th>
                    <th>%</th>
                    <th>%</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>캐스퍼</td>
                    <td class="t-red">{{ statusInfo.dayContractCnt }}</td>
                    <td class="t-red">{{ statusInfo.contractRatioDay }}</td>
                    <td class="t-red">{{ statusInfo.monthContractCnt }}</td>
                    <td class="t-red">{{ statusInfo.contractRatioMonth }}</td>
                    <td class="t-red">{{ statusInfo.dayReleaseCnt }}</td>
                    <td class="t-red">{{ statusInfo.releaseRatioDay }}</td>
                    <td class="t-red">{{ statusInfo.monthReleaseCnt }}</td>
                    <td class="t-red">{{ statusInfo.releaseRatioMonth }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div class="board">
              <table>
                <colgroup>
                  <col style="width:25%"/>
                  <col style="width:25%"/>
                  <col style="width:25%"/>
                  <col style="width:25%"/>
                </colgroup>
                <thead>
                  <tr>
                    <th>결제건수</th>
                    <th>결제대기</th>
                    <th>결제완료</th>
                    <th>결제실패</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>전체</td>
                    <td class="t-red">{{ statusInfo.payReadyAll }}</td>
                    <td class="t-red">{{ statusInfo.payCompleteAll }}</td>
                    <td class="t-red">{{ statusInfo.payFailAll }}</td>
                  </tr>
                  <tr>
                    <td>본인</td>
                    <td class="t-red">{{ statusInfo.payReadyEE }}</td>
                    <td class="t-red">{{ statusInfo.payCompleteEE }}</td>
                    <td class="t-red">{{ statusInfo.payFailEE }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </el-col>
          <el-col :span="8" class="contentsBox alarm-box">
            <main-box
              :alram-type="'B'"
              :table-title-type="'A'"
              :table-title="'공지사항'"
              :table-content="'A'"
              :table-link="'/wp/notice/manager'"
              :table-datas.sync="noticeList"
              class="pd-15 notice"
            />
            <main-box
              :alram-type="'B'"
              :table-title-type="'A'"
              :table-title="'부재자'"
              :table-content="'B'"
              :table-link="'/wp/set/absence-resume'"
              :table-datas.sync="absenteeList"
              :absentee-count="absenteeCount"
              class="pd-15"
            />
          </el-col>
        </el-row>
        <el-row>
          <!-- <el-col :span="8" class="contentsBox">
            <main-box
              :alram-type="'A'"
              :progress-num="
                parseInt(workInfo.customerImportantProgressCount) || 0
              "
              :not-read-num="
                parseInt(workInfo.customerImportantUnconfirmCount) || 0
              "
              :table-title-type="'B'"
              :table-title1="'고객센터이관'"
              :table-title2="'긴급알림'"
              :table-link="'/wp/cs/reception'"
              :table-datas.sync="csImportList"
            />
          </el-col> -->
          <el-col :span="8" class="contentsBox">
            <main-box
              :alram-type="'A'"
              :progress-num="parseInt(workInfo.ecProgressCount) || 0"
              :not-read-num="parseInt(workInfo.ecUnconfirmCount) || 0"
              :table-title-type="'A'"
              :table-title="'직원인증'"
              :table-link="'/wp/employee-auth/reception'"
              :table-datas.sync="ecWorkList"
            />
          </el-col>
          <el-col :span="8" class="contentsBox">
            <main-box
              :alram-type="'A'"
              :progress-num="parseInt(workInfo.myPageProgressCount) || 0"
              :not-read-num="parseInt(workInfo.myPageUnconfirmCount) || 0"
              :table-title-type="'A'"
              :table-title="'대고객 마이페이지 수신업무'"
              :table-link="'/wp/mypage-reception/customer/reception'"
              :table-datas.sync="customerMyPageList"
            />
          </el-col>
          <el-col :span="8" class="contentsBox">
            <main-box
              :alram-type="'A'"
              :progress-num="parseInt(workInfo.myPageProgressCount) || 0"
              :not-read-num="parseInt(workInfo.myPageUnconfirmCount) || 0"
              :table-title-type="'A'"
              :table-title="'법인 마이페이지 수신업무'"
              :table-link="'/wp/mypage-reception/corporation/reception'"
              :table-datas.sync="coporationMyPageList"
            />
          </el-col>
        </el-row>
      </div>
    </div>
    <el-dialog
      custom-class="message"
      :visible.sync="duplicateUserAlert"
      width="30%"
      :center="true"
    >
      <span>{{
        userInfo && userInfo.eeNm + "가(이) 새로운 환경에서 로그인 되었습니다."
      }}</span>
      <br />
      <span>다른 환경의 접속은 연결이 끊어집니다.</span>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="duplicateUserAlert = false">
          확인
        </el-button>
      </span>
    </el-dialog>
  </section>
</template>


<script>
import MainBox from "~/components/common/MainBox.vue";
import { mapState } from "vuex";
import moment from "moment";

export default {
  name: "Main",
  layout: "default",
  components: {
    MainBox
  },
  data() {
    return {
      duplicateUserAlert: false,
      totalWork: {
        // 모든 집계 정보
        allCount: 0, // 금일전체건수
        customerCenterCount: 0, // 고객센터이관업무 건수
        myPageCount: 0, // 마이페이지 건수
        obCount: 0, // OB 건수
        acceptCount: 0, // 접수 건수
        progressCount: 0, // 진행중 건수
        endCount: 0 // 종결 건수
      },
      workInfo: {
        // 업무별 알림 건수
        customerImportantProgressCount: "", // 고객센터이관 긴급 진행중건수
        customerImportantUnconfirmCount: "", // 고객센터이관 긴급 읽지않는건수
        customerNormalProgressCount: "", // 고객센터이관 일반 진행중건수
        customerNormalUnconfirmCount: "", // 고객센터이관 일반 읽지않는건수
        myPageProgressCount: "", // 마이페이지수신업무 진행중건수
        myPageUnconfirmCount: "", // 마이페이지수신업무 읽지않는건수
        ecProgressCount: "", // 직원인증 진행중건수
        ecUnconfirmCount: "" // 직원인증 읽지않는건수
      },
      noticeList: [], // 공지사항 목록
      csImportList: [], // 고객센터이관 긴급알림 목록
      csNormalList: [], // 고객센터이관 일반알림 목록
      ecWorkList: [], // 직원인증 목록
      myPageList: [], // 마이페이지 목록
      customerMyPageList: [], // 대고객 마이페이지 목록
      coporationMyPageList: [], // 법인 마이페이지 목록
      absenteeList: [], //부재자 목록
      absenteeCount: 0, //부재자 인원수
      imgtxt: "",
      imgTitle: "",
      statusInfo: {
        month: '',
        monthGoalCnt: '',
        workingDayNo: '',
        totalWorkingDay: '',
        workingDayRatio: '',
        dayContractCnt: '',
        monthContractCnt: '',
        contractRatioDay: '',
        contractRatioMonth: '',
        dayReleaseCnt: '',
        monthReleaseCnt: '',
        releaseRatioDay: '',
        releaseRatioMonth: '',
        payReadyAll: '',
        payReadyEE: '',
        payCompleteAll: '',
        payCompletEE: '',
        payFailAll: '',
        payFaillEE: '',
      },
    };
  },
  computed: {
    ...mapState(["consultants", "userInfo", "banners"])
  },
  created() {
    this.$store.dispatch("loadBannerList", { vm: this });
  },
  mounted() {
    this.songpa();
    this.checkedDuplicateUser(); // 중복 로그인 체크 - alert
    this.getTotalWorkCount();
    this.getTotalDataList();
    this.getAbsentee(); // 부재자 목록
    this.getStatusInfo();
  },
  methods: {
    goPage(pgNm) {
      // 업무별 페이지 이동
      switch (pgNm) {
        case "cusob":
          // location.hash = '/ob/reception'
          this.$router.push("/wp/ob/customer/reception");
          break;
        case "copob":
          // location.hash = '/ob/reception'
          this.$router.push("/wp/ob/corporation/reception");
          break;
        case "cs":
          // location.hash = '/cs/reception'
          this.$router.push("/wp/cs/reception");
          break;
        case "cusmypage":
          // location.hash = '/mypage-reception/reception'
          this.$router.push("/wp/mypage-reception/customer/reception");
          break;
        case "copmypage":
          // location.hash = '/mypage-reception/reception'
          this.$router.push("/wp/mypage-reception/corporation/reception");
          break;
        case "ec":
          // location.hash = '/mypage-reception/reception'
          this.$router.push("/wp/employee-auth/reception");
          break;
      }
    },
    customBannerUrl(suffixUrl) {
      let preffixUrl = "https://ep.hmc.co.kr";
      if (["stg", "dev"].includes(process.env.VUE_APP_PROFILE)) {
        preffixUrl = "https://tep.hmc.co.kr";
      }
      return preffixUrl + suffixUrl;
    },
    async getTotalWorkCount() {
      const [res, err] = await this.$https.get(
        "/v2/exclusive/main/total-work-count"
      ); // API-WE-업무담당자-005 (메인화면 집계 정보 조회)
      if (!err) {
        this.totalWork = res.data;
      }

      const [res1, err1] = await this.$https.get(
        "/v2/exclusive/main/work-count"
      ); // API-WE-업무담당자-009 (메인화면 업무 알림 건수 조회)
      if (!err1) {
        this.workInfo = res1.data;
      }
    },
    async getTotalDataList() {
      const [res, err] = await this.$https.get("/v2/exclusive/main/notice"); // API-WE-업무담당자-008 (메인화면 공지사항 조회)
      if (!err) {
        res.data.sort((a, b) => {
          // 오름차순(중요가 최상단)
          return a.noticeGradeCode < b.noticeGradeCode
            ? -1
            : a.noticeGradeCode < b.noticeGradeCode
            ? 1
            : 0;
        });

        res.data = res.data.map(items => {
          const convertObj = {
            path: "",
            title: items.noticeTitle || "",
            date: items.regDate || "",
            content: items.noticeContents || "",
            state: items.noticeConfirmDate !== null ? "success" : "fail",
            titleP: items.noticeGradeCode === "A" ? "important" : "",
            noticeNumber: items.noticeSerialNumber || ""
          };
          items = convertObj;
          return items;
        });

        this.noticeList = res.data;
      }

      this.getWorkData("customerImport"); // 고객센터이관 긴급
      this.getWorkData("customerNormal"); // 고객센터이관 일반
     // this.getWorkData("myPage"); // 마이페이지 수신업무
      this.getWorkData("customerMyPage"); // 대고객 마이페이지 수신업무
      this.getWorkData("coporationMyPage"); // 법인 마이페이지 수신업무
      this.getEcWorkData(); // 직원인증
    },
    async getWorkData(type) {
      let params = { searchType: "" };
      switch (type) {
        case "customerImport":
          params.searchType = 10; // 긴급알림 코드
          break;
        case "customerNormal":
          params.searchType = 20; // 일반알림 코드
          break;
        case "myPage":
          params.searchType = 30; // 수신업무 코드
          break;
        case "customerMyPage":
          params.searchType = 40; // 대고객 수신업무 코드
          break;
        case "coporationMyPage":
          params.searchType = 50; // 법인 수신업무 코드
          break;
      }

      const [res, err] = await this.$https.get(
        "/v2/exclusive/main/work",
        params
      ); // API-WE-업무담당자-007 (메인화면 업무 목록 조회) - 고객센터고객센터 일반알림
      if (!err) {
        switch (type) {
          case "customerImport":
          case "customerNormal":
            res.data = res.data.map(items => {
              const convertObj = {
                path: {
                  name: "cs-process",
                  params: { workSerialNumber: items.workAssignNumber }
                },
                title: items.counselTitleName || "", // 제목
                date: items.regDate || "", // 등록일시
                name: items.contractorName || "", // 고객이름
                contract: items.onlineStatusName || "", // 판매진행상태
                state: items.noticeConfirmYn === "Y" ? "success" : "fail" // 알림확인여부
              };
              items = convertObj;
              return items;
            });

            if (type === "customerImport") {
              this.csImportList = res.data; // 긴급알림 코드
            } else if (type === "customerNormal") {
              this.csNormalList = res.data; // 일반알림 코드
            }
            break;
          case "myPage":
            res.data = res.data.map(items => {
              const convertObj = {
                path: {
                  name: "wp-mypage-reception-process",
                  params: { workSerialNumber: items.workAssignNumber }
                },
                title: items.workProcessResultName || "", // 유형/처리결과
                date: items.transferDate || "", // 파일업로드일시
                name: items.contractorName || "", // 고객이름
                contract: items.onlineStatusName || "", // 판매진행상태
                state: items.noticeConfirmYn === "Y" ? "success" : "fail" // 알림확인여부
              };
              items = convertObj;
              return items;
            });
            this.myPageList = res.data; // 수신업무 코드
            break;
          case "customerMyPage":
            res.data = res.data.map(items => {
              const convertObj = {
                path: {
                  name: "wp-mypage-reception-customer-process",
                  params: { workSerialNumber: items.workAssignNumber }
                },
                title: items.workProcessResultName || "", // 유형/처리결과
                date: items.transferDate || "", // 파일업로드일시
                name: items.contractorName || "", // 고객이름
                contract: items.onlineStatusName || "", // 판매진행상태
                state: items.noticeConfirmYn === "Y" ? "success" : "fail" // 알림확인여부
              };
              items = convertObj;
              return items;
            });
            this.customerMyPageList = res.data; // 수신업무 코드
            break;
          case "coporationMyPage":
            res.data = res.data.map(items => {
              const convertObj = {
                path: {
                  name: "wp-mypage-reception-corporation-process",
                  params: { workSerialNumber: items.workAssignNumber }
                },
                title: items.workProcessResultName || "", // 유형/처리결과
                date: items.transferDate || "", // 파일업로드일시
                name: items.contractorName || "", // 고객이름
                contract: items.onlineStatusName || "", // 판매진행상태
                state: items.noticeConfirmYn === "Y" ? "success" : "fail" // 알림확인여부
              };
              items = convertObj;
              return items;
            });
            this.coporationMyPageList = res.data; // 수신업무 코드
            break;
        }
      }
    },
    async getAbsentee() {
      let param = {
        absenceStartDate: moment().format("YYYYMMDD")
      };
      const [res, err] = await this.$https.get(
        "/v2/exclusive/setting/absence-history",
        param
      ); // API-E-업무담당자-089(부재 설정 처리)
      console.log(res, err);
      if (!err) {
        if (!res.data || !res.data.list || res.data.list.length === 0) {
          this.absenteeList = [];
          this.absenteeCount = 0;
        } else {
          this.absenteeList = res.data.list
            .map((el, idx) => {
              return {
                ...el,
                no: idx + 1,
                exclusiveUserName: el.exclusiveUserName
                  ? el.exclusiveUserName
                  : "",
                absenceStartDate: el.absenceStartDate
                  ? moment(el.absenceStartDate, "YYYYMMDDHHmm").format(
                      "YYYY-MM-DD HH:mm"
                    )
                  : "",
                absenceEndDate: el.absenceEndDate
                  ? moment(el.absenceEndDate, "YYYYMMDDHHmm").format(
                      "YYYY-MM-DD HH:mm"
                    )
                  : ""
              };
            })
            .slice(0, 3);
          this.absenteeCount = this.fnAbsenteeCount(res);
        }
        console.log("/main/getAbsentee", this.absenteeList);
      }
    },
    async getEcWorkData() {
      const [res2, err2] = await this.$https.get("/v2/exclusive/main/ecWork"); // API-WX-전담컨설턴트-037 (메인화면 직원인증 목록 조회)
      if (!err2) {
        res2.data = res2.data.map(items => {
          const convertObj = {
            path: {
              name: "wp-employee-auth-process",
              params: { workSerialNumber: items.workAssignNumber }
            },
            title: items.content || "", // 제목
            date: items.regDate || "", // 등록일시
            name: items.customerName || "", // 고객이름
            contract: items.workProcessResultName || "", // 판매진행상태
            state: items.noticeConfirmYn === "Y" ? "success" : "fail" // 알림확인여부
          };
          items = convertObj;
          return items;
        });

        this.ecWorkList = res2.data; // 직원인증 목록
      }
    },
    async getAbsentee() {
      let param = {
        absenceStartDate: moment().format("YYYYMMDD")
      };
      const [res, err] = await this.$https.get(
        "/v2/exclusive/setting/absence-history",
        param
      ); // API-E-업무담당자-089(부재 설정 처리)
      console.log(res, err);
      if (!err) {
        if (!res.data || !res.data.list || res.data.list.length === 0) {
          this.absenteeList = [];
          this.absenteeCount = 0;
        } else {
          this.absenteeList = res.data.list
            .map((el, idx) => {
              return {
                ...el,
                no: idx + 1,
                exclusiveUserName: el.exclusiveUserName
                  ? el.exclusiveUserName
                  : "",
                absenceStartDate: el.absenceStartDate
                  ? moment(el.absenceStartDate, "YYYYMMDDHHmm").format(
                      "YYYY-MM-DD HH:mm"
                    )
                  : "",
                absenceEndDate: el.absenceEndDate
                  ? moment(el.absenceEndDate, "YYYYMMDDHHmm").format(
                      "YYYY-MM-DD HH:mm"
                    )
                  : ""
              };
            })
            .slice(0, 3);
          this.absenteeCount = this.fnAbsenteeCount(res);
        }
        console.log("/main/getAbsentee", this.absenteeList);
      }
    },
    async getStatusInfo() {
      const param = {
        eeNo : this.userInfo.eeno
      }

      const [res, err] = await this.$https.post('/v2/exclusive/main/getStatusInfo', param)

      if(!err){
        if(res.data){
          this.statusInfo = {
            ...res.data,
            workingDayRatio:(res.data.workingDayNo / res.data.totalWorkingDay * 100).toFixed(1) + '%',
            contractRatioDay: (res.data.dayContractCnt / res.data.monthGoalCnt * 100).toFixed(1) + '%',
            contractRatioMonth: (res.data.monthContractCnt / res.data.monthGoalCnt * 100).toFixed(1) + '%',
            releaseRatioDay: (res.data.dayReleaseCnt / res.data.monthGoalCnt * 100).toFixed(1) + '%',
            releaseRatioMonth: (res.data.monthReleaseCnt / res.data.monthGoalCnt * 100).toFixed(1) + '%',
          }
        }
      }

    },
    checkedDuplicateUser() {
      // 중복 로그인 사용자 체크 - alert
      this.duplicateUserAlert = this.$route.params
        ? this.$route.params.duplicateYn === "Y"
        : false;
    },
    //구매상담신청현황 (송파대로) 권한에 따라 메인 접근 불가능 (임시)
    songpa() {
      console.log(this.userInfo);
      // if(this.userInfo && this.userInfo.exclusiveUseAuthGroupId === 'M0004') {
      if (
        this.userInfo &&
        (this.userInfo.eeno === "2710017" || this.userInfo.eeno === "9063718")
      ) {
        this.$router.push("/wp/support/songpa");
      }
    },
    fnAbsenteeCount(res) {
      //금일부재자 명 구함
      let toDate = new Date();
      return res.data.list.filter(el => {
        return moment(el.absenceStartDate, "YYYYMMDD") <= toDate;
      }).length;
    }
  }
};
</script>
<style lang="scss" scoped>
@import "~/assets/style/pages/main.scss";
</style>
