<template>
  <section>
    <div id="reception">
      <div class="btn-wrap">
        <div class="side">
          <el-button
            type="info"
            @click="resetSearchCond"
          >
            초기화
          </el-button>
        </div>

        <div
          class="main"
          style="width: 300px;"
        >
          <el-button
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            @click="onSearch(1)"
          >
            조회
          </el-button>
          <el-button
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            class="excel"
            @click="downloadExcel"
          >
            EXCEL 다운로드
          </el-button>
        </div>
      </div>
      <el-form
        ref="ruleForm"
        :model="ruleForm"
        class="detail-form detail-box"
      >
        <el-row>
          <el-col :span="24">
            <el-form-item
              label="기간"
            >
              <el-date-picker
                v-model="ruleForm.searchFromDt"
                type="date"
                :clearable="false"
              />
              <span class="ex-txt">~</span>
              <el-date-picker
                v-model="ruleForm.searchEndDt"
                type="date"
                :clearable="false"
              />
              <el-radio-group
                v-model="searchDtRadio"
                class="tabBtn-case01"
                @change="onChangeSearchDtRadio"
              >
                <el-radio-button label="lastDay">
                  전일
                </el-radio-button>
                <el-radio-button label="today">
                  오늘
                </el-radio-button>
                <el-radio-button label="day7">
                  7일
                </el-radio-button>
                <el-radio-button label="day30">
                  30일
                </el-radio-button>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item
              label="업무 유형"
              prop="workLevelName"
            >
              <el-select
                v-model="ruleForm.workType"
              >
                <el-option
                  v-for="{ value, label } in commonCodes.U021"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="16">
            <el-form-item
              label="업무 진행상태"
            >
              <el-select
                v-model="ruleForm.workStatus"
                multiple
                collapse-tags
                @change="onChangeMultiSelect($event, 'work')"
              >
                <el-option
                  v-for="{ value, label } in commonCodes.U011 && commonCodes.U011.slice(1)"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
              <el-checkbox
                v-model="workSelectedVal"
                style="margin-left: 8px;"
                @change="selectedAll($event,'work')"
              >
                전체
              </el-checkbox>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item
              label="임직원몰 진행상태"
            >
              <el-select
                v-model="ruleForm.onlineStatus"
                multiple
                collapse-tags
                placeholder="전체"
                @change="onChangeMultiSelect($event,'online')"
              >
                <!-- commonCodes.T010 -->
                <el-option
                  v-for="{ value, label } in commonCodes.T010 && commonCodes.T010.slice(1)"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
              <el-checkbox
                v-model="onlineSelectedVal"
                style="margin-left: 8px;"
                @change="selectedAll($event,'online')"
              >
                전체
              </el-checkbox>
            </el-form-item>
          </el-col>
          <el-col :span="16">
            <el-form-item
              label="레거시 진행상태"
            >
              <el-select
                v-model="ruleForm.legacyStatus"
                multiple
                collapse-tags
                @change="onChangeMultiSelect($event, 'legacy')"
              >
                <el-option
                  v-for="{ value, label } in LegacyCommonCodes.C013 && LegacyCommonCodes.C013.slice(1)"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
              <el-checkbox
                v-model="legacySelectedVal"
                style="margin-left: 8px;"
                @change="selectedAll($event, 'legacy')"
              >
                전체
              </el-checkbox>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item
              label="업무담당자"
            >
              <el-select
                v-model="ruleForm.consultantId"
                placeholder="전체"
                multiple
                collapse-tags
                @change="onChangeMultiSelect($event,'consultant')"
              >
                <el-option
                  v-for="{ sysUserNo, sysUserNm } in consultants && consultants.slice(1)"
                  :key="sysUserNo"
                  :value="sysUserNo"
                  :label="sysUserNm"
                />
              </el-select>
              <el-checkbox
                v-model="consultantSelectedVal"
                style="margin-left: 8px;"
                @change="selectedAll($event,'consultant')"
              >
                전체
              </el-checkbox>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item
              label="처리자"
            >
              <el-select
                v-model="ruleForm.managerId"
                placeholder="전체"
              >
                <el-option
                  v-for="{ sysUserNo, sysUserNm } in consultants"
                  :key="sysUserNo"
                  :value="sysUserNo"
                  :label="sysUserNm"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item
              label="접수유형"
            >
              <el-select
                v-model="ruleForm.workLevelCode"
              >
                <el-option
                  v-for="{ value, label } in commonCodes.U004"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item
              label="계약번호"
              prop="contractId"
            >
              <el-input
                v-model="ruleForm.contractId"
                @keydown.native.tab="onAddZero(ruleForm.contractId)"
                @keyup.native.enter="onSearch(1)"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item
              label="계약자명"
              prop="contractEmployeeName"
            >
              <el-input
                v-model="ruleForm.contractEmployeeName"
                @blur="ruleForm.contractEmployeeName = $event.target.value"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item
              label="계약자 사번"
              prop="contractEmployeeId"
            >
              <el-input
                v-model="ruleForm.contractEmployeeId"
              />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-form
        ref="ruleForm"
        :model="ruleForm"
        class="detail-form detail01"
        style="margin-top:10px;"
      >
        <el-form-item label="">
          <el-col
            :span="4"
            class="header"
          >
            집계데이터 조회
          </el-col>
          <el-col :span="5">
            대상리스트<span><span>{{ countData.totalCount || 0 }}</span>건</span>
          </el-col>
          <el-col :span="5">
            접수<span><span>{{ countData.received || 0 }}</span>건</span>
          </el-col>
          <el-col :span="5">
            진행중<span><span>{{ countData.proceeding || 0 }}</span>건</span>
          </el-col>
          <el-col :span="5">
            종결<span><span>{{ countData.closed || 0 }}</span>건</span>
          </el-col>
        </el-form-item>
      </el-form>
      <div class="btn-wrap">
        <div class="side">
          <el-checkbox
            v-model="checked"
            label="전체선택"
            @change="toggleSelectionAll"
          />
        </div>

        <div
          class="main"
        >
          <el-button
            v-if="isValidAuthBtn('authExclusive')"
            type="primary"
            @click="changeReadStatus"
          >
            읽음처리
          </el-button>
          <el-button
            v-if="isValidAuthBtn('authManage')"
            type="primary"
            @click="openConsultantPopup"
          >
            처리자 변경
          </el-button>
        </div>
      </div>
      <h-table
        ref="multipleTable"
        :table-type="'TwoHeadTable'"
        :table-header="tableHeader"
        :table-datas="tableData"
        :handle-change="handleSelect"
      />
      <div class="btn-wrap">
        <div class="side" />
        <div class="pagination">
          <v-pagination
            v-if="tableData.length"
            :page.sync="pageInfo.page"
            :size="pageInfo.size"
            :total="pageInfo.total"
            @page-change="onSearch"
          />
        </div>
        <div class="main" />
      </div>
      <!-- 초기화 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="alertVisible"
      >
        <!-- Message -->
        조회 결과가 없습니다.

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="primary"
            @click="alertVisible = false"
          >
            확인
          </el-button>
        </template>
      </el-dialog>
      <!-- 업무담당자 변경 팝업 -->
      <el-dialog
        title="업무담당자 변경"
        :visible.sync="consultantPop"
        @open="consutantPopupOpened"
      >
        <!-- Message -->
        <el-form
          :inline="true"
          class="detail-form"
        >
          <el-row>
            <el-col :span="24">
              <el-form-item label="컨시어지">
                <el-select
                  v-model="selConsultant"
                  placeholder="컨시어지 선택"
                >
                  <el-option
                    v-for="{ sysUserNo, sysUserNm } in consultants"
                    :key="sysUserNo"
                    :value="sysUserNo"
                    :label="sysUserNm"
                  />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="primary"
            @click="changeConsultant"
          >
            변경
          </el-button>
        </template>
      </el-dialog>
      <loading
        :pop-visible.sync="popVisibleLoading"
        @close="popVisibleLoading = false"
      />
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import HTable from '~/components/common/HTable.vue'
import { mapState } from 'vuex'
import moment from 'moment'
import Loading from '~/components/popup/Loading.vue'
import PopMessage from '~/components/popup/PopMessage.vue'

export default {
  name: 'Reception',
  layout: 'default',
  components:{
    HTable,
    Loading,
    PopMessage
  },
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      workSelectedVal: false,
      legacySelectedVal: false,
      popVisibleLoading: false,
      onlineSelectedVal: false,
      consultantSelectedVal: false,
      selConsultant: null,
      multipleSelection: [],
      alertVisible: false,
      consultantPop: false,
      checked: false,
      searchDtRadio: 'today',
      ruleForm:{
        searchFromDt: moment(),
        searchEndDt: moment(),
        workLevelCode: 'all', // 접수 유형
        workType: 'all', // 업무 유형
        workStatus: ['10','20'], // 업무진행상태(종결제외: 접수,진행중)
        onlineStatus: [], // 임직원몰 진행상태
        legacyStatus: [],  // 레거시 진행상태
        consultantId: [],
        managerId: '',
        contractId: '',
        contractEmployeeName: '',
        contractEmployeeId: '',
        customerId: ''
      },
      countData: {
        totalCount: 0,
        received: 0,
        proceeding: 0,
        closed: 0
      },
      code: [
        { value: 'all',  label: '전체' }
      ],
      tableData: [],
      tableHeader:[
        {
          label: '선택',
          type: 'checkBox',
          prop: 'isSelected',
          width: '50',
          align: 'center',
          children: []
        },
        {
          label: '업무 일련번호',
          prop: 'workSerialNumber',
          align: 'center',
          width: '110',
          children:[]
        },
        {
          label: '진행정보',
          type: '',
          prop: '',
          align: 'center',
          children: [
            {
              label: '접수 유형',
              prop: 'workLevelName',
              width: '100',
              align: 'center'
            },
            {
              label: '처리결과',
              prop: 'progressResult',
              width: '90',
              align: 'center'
            },
            {
              label: '레거시 진행상태',
              prop: 'legacyStatusName',
              width: '110',
              align: 'center'
            },
            {
              label: '임직원몰 진행상태',
              prop: 'onlineStatusName',
              width: '170',
              align: 'center'
            }
          ]
        },
        {
          label: '고객정보',
          type: '',
          prop: '',
          align: 'center',
          children: [
            {
              label: '계약번호',
              prop: 'contractNumber',
              width: '130',
              align: 'center',
              type: 'link',
              link: '/#/cs/process',
              linkData: 'workSerialNumber',
            },
            {
              label: '계약자명',
              prop: 'contractorName',
              width: '100',
              align: 'center'
            },
            {
              label: '계약자 사번',
              prop: 'employeeId',
              width: '100',
              align: 'center'
            }
          ]
        },
        {
          label: '이관정보',
          type: '',
          prop: '',
          align: 'center',
          children: [
            {
              label: '분류',
              prop: 'progressType',
              width: '100',
              align: 'center'
            },
            {
              label: '제목',
              prop: 'faqTitle',
              width: '200',
              align: 'center'
            },
            {
              label: '본문내용(10자 내외)',
              prop: 'faqContents',
              width: '300',
              align: 'center'
            },
            {
              label: '이관시간',
              prop: 'regDt',
              width: '150',
              align: 'center'
            }
          ]
        },
        {
          label: '계약 정보',
          type: '',
          prop: '',
          align: 'center',
          children: [
            {
              label: '차명',
              prop: 'carName',
              width: '120',
              align: 'center'
            },
            {
              label: '재고구분',
              prop: 'stockType',
              width: '100',
              align: 'center'
            },
            {
              label: '계약일시',
              prop: 'contractDate',
              width: '150',
              align: 'center'
            },
            {
              label: '배정일시',
              prop: 'assignDate',
              width: '150',
              align: 'center'
            },
            {
              label: '출고일/출고예정일',
              prop: 'releaseOrExpectDate',
              width: '150',
              align: 'center'
            }
          ]
        },
        {
          label: '처리상세 결과',
          type: '',
          prop: '',
          align: 'center',
          children: [
            {
              label: '처리 결과',
              prop: 'workProcessResultName',
              width: '100',
              align: 'center'
            },
            {
              label: '처리 일시',
              prop: 'workProcessEndDate',
              width: '150',
              align: 'center'
            }
          ]
        },
        {
          label: '업무담당자',
          type: '',
          prop: '',
          align: 'center',
          children: [
            {
              label: '업무담당자',
              prop: 'consultantName',
              width: '80',
              align: 'center'
            },
            {
              label: '처리자',
              prop: 'managerName',
              width: '80',
              align: 'center'
            }
          ]
        },
        {
          label: '생성일시',
          prop: 'regDate',
          align: 'center',
          width: '150',
          children:[]
        }
      ],
      commonCodes: {},
      LegacyCommonCodes: {},
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      }
    }
  },
  computed: {
    ...mapState({
      userInfo: state => state.userInfo
    }),
    consultants: function() {
      const consultants = this.$store.state.consultants.slice()
      if(consultants && consultants.length > 0) {
        consultants.unshift( { 'useAuthId': '', 'sysUserNo': '', 'sysUserNm': '전체', 'opsNm': '' } )
      }
      return consultants
    }
  },
  watch: {
    '$route': 'fetchData'
  },
  async created() {
    this.fetchData()
    await this.loadCommonCode()
  },
  mounted() {
    this.$store.dispatch('loadConsultants', {vm: this})
  },
  methods: {
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null
      switch(systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {vm: this, codeTypeCode: codeType})
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {vm: this, codeTypeCode: codeType})
        break
      case 'W':
        res = this.$store.dispatch('loadCommonCodesW', {
          vm: this,
          codeTypeCode: codeType
        })
        break
      }
      return res
    },
    async loadCommonCode() {
      const [ccU021, ccU011, ccT010, ccU004, ccC013] = await Promise.all([
        this.fetchCommonCodeData('E', 'U021'), // 업무유형
        this.fetchCommonCodeData('E', 'U011'), // 업무 진행상태
        /* [#9951/2021.12.02] 온라인 진행상태 코드 systemTypeCode W로 전체 변경 적용 */
        this.fetchCommonCodeData('W', 'T010'), // 임직원몰 진행상태
        this.fetchCommonCodeData('E', 'U004'), // 접수유형

        this.fetchCommonCodeData('C', 'C013') // 레거시 진행상태
      ])

      this.commonCodes = { ...ccU021, ...ccU011, ...ccT010, ...ccU004 }
      this.LegacyCommonCodes = { ...ccC013 }

      this.initRuleFormStatus()
    },
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    onAddZero(contractNumber) {
      let resultString = ''
      if(contractNumber.length > 6) {
        const frontString = contractNumber.substring(0,7)
        const backString = contractNumber.substring(7)

        resultString = resultString.concat(frontString)
        resultString = resultString.concat(backString.length >= 6 ? backString : Array.from({length: 6 - backString.length}, () => 0).join('') + backString)
      }

      if(!resultString) { resultString = contractNumber }
      this.ruleForm.contractId = resultString
    },
    fetchData() {
      if(this.$route.query.workLevelCode) {
        this.ruleForm.workLevelCode = this.$route.query.workLevelCode
        console.log(this.ruleForm.workLevelCode)
      }
    },
    handleSelect(val, row) {
      this.tableData.filter((items) => { return items.no !== row.no }).map((items) => { items.isSelected = false })
      console.log(this.tableData)
    },
    resetSearchCond() {
      Object.assign(this.ruleForm, this.$options.data().ruleForm)
      this.searchDtRadio = 'today'
    },
    onSearch(page) {
      if(!this.isValidAuthBtn('authSelect')) { // 권한없을경우 동작 x
        return
      }

      this.$data.pageInfo.page = page
      this.getData()
    },
    initRuleFormStatus() {
      if(this.ruleForm.workStatus && this.ruleForm.workStatus.length === 0) { // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false, 'work')
      }
      if(this.ruleForm.legacyStatus && this.ruleForm.legacyStatus.length === 0) { // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false, 'legacy')
      }
      if(this.ruleForm.onlineStatus && this.ruleForm.onlineStatus.length === 0) { // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false,'online')
      }
      if(this.ruleForm.consultantId && this.ruleForm.consultantId.length === 0) { // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false,'consultant')
      }
    },
    selectedAll(e,type) {
      if(type==='work'){
        if(e) {
          this.ruleForm.workStatus = this.commonCodes.U011.slice(1).map((items) => {
            return items.value
          }) || []
        } else {
          this.ruleForm.workStatus = []
        }
      }else if(type==='legacy'){
        if(e) {
          this.ruleForm.legacyStatus = this.LegacyCommonCodes.C013.slice(1).map((items) => {
            return items.value
          }) || []
        } else {
          this.ruleForm.legacyStatus = []
        }
      }else if(type==='online') {
        if (e) {
          this.ruleForm.onlineStatus = this.commonCodes.T010.slice(1).map((items) => {
            return items.value
          }) || []
        } else {
          this.ruleForm.onlineStatus = []
        }
      }else if(type==='consultant'){
        if(e) {
          this.ruleForm.consultantId = this.consultants.slice(1).map((items) => {
            return items.sysUserNo
          }) || []
        } else {
          this.ruleForm.consultantId = []
        }
      }

    },
    onChangeMultiSelect(data, type) {
      if(type === 'legacy') { // 레거시 진행상태
        if(data.length === this.LegacyCommonCodes.C013.slice(1).length) {
          this.legacySelectedVal = true
        } else {
          this.legacySelectedVal = false
        }
      } else if(type === 'work') { //업무 진행상태
        if(data.length === this.commonCodes.U011.slice(1).length) {
          this.workSelectedVal = true
        } else {
          this.workSelectedVal = false
        }
      } else if(type==='online'){
        if(data.length === this.commonCodes.T010.slice(1).length) {
          this.onlineSelectedVal = true
        } else {
          this.onlineSelectedVal = false
        }
      }else if(type==='consultant'){
        if(data.length === this.consultants.slice(1).length) {
          this.consultantSelectedVal = true
        } else {
          this.consultantSelectedVal = false
        }
      }
    },
    async getData() {

      if(!this.ruleForm.searchFromDt || !this.ruleForm.searchEndDt) {
        this.alertMessage = '날짜는 필수입력사항입니다.'
        this.alertMessagePop = true
        return false
      }

      if(moment(this.ruleForm.searchFromDt).diff(moment(this.ruleForm.searchEndDt)) > 0) {
        this.alertMessage = '시작일은 종료일보다 클수 없습니다.'
        this.alertMessagePop = true
        return false
      }

      this.initRuleFormStatus()

      const { page: pageNo, size: pageSize } = this.$data.pageInfo

      const params = {
        ...this.ruleForm,
        workType: this.ruleForm.workType !== 'all' ? this.ruleForm.workType : '',
        workLevelCode: this.ruleForm.workLevelCode!=='all' ? this.ruleForm.workLevelCode : '',
        // workStatus: this.ruleForm.workStatus!=='all' ? this.ruleForm.workStatus : '',
        // legacyStatus: this.ruleForm.legacyStatus!=='all' ? this.ruleForm.legacyStatus : '',
        // onlineStatus: this.ruleForm.onlineStatus!=='all' ? this.ruleForm.onlineStatus : '',
        searchFromDt: moment(this.ruleForm.searchFromDt).format('YYYYMMDD'),
        searchEndDt: moment(this.ruleForm.searchEndDt).format('YYYYMMDD'),
        pageNo,
        pageSize
      }
      this.popVisibleLoading = true
      // API-E-업무담당자-057 (고객센터이관업무 목록조회)
      const [res,err] = await this.$https.post('/v1/exclusive/customer-list', params)
      if(!err) {
        if(!res.data.list || res.data.list.length===0) {
          this.tableData = []
        } else {
          this.tableData = res.data.list.map((el, idx) => {
            return {
              ...el,
              no : res.data.total - res.data.endRow + res.data.list.length - idx,
              isSelected: false,
              faqContents : el.faqContents ? el.faqContents.slice(0, 10) : '',
              bold: el.noticeConfirmYn !== 'Y' ? 'bold' : ''
            }
          })
        }

        this.$data.pageInfo = {
          ...this.$data.pageInfo,
          total: res.data.total
        }

        console.log('/customer', this.tableData)
        this.popVisibleLoading = false
      } else {
        console.error(err)
        this.tableData = []
        this.popVisibleLoading = false
      }

      const [res2,err2] = await this.$https.get('/v1/exclusive/customer-count', params)
      if(!err2) {
        if(!res2.data) {
          Object.assign(this.$data.countData, this.$options.data().countData)
          return
        }
        this.countData = res2.data
        console.log('/customer-count', this.countData)
      } else {
        console.error(err2)
      }
    },
    async downloadExcel() {

      this.initRuleFormStatus()

      const params = {
        ...this.ruleForm,
        workLevelCode: this.ruleForm.workLevelCode!=='all' ? this.ruleForm.workLevelCode : '',
        workType: this.ruleForm.workType !=='all' ? this.ruleForm.workType : '',
        // workStatus: this.ruleForm.workStatus!=='all' ? this.ruleForm.workStatus : '',
        // legacyStatus: this.ruleForm.legacyStatus!=='all' ? this.ruleForm.legacyStatus : '',
        // onlineStatus: this.ruleForm.onlineStatus!=='all' ? this.ruleForm.onlineStatus : '',
        searchFromDt: moment(this.ruleForm.searchFromDt).format('YYYYMMDD'),
        searchEndDt: moment(this.ruleForm.searchEndDt).format('YYYYMMDD')
      }
      // API-E-업무담당자-058 (고객센터이관업무 목록조회 엑셀저장)
      const [res,err] = await this.$https.post('/v1/exclusive/customer-excel', params, null, null, { responseType: 'blob' })
      if(!err) {
        const blob = new Blob([res], {type : res.Type })
        const nowDate = moment().format('YYYYMMDD_HHmm')
        if(window.navigator.msSaveOrOpenBlob) {
          // IE11
          window.navigator.msSaveOrOpenBlob(blob, '고객센터이관업무목록_' + nowDate + '.xlsx')
        } else {
          // IE11 외 브라우저
          const blobURL = window.URL.createObjectURL(blob)
          const tempLink = document.createElement('a')

          tempLink.href = blobURL

          tempLink.setAttribute('download', '고객센터이관업무목록_' + nowDate + '.xlsx')
          document.body.appendChild(tempLink)
          tempLink.click()
          document.body.removeChild(tempLink)
          window.URL.revokeObjectURL(blobURL)
        }
      } else {
        console.error(err)
        this.tableData = []
      }
    },
    onChangeSearchDtRadio(val) {
      if(val==='lastDay') {
        this.ruleForm.searchFromDt = moment().subtract('days', 1)
        this.ruleForm.searchEndDt = moment().subtract('days', 1)
      } else if(val==='today') {
        this.ruleForm.searchFromDt = moment()
        this.ruleForm.searchEndDt = moment()
      } else if(val==='day7') {
        this.ruleForm.searchFromDt = moment().subtract('days', 7)
        this.ruleForm.searchEndDt = moment()
      } else if(val==='day30') {
        this.ruleForm.searchFromDt = moment().subtract('days', 30)
        this.ruleForm.searchEndDt = moment()
      }
    },
    async changeReadStatus() {
      this.multipleSelection = this.tableData.filter((items) => {
        return items.isSelected === true
      })

      if(this.multipleSelection.length===0) {
        this.alertMessage = '업무를 먼저 선택해주세요.'
        this.alertMessagePop = true
      } else {
        const workAssignNumberList = this.multipleSelection.map(el => el.workSerialNumber).join(',') //TODO : col22(업무일련번호)를 업무ID 값으로 변경 필요?

        let params = new URLSearchParams()
        params.append('workAssignNumberList', workAssignNumberList)

        const [res, err] = await this.$https.put('v1/exclusive/common/work-read', params) //workAssignNumberList : 업무 ID 목록(comma-separated)
        if(!err) {
          console.log(res)
          this.alertMessage = '읽음처리 되었습니다.'
          this.alertMessagePop = true
          this.onSearch(1)
        } else {
          console.error(err)
        }
      }
    },
    openConsultantPopup() {
      if(this.multipleSelection.length===0) {
        this.alertMessage = '업무를 먼저 선택해주세요.'
        this.alertMessagePop = true
      } else {
        this.consultantPop = true
      }
    },
    consutantPopupOpened() {
      //컨설턴트 명단 store load
      this.$store.dispatch('loadConsultants', {vm: this})
    },
    async changeConsultant() {
      if(!this.selConsultant) {
        this.alertMessage = '컨설턴트를 선택해주세요.'
        this.alertMessagePop = true
      } else {
        const workAssignNumberList = this.multipleSelection.map(el => el.workSerialNumber).join(',')

        const [res, err] = await this.$https.put(`v1/exclusive/common/disposer?workEmployeeNumber=${this.selConsultant}&workAssignNumberList=${workAssignNumberList}`) //workEmployeeNumber : 컨설턴트 ID, workAssignNumberList[] : 업무 ID 목록(comma-separated)
        if(!err) {
          console.log(res)
          this.alertMessage = '처리자가 변경되었습니다.'
          this.alertMessagePop = true
          this.selConsultant = null
          this.consultantPop = false
          this.onSearch(1)
        } else {
          console.error(err)
        }
      }

    },
    toggleSelectionAll() {
      if(this.checked) {
        this.tableData.map((items) => { items.isSelected = true })
      }
      else {
        this.tableData.map((items) => { items.isSelected = false })
      }
    }
  },

}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/reception.scss';
</style>
