<template>
  <section>
    <div id="process">
      <div class="article-title">
        <h-search
          v-model="workSerialNumber"
          :title="'업무일련번호'"
          :on-click="searchWork"
          :active-button="isValidAuthBtn('authSelect')"
          @enter="searchWork"
        />
        <div class="btn-group">
          <div>
            <!-- 수정은 고객센터 -->
            <!-- <el-button
              v-if="isValidAuthBtn('authExclusive') && (isAuth || activeFlag)"
              type="primary"
              :disabled="!workSerialNumber"
              @click="save"
            >
              저장
            </el-button> -->
            <!-- <el-button
              v-if="isValidAuthBtn('authExclusive') && (isAuth || activeFlag)"
              type="primary"
              :disabled="!workSerialNumber"
              @click="openPopSms()"
            > -->
            <!-- 저장 버튼의 경우 처리자와 동일할 시 활성화 되나 SMS는 제약이 없어 조건 x -->
            <el-button
              v-if="isValidAuthBtn('authSms') && isValidUserAuthBtn()"
              type="primary"
              :disabled="!workSerialNumber"
              @click="openPopSms()"
            >
              문자보내기
            </el-button>
          </div>
        </div>
      </div>

      <h-relese-info
        :info="data"
      />
      <div class="article">
        <el-tabs
          v-model="activeName"
          type="card"
          stretch
          @tab-click="handleTabClick"
        >
           <el-tab-pane
            label="계약정보"
            name="fifth"
          >
            <contract-info
              ref="contractInfo"
              :contract-number.sync="contractNumber"
              :contract-data.sync="contractData"
              :contract-info-data.sync="info"
              :user-info-data.sync="userInfo"
              :common-codes.sync="commonCodes"
              :active-user-flag.sync="activeFlag"
              @refresh="onRefresh($event, 'contract')"
            />
          </el-tab-pane>
          <el-tab-pane
            label="차량정보"
            name="second"
          >
            <car-info
              ref="CarInfo"
              :contract-info-data.sync="info"
              :contract-number.sync="contractNumber"
              :active-user-flag.sync="activeFlag"
              @data="getCarProductionNumber"
            />
            <!-- <car-info
              :car-info-data.sync="carInfoData"
              :choice-option-names.sync="choiceOptionNames"
              :tuix-option-names.sync="tuixOptionNames"
            /> -->
          </el-tab-pane>
          <el-tab-pane
            label="결제정보"
            name="third"
          >
            <pay-info
              ref="payInfo"
              :contract-number.sync="contractNumber"
              :user-info-data.sync="userInfo"
              :contract-data.sync="contractData"
              :contract-info-data.sync="info"
              :active-user-flag.sync="activeFlag"
              @refresh="onRefresh($event, 'pay')"
            />
          </el-tab-pane>
          <el-tab-pane
            label="출고정보"
            name="fourth"
          >
            <release-info
              ref="releaseInfo"
              :contract-info-data.sync="info"
              :contract-data.sync="contractData"
              :active-user-flag.sync="activeFlag"
              @refresh="onRefresh($event, 'release')"
            />
          </el-tab-pane>
          <el-tab-pane
            label="상태이력"
            name="first"
          >
            <status-history
              ref="StatusHistory"
              :component-sort-list.sync="componentSortList"
              :contract-number.sync="contractNumber"
              @refresh="onRefresh($event, 'status')"
            />
          </el-tab-pane>
          <el-tab-pane
            label="문자이력"
            name="sixth"
          >
            <sms-history
              ref="SmsHistory"
              :contract-number.sync="contractNumber"
            />
            <!-- <sms-history
              :data.sync="messageTabData"
              @refresh="onRefresh($event, 'sms')"
            /> -->
          </el-tab-pane>
        </el-tabs>
      </div>

      <!-- 조회결과없음 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="alertNoData"
      >
        <!-- Message -->
        조회 결과가 없습니다.

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="info"
            @click="alertNoData = false"
          >
            확인
          </el-button>
        </template>
      </el-dialog>

      <!-- 문자보내기 팝업 -->
      <el-dialog
        title="문자보내기"
        :visible.sync="popVisible05"
        width="1100px"
      >
        <!-- Popup Contents -->
        <div class="board-wrap sandmessage">
          <h-title :title="'수신자 정보'" />
          <el-form
            ref="contractData"
            :model="contractData"
            class="detail-form"
          >
            <el-row>
              <el-col :span="9">
                <el-form-item label="1">
                  <!-- {{ contractData.contractorInfo && contractData.contractorInfo.length > 0 ? contractData.contractorInfo[0].customerName : '' }} -->
                  <el-select v-model="contractorNames" multiple placeholder="수신자명">
                    <el-option
                      v-for="item in contractData.contractorInfo"
                      :key="item.customerName"
                      :label="item.customerName"
                      :value="item.customerName">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="15">
                <el-form-item label="휴대전화번호">
                  <!-- {{ contractData.contractorInfo && contractData.contractorInfo.length > 0 ? contractData.contractorInfo[0].customerMobile : '' }} -->
                  {{ contractorHpTns() }}
                </el-form-item>
              </el-col>
              <!-- <el-col :span="8">
                <el-form-item label="발송일시" />
              </el-col> -->
            </el-row>
          </el-form>
          <h-title :title="'발신내용'" />
          <el-form
            ref="ruleFormpopup"
            :model="ruleFormpopup"
            class="detail-form"
          >
            <el-row>
              <el-col :span="24">
                <el-form-item label="제목">
                  <el-input
                    v-model="ruleFormpopup.title"
                    class="mms-title"
                    @blur="ruleFormpopup.title = $event.target.value"
                  />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item label="내용">
                  <el-input
                    v-model="ruleFormpopup.text"
                    type="textarea"
                    @blur="ruleFormpopup.text = $event.target.value"
                  />
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="primary"
            @click="initRuleFormPop"
          >
            초기화
          </el-button>
          <el-button
            type="primary"
            @click="oneClickDisable($event, sendSms)"
          >
            전송
          </el-button>
        </template>
      </el-dialog>
      <!-- ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## -->    
      <loading
        :pop-visible.sync="popVisibleLoading"
        @close="popVisibleLoading = false"
      />
      <!-- ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## -->      
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import HSearch from '~/components/common/HSearch.vue'
import HReleseInfo from '~/components/common/HReleseInfoOb.vue'
import HTitle from '~/components/common/HTitle.vue'
import ContractInfo from '~/components/tab/ContractInfo.vue'
import CarInfo from '~/components/tab/CarInfo.vue'
import PayInfo from '~/components/tab/PayInfo.vue'
import ReleaseInfo from '~/components/tab/ReleaseInfo.vue'
import StatusHistory from '~/components/tab/StatusHistory.vue'
import SmsHistory from '~/components/tab/SmsHistory.vue'
import { mapGetters } from 'vuex'
import moment from 'moment'
import PopMessage from '~/components/popup/PopMessage.vue'
/* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
import Loading from "~/components/popup/Loading.vue";
/* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */

export default {
  name: 'Process',
  layout: 'default',
  components: {
    HSearch,
    HReleseInfo,
    HTitle,
    ContractInfo,
    CarInfo,
    PayInfo,
    ReleaseInfo,
    StatusHistory,
    SmsHistory,
    PopMessage,
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
    Loading
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */    
  },

  data() {
    return {
      isAuth: process.env.VUE_APP_AUTH === 'true', // 권한 패스용
      alertMessage: '',
      customerTypeCode: '',
      alertMessagePop: false,
      activeFlag: false, // 탭에서 조건별 활성화되어야 하는 버튼 제어 플래그
      activeName: 'first',
      alertNoData: false,
      popVisible05: false,
      ruleFormpopup:{
        title: '',
        text: ''
      },
      data: {
        progressResultCode: '10', // 처리결과 코드
        progressTypeCode: ''
      },
      //processHistory: [], 
      workSerialNumber: null,
      contractNumber: null,
      info: {},
      contractData: {},
      signData: [],
      statusDateData: {},
      paperReviewData: [],
      //carInfoData: {},
      //choiceOptionNames: '',
      //tuixOptionNames: '',
      payInfoData: {},
      payAmountList: [],
      payDetail: {},
      releaseInfoData: {},
      releaseCenterData: {},
      releaseTakeoverData: {},
      releaseConsignData: {},
      releaseRegistAgencyData: {},
      //:contract-info-data.sync="info" (호출시 해당 info데이터 넘겨주기! (작업 필요))
      contractInfo: {},
      //statusTabData: { consultant:[], sale: [], sales: [], payment:[], papers:[], electron: [], point: [], apiLog : [], type: 'consultant'}, // type: 전담전용?
      //messageTabData: [],
      commonCodes: {},
      contractorNames: [],  // 선택한 계약자명
      componentSortList: [
        'consultant-history',
        'dc-history',
        'sale-history',
        'sales-history',
        'payment-history',
        'point-history',
        'paper-history',
        'sign-history',
        'api-log-history'
      ],
      workType: '',         // 업무유형
      workStatus: [],       // 업무진행상태
      gridType: 'customer',
      authGroupIds: '',
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      popVisibleLoading: false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
    }
  },
  computed: {
    ...mapGetters(['userInfo'])
  },
  async created() {
    await this.loadCommonCode()
  },
  mounted() {
    this.$store.dispatch('loadConsultants', {vm: this})
    this.workSerialNumber = localStorage.getItem('workSerialNumber') || '' // 새창으로 넘어오는 경우
    if(this.$route.params.workSerialNumber) { // route 이동으로 넘어오는 경우 * params이 있을 경우에만 셋팅
      this.workSerialNumber = this.$route.params.workSerialNumber
    }

    if(this.workSerialNumber) {
      this.getData(this.workSerialNumber)
    }

    localStorage.removeItem('workSerialNumber')
  },
  methods: {
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null
      switch(systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {vm: this, codeTypeCode: codeType})
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {vm: this, codeTypeCode: codeType})
        break
      }
      return res
    },
    async loadCommonCode() {
      const [ccU011, ccU015, ccU020] = await Promise.all([
        this.fetchCommonCodeData('E', 'U011'),
        this.fetchCommonCodeData('E', 'U020'), // 업무 유형
        this.fetchCommonCodeData('E', 'U015')
      ])

      this.commonCodes = { ...ccU020, ...ccU011, ...ccU015 }

      const ccdKeys = Object.keys(this.commonCodes)

      if(ccdKeys.length > 0) ccdKeys.map((keys) => { this.commonCodes[keys].splice(0, 1) }) // `전체` 선택항목 제거
    },
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    /* 유저 버튼 권한 체크 */
    isValidUserAuthBtn() {
      var authGroupIds = this.userInfo.exclusiveUseAuthGroupIds

      for(var id of authGroupIds){
        // 대고객 일반이며 담당자 본인인 경우  or 관리자
        if ((['WT001'].includes(id) && this.activeFlag) || ['WT002'].includes(id)){
          return true
        } else {
          continue
        }
      }

      return false
    },
    async getData(serialNumber) {
      if(!serialNumber) return
      // API-E-업무담당자-053 (OB업무 상세조회)
      const [res1,err1] = await this.$https.post('/v2/exclusive/ob-detail', { workAssignNumber : serialNumber })

      if(!err1) {
        if(!res1.data) { // 상세보기 - 조회 결과 없음 팝업 노출
          const beforeWorkSerialNumber = this.workSerialNumber
          Object.assign(this.$data, this.$options.data())
          this.workSerialNumber = beforeWorkSerialNumber
          this.alertNoData = true
          return
        }
        this.workSerialNumber = serialNumber
        // Ob Detail Info
        this.data = {
          ...res1.data,
          progressResultCode: res1.data.progressResultCode || '10' // default '접수(10)'
        }
        this.contractNumber = res1.data && res1.data.contractNumber
        this.getContractInfoData()
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
        this.getContractTabData()
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      

        if(this.data.managerId && this.data.managerId === this.userInfo.eeno) { // 사용자 사번과 처리자가 같을 경우
          this.activeFlag = true
        }
      } else {
        console.error(err1)
      }

      //공통탭 호출
      this.getInfoData()

      /*
      SB 전담 처리이력 삭제건
      const [res2,err2] = await this.$https.get('/v2/exclusive/ob/'+serialNumber+'/history')//API-E-업무담당자-054 (OB업무 처리정보 이력 조회)
      if(!err2) {
        console.log('/ob/'+serialNumber+'/history', res2.data)

        this.processHistory = res2.data.map((el, idx) => {
          const { workAssignNumber = '', managerId = this.data.managerId, workProcessResultCode = '', workProcessDate = '', workProcessContent = '' } = el

          return {
            workAssignNumber,
            workProcessSerialNumber: ''+(idx+1),
            managerId: managerId || this.data.managerId,
            workProcessResultCode,
            workProcessDate: workProcessDate ? moment(workProcessDate).format('YYYY-MM-DD HH:mm') : '',
            workProcessContent
          }
        })
        this.addProcessRow() // default 1개
      } else {
        console.error(err2)
      }
    */

    },
    async getContractInfoData() {
      // API-E-업무담당자-013 (계약출고상세조회)
      const [res, err] = await this.$https.post('/v2/exclusive/contract-detail', { contractNumber: this.contractNumber })
      if(!err) {
        // screenUseTypeCode (01:열람,02:수정,03:삭제,04:인쇄,05:입력,06:업로드,07:다운로드)
        this.$store.dispatch('commonSupportLog', { vm: this, params: { screenUseTypeCode: '01', useInfo: JSON.stringify(res.data) } })
        this.contractInfo = res.data
      } else {
        console.error(err)
      }
    },
    searchWork(value) {
      if(!this.isValidAuthBtn('authSelect')) { // 권한없을경우 동작 x
        return
      }

      if(!value) {
        this.alertMessage = '업무일련번호를 입력해주세요.'
        this.alertMessagePop = true
        return
      } else {
        value = value.trim() // 공백 제거
      }

      this.getData(value)
    },
    /*
    SB 전담 처리이력 삭제건
    addProcessRow() {
      const { workSerialNumber = '', managerId = ''} = this.data
      this.processHistory.push({
        isAdd: this.processHistory.length > 1 ? true : false,
        workAssignNumber: workSerialNumber,
        workProcessSerialNumber : ''+(this.processHistory.length+1),
        managerId,
        workProcessResultCode: '',
        workProcessDate: '',
        workProcessContent: ''
      })
    },
    onChangeProcessResultCode(idx) {
      this.processHistory[idx].workProcessDate = moment().format('YYYY-MM-DD HH:mm')
      this.processHistory[idx].isAdd = true
    },
    onChangeMemo(idx){
      this.processHistory[idx].isAdd = true
    },
    */
    async save() {
      if(!this.workSerialNumber) {
        this.alertMessage = '업무를 먼저 검색해주세요.'
        this.alertMessagePop = true
        return
      }

      // const { workSerialNumber: workAssignNumber = '', progressResultCode : workProcessResultCode = '', workProcessContents : workProcessContent = '' } = this.data
      //const { workSerialNumber: workAssignNumber = '', progressTypeCode : workType = '', progressResultCode : workProcessResultCode = '', workProcessContent : workProcessContent = '' } = this.data
      // 변경정보 
      const { managerId: managerId = '', workSerialNumber: workAssignNumber = '', progressTypeCode : workType = '', progressResultCode : workProcessResultCode = '', workProcessContent : workProcessContent = '' } = this.data
      const { id = '' } = this.userInfo

      /*
      //2021.04.05 전담 SB에서 처리내역 관련 내용 삭제
      let workProcessList = this.processHistory.map(el => {
        const { managerId = '', workProcessContent = '', customerProcessType = '', workProcessDate = '', workProcessResultCode = '', workProcessSerialNumber = '', progressTypeCode = workType, workAssignNumber = '', isAdd = false } = el
        return { managerId, workProcessContent, customerProcessType: 'E', workProcessDate, workProcessDetailResultCode: workProcessResultCode, workProcessSerialNumber, workType: progressTypeCode, workAssignNumber, isAdd }
      })

      workProcessList = workProcessList.filter((items) => {    // 변경되거나 추가된 사항만 저장
        if(items.workProcessDetailResultCode) {
          return items.isAdd === true
        }
      })
      */


      // validation check
      // 1. 처리결과 미입력 workType 빈값 // ETC_A_030
      if(!workType) {
        this.alertMessage = '처리결과를 선택해주세요.'
        this.alertMessagePop = true
        return
      }

      // 2. 진행상황 메모 미 입력시 ETC_A_008 출력
      if(!workProcessContent) {
        this.alertMessage = '진행 상황 메모를 입력해주세요.'
        this.alertMessagePop = true
        return
      }

      let workProcess = { managerId, customerProcessType: 'E', workProcessDetailResultCode: workProcessResultCode, workProcessContent, workProcessDate: moment().format('YYYY-MM-DD HH:mm'), workAssignNumber, workType, customerNumber: id }
      const body = { workAssignNumber, workType, workProcessResultCode, workProcessContent, workProcess, customerNumber: id }

      const [res,err] = await this.$https.post('/v2/exclusive/ob', body)//API-E-업무담당자-055 (OB업무 - 처리 내역을 저장하는 API)
      if(!err && res) {
        // 3. 저장 후 안내 ETC_A_031 출력
        this.alertMessage = '진행 상황 메모를 저장했습니다.'
        this.alertMessagePop = true
        this.getData(this.workSerialNumber)
      } else {
        // 4. 실패 시 안내 ETC_A_032 출력 - 내부 오류 메시지 출력 - 
        this.alertMessage = '진행 상황 메모를 저장에 실패했습니다.'
        this.alertMessagePop = true
        console.error('error :: ' + err)
      }

    },
    async getInfoData() {
      this.popVisibleLoading = true

      // API-E-업무담당자-013 (계약출고상세조회)
      const [res, err] = await this.$https.post(
        '/v2/exclusive/contract-detail',
        { contractNumber: this.contractNumber }
      )
      if (!err) {
        if (!res.data) {
          // 상세보기 - 조회 결과 없음 팝업 노출
          const beforeContractNumber = this.contractNumber
          const beforeActiveName = this.activeName
          Object.assign(this.$data, this.$options.data())
          this.contractNumber = beforeContractNumber // 이전 계약번호 유지
          this.activeName = beforeActiveName // 이전 탭 상태 유지
          this.alertNoData = true
          return
        }

        this.info = res.data
        if (
          this.info.consultantId &&
          this.info.consultantId === this.userInfo.eeno
        ) {
          // 사용자 사번과 계약건의 업무담당자이 같을 경우
          this.activeFlag = true
        }

        this.info.customerTypeCodes = this.customerTypeCodes

        this.getStatusTabData()
        
        this.popVisibleLoading = false
      } else {
        this.popVisibleLoading = false
        console.error(err)
      }
    },
    async getContractTabData() {
      if (!this.contractNumber) return

      //계약자 정보 + 서비스가입 + 계약금 결제
      // API-E-업무담당자-014 (계약정보조회)
      // if(Object.keys(this.contractData).length===0) {
      const [res1, err1] = await this.$https.post(
        '/v2/exclusive/work/contract',
        { contractNumber: this.contractNumber }
      )
      if (!err1 && res1) {
        if (!res1.data) {
          return
        }
        this.contractData = res1.data

        const contractorInfo =
          this.contractData && this.contractData.contractorInfo
        this.contractorNames =
          contractorInfo && contractorInfo.length
            ? contractorInfo.map(items => {
              return items.customerName
            }) : []  

        this.$refs.contractInfo.getAllData()
      } else {
        console.error(err1)
      }
    },
    handleTabClick(tab) {
      if(tab.name==='first') this.getStatusTabData()
      else if(tab.name==='second') this.getCarTabData()
      else if(tab.name==='third') this.getPaymentTabData()
      else if(tab.name==='fourth') this.getReleaseTabData()
      else if(tab.name==='fifth') this.getContractTabData()
      else if(tab.name==='sixth') this.getMessageTabData()
    },
    async getCarTabData() {
      if (!this.contractNumber) return

      this.$refs.CarInfo.getCarInfoData()

    },
    getCarProductionNumber(pdNumber) {
      this.carProductionNumber = pdNumber
    },
    async getPaymentTabData() {
      if (!this.contractNumber) return
      this.$refs.payInfo.getAllData()
    },
    async getReleaseTabData() {
      if (!this.contractNumber) return
      this.$refs.releaseInfo.getAllData()
    },
    // 상태이력
    async getStatusTabData() {
      if(!this.contractNumber) return

      this.$refs.StatusHistory.getAllData()
      //this.$refs.StatusHistory.getAllData()

      //API-WE-업무담당자-035 (판매처리이력 조회)
      // this.$refs.StatusHistory.getSaleHistory()

      // //API-WE-업무담당자-036 (매출변경이력 조회)
      // this.$refs.StatusHistory.getSalesHistory()

      // //API-WE-업무담당자-037 (결제변경이력 조회)
      // this.$refs.StatusHistory.getPaymentHistory()

      // // API-WE-업무담당자-129 (포인트신청이력 조회)
      // this.$refs.StatusHistory.getPointHistory()

      // //API-WE-업무담당자-038 (업무담당자처리이력 조회)
      // this.$refs.StatusHistory.getConsultantHistory()
      
      // //API-WE-업무담당자-040 (서류심사이력 조회)
      // this.$refs.StatusHistory.getPaperHistory()
      
      // //API-WE-업무담당자-041 (전자서명이력 조회)
      // this.$refs.StatusHistory.getSignHistory()
      
      // //API-WE-업무담당자-133 (국판 호출 로그 이력 조회)
      // this.$refs.StatusHistory.getApiHistory()
    },
    async getMessageTabData() {
      if(!this.contractNumber) return

      this.$refs.SmsHistory.getSmsHistoryData()
    },
    onCheck(value) {
      console.log(value)
    },
    initRuleFormPop() { // 초기화 버튼
      Object.assign(this.$data.ruleFormpopup, this.$options.data().ruleFormpopup)
    },
    tableRowClassName({row}) {
      if (row.background === 'red') {
        return 'warning-row'
      }
      else if (row.border === 'red') {
        return 'warning-row1'
      }
      return ''
    },
    async sendSms() {
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      let customersInfo = []
      const contractorInfo = this.contractData && this.contractData.contractorInfo
      const targetContractorInfo = contractorInfo && contractorInfo.filter((items) => {
        return this.contractorNames.includes(items.customerName)
      })

      targetContractorInfo.map((items) => {
        customersInfo.push({
          sendChannelCode: '003', // 발송경로 구분 코드 - 업무담당자
          saleContractNo: this.contractNumber || '', // 판매계약번호
          customerMgmtNo: items.customerManagementNumber || '', // 고객관리번호
          customerUniqueNo: this.userInfo.eeno || '', // 고객고유번호
          messageTitle: this.ruleFormpopup.title, // 제목
          messageContents: this.ruleFormpopup.text, // 내용
          receiverTel: items.customerMobile, // 수신자전화번호
          receiverName: items.customerName // 수신자명
        })
      })

      const [result1, result2] = await Promise.all(
        customersInfo.map((items) => {
          return this.$https.post('/v2/exclusive/common/sms-send', items) // API-E-공통서비스-023 (문자 보내기)
        })
      )
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      // 1명의 계약자에게만 발송하는 경우
      if (!result2) {
        const [res1, err1] = result1
        if (!err1) {
          if(res1.rspStatus && res1.rspStatus.rspCode === '0000') {
            this.popVisible05 = false // 팝업 닫기
            this.alertMessage = '문자가 전송되었습니다.'
            this.alertMessagePop = true
          }
        }
      }

      // 주계약자 및 공동명의자 모두 발송하는 경우
      if (result1 && result2) {
        const [res1, err1] = result1
        const [res2, err2] = result2

        // 모두 전송되었을 경우
        if (!err1 && !err2) {
          if(res1.rspStatus && res1.rspStatus.rspCode === '0000' &&
            res2.rspStatus && res2.rspStatus.rspCode === '0000') {
            this.popVisible05 = false // 팝업 닫기
            this.alertMessage = '문자가 전송되었습니다.'
            this.alertMessagePop = true
          }
        }
      }
      this.getMessageTabData() // reload
      this.popVisible05 = false // 팝업 닫기
    },
    openPopSms() { // 문자보내기 팝업 노출
      // ※ 출고일 장기 경과 데이터 이관으로 고객정보 부재가 발생하는 케이스가 생김.
      // 고객 데이터에 따른 안내팝업 처리
      // 고객관리번호는 필수값이 아니라 체크안함. 고객정보의 수신자 전화번호와 수신자명은 필수값 임으로 체크
      let customerMobile = '', customerName = ''

      if (this.contractData && this.contractData.contractorInfo[0]) {
         ({ customerMobile, customerName } = this.contractData.contractorInfo[0])
      }

      if (!customerMobile || !customerName) { // 고객정보가 없을 경우
        this.alertMessage = '출고일 장기 경과건으로 고객 데이터가 없습니다.\n데이터 복원후 진행해주세요.'
        this.alertMessagePop = true
      } else {
        this.popVisible05 = true
        Object.assign(this.ruleFormpopup, this.$options.data().ruleFormpopup)
      }
    },
    onRefresh(flag, tab) {
      if (flag) {
        switch (tab) {
        case 'contract':
          this.getContractTabData()
          break
        case 'car':
          this.getCarTabData()
          break
        case 'pay':
          this.getPaymentTabData() // 결제정보탭 reload
          break
        case 'release':
          this.getReleaseTabData()
          break
        case 'status':
          this.getInfoData()
          //this.getStatusTabData()
          break
        case 'sms':
          this.getMessageTabData()
          break
        }
      }
    },
    contractorHpTns() {
      const contractorInfo = this.contractData && this.contractData.contractorInfo
      const targetContractorInfo = contractorInfo && contractorInfo.filter((items) => {
        return this.contractorNames.includes(items.customerName)
      })
      return targetContractorInfo && targetContractorInfo.map((items) => { return items.customerMobile + (items.contractorTypeName ? ('(' + items.contractorTypeName + ')') : '') }).join(', ')
    },
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
    oneClickDisable(event, clickEvent, ...args) {
      if(event.target.disabled === true){
        retrun
      }

      event.target.disabled = true

      try {
        clickEvent(...args)
      } catch {}
      setTimeout(() => {
        event.target.disabled = false
      }, 2000)
    }
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */    
  },


}
</script>

<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>

