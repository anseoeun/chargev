<template>
  <section>
    <div id="work">
      <div class="btn-wrap">
        <div class="side">
          <el-button
            type="primary"
            @click="resetSearchCond"
          >
            초기화
          </el-button>
        </div>
        <div class="main">
          <el-button
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            @click="getData"
          >
            조회
          </el-button>
        </div>
      </div>
      <el-form
        :ref="ruleForm"
        class="detail-form"
      >
        <el-row>
          <el-col :span="24">
            <el-form-item
              label="기간"
              required
            >
              <el-date-picker
                v-model="ruleForm.regStartDate" 
                type="date"
              />
              <span class="ex-txt"> ~ </span>
              <el-date-picker
                v-model="ruleForm.regEndDate" 
                type="date"
              />
              <el-radio-group
                v-model="searchDtRadio"
                class="tabBtn-case01"
                @change="onChangeSearchDtRadio"
              >
                <el-radio-button label="lastDay">
                  전일
                </el-radio-button>
                <el-radio-button label="today">
                  오늘
                </el-radio-button>
                <el-radio-button label="day7">
                  7일
                </el-radio-button>
                <el-radio-button label="day30">
                  30일
                </el-radio-button>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="계약번호">
              <el-input 
                v-model="ruleForm.saleContractNumber"
                @keydown.native.tab="onAddZero(ruleForm.saleContractNumber)"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="계약자명">
              <el-input 
                v-model="ruleForm.contractorName" 
                @blur="ruleForm.contractorName = $event.target.value"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item
              label="업무담당자"
              required
            >
              <el-select
                v-model="ruleForm.exclusiveUserId"
                placeholder="선택"
              >
                <el-option
                  v-for="{ sysUserNo, sysUserNm } in consultants"
                  :key="sysUserNo"
                  :value="sysUserNo"
                  :label="sysUserNm"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span>{{ ruleForm.note }}</span>
      
      <div class="board-wrap">
        <el-table
          :data="tableList"
          max-height="450"
        >
          <el-table-column
            label="NO."
            prop="no"
            width="100"
            align="center"
          />
          <el-table-column
            label="계약번호"
            prop="saleContractNumber"
            align="center"
          >
            <template slot-scope="scope">
              <router-link
                :to="{ name: 'contract-release-detail', params: { contractNumber: scope.row.saleContractNumber }}"
              >
                {{ scope.row.saleContractNumber }}
              </router-link>
            </template>
          </el-table-column>
          <el-table-column
            label="계약자명"
            prop="contractorName"
            align="center"
          />
          <el-table-column
            label="업무담당자C"
            prop="exclusiveUserName"
            align="center"
          />
          <el-table-column label="변경 전 업무담당자">
            <el-table-column
              label="이름"
              prop="alterationPreviousUserName"
              align="center"
            />
            <el-table-column
              label="사번"
              prop="alterationPreviousUserId"
              align="center"
            />
          </el-table-column>
          <el-table-column label="변경 후 업무담당자">
            <el-table-column
              label="이름"
              prop="alterationAfterUserName"
              align="center"
            />
            <el-table-column
              label="사번"
              prop="alterationAfterUserId"
              align="center"
            />
          </el-table-column>
          <el-table-column
            label="변경날짜"
            prop="alterationDate"
            align="center"
          />
          <el-table-column
            label="비고(변경사유)"
            prop="alteratioReason"
            align="center"
          />
        </el-table>
      </div>
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import { mapState } from 'vuex'
import moment from 'moment'
import PopMessage from '~/components/popup/PopMessage.vue'

export default {
  name: 'Work',
  layout: 'default',
  components: { 
    PopMessage 
  },
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      searchDtRadio:'today',
      ruleForm:{
        regStartDate: moment(),
        regEndDate:moment(),
        saleContractNumber:'',
        contractorName:'',
        exclusiveUserId:'',
        note:'* 기간, 업무담당자는 필수 기입 사항입니다. '
      },
      tableList:[]
    }
  },
  computed: {
    ...mapState(['consultants','userInfo']),
    sampleCheckAuth() { // TODO: 추후삭제
      return this.$store.getters.userInfo.exclusiveUseAuthGroupId
    }
  },
  watch: { // TODO: 추후삭제
    sampleCheckAuth(val) { // 실데이터 이전 권한 체크용도
      if(['M0001', 'M0003'].includes(val)) {
        this.ruleForm.exclusiveUserId = this.userInfo.eeno
      } else {
        this.ruleForm.exclusiveUserId = ''
      }
    }
  },
  mounted(){
    this.$store.dispatch('loadConsultants', {vm: this})
    this.$store.dispatch('loadUserInfo', { vm: this})
    
    if(['M0001', 'M0003'].includes(this.userInfo.exclusiveUseAuthGroupId)) { // 일반 업무담당자 or 조회권한만 있는 업무담당자일 경우에만 default 로그인 사용자
      this.ruleForm.exclusiveUserId = this.userInfo.eeno
    }
  },
  methods:{
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    onAddZero(contractNumber) {
      let resultString = ''
      if(contractNumber.length > 6) {
        const frontString = contractNumber.substring(0,7)
        const backString = contractNumber.substring(7)
        
        resultString = resultString.concat(frontString)
        resultString = resultString.concat(backString.length >= 6 ? backString : Array.from({length: 6 - backString.length}, () => 0).join('') + backString)
      }

      if(!resultString) { resultString = contractNumber }
      this.ruleForm.saleContractNumber = resultString
    },
    resetSearchCond() {
      Object.assign(this.ruleForm, this.$options.data().ruleForm)
      this.searchDtRadio = 'today'
      // this.ruleForm.exclusiveUserId = this.userInfo.eeno
    },
    async getData() {
      if(this.ruleForm.regStartDate && this.ruleForm.regEndDate && this.ruleForm.exclusiveUserId) {
        const params = { 
          ...this.ruleForm,
          regStartDate: moment(this.ruleForm.regStartDate).format('YYYYMMDD'),
          regEndDate: moment(this.ruleForm.regEndDate).format('YYYYMMDD')
        }

        const [res, err] = await this.$https.get('/v1/exclusive/setting/assign-history', params)
        if(!err) {
          if(!res.data.list || res.data.list.length === 0) {
            this.tableList = null
          } else {
            this.tableList = res.data.list.map((el, idx) => { 
              return {
                ...el,
                no:idx+1
              }
            })
            console.log('table: ', this.tableList) 
          }
        } else {
          console.error(err)
          this.tableList = null
        }

      } else {
        this.alertMessage = '기간, 업무담당자는 필수 기입 사항입니다.',
        this.alertMessagePop = true
      }
    },
    onChangeSearchDtRadio(val) {
      if(val === 'lastDay') {
        this.ruleForm.regStartDate = moment().subtract('days', 1)
        this.ruleForm.regEndDate = moment().subtract('days', 1)
      } else if(val === 'today') {
        this.ruleForm.regStartDate = moment()
        this.ruleForm.regEndDate = moment()
      } else if(val === 'day7') {
        this.ruleForm.regStartDate = moment().subtract('days', 7)
        this.ruleForm.regEndDate = moment()
      } else if(val === 'day30') {
        this.ruleForm.regStartDate = moment().subtract('days', 30)
        this.ruleForm.regEndDate = moment()
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/set/work.scss';
</style>

