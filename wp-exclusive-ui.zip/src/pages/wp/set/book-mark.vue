<template>
  <section>
    <div id="book-mark">
      <div class="btn-wrap">
        <div class="side"></div>
        <div class="main">
          <el-button 
            v-if="isValidAuthBtn('authExclusive')"
            type="primary"
            @click="saveBookMark"
          >
            저장
          </el-button>
        </div>
      </div>
      <div class="board-wrap">
        <el-button
          v-if="isValidAuthBtn('authExclusive')"
          type="info"
          class="delete-btn"
          @click="deleteBookMark"
        >
          전체삭제
        </el-button>
        <el-transfer
          v-model="bookmarkList"
          target-order="push"
          :props="{key: 'menuId', label: 'menuName'}"
          :data="customMenuList"
          :titles="['전체메뉴', '즐겨찾기']"
          @right-check-change="rightCheckChang"
        />
        <div class="btn-wrap">
          <div class="side"></div>
          <div class="main">
            <div>
              <el-button 
                type="primary"
                @click="orderButton('lowDown')"
              >
                <i class="dubbledown-icon"></i>
              </el-button>
              <el-button
                type="primary"
                icon="el-icon-caret-bottom"
                @click="orderButton('down')"
              />
            </div>
            <div>
              <el-button
                type="primary"
                icon="el-icon-caret-top"
                @click="orderButton('up')"
              />
              <el-button
                type="primary"
                @click="orderButton('highUp')"
              >
                <i class="dubbletop-icon"></i>
              </el-button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## -->
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />
    <!-- ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## -->    
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import { mapGetters } from 'vuex'
import PopMessage from '~/components/popup/PopMessage.vue'
/* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
import Loading from "~/components/popup/Loading.vue";
/* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */

export default {
  name: 'BookMark',
  layout: 'default',
  components: {
    PopMessage,
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
    Loading
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */    
  },
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      menuList: [], // 메뉴 목록
      bookmarkList: [], // 즐겨찾기 목록
      checkedBookmark: [], // 체크된 즐겨찾기 목록
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      popVisibleLoading: false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
    }
  },
  computed: {
    ...mapGetters({
      userInfo: 'userInfo',
      sideMenus: 'menuList'
    }),
    customMenuList: function() {
      const sideMenus = this.sideMenus
      let customMenuList = []
      
      sideMenus.map((items) => {
        const depth2List = items.children
        if(depth2List && depth2List.length > 0) {
          depth2List.map((items2) => {
            if(items2.menuLink !== '-') { customMenuList.push(items2) } // depth2 
            const depth3List = items2.children
            if(depth3List && depth3List.length > 0) { // depth3
              customMenuList.push(...depth3List) 
            }
          })
        }
      })

      console.log(sideMenus)  
      
      // const customMenuList = sideMenus.flatMap((el) => {
      //   let num = null // depth2 목록의 상위 parent 인덱스(위치)
        
      //   el.children.some((items, idx) => { // depth2 목록의 상위(parentId)와 일치하는 인덱스 저장
      //     if(items.children.length > 0) { 
      //       num = idx
      //       return true 
      //     }
      //   })

      //   const depth2List = el.children.flatMap((el2) => { // depth2 목록 추출
      //     return el2.children
      //   })

      //   if(num) { // depth2의 목록이 있을경우
      //     const startDepth1List = el.children.slice(0, num)
      //     const endDepth1List = el.children.slice(num)
      //     const result = startDepth1List.concat(depth2List).concat(endDepth1List)
      //     return result.filter((items) => { return items.menuLink !== '-' }) 
      //   } else {  // depth2의 목록이 없을 경우
      //     return el.children
      //   }
      // })
      return customMenuList
    }
  },
  mounted() {
    this.getDataInfo()
  },
  methods: {
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    async getDataInfo() { // 즐겨찾기 목록 조회
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */    
      const [res2, err2] = await this.$https.get('/v2/exclusive/bookmark') // API-WE-업무담당자-004 (업무담당자 컨설턴트 별 즐겨찾기 목록 조회)
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
      if(!err2) {
        console.log(res2.data)
        this.bookmarkList = res2.data.map(items => { return items.menuId })
        console.log(this.bookmarkList)
      } else {
        console.error(err2)
      }
    },
    async saveBookMark() { // 즐겨찾기 저장
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */    
      const saveBookMarkList = this.bookmarkList.map((items) => {
        return { menuId: items }
      }) || []

      // API-WE-업무담당자-103 (즐겨찾기 변경 처리)
      const [res, err] = await this.$https.post('v2/exclusive/setting/bookmark-save', saveBookMarkList)
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      if(!err) {
        if(res.rspStatus && res.rspStatus.rspCode === '0000') {
          this.alertMessage = '저장되었습니다.'
          this.alertMessagePop = true
          this.$store.dispatch('loadBookMarkList', {vm: this})
        }
      } else {
        console.error(err)
      }
    },
    orderButton(type) { // button type
      if(this.checkedBookmark.length === 0) return

      const newBookMarkList = this.bookmarkList.slice()

      switch(type) {
      case 'up': // 하나 위로
        this.checkedBookmark.some(items => {
          const idx = newBookMarkList.indexOf(items)        
          if(idx === 0) { return true }
          newBookMarkList.splice(idx, 1)
        })

        this.checkedBookmark.some(items => {
          const idx = this.bookmarkList.indexOf(items)
          if(idx === 0) { return true }
          newBookMarkList.splice(idx - 1, 0, items)
        })
        break
      case 'down': // 하나 아래로
        this.checkedBookmark.some(items => {
          const idx = newBookMarkList.indexOf(items)
          const lastItem = this.checkedBookmark[this.checkedBookmark.length - 1]
          const lastIdx = newBookMarkList.indexOf(lastItem)

          if(lastIdx >= this.bookmarkList.length - 1) { return true }
          newBookMarkList.splice(idx, 1)
        })
        
        this.checkedBookmark.some(items => {
          const idx = this.bookmarkList.indexOf(items)
          const lastItem = this.checkedBookmark[this.checkedBookmark.length - 1]
          const lastIdx = newBookMarkList.indexOf(lastItem)

          if(lastIdx >= this.bookmarkList.length - 1) { return true }
          newBookMarkList.splice(idx + 1, 0, items)
        })
        break
      case 'highUp': // 최상단
        this.checkedBookmark.map(items => {
          const idx = newBookMarkList.indexOf(items)
          newBookMarkList.splice(idx, 1)
        })
        newBookMarkList.unshift(...this.checkedBookmark)
        break
      case 'lowDown': // 최하단
        this.checkedBookmark.map(items => {
          const idx = newBookMarkList.indexOf(items)
          newBookMarkList.splice(idx, 1)
        })
        newBookMarkList.push(...this.checkedBookmark)
        break
      }
      this.bookmarkList = newBookMarkList
    },
    rightCheckChang(data) {
      console.log(this.bookmarkList)
      const moveList = this.bookmarkList.filter(items => {
        return data.includes(items)
      })
      this.checkedBookmark = moveList
    },
    deleteBookMark() { // 전체삭제
      this.bookmarkList = []
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~/assets/style/pages/set/book-mark.scss';
</style>
