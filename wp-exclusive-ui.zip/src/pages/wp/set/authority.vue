<template>
  <section>
    <div id="authority">
      <div class="btn-wrap">
        <div class="side">
          <el-button type="primary" @click="resetRuleForm">
            초기화
          </el-button>
        </div>
        <div class="main">
          <el-button
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            @click="getConsultantList"
          >
            조회
          </el-button>
          <el-button
            v-if="isValidAuthBtn('authManage')"
            type="primary"
            @click="oneClickDisable($event, saveAuthority)"
          >
            저장
          </el-button>
        </div>
      </div>
      <div class="board-wrap">
        <el-form ref="ruleForm" :model="ruleForm" class="detail-form">
          <el-row>
            <el-col :span="8">
              <el-form-item label="사번">
                <el-input
                  v-model="ruleForm.systemUserNo"
                  @keyup.enter.native="getConsultantList"
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="이름">
                <el-input
                  v-model="ruleForm.systemUserName"
                  @blur="ruleForm.systemUserName = $event.target.value"
                  @keyup.enter.native="getConsultantList"
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="권한">
                <el-select v-model="ruleForm.useAuthGroupId">
                  <el-option
                    v-for="{ value, label } in authCodeAll"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-table
          :data="consultantList"
          max-height="450"
          empty-text="조회 결과가 존재하지 않습니다."
        >
          <el-table-column
            width="80"
            label="NO."
            prop="rowIndex"
            align="center"
          />
          <el-table-column
            width="122;"
            label="성명"
            prop="systemUserName"
            align="center"
          />
          <el-table-column
            width="125"
            label="사번"
            prop="systemUserNo"
            align="center"
          />
          <el-table-column
            label="현재권한"
            prop="oldUseAuthGroupId"
            align="center"
          >
            <template slot-scope="scope">
              <span>
                {{ scope.row.useAuthGroupName }}
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="변경권한"
            prop="newUseAuthGroupId"
            align="center"
            width="250"
          >
            <template slot-scope="scope">
              <el-select
                v-model="scope.row.newUseAuthGroupId"
                :disabled="
                  !userInfo.exclusiveUseAuthGroupIds.includes('WT002') ||
                    !userInfo.exclusiveUseAuthGroupIds.includes('WT004')
                "
              >
                <el-option
                  v-for="{ value, label } in code.authority"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </template>
          </el-table-column>
          <el-table-column
            width="160"
            label="현재 업무시작일시"
            prop="workStartDate"
            align="center"
          />
          <el-table-column
            label="변경할 업무시작일시"
            prop="newWorkStartDate"
            align="center"
            width="250"
          >
            <template slot-scope="scope">
              <el-date-picker
                v-if="
                  scope.row.useAuthGroupId == 'M0001' &&
                    scope.row.newUseAuthGroupId !== 'M0002' &&
                    scope.row.newUseAuthGroupId !== 'M0003'
                "
                v-model="scope.row.newWorkStartDate"
                type="datetime"
                :disabled="userInfo.exclusiveUseAuthGroupId !== 'M0002'"
              >
              </el-date-picker>
            </template>
          </el-table-column>
          <el-table-column
            width="160"
            label="변경날짜"
            prop="updDate"
            align="center"
          />
          <el-table-column
            v-if="isValidAuthBtn('authManage')"
            width="140"
            label="권한삭제"
            align="center"
          >
            <template slot-scope="props">
              <el-button
                type="primary"
                style="width: 40px"
                @click="onDelete(props.row)"
              >
                삭제
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
    <!-- ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## -->
    <loading
      :pop-visible.sync="popVisibleLoading"
      @close="popVisibleLoading = false"
    />
    <!-- ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## -->    
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import { mapGetters } from "vuex";
import PopMessage from "~/components/popup/PopMessage.vue";
import moment from "moment";
/* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
import Loading from "~/components/popup/Loading.vue";
/* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */

export default {
  name: "Authority",
  layout: "default",
  components: {
    PopMessage,
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
    Loading
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */    
  },
  data() {
    return {
      alertMessage: "",
      alertMessagePop: false,
      ruleForm: {
        systemUserNo: "", // 사번
        systemUserName: "", // 이름
        useAuthGroupId: "" // 권한
      },
      code: {
        authority: [
          { value: null, label: "선택" },
          { value: "WT001", label: "대고객 구매지원시스템-일반" },
          { value: "WT002", label: "대고객 구매지원시스템-관리자" },
          { value: "WT003", label: "법인 구매지원시스템-일반" },
          { value: "WT004", label: "법인 구매지원시스템-관리자" }
        ]
      },
      consultantList: [], // 업무담당자 컨설턴트 정보
      cgConsultantList: [], // 업무담당자 컨설턴트 정보(권한이 변경된)
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      popVisibleLoading: false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
    };
  },
  computed: {
    ...mapGetters(["userInfo"]),
    authCodeAll: function() {
      const authList = this.code.authority.slice();
      authList.shift();
      authList.unshift({ value: "", label: "전체" });
      return authList;
    }
  },
  created() {
    this.$store.dispatch("loadUserInfo", { vm: this });
  },
  mounted() {
    this.getConsultantList();
  },
  methods: {
    isValidAuthBtn(authId) {
      // 버튼별 권한 체크
      let bResult = false; // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || [];
      if (currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some(items => {
          if (items.btnId === authId) {
            bResult = true;
            return true;
          }
        });
      }
      return bResult;
    },
    resetRuleForm() {
      // 초기화 버튼
      Object.assign(this.$data.ruleForm, this.$options.data().ruleForm);
    },
    async getConsultantList() {
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      // 업무담당자 목록 정보 조회
      const params = {
        pageNo: 1,
        pageSize: 99999,
        ...this.ruleForm
      };

      const [res, err] = await this.$https.get(
        "/v2/exclusive/setting/consultant",
        params
      ); //API-WE-업무담당자-101 (업무담당자 목록 조회)
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
      if (!err) {
        this.consultantList = res.data.list;
      }
    },
    async saveAuthority() {
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      // 업무담당자 컨설턴트 권한 변경

      const saveList = this.consultantList.filter(items => {
        return items.newUseAuthGroupId || items.newWorkStartDate;
      }); // 권한또는 업무시작일시가 변경된 사용자의 데이터만 필터
      saveList.map(items => {
        items.newWorkStartDate = items.newWorkStartDate
          ? moment(items.newWorkStartDate).format("YYYY-MM-DD HH:mm:ss")
          : null;
      });

      console.log("변경권한 리스트: ", saveList);

      if (saveList.length === 0) {
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
        this.popVisibleLoading = false
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */        
        this.alertMessage = "변경된 권한 목록이 없습니다.";
        this.alertMessagePop = true;
        return;
      }

      //const [res, err] = await this.$https.put('/common/v1/common/exclusive/consultant/authority', saveList, null, 'gateway') // API-WE-업무담당자-102 (업무담당자 컨설턴트 권한 변경)
      const [res, err] = await this.$https.put(
        "/common/v2/common/exclusive/consultant/authority",
        saveList,
        null,
        "gateway"
      ); // API-WE-업무담당자-102 (업무담당자 컨설턴트 권한 변경)
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
      if (!err) {
        if (res.rspStatus && res.rspStatus.rspCode === "0000") {
          this.alertMessage = "권한이 변경되었습니다.";
          this.alertMessagePop = true;
          this.getConsultantList();
        }
      } else {
        this.alertMessage =
          err.rspMessage || "시스템 오류 입니다.\n관리자에게 문의하세요.";
        this.alertMessagePop = true;
        this.getConsultantList();
      }
    },
    async onDelete(row) {
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      const { useAuthGroupId = "", systemUserNo = "" } = row;

      const params = { useAuthGroupId, systemUserNo };

      //const [res, err] = await this.$https.delete('/common/v1/common/exclusive/consultant/authority-delete', null, params, null, 'gateway') // API-WE-공통서비스-031 (업무담당자 권한 삭제)
      const [res, err] = await this.$https.delete(
        "/common/v2/common/exclusive/consultant/authority-delete",
        null,
        params,
        null,
        "gateway"
      ); // API-WE-공통서비스-031 (업무담당자 권한 삭제)
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
      if (!err) {
        if (res.rspStatus && res.rspStatus.rspCode === "0000") {
          this.alertMessage = "권한이 삭제되었습니다.";
          this.alertMessagePop = true;
          this.getConsultantList();
        }
      } else {
        this.getConsultantList();
      }
    },
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
    oneClickDisable(event, clickEvent, ...args) {
      if(event.target.disabled === true){
        retrun
      }

      event.target.disabled = true

      try {
        clickEvent(...args)
      } catch {}
      setTimeout(() => {
        event.target.disabled = false
      }, 2000)
    }
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */    
  }
};
</script>

<style lang="scss" scoped>
#authority {
  .detail-form {
    margin: 20px 0;
  }
}
</style>
