<template>
  <section>
    <div id="login">
      <div class="loginWrap">
        <div class="logo">
          <h1>
            hyundai system admin
          </h1>
        </div>
        <div class="login-form-wrap">
          <h3>CASPER 구매 지원시스템</h3>
          <el-form
            ref="ruleForm"
            :model="ruleForm"
            class="login-form"
          >
            <el-row>
              <el-col :span="24">
                <el-form-item
                  label=""
                  prop="id"
                >
                  <template>
                    아이디<br/>
                  </template>
                  <el-input
                    v-model="ruleForm.uid"
                    class="login-input"
                    placeholder="아이디(사번)을 입력하세요."
                    @blur="ruleForm.uid = $event.target.value"
                    @keyup.native.enter="loginAction"
                  />
                </el-form-item>
              </el-col>
              <el-col :span="24">
                <el-form-item
                  label=""
                  prop="pwd"
                >
                  <template>
                    비밀번호<br/>
                  </template>
                  <el-input
                    v-model="ruleForm.pwd"
                    class="login-input"
                    type="password"
                    placeholder="비밀번호를 입력하세요."
                    @keyup.native.enter="loginAction"
                  />
                  <div
                    v-if="isCapsLock"
                    class="capslock-pop"
                  >
                    <div class="capslock-pop-wrap">
                      <span>Caps Lock이 켜져 있습니다.</span>
                    </div>
                  </div>
                </el-form-item>
              </el-col>
              <el-col :span="24">
                <el-checkbox
                  v-model="checkedId"
                >
                  아이디 저장
                </el-checkbox>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <div class="privTxt">
                  이 시스템에서 제공되는 모든 고객정보는 개인정보
                  보호지침에 따라 당사의 영업 및 고객 관리목적에
                  한정하여 사용되어야 하며, 개인정보를 타인에게
                  누설하거나 제공되는 것을 절대 금지하고 있습니다.
                </div>
              </el-col>
              <el-col :span="24">
                <el-checkbox v-model="checkedAgree">
                  동의함
                </el-checkbox>
              </el-col>
              <el-col v-show="devAdminLogin" :span="24">
                <el-checkbox v-model="checkedDevLogin">
                  개발계 로그인
                </el-checkbox>
              </el-col>
            </el-row>
            <el-row>
              <el-button
                type="primary"
                class="loginBtn"
                @click="loginAction"
              >
                로그인
              </el-button>
            </el-row>
          </el-form>
        </div>
      </div>
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      :pop-sub-message.sync="alertSubMessage"
      sub-message-style="font-size: 12px;"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import PopMessage from '~/components/popup/PopMessage.vue'

export default {
  name: 'Login',
  layout: 'fullpage',
  components: {
    PopMessage
  },
  data() {
    return {
      alertMessage: '',
      alertSubMessage: '',
      alertMessagePop: false,
      ruleForm: {
        uid: '',
        pwd: ''
      },
      checkedId: false, // 아이디 저장 체크
      checkedAgree: false, // 동의함 체크
      isCapsLock: false,
      devAdminLogin: false,
      checkedDevLogin: false
    }
  },
  mounted() {
    //--for CHECK - 환경설정 파일 확인
    console.log(process.env)

    if(localStorage.getItem('copyId')) {
      this.ruleForm.uid = localStorage.getItem('copyId')
    }
    document.msCapsLockWarningOff = true
    window.addEventListener('keydown', this.onKeyCapsLock)
  },
  methods: {
    // CapsLock
    onKeyCapsLock(e) {
      this.isCapsLock = e.getModifierState('CapsLock')
    },
    loginAction() { // 로그인
      const { uid, pwd } = this.ruleForm
      if(!uid) {
        this.alertMessage = '아이디를 입력해주세요.'
        this.alertMessagePop = true
        return
      }

      if(!pwd) {
        this.alertMessage = '비밀번호를 입력해주세요.'
        this.alertMessagePop = true
        return
      }

      if(!this.checkedAgree) {
        this.alertMessage = '개인정보 보호 동의를 확인해주세요.'
        this.alertMessagePop = true
        return
      }

      if(this.checkedId) { // `아이디 저장` 버튼을 체크했을 경우
        window.localStorage.setItem('copyId', uid)
      } else {
        if(!window.localStorage.getItem('copyId')) {
          window.localStorage.removeItem('copyId')
        }
      }

      if(this.checkedDevLogin) {
        this.$store.dispatch('devLogin', {vm: this, uid, pwd}).then((res) => {
          const { rspCode = '', rspMessage = '', rspStatus = '', data = '' } = res
          let params = {}
          if(data && data.duplicateYn === 'Y') { params.duplicateYn = data.duplicateYn } // 중복로그인일 경우 중복 로그인 여부를 담는다.
          if(!rspStatus && rspCode !== '0000') {
            this.alertMessage = '로그인이 실패했습니다.'
            this.alertSubMessage = rspMessage || ''
            this.alertMessagePop = true
            return
          }
          this.$router.push({ name: 'main', params })
        })
      } else {
        this.$store.dispatch('login', {vm: this, uid, pwd}).then((res) => {
          const { rspCode = '', rspMessage = '', rspStatus = '', data = '' } = res
          let params = {}
          if(data && data.duplicateYn === 'Y') { params.duplicateYn = data.duplicateYn } // 중복로그인일 경우 중복 로그인 여부를 담는다.
          if(!rspStatus && rspCode !== '0000') {
            this.alertMessage = '로그인이 실패했습니다.'
            this.alertSubMessage = rspMessage || ''
            this.alertMessagePop = true
            return
          }
          this.$router.push({ name: 'main', params })
        })
      }

    }
  }
}
</script>

<style lang="scss" scoped>
@import '~/assets/style/pages/login.scss';
</style>
