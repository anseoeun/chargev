<template>
  <section>
    <div id="staff">
      <div class="article-title">
        <el-button 
          type="primary"
          @click="resetSearchForm">
           초기화
        </el-button>
        <el-button 
          type="primary"
          @click="search">
           조회
        </el-button>
      </div>
      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="8">
              <el-form-item label="조회구분">
                <el-select
                  v-model="searchForm.type">
                  <el-option 
                    v-for="{ type, code } in customerType" 
                    :key="code" 
                    :value="code" 
                    :label="type">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item 
                label="이메일">
                <el-input 
                 v-model="searchForm.email"
                 @keyup.native.enter="search" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item 
                label="고객관리번호">
                <el-input 
                 v-model="searchForm.subjectNumber"
                 @keyup.native.enter="search" />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item 
                label="이름" required>
                <el-input 
                  v-model="searchForm.name"
                  placeholder="이름과 생년월일을 조합해주세요"
                  @keyup.native.enter="search" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="생년월일">
                  <el-date-picker 
                    v-model="searchForm.bDay"
                    type="date"
                    format="yyyyMMdd"
                    value-format="yyyyMMdd"
                    placeholder="yyyyMMdd"
                  />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item 
                label="휴대전화">
                <el-input 
                  v-model="searchForm.mobile"
                  @keyup.native.enter="search" />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <div class="article-title">
        <h2>조회결과</h2>
      </div>
      <el-table 
        ref="singleTable"
        :data="customerInfo" 
        empty-text="조회된 결과가 존재하지 않습니다."
        class="box"
        highlight-current-row
        @current-change="handleCurrentChange"
      >
        <el-table-column prop="emailAddress" label="이메일" width="309" align="center"></el-table-column>
        <el-table-column prop="memberNumber" label="고객관리번호" width="200" align="center"></el-table-column>
        <el-table-column prop="fullName" label="고객명" width="200" align="center"></el-table-column>
        <el-table-column prop="birthDate" label="생년월일" width="200" align="center"></el-table-column>
        <el-table-column prop="mobile" label="휴대전화" width="200" align="center"></el-table-column>
        <el-table-column prop="employeeYn" label="직원여부" width="200" align="center"></el-table-column>
        <el-table-column prop="belongedTeam" label="소속" width="230" align="center"></el-table-column>
      </el-table>

      <div class="article-title gap">
        <div>
          <el-select v-model="searchForm.year">
            <el-option
              v-for="(item, idx) in searchYear"
              :key="idx"
              :value="item"
            />
          </el-select>
          <el-button type="primary" class="btn-small space" @click="searchHistory">조회</el-button>
        </div>
      </div>

      <div class="article">
        <el-tabs 
          v-model="activeTabName"
          type="card" 
          stretch
          @tab-click="handleTabClick"
        >
          <el-tab-pane name="estimate" :label="`견적이력(${historyCnt.estimateCnt}건)`">
            <estimateHistory
              ref="estimate"
              :customer-uniq-number="customerUniqNumber"
              :customer-name="customerName"
              :year="searchForm.year"
              @estimateCnt="setCount($event, 'estimate')"
            />
          </el-tab-pane>
          <el-tab-pane name="trial" :label="`시승이력(${historyCnt.trialCnt}건)`">
            <testDriveHistory
              ref="trial"
              :customer-name="customerName"
              :mobile="mobile"
              :year="searchForm.year"
              @trialCnt="setCount($event, 'trial')"
            />
          </el-tab-pane>
          <el-tab-pane name="contract" :label="`계약이력(${historyCnt.contractCnt}건)`">
            <contractHistory
              ref="contract"
              :customer-uniq-number="customerUniqNumber"
              :year="searchForm.year"
              @contractCnt="setCount($event, 'contract')"
            />
          </el-tab-pane>
          <el-tab-pane name="coupon" :label="`보유쿠폰(${historyCnt.couponCnt}건)`">
            <possessedCoupon
              ref="coupon"
              :member-mng-number="memberMngNumber"
              :year="searchForm.year"
              :customer-name="customerName"
              :mobile="mobile"
              @couponCnt="setCount($event, 'coupon')"
            />
          </el-tab-pane>
          <el-tab-pane name="sms" :label="`문자발송이력(${historyCnt.smsCnt}건)`">
            <smsHistory
              ref="sms"
              :customer-name="customerName"
              :mobile="mobile"
              :year="searchForm.year"
              @smsCnt="setCount($event, 'sms')"
            />
          </el-tab-pane>
        </el-tabs>
      </div>
      <pop-message
        :pop-visible.sync="alertMessagePop"
        :pop-message.sync="alertMessage"
        @confirm="alertMessagePop = false"
        @close="alertMessagePop = false"
      />
      <loading
        :pop-visible.sync="popVisibleLoading"
        :close-on-click-modal="false"
        @close="popVisibleLoading = false"
      />

    </div>
  </section>
</template>

<script>
import estimateHistory from '~/components/tab/Member/EstimateHistory.vue'
import possessedCoupon from '~/components/tab/Member/PossessedCoupon.vue'
import smsHistory from '~/components/tab/Member/SmsHistory.vue'
import contractHistory from '~/components/tab/Member/ContractHistory.vue'
import testDriveHistory from '~/components/tab/Member/TestDriveHistory.vue'
import moment from 'moment'
import PopMessage from '~/components/popup/PopMessage.vue'
import Loading from '~/components/popup/Loading.vue'
export default {
  layout: 'default',
  components: {
    PopMessage,
    Loading,
    estimateHistory,
    possessedCoupon,
    smsHistory,
    contractHistory,
    testDriveHistory,
  },
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      popVisibleLoading: true,
      customerUniqNumber: null,
      memberMngNumber: null,
      customerName: null,
      mobile: null,
      activeTabName: 'estimate',
      searchYear:[],
      historyCnt: {
        estimateCnt: 0,
        trialCnt: 0,
        contractCnt: 0,
        couponCnt: 0,
        smsCnt: 0,
      },
      historyCnt_new: {
        estimateCnt: 0,
        trialCnt: 0,
        contractCnt: 0,
        couponCnt: 0,
        smsCnt: 0,
      },
      searchForm: {
        year: moment().year(),
        type: 'M', //조회구분(M:회원정보, C:계약자정보)
        name: null, //이름
        email: null, //이메일주소
        subjectNumber: null, //고객관리번호
        mobile: null, //휴대전화
        bDay: null, //생년월일
      },
      customerType: [
        {
          type: '회원정보',
          code: 'M',
        },
        {
          type: '계약자정보',
          code: 'C',
        }
      ],
      customerInfo: [],
    }
  },
  computed: {
    changeData() {
      return [
        this.customerUniqNumber,
        this.memberMngNumber,
      ]
    }
  },
  watch: {
    changeData: {
      handler: function() {
        this.searchHistory()
      }
    }
  },
  mounted() {
    this.searchYear = {
      first: moment().year(),
      second:moment().add(-1, 'y').year(),
      third: moment().add(-2, 'y').year(),
      fourth: moment().add(-3, 'y').year(),
      fifth: moment().add(-4, 'y').year(),
    }
  },
  methods: {
    handleCurrentChange(val) {
      if(!val) return
      this.customerUniqNumber = val.customerUniqNumber
      this.memberMngNumber = val.memberNumber
      this.customerName = val.fullName
      this.mobile = val.mobile
    },
    search() {
      this.validation() //밸리데이션체크

      if(this.searchForm.type === 'C') {
        //'계약자정보'로 조회시
        this.getCustomerInfoByContract()
      }else {
        //'회원정보'로 조회시
        this.getCustomerInfo()
      }
    },
    searchHistory() {
      if(this.activeTabName === 'trial') this.trialHistory()
      else if(this.activeTabName === 'contract') this.contractHistory()
      else if(this.activeTabName === 'coupon') this.couponHistory()
      else if(this.activeTabName === 'sms') this.smsHistory()
      else this.estimateHistory()
    },
    async getCustomerInfo() {
      this.popVisibleLoading = true
      this.reset()
      // '회원정보'를 통해 회원정보조회
      let arr = []

      let mobileNumber = this.searchForm.mobile ? this.searchForm.mobile.replaceAll('-','') : null
      let birthDate = this.searchForm.bDay ? moment(this.searchForm.bDay).format('YYYYMMDD') : null
      let mbrNm = this.searchForm.name ? this.searchForm.name : null
      let csmrMgmtNo = this.searchForm.subjectNumber ? this.searchForm.subjectNumber : null
      let lgiId = this.searchForm.email ? this.searchForm.email : null


      const params = {
        mobile: mobileNumber,
        fullName: mbrNm,
        birthDate: birthDate,
        memberNumber: csmrMgmtNo,
        emailAddress: lgiId,
      }

      Object.keys(params).forEach(k => (
        !params[k] && params[k] !== undefined) && delete params[k]
      )

      //const [res, err] = await this.$https.post('/customer-info/v2/customer-info/hdot/customerInfo', params, null, 'gateway')
      const[res, err] = await this.$https.post('/v2/exclusive/total/member/searchMember', params)
      if(!err) {
        if(res.data) {
          arr = res.data.map(item => {
            return {
              ...item,
              employeeYn: item.employeeYn ? item.employeeYn : 'N',
              belongedTeam: item.belongedTeam ? item.belongedTeam : '-',
            }
          })

          if(arr.length > 0) {
            this.customerName = arr[0].fullName
            this.customerUniqNumber = arr[0].customerUniqNumber
            this.memberMngNumber = arr[0].memberNumber
          }

          this.$refs.singleTable.setCurrentRow(arr[0]) //첫번째 데이터 선택 활성화
        }else {
          this.reset()
        }
        this.customerInfo = arr
      }else {
        console.error('exclusive :: /customer-info/v2/customer-info/hdot/customerInfo ERROR !! '+err)
      }
      this.popVisibleLoading = false
    },
    async getCustomerInfoByContract() {
      this.popVisibleLoading = true
      
      this.reset()
      // '계약자정보'를 통해 회원정보조회
      let arr = []
      
      let mobileNumber = this.searchForm.mobile ? this.searchForm.mobile.replaceAll('-','') : null
      let birthDate = this.searchForm.bDay ? moment(this.searchForm.bDay).format('YYMMDD') : null
      let mbrNm = this.searchForm.name ? this.searchForm.name : null
      let csmrMgmtNo = this.searchForm.subjectNumber ? this.searchForm.subjectNumber : null
      let lgiId = this.searchForm.email ? this.searchForm.email : null


      const params = {
        mobile: mobileNumber,
        fullName: mbrNm,
        birthDate: birthDate,
        memberNumber: csmrMgmtNo,
        emailAddress: lgiId,
      }

      Object.keys(params).forEach(k => (
        !params[k] && params[k] !== undefined) && delete params[k]
      )

      const [res, err] = await this.$https.post('/v2/exclusive/total/member/searchCustomer', params)
      if(!err) {
        if(res.data) {
          arr = res.data.map(items => {
            return {
              emailAddress: items.emailAddress,
              fullName: items.fullName,
              birthDate: items.birthDate,
              mobile: items.mobile,
              employeeYn: items.employeeYn ? items.employeeYn : '-',
              belongedTeam: items.belongedTeam ? items.belongedTeam : '-',
              customerUniqNumber: items.customerUniqNumber ? items.customerUniqNumber : '', //고객고유번호
              memberNumber: items.memberNumber, //고객관리번호
            }
          })

          if(arr.length > 0) {
            this.customerName = arr[0].fullName
            this.customerUniqNumber = arr[0].customerUniqNumber
            this.memberMngNumber = arr[0].memberNumber
            this.mobile = arr[0].mobile

            this.$refs.singleTable.setCurrentRow(arr[0]) //첫번째 데이터 선택 활성화
          }else {
            this.reset()
          }
        }
      }else {
        console.error('exclusive :: /v2/exclusive/total/member/searchCustomer ERROR !! '+err)
      }
      this.customerInfo = arr
      this.popVisibleLoading = false
    },
    handleTabClick(tab) {
      if(tab.name === 'estimate') this.estimateHistory()
      else if(tab.name === 'trial') this.trialHistory()
      else if(tab.name === 'contract') this.contractHistory()
      else if(tab.name === 'coupon') this.couponHistory()
      else if(tab.name === 'sms') this.smsHistory()
    },
    async estimateHistory() {
      //견적이력 조회
      if(!this.customerUniqNumber) return

      await this.$refs.estimate.getEstimateData()
    },
    async trialHistory() {
      //시승이력 조회
      await this.$refs.trial.getTrialData()
    },
    async contractHistory() {
      //계약이력 조회
      if(!this.customerUniqNumber) return

      await this.$refs.contract.getContractData()
    },
    async couponHistory() {
      //보유쿠폰 조회
      if(!this.memberMngNumber) return

      await this.$refs.coupon.getPossessedCoupon()
    },
    async smsHistory() {
      //문자발송이력 조회
      await this.$refs.sms.getSmsData()
    },
    resetSearchForm() {
      //조회 영역 초기화
      Object.assign(this.searchForm, this.$options.data().searchForm)
      //검색 결과 초기화
      Object.assign(this.customerInfo, this.$options.data().customerInfo)

    },
    validation() {
      let chk = false
      if(this.searchForm.name && !this.searchForm.bDay){
        chk = true
      }
      if(this.searchForm.bDay && !this.searchForm.name) {
        chk = true
      }

      if(chk) {
        this.alertMessage = '이름과 생년월일을 조합해주세요.'
        this.alertMessagePop = true
        return
      }
    },
    setCount(cnt, type) {
      if(type === 'trial') this.historyCnt.trialCnt = cnt
      else if(type === 'estimate') this.historyCnt.estimateCnt = cnt
      else if(type === 'coupon') this.historyCnt.couponCnt = cnt
      else if(type === 'sms') this.historyCnt.smsCnt = cnt
      else if(type === 'contract') this.historyCnt.contractCnt = cnt
    },
    reset() {
      Object.assign(this.historyCnt, this.$options.data().historyCnt)
          
      this.$refs.estimate.estimateData = []
      this.$refs.trial.tableData = []
      this.$refs.contract.contractData = []
      this.$refs.coupon.couponData = []
      this.$refs.sms.tableData = []

      this.customerName = null
      this.customerUniqNumber = null
      this.memberMngNumber = null
    }
    
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
