<template>
  <section>
    <div id="support">

      <div class="article-title">
        <h-search 
          v-model="couponCode"
          :title="'쿠폰번호'"
          :on-click="search"
          @enter="search"
        />
        <div class="btn-group">
          <el-button type="primary" class="btn-excel" @click="download">EXCEL 다운로드</el-button>
        </div>
      </div>
      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="8">
              <el-form-item label="쿠폰번호">{{ couponInfo.couponCode }}</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="발급방식">{{ couponInfo.issueType }}</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="쿠폰명">{{ couponInfo.couponName }}</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="타겟번호">{{ couponInfo.targetCode }}</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="할인율(금액)">{{ couponInfo.discountAmount }}</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="사용기한">{{ couponInfo.couponUsableDateRange }}</el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <div class="box gap">
        <el-table :data="issueInfo" empty-text="조회된 조회결과가 존재하지 않습니다.">
          <el-table-column v-if="couponInfo.issueTypeCode === '30'" prop="certificationCode" label="인증코드" width="120" align="center"></el-table-column>
          <el-table-column v-if="couponInfo.issueTypeCode === '30'" prop="issueYn" label="발급여부" width="100" align="center"></el-table-column>
          <el-table-column v-if="couponInfo.issueTypeCode === '30'" prop="issueDate" label="발급일시" width="150" align="center"></el-table-column>
          <el-table-column prop="couponUseYn" label="사용여부" width="100" align="center"></el-table-column>
          <el-table-column prop="couponUseDate" label="사용일시" width="150" align="center"></el-table-column>
          <el-table-column prop="customerType" label="고객구분" width="150" align="center"></el-table-column>
          <el-table-column prop="issueSubjectNumber" label="고객관리번호" width="*" align="center"></el-table-column>
          <el-table-column prop="customerName" label="고객명" width="169" align="center"></el-table-column>
          <el-table-column prop="contractNumber" label="계약번호" width="150" align="center">
            <template slot-scope="props">
              <a
                class="link"
                :href="`/#/wp/contract/${props.row.contractType}/release-detail`"
                target="_blank"
                @click="$utils.setLocalStorage({ contractNumber: props.row.contractNumber })"
              >
                {{ props.row.contractNumber }}
              </a>
            </template>
          </el-table-column>
          <el-table-column prop="legacyStatus" label="국판진행상태" width="150" align="center"></el-table-column>
          <el-table-column prop="discountAmount" label="할인금액" width="150" align="center"></el-table-column>
        </el-table>
        <div class="btn-wrap">
          <div class="side"></div>
          <div class="pagination">
            <v-pagination
              v-if="issueInfo.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch"
            />
          </div>
          <div class="main"></div>
        </div>
      </div>
      <loading
        :pop-visible.sync="popVisibleLoading"
        :close-on-click-modal="false"
        @close="popVisibleLoading = false"
      />
    </div>
  </section>
</template>

<script>
import Loading from '~/components/popup/Loading.vue'
import HSearch from '~/components/common/HSearch.vue'
import moment from 'moment'
export default {
  layout: 'default',
  components: {
    Loading,
    HSearch,
  },
  data() {
    return {
      popVisibleLoading: false, // 로딩 활성화 여부
      searchDtRadio: 'day30',
      couponCode: null,
      couponInfo: [],
      issueInfo: [],
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      },
    }
  },
  watch: {
    couponInfo : function(){
      this.getIssueInfo()
    }
  },
  mounted() {
    this.couponCode = localStorage.getItem('couponCode') || ''
    if(this.couponCode) {
      this.search()
    }
    localStorage.removeItem('couponCode')
  },
  methods: {
    search() {
      this.getDetailInfo()
      //this.getIssueInfo()
    },
    async getDetailInfo() {
      if(!this.couponCode) return

      const [res, err] = await this.$https.get('/v2/exclusive/total/coupon/detail/'+this.couponCode)
      if(!err) {
        if(res.data) {
          this.couponInfo = {
            couponCode: res.data.couponCode,
            issueType: res.data.issueType,
            issueTypeCode: res.data.issueTypeCode,
            couponName: res.data.couponName,
            targetCode: res.data.targetCode,
            discountPrice: res.data.discountPrice,
            discountRate: res.data.discountRate,
            discountAmount : res.data.discountPrice ? res.data.discountPrice.toLocaleString() + '원' : res.data.discountRate + '%',
            couponUsableDateRange: res.data.couponUsableDateRange,
          }
        }
      }else {
        console.error('exclusive :: /v2/exclusive/total/coupon/detail ERROR !! '+err)
      }
    },
    async getIssueInfo() {
      if(!this.couponCode || !this.couponInfo.issueTypeCode) return

      this.popVisibleLoading = true

      const { page, size } = this.$data.pageInfo
      const params = {
        pageNo: page,
        pageSize: size,
        couponCode: this.couponCode,
        issueType: this.couponInfo.issueTypeCode
      }

      const [res, err] = await this.$https.post('/v2/exclusive/total/coupon/issue', params)
      if(!err) {
        if(res.data && res.data.list) {
          this.issueInfo = res.data.list.map((el, idx) => {
            return{
              ...el,
              no: res.data.total - res.data.endRow + res.data.list.length - idx,
              certificationCode: el.certificationCode,
              issueYn: el.issueYn,
              issueDate: el.issueDate,
              couponUseYn: el.couponUseYn,
              couponUseDate: el.couponUseDate ? el.couponUseDate : '',
              customerType: el.customerType ? el.customerType : '',
              issueSubjectNumber: el.issueSubjectNumber ? el.issueSubjectNumber : '',
              customerName: el.customerName ? el.customerName : '',
              contractNumber: el.contractNumber ? el.contractNumber : '',
              legacyStatus: el.legacyStatus ? el.legacyStatus : '',
              discountAmount: el.discountAmount ? el.discountAmount.toLocaleString() + '원' : '',
              contractType: el.corpYn === 'Y' ? 'corporation' : 'customer'
            }
          })
          this.$data.pageInfo = {
            ...this.$data.pageInfo,
            total: res.data.total
          }
        }
      }else {
        console.error('exclusive :: /v2/exclusive/total/coupon/issue ERROR !! '+err)
      }
      this.popVisibleLoading = false
    },
    async download() {
      if(!this.couponCode) return
      const params = {
        couponCode: this.couponCode,
        issueType: this.couponInfo.issueTypeCode
      }

      const [res, err] = await this.$https.post('/v2/exclusive/total/coupon/issue/excel-download', params, null, null, {responseType: 'blob'})
      if(!err) {
        const blob = new Blob([res], {type: res.Type})
        const nowDate = moment().format('YYYYMMDD_HHmm')
        if(window.navigator.msSaveOrOpenBlob) { //IE11
          window.navigator.msSaveOrOpenBlob(blob, '쿠폰발급사용상세조회_'+nowDate+'.xlsx')
        } else { //IE11 외
          const blobURL = window.URL.createObjectURL(blob)
          const tempLink = document.createElement('a')

          tempLink.href = blobURL

          tempLink.setAttribute('download', '쿠폰발급사용상세조회_'+nowDate+'.xlsx')
          document.body.appendChild(tempLink)        
          tempLink.click()
          document.body.removeChild(tempLink)        
          window.URL.revokeObjectURL(blobURL)
        }
      } else {
        console.error('exclusive :: /v2/exclusive/total/coupon/issue/excel-download ERROR !! '+err)
      }
    },
    onSearch(page) {
      this.$data.pageInfo.page = page
      this.search()
    },
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
