<template>
  <section>
    <div id="support">

      <div class="article-title">
        <el-button 
          type="primary"
          @click="resetSearchCond"
        >
        초기화
      </el-button>
        <div>
          <el-button type="primary" @click="getCouponList">조회</el-button>
          <el-button type="primary" class="btn-excel" @click="download">EXCEL 다운로드</el-button>
        </div>
      </div>
      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="24">
              <el-form-item label="발행일">
                <el-date-picker 
                  v-model="searchForm.releaseStrtDate"
                  type="date" />
                <span class="ex-txt">~</span>
                <el-date-picker 
                  v-model="searchForm.releaseEndDate"
                  type="date" />
                <el-radio-group
                  v-model="searchForm.searchDtRadio"
                  class="tabBtn-case01"
                  @change="onChangeSearchDtRadio"
                >
                  <el-radio-button label="lastDay">어제</el-radio-button>
                  <el-radio-button label="today">오늘</el-radio-button>
                  <el-radio-button label="day7">7일</el-radio-button>
                  <el-radio-button label="day30">30일</el-radio-button>
                  <el-radio-button label="month3">3개월</el-radio-button>
                  <el-radio-button label="month6">6개월</el-radio-button>
                  <el-radio-button label="year1">1년</el-radio-button>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item 
                label="발급방식">
                <el-select v-model="searchForm.issueType">
                  <el-option key="" label="전체" value="all"></el-option>
                  <el-option key="10" label="다운로드" value="10"></el-option>
                  <el-option key="20" label="수동지급" value="20"></el-option>
                  <el-option key="30" label="인증코드발급" value="30"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item 
                label="쿠폰명">
                <el-input 
                  v-model="searchForm.couponName"
                  @keyup.native.enter="getCouponList"
                 />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item 
                label="쿠폰번호">
                <el-input 
                  v-model="searchForm.couponCode"
                  @keyup.native.enter="getCouponList" />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <div class="box gap">
        <el-table 
          :data="couponData"
          empty-text="조회된 조회결과가 존재하지 않습니다."
        >
          <el-table-column prop="couponCode" label="쿠폰번호" width="120" align="center">
            <template slot-scope="props">
              <a
                  class="link"
                  href="/#/wp/total/coupon-issuing/use-detail"
                  target="_blank"
                  @click="
                   $utils.setLocalStorage({couponCode: props.row.couponCode})
                  "
                > 
                  {{ props.row.couponCode }}
                </a>
              </template>
          </el-table-column>
          <el-table-column prop="targetCode" label="타겟번호" width="120" align="center"></el-table-column>
          <el-table-column prop="issueType" label="발급방식" width="120" align="center"></el-table-column>
          <el-table-column prop="couponName" label="쿠폰명" width="299" align="center"></el-table-column>
          <el-table-column prop="couponUsableType" label="다회사용여부" width="120" align="center"></el-table-column>
          <el-table-column prop="relatedCars" label="대상차종" width="200" align="center"></el-table-column>
          <el-table-column prop="discountAmt" label="할인율(금액)" width="130" align="center"></el-table-column>
          <el-table-column prop="couponCreateDate" label="발행일시" width="130" align="center"></el-table-column>
          <el-table-column prop="couponUsableDateRange" label="사용기한" width="300" align="center"></el-table-column>
        </el-table>
        <div class="btn-wrap">
          <div class="side"></div>
          <div class="pagination">
            <v-pagination
              v-if="couponData.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch"
            />
          </div>
          <div class="main"></div>
        </div>
      </div>
      <loading
        :pop-visible.sync="popVisibleLoading"
        :close-on-click-modal="false"
        @close="popVisibleLoading = false"
      />
    </div>
  </section>
</template>

<script>
import Loading from '~/components/popup/Loading.vue'
import moment from 'moment'
export default {
  components: {
    Loading,
  },
  layout: 'default',
  data() {
    return {
      popVisibleLoading: false, // 로딩 활성화 여부
      searchForm: {
        searchDtRadio: 'day30',
        issueType: 'all',
        couponCode: null,
        couponName: null,
        releaseStrtDate: moment().subtract('days', 30),
        releaseEndDate: moment(),
      },
      couponData: [],
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      },
    }
  },
  created() {
    /** 쿠폰 리스트 조회 */
    this.getCouponList()
  },
  methods: {
    async getCouponList() {
      /** 쿠폰 리스트 조회 */

      this.popVisibleLoading = true

      const { page, size } = this.$data.pageInfo
      const params = {
        pageNo: page,
        pageSize: size,
        releaseStrtDate: moment(this.searchForm.releaseStrtDate).format('YYYYMMDD'),
        releaseEndDate: moment(this.searchForm.releaseEndDate).format('YYYYMMDD'),
        issueType: this.searchForm.issueType !== 'all' ? this.searchForm.issueType : '',
        couponCode: this.searchForm.couponCode,
        couponName: this.searchForm.couponName,
      }

      const [res, err] = await this.$https.post('/v2/exclusive/total/coupon',params)
      if(!err) {
        if(res.data && res.data.list) {
          this.couponData = res.data.list.map((el, idx) => {
            return {
              ...el,
              no: res.data.total - res.data.endRow + res.data.list.length - idx,
              isSelected: false,
              couponCode: el.couponCode,
              targetCode: el.targetCode,
              issueType: el.issueType,
              couponName: el.couponName,
              couponUsableType: el.couponUsableType,
              relatedCars: el.relatedCars ? el.relatedCars : '-',
              discountAmt: el.discountPrice ? el.discountPrice.toLocaleString() + '원' : el.discountRate + '%',
              couponCreateDate: el.couponCreateDate,
              couponUsableDateRange: el.couponUsableDateRange,
            }
          })
          this.$data.pageInfo = {
            ...this.$data.pageInfo,
            total: res.data.total
          }
        }
      }else {
        console.error('exclusive :: /v2/exclusive/total/coupon ERROR !! '+err)
      }

      this.popVisibleLoading = false
    },
    async download() {
      const params = {
        releaseStrtDate: moment(this.searchForm.releaseStrtDate).format('YYYYMMDD'),
        releaseEndDate: moment(this.searchForm.releaseEndDate).format('YYYYMMDD'),
        issueType: this.searchForm.issueType !== 'all' ? this.searchForm.issueType : '',
        couponCode: this.searchForm.couponCode,
        couponName: this.searchForm.couponName,
      }

      const[res, err] = await this.$https.post('/v2/exclusive/total/coupon/excel-download', params, null, null, {responseType: 'blob'})
      if(!err) {
        const blob = new Blob([res], {type: res.Type})
        const nowDate = moment().format('YYYYMMDD_HHmm')
        if(window.navigator.msSaveOrOpenBlob) { //IE11
          window.navigator.msSaveOrOpenBlob(blob, '쿠폰발급사용조회_'+nowDate+'.xlsx')
        } else { //IE11 외
          const blobURL = window.URL.createObjectURL(blob)
          const tempLink = document.createElement('a')

          tempLink.href = blobURL

          tempLink.setAttribute('download', '쿠폰발급사용조회_'+nowDate+'.xlsx')
          document.body.appendChild(tempLink)        
          tempLink.click()
          document.body.removeChild(tempLink)        
          window.URL.revokeObjectURL(blobURL)
        }
      }else {
        console.error('exclusive :: /v2/exclusive/total/coupon/excel-download ERROR !! '+err)
      }
    },
    resetSearchCond() {
      /** 검색조건 초기화 */
      Object.assign(this.searchForm, this.$options.data().searchForm)
    },
    onSearch(page) {
      this.$data.pageInfo.page = page
      this.getCouponList()
    },
    onChangeSearchDtRadio(val) {
      /** 쿠폰 발행일 조건 설정(어제,오늘,7일,30일,3개월,6개월,1년) */
      if(val==='lastDay') {
        this.searchForm.releaseStrtDate = moment().subtract('days', 1)
        this.searchForm.releaseEndDate = moment().subtract('days', 1)
      } else if(val==='today') {
        this.searchForm.releaseStrtDate = moment()
        this.searchForm.releaseEndDate = moment()
      } else if(val==='day7') {
        this.searchForm.releaseStrtDate = moment().subtract('days', 7)
        this.searchForm.releaseEndDate = moment()
      } else if(val==='day30') {
        this.searchForm.releaseStrtDate = moment().subtract('days', 30)
        this.searchForm.releaseEndDate = moment()
      } else if(val==='month3') {
        this.searchForm.releaseStrtDate = moment().subtract('months', 3)
        this.searchForm.releaseEndDate = moment()
      } else if(val==='month6') {
        this.searchForm.releaseStrtDate = moment().subtract('months', 6)
        this.searchForm.releaseEndDate = moment()
      } else if(val==='year1') {
        this.searchForm.releaseStrtDate = moment().subtract('months', 12)
        this.searchForm.releaseEndDate = moment()
      }
    },
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
