<template>
  <section>
    <div id="support">

      <div class="article-title">
        <h-search 
          v-model="certCode"
          :title="'인증코드'"
          :on-click="search"
          @enter="search"
        />
        <el-button type="primary" class="btn-excel" @click="download">EXCEL 다운로드</el-button>
      </div>
      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="8">
              <el-form-item label="행사번호">{{ AllianceCouponInfo.eventNo }}</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="발급방식">{{ AllianceCouponInfo.issueType }}</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="발행기간">{{ AllianceCouponInfo.couponIssueDateRange }}</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="제휴사명">{{ AllianceCouponInfo.allianceName }}</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="쿠폰명">{{ AllianceCouponInfo.couponName }}</el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label=""></el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <div class="box gap">
        <el-table :data="issueInfo" empty-text="조회된 조회결과가 존재하지 않습니다.">
          <el-table-column prop="no" label="NO" width="110" align="center"></el-table-column>
          <el-table-column prop="certCode" label="인증코드" width="200" align="center"></el-table-column>
          <el-table-column prop="issueYn" label="발급여부" width="120" align="center"></el-table-column>
          <el-table-column prop="issueDate" label="발급일시" width="310" align="center"></el-table-column>
          <el-table-column prop="psnCorpScnCd" label="발급대상" width="200" align="center"></el-table-column>
          <el-table-column prop="issueSubjectNumber" label="고객관리번호/사업자번호" width="300" align="center"></el-table-column>
          <el-table-column prop="customerName" label="고객명" width="300" align="center"></el-table-column>
        </el-table>
        <div class="btn-wrap">
          <div class="side"></div>
          <div class="pagination">
            <v-pagination
              v-if="issueInfo.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch"
            />
          </div>
          <div class="main"></div>
        </div>
      </div>
      <loading
        :pop-visible.sync="popVisibleLoading"
        :close-on-click-modal="false"
        @close="popVisibleLoading = false"
      />
    </div>
  </section>
</template>

<script>
import Loading from '~/components/popup/Loading.vue'
import HSearch from '~/components/common/HSearch.vue'
import moment from 'moment'
export default {
  layout: 'default',
  components: {
    Loading,
    HSearch,
  },
  data() {
    return {
      popVisibleLoading: false, // 로딩 활성화 여부
      searchDtRadio: 'day30',
      certCode:'',
      eventNo: '',
      AllianceCouponInfo: [],
      issueInfo: [],
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      },
    }
  },
  watch: {
    AllianceCouponInfo : function(){
      this.getIssueInfo()
    }
  },
  mounted() {
    this.eventNo = localStorage.getItem('eventNo') || ''
    if(this.eventNo) {
      this.getDetailInfo()
    }
    localStorage.removeItem('eventNo')
  },
  methods: {
    search() {
      this.getIssueInfo()
    },
    async getDetailInfo() {
      if(!this.eventNo) return

      const param = {
        eventNo : this.eventNo
      }

      const [res, err] = await this.$https.post('/v2/exclusive/total/allianceCouponDetail', param)
      if(!err) {
        if(res.data) {
          this.AllianceCouponInfo = {
            eventNo: res.data.eventNo,
            issueType: res.data.issueType,
            allianceName: res.data.allianceName,
            couponName: res.data.couponName,
            couponIssueDateRange: res.data.couponIssueDateRange,
          }
        }
      }else {
        console.error('exclusive :: /v2/exclusive/total/alianceCouponDetail ERROR !! '+err)
      }
    },
    async getIssueInfo() {
      if(!this.eventNo) return

      this.popVisibleLoading = true

      const { page, size } = this.$data.pageInfo

      const params = {
        pageNo: page,
        pageSize: size,
        eventNo: this.eventNo,
        certCode: this.certCode,
      }

      const [res, err] = await this.$https.post('/v2/exclusive/total/allianceCoupon/issue', params)
      if(!err) {
        if(res.data && res.data.list) {
          this.issueInfo = res.data.list.map((el, idx) => {
            return{
              no: res.data.total - res.data.endRow + res.data.list.length - idx,
              certCode: el.certCode,
              issueYn: el.issueYn,
              issueDate: el.issueDate,
              psnCorpScnCd: el.psnCorpScnCd,
              issueSubjectNumber: el.issueSubjectNumber ? el.issueSubjectNumber : '',
              customerName: el.customerName ? el.customerName : '',
            }
          })
          this.$data.pageInfo = {
            ...this.$data.pageInfo,
            total: res.data.total
          }
        }
      }else {
        console.error('exclusive :: /v2/exclusive/total/allianceCoupon/issue ERROR !! '+err)
      }
      this.popVisibleLoading = false
    },
    async download() {
      //엑셀 다운로드
      const params = {
        eventNo: this.eventNo,
      }

      const[res, err] = await this.$https.post('/v2/exclusive/total/allianceCouponIssueList/excel-download', params, null, null, {responseType: 'blob'})
      if(!err) {
        const blob = new Blob([res], {type: res.Type})
        const nowDate = moment().format('YYYYMMDD_HHmm')
        if(window.navigator.msSaveOrOpenBlob) { //IE11
          window.navigator.msSaveOrOpenBlob(blob, '제휴쿠폰 발급 정보 조회_'+nowDate+'.xlsx')
        } else { //IE11 외
          const blobURL = window.URL.createObjectURL(blob)
          const tempLink = document.createElement('a')

          tempLink.href = blobURL

          tempLink.setAttribute('download', '제휴쿠폰 발급 정보 조회_'+nowDate+'.xlsx')
          document.body.appendChild(tempLink)        
          tempLink.click()
          document.body.removeChild(tempLink)        
          window.URL.revokeObjectURL(blobURL)
        }
      }else {
        console.error('exclusive :: /v2/exclusive/total/allianceCouponIssueList/excel-download ERROR !! '+err)
      }
    },
    onSearch(page) {
      this.$data.pageInfo.page = page
      this.search()
    },
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
