<template>
  <section>
    <div id="support">

      <div class="article-title">
        <el-button 
          type="primary"
          @click="resetSearchCond"
        >
          초기화
        </el-button>
        <div>
          <el-button type="primary" @click="getAmbassadorRecord">조회</el-button>
          <el-button type="primary" class="btn-excel" @click="excelDownload">EXCEL 다운로드</el-button>
        </div>
      </div>
      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="24">
              <el-form-item label="출고일">
                <el-date-picker 
                  v-model="searchForm.startDate"
                  type="date" />
                <span class="ex-txt">~</span>
                <el-date-picker 
                  v-model="searchForm.finishDate"
                  type="date" />
                <el-radio-group 
                  v-model="searchDtRadio" 
                  class="tabBtn-case01"
                  @change="onChangeSearchDtRadio"
                >
                  <el-radio-button label="lastDay">어제</el-radio-button>
                  <el-radio-button label="today">오늘</el-radio-button>
                  <el-radio-button label="day7">7일</el-radio-button>
                  <el-radio-button label="day30">30일</el-radio-button>
                  <el-radio-button label="month3">3개월</el-radio-button>
                  <el-radio-button label="month6">6개월</el-radio-button>
                  <el-radio-button label="year1">1년</el-radio-button>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="리워드 적용여부">
                <el-select
                  v-model="searchForm.rewardAplyYn">
                  <el-option 
                    v-for="{ code, label } in rewardOptions"
                    :key="code"
                    :value="code"
                    :label="label"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="16">
              <el-form-item label="국판진행상태">
                <el-select v-model="searchForm.contractStateCodeList" class="select-multiple" style="width:430px;" multiple filterable allow-create default-first-option @change="checkStat">
                  <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>
                <el-checkbox v-model="stateChk" @change="allSetStateCode">전체</el-checkbox>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="엠버서더">
                <el-input 
                  v-model="searchForm.aqRcmCsmrMgmtNo" 
                  placeholder="고객관리번호 입력"
                  @keyup.native.enter="getAmbassadorRecord" />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="집계데이터 조회">
                <ul class="data-list">
                  <li><strong class="tit">전체</strong><span class="val"><strong>{{ pageInfo.total }}</strong>건</span></li>
                  <li><strong class="tit">리워드 적용</strong><span class="val"><strong>{{ rewardAplyCount }}</strong>건</span></li>
                  <li><strong class="tit">리워드 대기</strong><span class="val"><strong>{{ rewardWatingCount }}</strong>건</span></li>
                </ul>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>

      <div class="article-title gap">
        <div>
          <el-checkbox v-model="checkAll" @change="handleCheckAllChange">전체선택</el-checkbox>
          <el-button type="primary" @click="applyReward">리워드 적용</el-button>
          <el-button type="primary" @click="cancelReward">리워드 취소</el-button>
        </div>
      </div>
      <div class="box">
        <el-table :data="ambassadorData">
            <el-table-column label="선택" width="80" align="center">
                
              <template slot-scope="props">
                  <el-checkbox v-model="props.row.isSelected" @change="handleCheckedDataChange"></el-checkbox>
                </template>
              </el-table-column>
              <el-table-column prop="no" label="No." width="80" align="center"></el-table-column>
              <el-table-column prop="aqRcmCsmrMgmtNo" label="엠버서더" width="140" align="center"></el-table-column>
              <el-table-column prop="contractDivisionCode" label="계약구분" width="80" align="center"></el-table-column>
              <el-table-column prop="saleContractNumber" label="계약번호" width="140" align="center">
                <template slot-scope="props">
                  <a
                    class="link"
                    :href="`/#/wp/contract/${props.row.contractType}/release-detail`"
                    target="_blank"
                    @click="$utils.setLocalStorage({ contractNumber: props.row.saleContractNumber })"
                  >
                    {{ props.row.saleContractNumber }}
                  </a>
                </template>
              </el-table-column>
              <el-table-column prop="contracterName" label="계약자" width="140" align="center"></el-table-column>
              <el-table-column prop="releaseDate" label="출고일" width="140" align="center"></el-table-column>
              <el-table-column prop="customerUndertakingDecisionDate" label="인수확정일" width="140" align="center"></el-table-column>
              <el-table-column prop="carMakeCertificateRequestDate" label="제작증발급일" width="140" align="center"></el-table-column>
              <el-table-column prop="contractResponsibilityName" label="계약담당자" width="140" align="center"></el-table-column>
              <el-table-column prop="contractState" label="국판진행상태" width="140" align="center"></el-table-column>
              <el-table-column prop="onlineStatus" label="온라인진행상태" width="140" align="center"></el-table-column>
              <el-table-column prop="vinNumber" label="차대번호" width="140" align="center"></el-table-column>
              <el-table-column prop="rewardAplyYn" label="리워드" width="140" align="center"></el-table-column>
        </el-table>
      </div>
      <pop-message
        :pop-visible.sync="alertMessagePop"
        :pop-message.sync="alertMessage"
        @confirm="alertMessagePop = false"
        @close="alertMessagePop = false"
      />
      <loading
        :pop-visible.sync="popVisibleLoading"
        :close-on-click-modal="false"
        @close="popVisibleLoading = false"
      />
    </div>
  </section>
</template>

<script>
import moment from 'moment'
import PopMessage from '~/components/popup/PopMessage.vue'
import Loading from '~/components/popup/Loading.vue'
export default {
  layout: 'default',
  components: {
    PopMessage,
    Loading,
  },
  data() {
    return {
      checkAll: false,
      popVisibleLoading: false,
      alertMessage: '',
      alertMessagePop: false,
      checkedData: [],
      searchDtRadio: 'day30',
      searchForm: {
        startDate: moment().subtract('days', 30), //출고 조건 시작일
        finishDate: moment(), //출고 조건 종료일
        rewardAplyYn: 'ALL', //리워드 적용여부
        aqRcmCsmrMgmtNo: null, //고객관리번호
        contractStateCodeList: []
      },
      rewardAplyCount: 0,
      rewardWatingCount: 0,
      ambassadorData:[],
      options: [
        { value: '60', label: '출고' },
        { value: '70', label: '매출취소' },
        { value: '71', label: '전시차입고취소' },
        { value: '90', label: '해약' },
        { value: '91', label: '이관' },
      ],
      rewardOptions: [
        { code: 'ALL', label: '전체' },
        { code: 'N', label: '대기' },
        { code: 'Y', label: '적용' }
      ],
      value: [],
      stateChk: false,
      isIndeterminate: true,
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      },
    }
  },
  methods: {
    async getAmbassadorRecord() {
      //엠버서더 실적 리스트 조회

      this.popVisibleLoading = true //로딩바 동작

      const { page, size} = this.$data.pageInfo
      const { startDate, finishDate, rewardAplyYn, aqRcmCsmrMgmtNo, contractStateCodeList } = this.$data.searchForm
      
      const params = {
        pageNo: page,
        pageSize: size,
        startDate: moment(startDate).format('YYYYMMDD'), //출고 조건 시작일
        finishDate: moment(finishDate).format('YYYYMMDD'), //출고 조건 종료일
        rewardAplyYn: rewardAplyYn === 'ALL' ? '' : rewardAplyYn, //리워드 적용여부
        aqRcmCsmrMgmtNo: aqRcmCsmrMgmtNo, // 고객관리번호
        contractStateCodeList: contractStateCodeList, //국판진행상태
      }

      
      //엠버서더실적 목록 조회 API
      const [res, err] = await this.$https.post('/v2/exclusive/ambassador/ambassador-list', params)
      if(!err){
        if(res.data && res.data.list) {
          this.ambassadorData = res.data.list.map((el, idx) => {
            return{
              ...el,
              isSelected: false,
              no : res.data.total - res.data.endRow + res.data.list.length - idx,
              aqRcmCsmrMgmtNo: el.aqRcmCsmrMgmtNo, //고객관리번호
              saleContractNumber: el.saleContractNumber, //계약번호
              contracterName: el.contracterName, //계약자명
              contractType: el.contractDivisionCode === '법인' ? 'corporation' : 'customer',
              contractDivisionCode: el.contractDivisionCode, //계약구분 - 1(개인) 2(개인사업자) 3(법인)
              releaseDate: el.releaseDate, //출고일
              customerUndertakingDecisionDate: el.customerUndertakingDecisionDate, //인수확정일
              carMakeCertificateRequestDate: el.carMakeCertificateRequestDate, //제작증발급일
              contractResponsibilityName: el.contractResponsibilityName, //계약담당자
              contractState: el.contractStateCode, //국판진행상태
              onlineStatus: el.onlineStatusCd, //온라인진행상태
              vinNumber: el.vinNumber, //차대번호
              rewardAplyYn: el.rewardAplyYn ? el.rewardAplyYn === 'Y' ? '적용' : '대기' : '', //리워드 적용여부
            }
          })
          
          let rewardAplyCount = 0, rewardWatingCount = 0
          if(res.data.list.length > 0) {
            const data = res.data.list[0]
            rewardAplyCount = data.rewardAplyCount,
            rewardWatingCount = data.rewardWatingCount
          }
          this.rewardAplyCount = rewardAplyCount,
          this.rewardWatingCount = rewardWatingCount

          this.$data.pageInfo = {
            ...this.$data.pageInfo,
            total: res.data.total
          }
        }
      }else {
        console.error('/v2/exclusive/ambassador/ambassador-list ERROR ::: '+err)
      }
      this.popVisibleLoading = false //로딩바 동작 종료
    },
    async excelDownload() {
      //엠버서더 실적조회 리스트 엑셀 다운로드
      this.popVisibleLoading = true //로딩바 동작

      const { startDate, finishDate, rewardAplyYn, aqRcmCsmrMgmtNo, contractStateCodeList } = this.$data.searchForm
      
      const params = {
        startDate: moment(startDate).format('YYYYMMDD'), //출고 조건 시작일
        finishDate: moment(finishDate).format('YYYYMMDD'), //출고 조건 종료일
        rewardAplyYn: rewardAplyYn === 'ALL' ? '' : rewardAplyYn, //리워드 적용여부
        aqRcmCsmrMgmtNo: aqRcmCsmrMgmtNo, // 고객관리번호
        contractStateCodeList: contractStateCodeList, //국판진행상태
      }


      const [res, err] = await this.$https.post('/v2/exclusive/ambassador/ambassador-exceldownload', params, null, null, {responseType: 'blob'})
      if(!err) {
        const blob = new Blob([res], {type : res.Type })
        const nowDate = moment().format('YYYYMMDD_HHmm') 
        if(window.navigator.msSaveOrOpenBlob) {
          // IE11
          window.navigator.msSaveOrOpenBlob(blob, '엠버서더실적조회_' + nowDate + '.xlsx') 
        } else {            
          // IE11 외 브라우저
          const blobURL = window.URL.createObjectURL(blob)
          const tempLink = document.createElement('a')
          
          tempLink.href = blobURL        
                
          tempLink.setAttribute('download', '엠버서더실적조회_' + nowDate + '.xlsx')
          document.body.appendChild(tempLink)        
          tempLink.click()
          document.body.removeChild(tempLink)        
          window.URL.revokeObjectURL(blobURL)
        }
      }else {
        console.error('/v2/exclusive/ambassador/ambassador-exceldownload ERROR ::: '+err)
      }
      this.popVisibleLoading = false //로딩바 동작 종료
    },
    async applyReward() {
      // 리워드 적용
      if(this.checkedData.length === 0) {
        this.alertMessage = '항목을 선택하세요.'
        this.alertMessagePop = true

        return
      }
      this.popVisibleLoading = true //로딩바 동작

      const params = {
        data: this.checkedData
      }
      //const [res, err] = await this.$https.post('/v2/exclusive/ambassador/ambassador-rewardaplyy', params)
      const [res, err] = await this.$https.post('/purchase/v2/purchase/ambassador/ambassador-rewardaplyy', params, null, 'gateway')
      if(!err) {
        if(res.rspStatus && res.rspStatus.rspCode === '0000') {
          this.alertMessage = '적용되었습니다.'
          this.alertMessagePop = true

          this.getAmbassadorRecord()
        }
      }else {
        console.error('/purchase/v2/purchase/ambassador/ambassador-rewardaplyy ERROR ::: '+err)
      }
      this.checkAll = false
      this.popVisibleLoading = false //로딩바 동작 종료
    },
    async cancelReward() {
      // 리워드 취소
      if(this.checkedData.length === 0) {
        this.alertMessage = '항목을 선택하세요.'
        this.alertMessagePop = true

        return
      }

      this.popVisibleLoading = true //로딩바 동작

      const params = {
        data: this.checkedData
      }
      //const [res, err] = await this.$https.post('/v2/exclusive/ambassador/ambassador-rewardaplyn', params)
      const [res, err] = await this.$https.post('/purchase/v2/purchase/ambassador/ambassador-rewardaplyn', params, null, 'gateway')
      if(!err) {
        if(res.rspStatus && res.rspStatus.rspCode === '0000') {
          this.alertMessage = '수정되었습니다.'
          this.alertMessagePop = true

          this.getAmbassadorRecord()
        }
      }else {
        console.error('/purchase/v2/purchase/ambassador/ambassador-rewardaplyn ERROR ::: '+err)
      }
      this.checkAll = false
      this.popVisibleLoading = false //로딩바 동작 종료
    },
    handleCheckAllChange(val) {
      if(val) {
        this.checkedData = this.ambassadorData
      }else {
        this.checkedData = []
      } 

      this.ambassadorData.map(el=> {
        el.isSelected = val
      })
    },
    handleCheckedDataChange() {
      let arr = []
      this.ambassadorData.map(el=> {
        if(el.isSelected){
          arr.push(el)
        } 
      })
      this.checkedData = arr

      this.checkAll = this.checkedData.length === this.ambassadorData.length
    },
    resetSearchCond(){
      /** 검색조건 초기화 */
      Object.assign(this.searchForm, this.$options.data().searchForm)
      this.searchDtRadio = 'day30'
    },
    onChangeSearchDtRadio(val) {
      /** 출고일 조건 설정(어제,오늘,7일,30일,3개월,6개월,1년) */
      if(val==='lastDay') {
        this.searchForm.startDate = moment().subtract('days', 1)
        this.searchForm.finishDate = moment().subtract('days', 1)
      } else if(val==='today') {
        this.searchForm.startDate = moment()
        this.searchForm.finishDate = moment()
      } else if(val==='day7') {
        this.searchForm.startDate = moment().subtract('days', 7)
        this.searchForm.finishDate = moment()
      } else if(val==='day30') {
        this.searchForm.startDate = moment().subtract('days', 30)
        this.searchForm.finishDate = moment()
      } else if(val==='month3') {
        this.searchForm.startDate = moment().subtract('months', 3)
        this.searchForm.finishDate = moment()
      } else if(val==='month6') {
        this.searchForm.startDate = moment().subtract('months', 6)
        this.searchForm.finishDate = moment()
      } else if(val==='year1') {
        this.searchForm.startDate = moment().subtract('months', 12)
        this.searchForm.finishDate = moment()
      } 
    },
    allSetStateCode() {
      let arr = []
      if(this.stateChk) {
        this.options.map(el => {
          arr.push(el.value)
          this.searchForm.contractStateCodeList.push(el.value)
        })
      }else {
        arr = []
      }
      this.searchForm.contractStateCodeList = arr
    },
    checkStat() {
      this.stateChk = this.searchForm.contractStateCodeList.length === this.options.length
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>
