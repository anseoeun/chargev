<template>
  <section>
    <div id="staff">
      <div class="article-title" align="right">
        <div class="btn-group">
          <div>
            <el-button
              v-if="isValidAuthBtn('authSave') && isValidUserAuthBtn()"
              type="primary"
              :disabled="!data.customerManagementNumber"
              @click="oneClickDisable($event, saveCheck)"
            >
            저장
            </el-button>
            <el-button type="info" @click="oneClickDisable($event, onCancle)">취소</el-button>
          </div>
        </div>
      </div>

      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="8">
              <el-form-item label="고객관리번호">
                  <el-input v-model.trim="data.customerManagementNumber" style="width:200px;" />
                <el-button type="info" class="btn-small" @click="openCustomerPopup()">조회</el-button>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item v-model="data.wExsfNm" label="고객명"> {{ data.wExsfNm }} </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="배우자">
                <el-input v-model.trim="data.spusCsmrMgmtNo" style="width:200px;" />
                <el-button type="info" class="btn-small" @click="openCustomerPopup('spus')">조회</el-button>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="생년월일">
                <span v-if="birthDate">{{ birthDate }}</span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item v-model="data.emlAdr" label="이메일"> {{ data.emlAdr }} </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item v-model="data.hpTn" label="휴대전화"> {{ data.hpTn }} </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item v-model="data.workAssignNumber" label="업무번호" />
            </el-col>
            <!-- 나중에 임직원 진행상태코드, 실패사유코드 나오면 코드값 수정 필요 -->
            <el-col :span="8">
              <el-form-item label="진행상태" required>
                <div class="select-client">
                  <el-select
                    v-model="data.pgsStCd"
                    readonly
                      >
                      <el-option value="03" label="완료" readonly />
                  </el-select>
                </div>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item v-model="userInfo.eeNm" label="업무처리자" />
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item v-model="data.csetDtm" label="승인일시" />
            </el-col>
            <el-col :span="8">
              <el-form-item label="구매가능일"> 
                <span v-if="buyCanDtime">
                  {{ buyCanDtime }} 이후
                </span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="인증 만료일" required>
                <el-date-picker v-model="data.xprDt" format="yyyy-MM-dd" type="date" />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="요청메모">
                <el-input v-model="data.memoSbc" type="textarea" />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <div class="article-title">
        <h2>직원 인증 정보</h2>
      </div>
      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="8">
              <el-form-item label="소속" required>
                <el-select
                  v-model="data.wExsfCtfnCndSn"
                  placeholder="접수"
                >
                <el-option
                  v-for="(item, index) in subjectConditionList"
                  :key="index"
                  :value="item.conditionSerialNumber"
                  :label="item.cndSbc"
                  @click.native="conditonSetting(item)"
                />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="고객/손실구분" required>
                <span v-if="employeeAuthInfo.csmrTypeCd && employeeAuthInfo.csmrLossCd">
                 {{ employeeAuthInfo.csmrTypeCd }} / {{ employeeAuthInfo.csmrLossCd }}
                </span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="할인조건">
                <span v-if="data.coCd">
                  DC {{ data.dcRate ? data.dcRate : 0 }} % , 
                   일시불 할인 {{ data.foiYn === 'Y' ? '가능' : '불가' }} , 무이자 {{ data.lspDcYn === 'Y' ? '가능' : '불가' }} 
                   </span>
                </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="업체" required>
                <el-input v-model.trim="data.firmNm" style="width:200px;" />
                <el-button type="info" class="btn-small" @click="openCompanyPopup">조회</el-button>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="사번" required>
                <el-input v-model.trim="data.wExsfNo" />
              </el-form-item>
            </el-col>
            <!-- <el-col :span="8">
              <el-form-item label="입사일" required>
                <el-date-picker type="date" v-model="data.etcpDt" />
              </el-form-item>
            </el-col> -->
          </el-row>
        </el-form>
      </div>
      
      <div class="article-title gap">
        <h2>서류 심사 목록</h2>
        <!-- <el-button
          v-if="isValidAuthBtn('authExclusive')"
          :disabled="!workAssignNumber"
          type="primary"
          class="btn-md"
          icon="el-icon-plus"
          style="position: relative; width: 20px;"
          @click="addDocumentRow"
        /> -->
      </div> 
      <div class="box">     
        <el-table
          :data="documentList"
          class="box append-box"
          >
          <el-table-column prop="no" label="NO." width="60" align="center">
            <template slot-scope="props">
              <span>{{ props.row.no }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="구분"
            prop="neceDocTargNm"
            align="center"
            width="310"
            placeholder="선택하세요"
          >
            <template slot-scope="props">
              <span>
                {{ props.row.neceDocTargNm }}
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="소분류"
            prop="neceDocNm"
            align="center"
            width="319"
          >
            <template slot-scope="props">
              <span>{{ props.row.neceDocNm }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="스크래핑 결과"
            prop="scrapingCompleteYn"
            align="center"
            width="100"
          >
            <template slot-scope="scope">
              <span v-if="scope.row.scrapingCompleteYn">
                {{ scope.row.scrapingCompleteYn }}
              </span>
              <span v-else>
                -
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="추가서류여부"
            prop="additionPapersYn"
            align="center"
            width="100"
          />
          <el-table-column
            label="제출서류"
            prop="fileGroupSerialNumber"
            align="center"
            width="150"
          >
            <template slot-scope="scope">
              <span
                v-if="scope.row.fileGroupSerialNumber"
                style="cursor: pointer; color: #1a0dab;"
                @click="getFileData(scope.row)"
              >
                <i class="file_img"></i>{{ scope.row.attcFilNm }}<br />
              </span>
              <span
                v-else
                style="cursor: pointer; color: #1a0dab;"
              >
              <el-upload
                ref="upload"
                name="file"
                accept=".jpg, .jpeg, .gif, .pdf"
                action=""
                :auto-upload="false"
                :multiple="false"
                :limit="1"
                :file-list="fileList"
                :on-change="handleChange"
              >
                <el-button
                  slot="trigger"
                  type="info"
                  class="btn-small"
                  @click="rememberIdex(scope.row.no)"
                >
                  등록
                </el-button>
              </el-upload>
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="요청일시"
            prop="papersRequestDate"
            align="center"
            
            width="200"
          >
            <template slot-scope="scope">
              <span v-if="scope.row.papersRequestDate">
                {{ scope.row.papersRequestDate }}
              </span>
              <span v-else>
                -
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="등록일시"
            prop="uploadDate"
            align="center"
            width="200"
          >
            <template slot-scope="scope">
              <span v-if="scope.row.uploadDate">
                {{ scope.row.uploadDate }}
              </span>
              <span v-else>
                -
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="처리일시"
            prop="workProcessDate"
            align="center"
            width="200"
          >
            <template slot-scope="scope">
              <span v-if="scope.row.workProcessDate">
                {{ scope.row.workProcessDate }}
              </span>
              <span v-else>
                -
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="처리결과"
            align="center"
            width="150"
          >
            <template>
              <span>완료</span>
            </template>
          </el-table-column>
          <el-table-column
            label="진행 상황 메모"
            prop="ppExamSbc"
            align="center"
            width="450"
          >
            <template slot-scope="scope">
              <el-input
                v-model="scope.row.ppExamSbc"
              />
            </template>
          </el-table-column>
        </el-table>
      </div>

      <!-- 심사 대상 서류 목록 -->
      <paper-review-info
        v-if="data.workAssignNumber"
        ref="paperInfo"
        :work-assign-number.sync="workAssignNumber"
        :user-info-data.sync="userInfo"
        :contract-info-data.sync="employeeAuthInfo"
        :active-user-flag.sync="activeFlag"
        @setPaperReviewData="setPaperReviewData"
      /> 
      <div class="article-title">
        <h2>직원인증 이력</h2>
      </div>
      <div class="box">
        <el-table
          :data="authHistoryList"
        >
          <el-table-column prop="rowNo" label="NO." width="60" align="center"></el-table-column>
          <el-table-column prop="vbgInpDtm" label="요청일시" width="200" align="center"></el-table-column>
          <el-table-column prop="csetDtm" label="처리일시" width="200" align="center"></el-table-column>
          <el-table-column prop="coCdNm" label="소속" width="360"></el-table-column>
          <el-table-column prop="dcSbc" label="할인률" width="319"></el-table-column>
          <el-table-column prop="managerName" label="업무처리자" width="150" align="center"></el-table-column>
          <el-table-column prop="progressState" label="진행상태" width="150" align="center"></el-table-column>
          <el-table-column prop="employeeYn" label="직원여부" width="100" align="center"></el-table-column>
        </el-table>
      </div>

      <!-- 회원조회 팝업 -->
      <customer-search-popup
        ref="customerPop"
        :pop-visible-company.sync="popVisibleCustomer"
        @buyCanDtime="getBuyCanDtime"
        @close="popVisibleCustomer = false"
      />

        <!-- @settingCustomer="value => {
            data.customerManagementNumber = value;
          }
          "
        @settingSpusCustomer="value => {
            data.spusCsmrMgmtNo = value;
          }
          " -->

      <!-- 업체조회 팝업 (진행상태 완료일때만 조회 가능) -->
      <company-search-popup
        ref="companyPop"
        :pop-visible-company.sync="popVisibleCompany"
        @selectCompany="settingCompany"
        @close="popVisibleCompany = false"
      />
      <!-- //업체조회 팝업 -->
    </div>
   
      <!-- 임직원 저장 시 안내문구 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="employeeAuthCompleteFlag"
      >
        <!-- [#9412/2021.10.27/A936506] 저장 시 주의 문구 추가 건 -->
        <!-- Message -->
        직원인증을 승인하시겠습니까?<br>
        소속, 사번을 다시 확인해주세요. 불일치 시 혜택정보 조회가 안될 수 있습니다.
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="info"
            @click="employeeAuthCompleteFlag = false"
          >
            아니요
          </el-button>
          <el-button
            type="primary"
            @click="save"
            @click.native="employeeAuthCompleteFlag = false"
          >
            예
          </el-button>
        </template>
      </el-dialog>
    <!-- //임직원 저장 시 안내문구 팝업 -->

    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      :pop-align.sync="alertAlignStyle"
      @click.native="popResetAndCheck"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import PaperReviewInfo from '~/components/tab/contract/EmployeePaperReviewInfo.vue'
import CompanySearchPopup from '~/components/popup/CompanySearchPopup.vue'
import CustomerSearchPopup from '~/components/popup/CustomerSearchPopup.vue'

import { mapState,mapGetters } from 'vuex'
import moment from 'moment'
import PopMessage from '~/components/popup/PopMessage.vue'

export default {
  layout: 'default',
  components: {
    PopMessage,
    PaperReviewInfo,
    CompanySearchPopup,
    CustomerSearchPopup
  },

  data() {
    return {
      isAuth: process.env.VUE_APP_AUTH === 'true', // 권한 패스용
      fileList: [],
      uploadDocumentIndex: 0, // 파일 업로드한 문서 index
      noticeForm: {
        index: '',
        noticeTitle: '',
        noticeContents: '',
        noticeStartDt: moment(),
        noticeEndtDt: moment(),
        noticeYn: 'Y',
        noticeGradeCode: 'B', // 일반
        noticeGrade: '',
        userId: '',
        userName: '',
        regDate: '',
        fileGroupSerialNumber: null,
        note: '* 첨부파일은 10MB를 초과할 수 없습니다.' 
      },
      popVisibleCompany: false,   // 업체조회
      popVisibleCustomer: false,  // 회원조회
      alertMessage: '',
      alertMessagePop: false,
      alertAlignStyle: '',        // alert 정렬 스타일
      moveCheck: false,
      activeFlag : false,
      employeeAuthCompleteFlag: false,
      activeName: 'first',
      alertNoData: false,
      popVisibleSMS: false,
      popVisibleRequestPaper: false,
      ruleFormpopup: {
        title: '',
        text: ''
      },
      birthDate: '', // 생년월일 구하기 위한 변수
      // 첫 호출 시 데이터 보여줘야하는 항목 초기화
      data: {
        customerManagementNumber : '',
        spusCsmrMgmtNo: '',
        wExsfNm : '',
        emlAdr : '',
        xprDt : '9999-12-31',
        hpTn: '',
        firmNm: ''
      },
      buyCanDtime: '',
      paperReviewData: [], // 서류심사 목록 (팝업)
      documentList: [],
      authHistoryList: [],  // 직원 인증 이력
      // addPaperPopDocumentList: [], // 추가서류 팝업 문서 목록
      settingDocumentList: [],  // 임직원 서류 심사 목록
      /* 추가서류 요청 내용 */
      // checkedDocList: [], // 서류목록 체크 여부
      // requestDocList: [], // 요청서류목록
      // selNeceDocInfo: { // 선택한 서류대상 정보
      //   neceDocTargNo: '', // 필요서류대상번호
      //   neceDocTargNm: '' // 필요서류대상명
      // },
      // selRequestDoc: [], // 선택한 요청 서류목록
      // needPapersSubject: '', // 추가요청내용
      /* 추가서류 요청 내용  END */
      reviewFilter: { neceDocTargNo: 'all', neceDocNo: 'all', workProcessDetailResultCode: 'all'},
      contractNumber: null,
      contractData: {},
      firmCd: '',
      subjectConditionList: [],
      carInfoData: {},
      choiceOptionNames: '',
      tuixOptionNames: '',
      payInfoData: {},
      payAmountList: [],
      payDetail: {},
      releaseInfoData: {},
      releaseCenterData: {},
      releaseTakeoverData: {},
      releaseConsignData: {},
      releaseRegistAgencyData: {},
      statusTabData: { sale: [], sales: [], payment:[], consultant:[], papers:[], electron: [], point: [], apiLog : []},
      messageTabData:[],
      employeeAuthInfo: {
        csmrTypeCd : '',    /* 고객유형코드 */
        csmrLossCd : ''     /* 고객손실코드 */
      },
      employeeDcVal: '', // Dc 할인율 정보
      paperTypes: [{ neceDocNo: 'all', neceDocNm: '전체' }],
      neceDocCategoryList: null, // 필수 서류 카테고리(구분) === 서류심사 목록 ===
      neceDocSubCategoryList: {}, // 필수 서류 카테고리(소분류) === 서류심사 목록 ===
      neceDocSubCategoryReview: [{ neceDocNo: 'all', neceDocNm: '전체' }], // 필수 서류 카테고리(소분류) === 서류심사 이력 ===
      workAssignNumber: null, // 업무 일련 번호
      wExsfCtfnOft: null,   // 임직원 인증 회차 수 번호
      addKeyIdx: 0,
      fileData: {},
      commonCodes: {},
      // conditionMsgType : [
      //   {
      //     type: 'AH1'
      //   }, 
      //   {
      //     type: 'AD1'
      //   },
      //   {
      //     type: 'AD2'
      //   },
      //   {
      //     type: 'AZ2'
      //   }
      // ],
      conditionMsgType : ['AH1', 'AD1', 'AD2', 'AZ2'],
      contractorNames: []  // 선택한 계약자명
    }
  },
  computed: {
    ...mapState(['documentTargets']),
    ...mapGetters(['userInfo'])
  },
  watch: {
    reviewFilter: {
      handler(obj) {
        this.changeFilter(obj)
      },
      deep: true
    }
  },
  mounted() {
    this.$store.dispatch('loadDocumentTargets', {vm: this})

    this.data.pgsStCd = '03'
    this.data.managerId = this.userInfo.eeno

    this.getData()
  },
  async created() {
    await this.loadCommonCode()
  },
  methods: {
    onCancle() {
      this.$router.go(-1)
    },
    // 파일업로드
    async handleChange(file) {
      if (file) {
        const allowedTypes = [
          'image/jpg', 'image/jpeg', 'image/gif', 'application/pdf'
        ] // 허용 가능한 파일

        // 파일 크기 체크 (3MB)
        const size = 10485760
        if (file.size > size) {
          this.alertMessagePop = true
          this.alertMessage = '파일당 10MB 를 넘지 않아야 합니다'
          return
        }

        let formData = new FormData()
        if (allowedTypes.includes(file.raw.type)) {
          formData.append('file', file.raw)
          formData.append('fileBizTypeCode', '015')
          formData.append('privateYn', 'Y')
          formData.append('customerNumber', this.userInfo.eeno)

          const [res, err] = await this.$https.post(
            '/common/v2/common/file/upload/files',
            formData,
            null,
            'gateway'
          ) // API-WE-공통서비스-004_파일 업로드

          if (!err) {
            let idx = Number(this.uploadDocumentIndex) - 1
            // upload된 file Group sn 문서 목록에 setting
            this.documentList[idx].fileGroupSerialNumber = res.data.fileGroupSn || ''
            this.documentList[idx].attcFilNm = file.name
          }
          // 대행등록 시
          // 처리결과+진행사항메모 입력은 필수.
          // 요청/등록/처리일시 모두 동일하게 처리.
        } else {
          this.$refs.upload.clearFiles() // 파일 초기화
          this.alertMessage = '허용되지 않는 확장자입니다.'
          this.alertMessagePop = true
        }
      }
    },
    async rememberIdex(no){
      this.uploadDocumentIndex = no
    },
    async getData(){
      // 임직원 기본서류를 가져온다
      const [res1, err1] = await this.$https.get('/v2/exclusive/employeeAuth/request/papers', { neceDocTargNo : '10040'})
      if(!err1) {
        // console.log('request/papers res : ', JSON.stringify(res1.data)) 
        // 초기 기억용
        this.settingDocumentList = res1.data.map((el, idx) => {
          return {
            ...el,
            no : idx+1,
            additionPapersYn: 'N',        // 추가서류여부
            copyWorkProcessDetailResultCode: el.workProcessDetailResultCode,
            workProcessDetailResultCode: '50', 
            attcScnCd: '01',              // 첫 서류는 기본서류 고정
            isEdit: false
          }
        })    
        
        this.documentList = this.settingDocumentList
      } else {
        console.log('request/papers err : ', err1) 
      }

      // 소속 정보 조회
      const [res2, err2] = await this.$https.get('/v2/exclusive/employeeAuth/subjectCondition')
      
      if(!err2) {
        this.subjectConditionList = res2.data.map((el, idx) => {
          el.no = idx+1
          return el
        })
      } else {
        console.error(err2)
      }

    } , 
    // 구매가능일 조회 및 고객정보 setting
    async getBuyCanDtime(memberInfo, customerType) {
      if(customerType) {
        // 배우자
        this.data.spusCsmrMgmtNo = memberInfo.memberMngNumber
      } else {
        // 임직원
        this.data.customerManagementNumber = memberInfo.memberMngNumber
        this.data.wExsfNm = memberInfo.customerName
        this.data.tymd = moment(memberInfo.birthDate).format('YYYYMMDD')
        this.data.birthDay = moment(memberInfo.birthDate).format('YYMMDD')
        this.birthDate = memberInfo.birthDate
        this.data.emlAdr = memberInfo.emailAddress
        this.data.hpTn = memberInfo.mobile 
      }

      // 구매가능일을 조회하기 위한 고객관리번호에 해당하는 모든 계약정보 조회
      //const [res, err] = await this.$https.post('/customer-info/v2/customer-info/hdot/contractInfo', {csmrMgmtNo : memberInfo.memberMngNumber}, null, 'gateway')
      const [res, err] = await this.$https.post('/customer-info/v2/customer-info/hdot/contractInfo', {csmrMgmtNo : memberInfo.memberMngNumber}, null, 'gateway')
      if(!err && res.data) {

        let contractInfo = res.data.contractInfo

        //1. 임직원 할인이 적용된 것 중 가장 큰 최신날짜값
        let filterList = contractInfo.filter((item) =>  {
          return item.eeDcYn === 'Y' 
        })

        if(filterList && filterList.length > 0) {
          let result = filterList.reduce(function (a, b) { return a.whotDt > b.whotDt ? a : b })

          let buyDateVal = moment(result.whotDt)

          buyDateVal = new Date(buyDateVal)
          buyDateVal.setFullYear(buyDateVal.getFullYear() + 2)

          this.buyCanDtime = moment(buyDateVal).format('YYYY-MM-DD')
        }
      }
      
      // 해당 임직원의 직원 인증 이력 조회
      if(!err && !customerType && this.data.customerManagementNumber) { // 배우자의 경우 이력 조회 x
        // 인증 이력
        const [res2,err2] = await this.$https.post('/v2/exclusive/employeeAuth/history/auth', { customerManagementNumber : this.data.customerManagementNumber })

        if(!err2 && res2.data) {
          this.authHistoryList = res2.data
        }

      }

      // 할인율 setting
      this.dcRateSetting()
    },
    openCustomerPopup(type) {
      this.$refs.customerPop.customerPopOpen(type)
    },
    openCompanyPopup() {
      this.popVisibleCompany = true
      this.$refs.companyPop.companyPopOpen()
    },
    settingCompany(companyData) {
      this.data.firmNm = companyData.afcoNm
      this.data.firmCd = companyData.afcoCd
      this.data.aplScnCd = companyData.afcoSncCd

    },
    conditonSetting(target){
      this.data.csmrLossCd = target.csmrLossCd
      this.data.csmrTypeCd = target.csmrTypeCd
      this.data.coCd = target.csmrTypeCd/* 회사(소속) code setting */
      /* [#9840/2021.12.17/A936506] 재구매 제한여부 컬럼 추가.
      'N'인 경우 구매가능일은 직원인증 완료(승인)일자로 산정. */
      let rePurchaseRestrictYn = target.rePurchaseRestrictYn  

      if(rePurchaseRestrictYn === 'N') {
        this.buyCanDtime = moment().format('YYYY-MM-DD')
      } else {
        this.buyCanDtime = ''
      }

      // 조견표에 업체코드가 있는 경우 해당 데이터는 국판에 넘기지 않는다
      if(target.firmCd) {
        this.data.firmCd = target.firmCd
        this.data.dsDataTargetYn = 'N'
      } else {
        this.data.firmCd = ''
        this.data.dsDataTargetYn = 'Y'
      }

      console.log('this.data ', target.firmCd, ' / dsDataTargetYn :', this.data.dsDataTargetYn)

      // 추가된 문서 초기화
      this.documentList = this.documentList.filter((items) => {
        return !items.isAdd || items.isAdd === undefined
      })

      // 팝업 Messeag 안내문구가 나가야하는 유형
      for(var type of this.conditionMsgType) {
        if(this.data.coCd === type) {
          this.alertMessage = '해당 직원은 계약 시 『일반개인』으로 진행 후, 차량대금 『결제당일』 직원 인증 요청하여 할인 적용이 필요한 대상입니다.\r\n→사유 : 국판시스템內 직원 등록 시 당일만 적용이 유효한 직원으로 결제당일 인증 진행 필요\r\n\r\n※ 판매대리점 인원의 경우 - 소속이동에 따른 기간인정 및 실적반영 미대상은 해당 없음'
          this.alertMessagePop = true 
          this.alertAlignStyle = 't-left'
        }
      }
      // 기본서류 + 추가서류 둘다 조회
      // 소속에 따른 추가 서류 setting method
      this.settingAddConditionDocumnet(target)
    },
    async settingAddConditionDocumnet(target) {
      let bascPpSubjNo = target.bascPpSubjNo // 기본서류 대상번호
      let addPpSubjNo = target.addPpSubjNo   // 추가서류 대상번호

      let addDocList = []
      this.paperReviewData = []

      addDocList.push(
        {
          neceDocTargNo :bascPpSubjNo, 
          attcScnCd : '01',
          additionPapersYn: 'N'
        }
      )
      if(addPpSubjNo) { 
        addDocList.push(
          {
            neceDocTargNo :addPpSubjNo, 
            attcScnCd : '02',
            additionPapersYn: 'Y'
          }
        )
      }

      // 실제로 추가될 서류 목록
      let addDocListTarget = []

      for(var doc of addDocList) {
        const [res1, err1] = await this.$https.get('/v2/exclusive/employeeAuth/request/papers', { neceDocTargNo : doc.neceDocTargNo})
        if(!err1) {        
          // 중복 표시
          res1.data.filter((el) => {
            this.documentList.map((doc) => {
              if(el.neceDocNo === doc.neceDocNo && el.neceDocTargNo === doc.neceDocTargNo) {
                el.dupleKey = true
              }
            })
          })

          // 중복 제거
          if(addDocListTarget.length > 0) {
            addDocListTarget.push(
              res1.data.filter((items) => {
                return !items.dupleKey
              })
            )
          } else {
            addDocListTarget = res1.data.filter((items) => {
              return !items.dupleKey
            })
          }
                  
          // this.$refs.paperInfo.addReviewPaperRow(this.paperReviewData)
          this.paperReviewData = [] // 초기화
                  
        } else {
          console.log('request/papers err : ', err1) 
        }

      }

      addDocListTarget.forEach((items, idx) => {
        var noIdx = this.documentList.length + 1
        this.documentList.push({
          ...items,
          scrapingResult: items.scrapingResult ? items.scrapingResult : 'N',
          // papersSectionalName: items.neceDocTargNm,
          // papersTypeName: items.neceDocNm,
          isAdd: true,
          no: noIdx,
          fileGroupSerialNumber: '',
          attcFilNm: '',
          addRowKey: idx++,
          workProcessDetailResultCode: '50', 
          attcScnCd: doc.attcScnCd,
          additionPapersYn: doc.additionPapersYn
        })
      })

      // 할인율 setting
      this.dcRateSetting()
    },
    async dcRateSetting(){
      // 할인율 setting
      const [resA, errA] = await this.$https.post('/customer-info/v2/customer-info/hds/employeeDcRate', {csmrMgmtNo : this.data.customerManagementNumber}, null, 'gateway')
         
      if(!errA) {
        if(resA.data) {
          this.data.dcRate = ((resA.data.dcRate && resA.data.dcRate > 0) ? resA.data.dcRate : '0')
        }
      } else {
        console.error('employeeDcRate Error {} ', errA)
      }
    },
    // async settingAddConditionDocumnet(target) {
    //   let bascPpSubjNo = target.bascPpSubjNo // 기본서류 대상번호
    //   let addPpSubjNo = target.addPpSubjNo   // 추가서류 대상번호

    //   let addDocList = []
    //   this.paperReviewData = []

    //   addDocList.push(
    //     {
    //       neceDocTargNo :bascPpSubjNo, 
    //       attcScnCd : '01',
    //       additionPapersYn: 'N'
    //     }
    //   )
    //   if(addPpSubjNo) { 
    //     addDocList.push(
    //       {
    //         neceDocTargNo :addPpSubjNo, 
    //         attcScnCd : '02',
    //         additionPapersYn: 'N'
    //       }
    //     )
    //   }

    //   for(var doc of addDocList) {
    //     const [res1, err1] = await this.$https.get('/v2/exclusive/employeeAuth/request/papers', { neceDocTargNo : doc.neceDocTargNo})
    //     if(!err1) {
    //       // console.log('request/papers res : ', JSON.stringify(res1.data)) 
    //       this.paperReviewData = res1.data.map((el, idx) => {
    //         return {
    //           ...el,
    //           scrapingResult: el.scrapingResult ? el.scrapingResult : 'N',
    //           papersSectionalName: el.neceDocTargNm,
    //           papersTypeName: el.neceDocNm,
    //           isAdd: true,
    //           isEdit:true,
    //           addRowKey: idx++,
    //           workProcessDetailResultCode: '10',  // 추가서류(대기)
    //           attcScnCd: doc.attcScnCd,
    //           additionPapersYn: doc.additionPapersYn
    //         }
    //       })

    //       // 중복제거하는 부분 (같이하기)
    //       /*
          
    //             // 이미 있는 Document는 x, 없는 것만 추가
    //   paperData.filter((el) => {
    //     this.paperReviewData.map((doc) => {
    //       if(el.neceDocNo === doc.neceDocNo && el.neceDocTargNo === doc.neceDocTargNo) {
    //         el.dupleKey = true
    //       }
    //     })
    //   })
      
    //   if(paperData && paperData.length > 0) {
    //     paperData.map((items) => {
    //       if(!items.dupleKey) {
    //         this.paperReviewData.push({
    //           ...items,
    //           no: this.paperReviewData.length + 1
    //           // 서류요청일시/상태변경일시/상태는 넣을때 setting
    //         })
    //         //             this.paperReviewData.push({
    //         //   no: this.paperReviewData.length + 1,
    //         //   neceDocNo: items.neceDocNo,
    //         //   neceDocTargNo: items.neceDocTargNo,
    //         //   papersSectionalName: items.neceDocTargNm,
    //         //   papersTypeName: items.neceDocNm,
    //         //   scrapingTargetYn: items.scrapingTargetYn,
    //         //   scrapingResult: items.scrapingResult,
    //         //   additionPapersYn: items.attcScnCd === 10 ? 'N' : 'Y'
    //         //   // 서류요청일시/상태변경일시는 넣을때 setting
    //         // })
    //       }
    //     })
    //   }
          
    //       */
        
    //       this.$refs.paperInfo.addReviewPaperRow(this.paperReviewData)
    //       this.paperReviewData = [] // 초기화
                  
    //     } else {
    //       console.log('request/papers err : ', err1) 
    //     }

    //   }

    // },
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null
      switch(systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {vm: this, codeTypeCode: codeType})
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {vm: this, codeTypeCode: codeType})
        break
      }
      return res
    },
    async loadCommonCode() {
      const [ccT002, ccZ081] = await Promise.all([
        this.fetchCommonCodeData('E', 'T002'), // 상태
        this.fetchCommonCodeData('E', 'Z081') // 업무 진행상태
      ])

      this.commonCodes = { ...ccT002, ...ccZ081 }
    },
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    /* 유저 버튼 권한 체크 */
    isValidUserAuthBtn() {
      var authGroupIds = this.userInfo.exclusiveUseAuthGroupIds

      // 관리자인 경우
      for(var id of authGroupIds){
        if(['WT002', 'WT004'].includes(id)) {
          return true
        } else {
          continue
        }
      }

      return false
    },
    changeFilter(obj) {
      const { neceDocTargNo, neceDocNo, workProcessDetailResultCode } = obj
      if(neceDocTargNo === 'all' && neceDocNo === 'all' && workProcessDetailResultCode === 'all') {
        this.documentList = this.settingDocumentList
      } else {
        this.documentList = this.settingDocumentList.filter((items) => {
          return (neceDocTargNo !== 'all' ? items.neceDocTargNo === neceDocTargNo : true) &&
                 (neceDocNo !== 'all' ? items.neceDocNo === neceDocNo : true) &&
                 (workProcessDetailResultCode !== 'all' ? items.workProcessDetailResultCode === workProcessDetailResultCode : true)
        })
      }
    },
    isValidStatusCode(originStatusCode = '', targetCode = '') {
      if(originStatusCode === '30' && ['10', '20'].includes(targetCode)) {
        return true
      } else if(originStatusCode === '20' && targetCode === '10') {
        return true
      }
      return false
    },
    async getFileData(row) {
      const { fileGroupSerialNumber: fileGroupSn = ''} = row
      const [res, err] = await this.$https.get('/common/v2/common/file/inquiry/' + fileGroupSn , null, null, 'gateway')

      if(!err) {
        // [#9081/2021.10.12/A936506] 다운로드 방식 변경건 적용 (올린 직후 파일다운로드 가능)
        this.fileData = res.data[0]
        this.downloadLink()
      }
    },
    async downloadLink() {
      const { fileSn, fileGroupSn, fileName, fileExtentions } = this.fileData
      const [res, err] = await this.$https.getb('/common/v2/common/file/download/'+ fileGroupSn  + '/' + fileSn, null, null, 'gateway')

      if(!err) {
        const blob = new Blob([res], {type : fileExtentions })
        if(window.navigator.msSaveOrOpenBlob) {
          // IE11
          window.navigator.msSaveOrOpenBlob(blob, fileName)
        } else {
          // IE11 외 브라우저
          const blobURL = window.URL.createObjectURL(blob)
          const tempLink = document.createElement('a')

          tempLink.href = blobURL

          tempLink.setAttribute('download', fileName)
          document.body.appendChild(tempLink)
          tempLink.click()
          document.body.removeChild(tempLink)
          window.URL.revokeObjectURL(blobURL)
        }
      }
    },
    // addDocumentRow() {
    //   this.documentList.push({isAdd: true, addRowKey: ''+this.addKeyIdx++, workProcessDetailResultCode: '10', neceDocNo: '', file: 'add', fileData: '' })
    // },
    setPaperReviewData(reviewData) {
      // paperReviewData
      this.paperReviewData = reviewData
      
    },
    saveCheck() {
      /* [#9412/2021.10.27/A936506] 소속 및 사번 등 공백 방지 및 오류 주의문구 추가를 위해 처리화면과 동일하게 메시지 팝업 삽입 */
      this.employeeAuthCompleteFlag = true
    },
    async save() {

      // 필수사항 Validation
      if(!this.data.customerManagementNumber) {
        this.alertMessage = '고객관리번호는 필수 입력사항 입니다.'
        this.alertMessagePop = true
        return
      }

      if(!this.data.xprDt) {
        this.alertMessage = '인증 만료일은 필수 입력사항 입니다.'
        this.alertMessagePop = true
        return
      }

      // 소속 , 업체 , 사번
      if(!this.data.coCd) {
        this.alertMessage = '해당 임직원의 소속을 선택해주세요.'
        this.alertMessagePop = true
        return
      }

      if(!this.data.firmCd) {
        this.alertMessage = '업체를 선택해주세요.'
        this.alertMessagePop = true
        return
      }

      if(!this.data.wExsfNo) {
        this.alertMessage = '사번은 필수 입력사항 입니다.'
        this.alertMessagePop = true
        return
      }

      /* 서류 심사 목록에서 전담이 등록해준 파일이 있는 경우 처리결과/진행사항 메모는 필수입력사항 */
      var result = true
      
      this.documentList.map((items) => {

        if(!items.neceDocTargNo || !items.neceDocNo) {
          this.alertMessage = '서류의 구분과 소분류 항목을 확인해주세요.'
          this.alertMessagePop = true
          result = false
        }

        if(!items.fileGroupSerialNumber) {
          this.alertMessage = '파일을 등록해주세요.'
          this.alertMessagePop = true
          result = false
        }

        //  처리결과/진행사항 메모는 필수입력사항 
        if(!items.workProcessDetailResultCode) {
          this.alertMessage = '처리결과를 선택해주세요.'
          this.alertMessagePop = true
          result = false
        } 
        
        if(!items.ppExamSbc) {
          this.alertMessage = '진행 상황 메모를 입력해주세요.'
          this.alertMessagePop = true
          result = false
        }

      })

      if(!result) { return false }
      else {
      
        this.documentList.map((items) => {
          items.customerManagementNumber = this.data.customerManagementNumber
          items.contractNumber = this.data.contractNumber
          items.managerId = this.data.managerId
        })

        const documentList = this.documentList
    
        const data = {
          ...this.data,
          documentList, // 서류심사목록
          xprDt: moment(this.data.xprDt).format('YYYYMMDD')
        }
      
        // const [res,err] = await this.$https.post('/v2/exclusive/employeeAuth', data) // API-WX-0 (임직원 인증 정보 저장)
        const [res, err] = await this.$https.post('/v2/exclusive/employeeAuth', data) // API-WX-0?? (임직원 인증 정보 저장)
    
        if(!err && res) {
          this.alertMessage = '저장되었습니다.'
          this.alertMessagePop = true
          this.movecheck = true
        } else {
          this.alertMessage = err.rspMessage ? err.rspMessage : '직원인증 정보 저장에 실패했습니다.'
          this.alertMessagePop = true
        }
      }
    },
    popResetAndCheck() {
      // style 초기화
      this.alertAlignStyle = ''

      if(this.movecheck) {
        // 페이지 이동
        const win = this.$router.push('/wp/employee-auth/reception')
        win.focus()
      }
    },
    async changeDocCtgList(e, rowData) { // 서류 심사 목록 - 구분 컬럼 변경시 이벤트
      this.documentList.some((items) => {
        if(items.addRowKey === ''+rowData.addRowKey) {
          items.neceDocNo = null
          return true
        }
      })

      if(e && e !== 'all') { // 구분 select value중에서 전체가 아닐 경우에만
        const [res, err] = await this.$https.get('/v2/exclusive/contract/papers?neceDocTargNo='+ e) //API-E-업무담당자-047 (필요서류목록 조회)
        if(!err) {
          // res.data.unshift({'neceDocNo': 'all', 'neceDocNm': '전체' })
          let obj = {}
          obj[rowData.addRowKey] = res.data
          this.neceDocSubCategoryList = { ...this.neceDocSubCategoryList, ...obj }
        } else {
          console.error(err)
        }
      }
    },
    // eslint-disable-next-line no-unused-vars
    changeDocSubCtgList(e, row) { // 서류 심사 목록 - 소분류 컬럼 변경시 이벤트
      row.isEdit = true
    },
    // eslint-disable-next-line no-unused-vars
    changeDocStatus(e, row) { // 서류 심사 목록 - 상태
      row.isEdit = true
    },
    // eslint-disable-next-line no-unused-vars
    changeDocContent(e, row) { // 서류 심사 목록 - 처리내용
      row.isEdit = true
    },
    // 임직원 서류 조회로 변경 필요
    async changeCategory(e) {
      this.reviewFilter.neceDocNo = 'all'
      if(e && e !== 'all') { // 구분 select value중에서 전체가 아닐 경우에만
        const [res, err] = await this.$https.get('/v2/exclusive/contract/papers?neceDocTargNo='+ e) //API-E-업무담당자-047 (필요서류목록 조회)

        if(!err) {
          res.data.unshift({'neceDocNo': 'all', 'neceDocNm': '전체' })
          this.neceDocSubCategoryReview = res.data
        } else {
          console.error(err)
        }
      }
    },
    changeSubCategory(e) {
      console.log(e)
    },
    tableRowClassName({row}) {
      if (row.background === 'red') {
        return 'warning-row'
      }
      else if (row.border === 'red') {
        return 'warning-row1'
      }
      return ''
    },

    // 서류심사 행추가로 생성된 행 삭제
    deleteDocumentRow(key) {
      const idx = this.documentList.findIndex(item => item.addRowKey === key)
      if (idx > -1) this.documentList.splice(idx, 1) // 일치하는 row 삭제
    },
    async documentTargetChanged(val, row) {
      const [res,err] = await this.$https.get('/v2/exclusive/contract/papers', { neceDocTargNo: val }) //API-E-업무담당자-047 (필요서류목록 조회)
      if (!err) {
        console.log(row)
        this.paperTypes = [{'neceDocNo': 'all', 'neceDocNm': '전체'}, ...res.data]
      }
    },
    initRuleFormPop() { // 초기화 버튼
      Object.assign(this.$data.ruleFormpopup, this.$options.data().ruleFormpopup)
    },
    oneClickDisable(event, clickEvent, ...args) {
      if(event.target.disabled === true){
        retrun
      }

      event.target.disabled = true

      try {
        clickEvent(...args)
      } catch {}
      setTimeout(() => {
        event.target.disabled = false
      }, 2000)
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
.btn-md{
  min-width: 40px;
  height: 40px;
}
.append-box {
  .el-input, .el-select {
    margin:2px 0;
  }
}
</style>

