<template>
  <section>
    <div id="staff">

      <div class="article-title">
        <el-button type="primary">초기화</el-button>
        <div>
          <el-button
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            @click="onSearch(1)"
            >
            조회
            </el-button>
            <el-button
              v-if="isValidAuthBtn('authSelect')"
              type="primary"
              @click="oneClickDisable($event, moveEmployeeAuthInsertPage)"
              >
                등록
            </el-button>
        </div>
      </div>

      <div class="box">
        <el-form ref="info" :model="ruleForm" class="detail-form table-wrap">
        <el-row>
          <el-col :span="24">
            <el-form-item
              label="신청일"
              required
            >
              <el-date-picker
                v-model="ruleForm.searchFromDt"
                type="date"
                :clearable="false"
              />
              <span class="ex-txt">~</span>
              <el-date-picker
                v-model="ruleForm.searchEndDt"
                type="date"
                :clearable="false"
              />
              <el-radio-group
                v-model="searchDtRadio"
                class="tabBtn-case01"
                @change="onChangeSearchDtRadio"
              >
                <el-radio-button label="lastDay">
                  전일
                </el-radio-button>
                <el-radio-button label="today">
                  오늘
                </el-radio-button>
                <el-radio-button label="day7">
                  7일
                </el-radio-button>
                <el-radio-button label="day30">
                  30일
                </el-radio-button>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="이름">
                <el-input
                  v-model="ruleForm.wExsfNm"
                  @input="ruleForm.wExsfNm=$event.target.value"
                  @keyup.native.enter="onSearch(1)"
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="생년월일">
                <el-date-picker v-model="ruleForm.tymd" type="date" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="고객관리번호">
                <el-input
                  v-model="ruleForm.customerManagementNumber"
                  @input="ruleForm.customerManagementNumber=$event.target.value"
                  @keyup.native.enter="onSearch(1)"
                />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="업무번호">
                <el-input
                  v-model="ruleForm.workAssignNumber"
                  @input="ruleForm.workAssignNumber=$event.target.value"
                  @keyup.native.enter="onSearch(1)"
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="진행상태">
                <el-select
                  v-model="ruleForm.workStatus"
                  multiple collapse-tags
                  >
                  <el-option
                    v-for="item in employeeProgressCodes"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>
                <el-checkbox
                  class="space"
                  @change="selectedAll($event,'employeeStatus')"
                  >
                  전체
                </el-checkbox>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="업무처리자">
                <el-select
                  v-model="ruleForm.managerId"
                  placeholder="전체"
                >
                  <el-option
                    v-for="{ sysUserNo, sysUserNm } in authConsultants"
                    :key="sysUserNo"
                    :value="sysUserNo"
                    :label="sysUserNm"
                  />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="집계데이터 조회">
                <ul class="data-list">
                  <li><strong class="tit">전체</strong><span class="val"><strong>{{ countData.totalCount || 0 }}</strong>건</span></li>
                  <li><strong class="tit">대기</strong><span class="val"><strong>{{ countData.received || 0 }}</strong>건</span></li>
                  <li><strong class="tit">처리중</strong><span class="val"><strong>{{ countData.proceeding || 0 }}</strong>건</span></li>
                  <li><strong class="tit">완료</strong><span class="val"><strong>{{ countData.closed || 0 }}</strong>건</span></li>
                  <li><strong class="tit">실패</strong><span class="val"><strong>{{ countData.failed || 0 }}</strong>건</span></li>
                </ul>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
            </div>

      <div class="article-title gap">
        <div>
          <el-checkbox
            v-model="checked"
            label="전체선택"
            @change="toggleSelectionAll"
          />
          <el-button
            v-if="isValidAuthBtn('authManage')"
            type="primary"
            @click="oneClickDisable($event, openConsultantPopup)"
          >
            처리자 변경
          </el-button>
        </div>
      </div>
      <div class="box">
        <el-table
          ref="multipleTable"
          :data="tableData"
          max-height="450"
          empty-text="조회된 조회결과가 없습니다."
          :row-class-name="tableRowClassName"
          @sort-change="sortChange"
      >
        <el-table-column
          label="선택"
          prop="isSelected"
          align="center"
          width="50"
        >
          <template slot-scope="scope">
            <el-checkbox
              v-model="scope.row.isSelected"
              @change="onChange($event, scope.row)"
              @click.native.stop
            />
          </template>
        </el-table-column>
          <el-table-column prop="no" label="NO." width="90" align="center" />
          <el-table-column prop="workAssignNumber" label="업무번호" width="160" align="center">
            <template slot-scope="props">
              <a
                class="link"
                href="/#/wp/employee-auth/process"
                target="_blank"
                @click="$utils.setLocalStorage({ workAssignNumber: props.row.workAssignNumber, wExsfCtfnOft : props.row.wExsfCtfnOft })"
              >
                {{ props.row.workAssignNumber }}
              </a>
            </template>
          </el-table-column>
          <el-table-column prop="checkDocCnt" label="심사서류" width="100" align="center" />
          <el-table-column prop="progressState" label="진행상태" width="100" align="center" />
          <el-table-column prop="managerName" label="업무처리자" width="140" align="center" />
          <el-table-column prop="customerManagementNumber" label="고객관리번호" width="160" align="center" />
          <el-table-column prop="wExsfNm" label="이름" width="140" align="center" />
          <el-table-column prop="tymd" label="생년월일" width="100" align="center" />
          <el-table-column prop="coCdNm" label="소속" width="200" align="center" show-overflow-tooltip />
          <el-table-column prop="firmNm" label="업체" width="200" align="center" show-overflow-tooltip />
          <el-table-column prop="wExsfNo" label="사번" width="140" align="center" />
          <el-table-column prop="csetDtm" label="승인일시" width="140" align="center" />
          <el-table-column prop="xprDt" label="만료일" width="120" align="center" />
          <el-table-column prop="buyCanDt" label="구매가능일" width="120" align="center" />
        </el-table>
        <!-- page -->
        <div class="btn-wrap">
          <div class="side"></div>
          <div class="pagination">
            <v-pagination
              v-if="tableData.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch"
            />
          </div>
          <div class="main"></div>
        </div>
        <!-- page end -->
      </div> 
     <!-- 초기화 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="alertNoData"
      >
        <!-- Message -->
        조회 결과가 없습니다.

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="primary"
            @click="alertNoData = false"
          >
            확인
          </el-button>
        </template>
      </el-dialog>
      <!-- 업무담당자 변경 팝업 -->
      <el-dialog
        title="업무담당자 변경"
        :visible.sync="consultantPop"
        @open="consutantPopupOpened"
      >
        <!-- Message -->
        <el-form
          :inline="true"
          class="detail-form"
        >
          <el-row>
            <el-col :span="24">
              <el-form-item label="컨시어지">
                <el-select
                  v-model="selConsultant"
                  placeholder="컨시어지 선택"
                >
                  <el-option
                    v-for="{ sysUserNo, sysUserNm } in authConsultants && authConsultants.slice(1)"
                    :key="sysUserNo"
                    :value="sysUserNo"
                    :label="sysUserNm"
                  />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="primary"
            @click="oneClickDisable($event, changeConsultant)"
          >
            변경
          </el-button>
        </template>
      </el-dialog>
      <loading
        :pop-visible.sync="popVisibleLoading"
        @close="popVisibleLoading = false"
      />
    </div>
   <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import { mapState } from 'vuex'
import moment from 'moment'
import Loading from '~/components/popup/Loading.vue'
import PopMessage from '~/components/popup/PopMessage.vue'

export default {
  name: 'Reception',
  layout: 'default',
  components:{
    Loading,
    PopMessage
  },
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      workSelectedVal: false,
      authConsultantselectedVal: false,
      authConsultantIncludYn: false,
      popVisibleLoading: false,
      selConsultant: null,
      multipleSelection: [],
      alertNoData: false,
      consultantPop: false,
      checked: false,
      searchDtRadio: 'today',
      employeeProgressCodes: {},
      ruleForm:{
        searchFromDt: moment(),
        searchEndDt: moment(),
        workType: 'all',
        workStatus: ['01','02'],           // 임직원 업무진행상태 대기, 처리중
        managerId: '',                  // 업무처리자
        wExsfNm: '',                    // 임직원명
        tymd: '',                       // 생년월일
        customerManagementNumber: '',   // 고객관리번호
        workSerialNumber: ''            // 업무번호
      },
      countData: {
        totalCount: 0,
        received: 0,      // 대기(접수)
        proceeding: 0,    // 처리중
        closed: 0,        // 완료
        failed: 0         // 실패
      },
      code: [
        { value: 'all',  label: '전체' }
      ],
      tableData: [],
      commonCodes: {},
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      },
      sortInfo: {
        order: '',
        prop: ''
      },
    }
  },
  computed: {
    ...mapState(['authConsultants', 'userInfo']),
    authConsultants: function() {
      const authConsultants = this.$store.state.authConsultants.slice()
      if(authConsultants && authConsultants.length > 0) {
        authConsultants.unshift( { 'useAuthId': '', 'sysUserNo': '', 'sysUserNm': '전체', 'opsNm': '' } )
      }
      return authConsultants
    }
  },
  mounted() {
    this.$store.dispatch('loadAuthConsultants', {vm: this})

    if(this.authConsultants) {
    
      var includeBoolean = false
      this.ruleForm.managerId = ''

      this.authConsultants.map(items => {
        if(items.sysUserNo === this.ruleForm.managerId) {
          includeBoolean = true
        }
      })
    }
    
    // 전담 컨설턴트에 포함된 경우에만 ..
    if(includeBoolean) this.ruleForm.managerId = this.userInfo.eeno
    else this.ruleForm.managerId = ''

    // this.ruleForm.managerId = this.userInfo.eeno
    //var authGroupIds = this.userInfo.exclusiveUseAuthGroupIds
    
  },
  async created() {
    await this.loadCommonCode()
  },
  methods: {
    moveEmployeeAuthInsertPage(){
      this.$router.push('/wp/employee-auth/process_write')
    },
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null
      switch(systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {vm: this, codeTypeCode: codeType})
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {vm: this, codeTypeCode: codeType})
        break
      }
      return res
    },
    async loadCommonCode() {
      // 필요한거 : 임직원 업무 진행상태 코드
      const [ccZ081] = await Promise.all([
        this.fetchCommonCodeData('E', 'Z081') // 임직원몰 진행상태
      ])

      this.commonCodes = {...ccZ081 }

      this.initRuleFormStatus()
      
      this.employeeProgressCodes = this.commonCodes.Z081.slice(1)
      
      //Z081 중복제거 (지금 밑에걸로 하면 이름만 나와서 :??)
      // this.employeeProgressCodes = this.commonCodes.Z081.slice(1)
      //   .map(el => {
      //     return el.label.replace(/\s/gi, '')
      //   })
      //   .reduce((unique, item) => {
      //     return unique.includes(item) ? unique : [...unique, item]
      //   }, [])

    },
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    onAddZero(contractNumber) {
      let resultString = ''
      if(contractNumber.length > 6) {
        const frontString = contractNumber.substring(0,7)
        const backString = contractNumber.substring(7)

        resultString = resultString.concat(frontString)
        resultString = resultString.concat(backString.length >= 6 ? backString : Array.from({length: 6 - backString.length}, () => 0).join('') + backString)
      }

      if(!resultString) { resultString = contractNumber }
      this.ruleForm.contractId = resultString
    },
    resetSearchCond() {
      Object.assign(this.ruleForm, this.$options.data().ruleForm)
      this.searchDtRadio = 'today'
    },
    onSearch(page) {
      if(!this.isValidAuthBtn('authSelect')) { // 권한없을경우 동작 x
        return
      }

      this.$data.pageInfo.page = page
      this.getData()
    },
    initRuleFormStatus() {
      if(this.ruleForm.workStatus && this.ruleForm.workStatus.length === 0) { // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false, 'employeeStatus')
      }
      if(this.ruleForm.consultantId && this.ruleForm.managerId.length === 0) { // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false,'consultant')
      }
    },
    selectedAll(e,type) {
      if(type==='employeeStatus'){
        if(e) {
          this.ruleForm.workStatus = this.commonCodes.Z081.slice(1).map((items) => {
            return items.value
          }) || []
        } else {
          this.ruleForm.workStatus = []
        }
      }else if(type==='legacy'){
        if(e) {
          this.ruleForm.legacyStatus = this.LegacyCommonCodes.C013.slice(1).map((items) => {
            return items.value
          }) || []
        } else {
          this.ruleForm.legacyStatus = []
        }
      }else if(type==='online') {
        if (e) {
          this.ruleForm.onlineStatus = this.commonCodes.Z081.slice(1).map((items) => {
            return items.value
          }) || []
        } else {
          this.ruleForm.onlineStatus = []
        }
      }else if(type==='consultant'){
        if(e) {
          this.ruleForm.consultantId = this.authConsultants.slice(1).map((items) => {
            return items.sysUserNo
          }) || []
        } else {
          this.ruleForm.consultantId = []
        }
      }else if(type==='employeeStatus'){
        if(e) {
          this.ruleForm.workStatus = this.employeeProgressCodes.slice(1).map((items) => {
            return items.sysUserNo
          }) || []
        } else {
          this.ruleForm.workStatus = []
        }
      }

    },
    onChangeMultiSelect(data, type) {
      if(type === 'work') { //업무 진행상태
        if(data.length === this.commonCodes.U011.slice(1).length) {
          this.workSelectedVal = true
        } else {
          this.workSelectedVal = false
        }
      } else if(type==='consultant') {
        if (data.length === this.authConsultants.slice(1).length) {
          this.authConsultantselectedVal = true
        } else {
          this.authConsultantselectedVal = false
        }
      }
    },
    async getData() {
      if(!this.ruleForm.searchFromDt || !this.ruleForm.searchEndDt) {
        this.alertMessage = '날짜는 필수입력사항입니다.'
        this.alertMessagePop = true
        return false
      }

      if(moment(this.ruleForm.searchFromDt).diff(moment(this.ruleForm.searchEndDt)) > 0) {
        this.alertMessage = '시작일은 종료일보다 클수 없습니다.'
        this.alertMessagePop = true
        return false
      }

      this.initRuleFormStatus()
      const { page: pageNo, size: pageSize } = this.$data.pageInfo

      const params = {
        ...this.ruleForm,
        employeeWorkStatus: this.ruleForm.workStatus!=='all' ? this.ruleForm.workStatus : '',
        searchFromDt: moment(this.ruleForm.searchFromDt).format('YYYYMMDD'),
        searchEndDt: moment(this.ruleForm.searchEndDt).format('YYYYMMDD'),
        tymd: this.ruleForm.tymd ? moment(this.ruleForm.tymd).format('YYYYMMDD') : '',
        pageNo,
        pageSize,
        sortingId: this.sortInfo.prop,
        sortingType: this.sortInfo.order
      }
     
      this.popVisibleLoading = true
      
      // 1. 임직원 인증 업무 목록 조회
      const [res,err] = await this.$https.post('/v2/exclusive/employeeAuth-list', params)

      if(!err) {
        if(!res.data || res.data.length===0) {
          this.tableData = []
        } else {
          this.tableData = res.data.list.map((el, idx) => {
            return {
              ...el,
              no : idx+1,
              isSelected: false,
              payExpireDate: el.payExpireDate ? moment(el.payExpireDate).format('YYYY-MM-DD') : '',
              progressExpireDate: el.progressExpireDate ? moment(el.progressExpireDate).format('YYYY-MM-DD') : '',
              bold: el.noticeConfirmYn !== 'Y' ? 'bold' : ''
            }
          })
        }

        this.$data.pageInfo = {
          ...this.$data.pageInfo,
          total: res.data.total
        }
        this.popVisibleLoading = false
      } else {
        console.error(err)
        this.tableData = []
        this.popVisibleLoading = false
      }

      // 2. 집계 데이터 조회
      const [res2,err2] = await this.$https.post('/v2/exclusive/employeeAuth-count', params)

      if(!err2) {
        if(!res2.data) {
          Object.assign(this.$data.countData, this.$options.data().countData)
          return
        }
        this.countData = res2.data
      } else {
        console.error(err2)
      }
    },
    onChangeSearchDtRadio(val) {
      if(val==='lastDay') {
        this.ruleForm.searchFromDt = moment().subtract('days', 1)
        this.ruleForm.searchEndDt = moment().subtract('days', 1)
      } else if(val==='today') {
        this.ruleForm.searchFromDt = moment()
        this.ruleForm.searchEndDt = moment()
      } else if(val==='day7') {
        this.ruleForm.searchFromDt = moment().subtract('days', 7)
        this.ruleForm.searchEndDt = moment()
      } else if(val==='day30') {
        this.ruleForm.searchFromDt = moment().subtract('days', 30)
        this.ruleForm.searchEndDt = moment()
      }
    },
    openConsultantPopup() {
      this.multipleSelection = this.tableData.filter((items) => {
        return items.isSelected === true
      })

      if(this.multipleSelection.length===0) {
        this.alertMessage = '업무를 먼저 선택해주세요.'
        this.alertMessagePop = true
      } else {
        this.consultantPop = true
      }
    },
    consutantPopupOpened() {
      //컨설턴트 명단 store load
      this.$store.dispatch('loadAuthConsultants', {vm: this})
    },
    async changeConsultant() {
      if(!this.selConsultant) {
        /* ETC_A_029 */
        this.alertMessage = '처리자 변경이 필요한 업무를 선택해주세요.'
        this.alertMessagePop = true
      } else {
        const workAssignNumberList = this.multipleSelection.map(el => el.workAssignNumber).join(',')

        const [res, err] = await this.$https.post(`v2/exclusive/common/disposer?workEmployeeNumber=${this.selConsultant}&workAssignNumberList=${workAssignNumberList}`) //workEmployeeNumber : 컨설턴트 ID, workAssignNumberList[] : 업무 ID 목록(comma-separated)
        if(!err && res) {
          this.alertMessage = '처리자가 변경되었습니다.'
          this.alertMessagePop = true
          this.selConsultant = null
          this.consultantPop = false
          this.getData()
        } else {
          console.error(err)
        }
      }

    },
    onChange(val, row) {
      this.tableData.filter((items) => { return items.no !== row.no }).map((items) => { items.isSelected = false })
    },
    toggleSelectionAll() {
      if(this.checked) {
        this.tableData.map((items) => { items.isSelected = true })
      }
      else {
        this.tableData.map((items) => { items.isSelected = false })
      }
    },
    tableRowClassName({row}) {
      if(row.bold === 'bold') {
        return 'bold'
      }
    },
    sortChange(props) {
      const { prop, order } = props

      let convertOrder = ''

      if (order === 'descending') {
        convertOrder = 'desc'
      } else if (order === 'ascending') {
        convertOrder = 'asc'
      }

      this.sortInfo = { prop, order: convertOrder }
      this.getData()  
    },
    oneClickDisable(event, clickEvent, ...args) {
      if(event.target.disabled === true){
        retrun
      }

      event.target.disabled = true

      try {
        clickEvent(...args)
      } catch {}
      setTimeout(() => {
        event.target.disabled = false
      }, 2000)
    }
  },

}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
@import '~/assets/style/pages/reception.scss';
</style>
