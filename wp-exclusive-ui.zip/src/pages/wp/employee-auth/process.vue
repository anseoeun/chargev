<template>
  <section>
    <div id="staff">
      <div class="article-title">
        <h-search
          v-model="workAssignNumber"
          :title="'업무번호'"
          :on-click="searchWork"
          :active-button="isValidAuthBtn('authSelect')"
          @enter="searchWork"
          />
        <div class="btn-group">
          <div>
            <el-button
              v-if="isValidAuthBtn('authExclusive') && isValidUserAuthBtn() && isValidUserAuthCancelBtn()"
              type="primary"
              :disabled="!workAssignNumber || this.data.pgsStCd !== '03'"
              @click="oneClickDisable($event, employeeAuthCancel)"
            >
            직원인증취소
            </el-button>

            <el-button
              v-if="isValidAuthBtn('authExclusive') && isValidUserAuthBtn()"
              type="primary"
              :disabled="!workAssignNumber"
              @click="oneClickDisable($event, saveCheck)"
            >
            저장
            </el-button>
            <el-button
              v-if="isValidAuthBtn('authExclusive') && isValidUserAuthBtn()"
              type="primary"
              :disabled="!workAssignNumber"
              @click="oneClickDisable($event, openPopSms())"
            >
            문자보내기
            </el-button>
            <!-- <el-button type="info">취소</el-button> -->
          </div>
        </div>
      </div>

      <div class="box">
        <el-form ref="info" class="detail-form table-wrap">
          <el-row>
            <el-col :span="8">
              <el-form-item label="고객관리번호">
                  {{ data.customerManagementNumber }}
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="고객명"> {{ data.wExsfNm }} </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="배우자">
                <el-input v-model.trim="data.spusCsmrMgmtNo" style="width:200px;" />
                <el-button type="info" class="btn-small" @click="openCustomerPopup('spus')">조회</el-button>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="생년월일"> {{ data.tymd }} </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="이메일"> {{ data.emlAdr }} </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="휴대전화"> {{ data.hpTn }} </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="업무번호"> {{ data.workAssignNumber }} </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item
                label="진행상태"
                required>
                <div class="select-client">
                  <el-select
                    v-model="data.pgsStCd"
                    :disabled="data.alreadyAuthCompleteFlag"
                    placeholder="접수"
                      >
                      <el-option
                        v-for="{ value, label } in commonCodes.Z081 && commonCodes.Z081.slice(1, commonCodes.Z081.length)"
                        :key="value"
                        :value="value"
                        :label="label"
                      />
                  </el-select>
                </div>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="업무처리자"> {{ data.managerName }} </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="승인일시">
                {{ data.csetDtm }} 
                <span v-if="data.csetXprDtm">( {{ data.csetXprDtm }} 이후 결제 시 재승인 요청 )</span>
                </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="구매가능일"> 
                <span v-if="buyCanDtime">
                  {{ buyCanDtime }} 이후
                </span>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="인증 만료일" required>
                <el-date-picker
                  v-model="data.xprDt"
                  type="date"
                   />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="요청메모">
                <el-input v-model="data.memoSbc" type="textarea" />
              </el-form-item>
            </el-col>
          </el-row>
          <!-- [#9993/2021.12.10/A936505] 실패사유 추가 -->
          <el-row>
            <el-col :span="24">
              <el-form-item label="실패사유">
                <el-input v-model="data.failRsonSbc" type="textarea" />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>


      <div class="article">
        <el-tabs
          v-model="activeName"
          type="card"
          stretch
        >
          <el-tab-pane
            label="직원인증" 
            name="first"
          >
          <!-- 탭내용 -->
          <employee-auth-info
            ref="employeeInfo"
            :user-info="userInfo"
            :common-codes="commonCodes"
            @setDocumentList="settingDocumentList"
            @setRePurchaseRestrict="setRePurchaseRestrictValue"
            :key="componentKey"
          />
          <!-- 탭내용 END -->
          </el-tab-pane>
          <el-tab-pane
            label="이력조회"
            name="second"
          >
          <!-- 탭내용 -->
          <employee-history
            v-if="data.workAssignNumber"
            ref="employeeHistory"
            :data="data"
          />
          <!-- 탭내용 END -->
          </el-tab-pane>
        </el-tabs>
      </div>



      <!-- 임직원 인증 승인 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="employeeAuthCompletePopFlag"
      >
        <!-- [#9412/2021.10.27/A936506] 저장 시 사번 주의 문구 추가 및 메시지 수정건 -->
        <!-- Message -->
        직원인증을 승인하시겠습니까?<br/>
        소속, 사번을 다시 확인해주세요. 불일치 시 혜택정보 조회가 안될 수 있습니다.

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="info"
            @click="employeeAuthCompletePopFlag = false"
          >
            아니요
          </el-button>
          <el-button
            type="primary"
            @click="save"
            @click.native="employeeAuthCompletePopFlag = false"
          >
            예
          </el-button>
        </template>
      </el-dialog>

      <!-- 임직원 취소처리 승인 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="employeeAuthCancelPopFlag"
      >
        <!-- [#9412/2021.10.27/A936506] 저장 시 사번 주의 문구 추가 및 메시지 수정건 -->
        <!-- Message -->
        직원인증을 취소처리 하시겠습니까?
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="info"
            @click="employeeAuthCancelPopFlag = false"
          >
            아니요
          </el-button>
          <el-button
            type="primary"
            @click="employeeAuthCancelSave"
            @click.native="employeeAuthCancelPopFlag = false"
          >
            예
          </el-button>
        </template>
      </el-dialog>


      <!-- 임직원 인증 실패 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="employeeAuthFailPopFlag"
      >
        <!-- Message -->
        직원인증을 거절하시겠습니까?<br/>
        기존에 설정된 소속 및 할인율이 초기화됩니다.

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="info"
            @click="employeeAuthFailPopFlag = false"
          >
            아니요
          </el-button>
          <el-button
            type="primary"
            @click="save"
            @click.native="employeeAuthFailPopFlag = false"
          >
            예
          </el-button>
        </template>
      </el-dialog>

      <!-- 회원조회 팝업 -->
      <customer-search-popup
        ref="customerPop"
        :pop-visible-company.sync="popVisibleCustomer"
        @buyCanDtime="getBuyCanDtime"
        @close="popVisibleCustomer = false"
      />

        <!-- @settingCustomer="value => {
            data.customerManagementNumber = value;
          }
          "
        @settingSpusCustomer="value => {
            data.spusCsmrMgmtNo = value;
          }
          " -->
    </div>

      <!-- 문자보내기 팝업 -->
      <el-dialog
        title="문자보내기"
        :visible.sync="popVisibleSMS"
        width="1100px"
      >
        <!-- Popup Contents -->
        <div class="board-wrap sandmessage">
          <h-title :title="'수신자 정보'" />
          <el-form
            ref="contractData"
            :model="contractData"
            class="detail-form"
          >
            <el-row>
              <el-col :span="9">
                <el-form-item label="수신자명">
                  <!-- {{ contractData.contractorInfo && contractData.contractorInfo.length > 0 ? contractData.contractorInfo[0].customerName : '' }} -->
                  <el-select v-model="contractorNames" multiple placeholder="수신자명">
                    <el-option
                      :key="data.customerManagementNumber"
                      :value="data.wExsfNm"
                      :label="data.wExsfNm"
                    />
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="15">
                <el-form-item label="휴대전화번호">
                  <!-- {{ contractData.contractorInfo && contractData.contractorInfo.length > 0 ? contractData.contractorInfo[0].customerMobile : '' }} -->
                  {{ data.hpTn }}
                </el-form-item>
              </el-col>
              <!-- <el-col :span="8">
                <el-form-item label="발송일시" />
              </el-col> -->
            </el-row>
          </el-form>
          <h-title :title="'발신내용'" />
          <el-form
            ref="ruleFormpopup"
            :model="ruleFormpopup"
            class="detail-form"
          >
            <el-row>
              <el-col :span="24">
                <el-form-item label="제목">
                  <el-input
                    v-model="ruleFormpopup.title"
                    class="mms-title"
                    @blur="ruleFormpopup.title = $event.target.value"
                  />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item label="내용">
                  <el-input
                    v-model="ruleFormpopup.text"
                    type="textarea"
                    @blur="ruleFormpopup.text = $event.target.value"
                  />
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="primary"
            @click="initRuleFormPop"
          >
            초기화
          </el-button>
          <el-button
            type="primary"
            @click="oneClickDisable($event, sendSms)"
          >
            전송
          </el-button>
        </template>
      </el-dialog>
    <!-- message Popup -->
    
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import HSearch from '~/components/common/HSearch.vue'
import HTitle from '~/components/common/HTitle.vue'
import CustomerSearchPopup from '~/components/popup/CustomerSearchPopup.vue'
import EmployeeAuthInfo from '~/components/tab/employee/EmployeeAuthInfo.vue'
import EmployeeHistory from '~/components/tab/employee/EmployeeHistory.vue'

import { mapState,mapGetters } from 'vuex'
import moment from 'moment'
import PopMessage from '~/components/popup/PopMessage.vue'


export default {
  layout: 'default',
  components: {
    HSearch,
    HTitle,
    PopMessage,
    CustomerSearchPopup,
    EmployeeAuthInfo,
    EmployeeHistory
  },

  data() {
    return {
      selectedIndex: 0,
      isAuth: process.env.VUE_APP_AUTH === 'true', // 권한 패스용
      contractorNames: '',
      alertMessage: '',
      alertMessagePop: false,
      activeFlag : false,
      popVisibleCustomer: false,  // 회원조회
      // 진행상태에 따른 다른 팝업 노출
      employeeAuthCompletePopFlag : false, // 진행상태 완료
      employeeAuthFailPopFlag: false,      // 진행상태 실패
      employeeAuthCancelPopFlag: false,      // 인증 진행상태 취소
      activeName: 'first',
      alertNoData: false,
      popVisibleSMS: false,
      ruleFormpopup: {
        title: '',
        text: ''
      },
      data: {},
      documnetList: [], // 문서 목록 
      buyCanDtime: null,
      contractNumber: null,
      contractData: {},
      workAssignNumber: null, // 업무 일련 번호
      wExsfCtfnOft: null,   // 임직원 인증 회차 수 번호
      addKeyIdx: 0,
      commonCodes: {},
      componentKey:0
    }
  },
  computed: {
    ...mapState(['documentTargets']),
    ...mapGetters(['userInfo'])
  },
  async created() {
    await this.loadCommonCode()
    this.$store.dispatch('loadDocumentTargets', {vm: this})

    this.workAssignNumber = localStorage.getItem('workAssignNumber') || '' // 새창으로 넘어오는 경우
    this.wExsfCtfnOft = localStorage.getItem('wExsfCtfnOft') || '' // 새창으로 넘어오는 경우
    
    if(this.workAssignNumber) {
      this.getData(this.workAssignNumber, this.wExsfCtfnOft)
    }

    localStorage.removeItem('workAssignNumber')
  },
  methods: {
    /* [#9840/2021.12.17/A936506] 재구매 제한여부 컬럼 추가. 'N'인 경우 구매가능일은 직원인증 완료(승인)일자로 산정. */
    setRePurchaseRestrictValue(param) {
      this.data.rePurchaseRestrictYn = param
      this.getBuyCanDtime()
    },
    // 구매가능일 조회
    async getBuyCanDtime(memberInfo) {

      this.buyCanDtime = ''

      /* [#9840/2021.12.17/A936506] 재구매 제한여부 컬럼 추가. 'N'인 경우 구매가능일은 직원인증 완료(승인)일자로 산정. */
      if(this.data.rePurchaseRestrictYn && this.data.rePurchaseRestrictYn === 'N') {
        this.buyCanDtime = this.data.csetDtm
        return
      }

      let csmrMgmtNo = ''

      if(memberInfo) {
        if(memberInfo.type) {
          // 배우자
          this.data.spusCsmrMgmtNo = memberInfo.memberMngNumber
        } 

        csmrMgmtNo = memberInfo.memberMngNumber
      } else {
        csmrMgmtNo = this.data.customerManagementNumber
      }

      // 구매가능일을 조회하기 위한 고객관리번호에 해당하는 모든 계약정보 조회
      //const [res, err] = await this.$https.post('/customer-info/v2/customer-info/hdot/contractInfo', {csmrMgmtNo : memberInfo.memberMngNumber}, null, 'gateway')
      const [res, err] = await this.$https.post('/customer-info/v2/customer-info/hdot/contractInfo', {csmrMgmtNo : csmrMgmtNo}, null, 'gateway')
      
      if(!err && res.data){
        
        let contractInfo = res.data.contractInfo

        if(contractInfo) {

          //1. 임직원 할인이 적용된 것 중 가장 큰 최신날짜값
          let filterList = contractInfo.filter((item) =>  {
            return item.eeDcYn === 'Y'
          })

          if(filterList && filterList.length > 0) {
            let result = filterList.reduce(function (a, b) { return a.whotDt > b.whotDt ? a : b })

            let buyDateVal = moment(result.whotDt)

            buyDateVal = new Date(buyDateVal)
            buyDateVal.setFullYear(buyDateVal.getFullYear() + 2)

            this.buyCanDtime = moment(buyDateVal).format('YYYY-MM-DD')
          }
        }
      }
    },
    openCustomerPopup(type) {
      this.$refs.customerPop.customerPopOpen(type)
    },
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null
      switch(systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {vm: this, codeTypeCode: codeType})
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {vm: this, codeTypeCode: codeType})
        break
      }
      return res
    },
    async loadCommonCode() {
      const [ccT002, ccZ081] = await Promise.all([
        this.fetchCommonCodeData('E', 'T002'), // 상태
        this.fetchCommonCodeData('E', 'Z081') // 업무 진행상태
      ])

      this.commonCodes = { ...ccT002, ...ccZ081 }
    },
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    /* 유저 버튼 권한 체크 */
    isValidUserAuthBtn() {
      var authGroupIds = this.userInfo.exclusiveUseAuthGroupIds

      for(var id of authGroupIds){
        // 법인/대고객 일반이며 담당자 본인인 경우  
        if ((['WT001'].includes(id) && this.activeFlag)){
          return true
        // 대고객/법인 관리자
        } else if(['WT002'].includes(id)) {
          return true
        } else {
          continue
        }
      }
      return false
    },
    /* 직원인증취소 가능여부 체크 : wExsfCtfnOftLast(마지막차수)가 동일할 경우만 처리 가능함. */
    isValidUserAuthCancelBtn() {
      if (this.data && this.data.wExsfCtfnOftLast && this.data.wExsfCtfnOft === this.data.wExsfCtfnOftLast) {
        return true
      }
      return false
    },    
    async reset() {
      this.data = {}
      this.documentList = []
      this.paperReviewData = []
    },
    async getData(serialNumber, oftNumber) {
     
      if(!serialNumber) return

      await this.reset()

      // 1. 데이터 조회
      const [res1,err1] = await this.$https.post('/v2/exclusive/employeeAuth-detail', { workAssignNumber : serialNumber, wExsfCtfnOft : oftNumber })

      if(!err1) {
        if(!res1.data) { // 상세보기 - 조회 결과 없음 팝업 노출
          const beforeworkAssignNumber = this.workAssignNumber
          Object.assign(this.$data, this.$options.data())
          this.workAssignNumber = beforeworkAssignNumber
          this.alertNoData = true
          return
        }

        // screenUseTypeCode (01:열람,02:수정,03:삭제,04:인쇄,05:입력,06:업로드,07:다운로드)
        this.$store.dispatch('commonSupportLog', { vm: this, params: { screenUseTypeCode: '01', useInfo: JSON.stringify(res1.data) } })
        this.data = { 
          ...res1.data
        }
        // 기존값 기억(인증완료 여부)
        this.data.alreadyAuthCompleteFlag = ((this.data.pgsStCd === '03' || this.data.pgsStCd === '04') ? true : false)
        this.contractNumber = res1.data && res1.data.contractNumber

        // 1-1. 진행상태 완료 건 > 할인율 setting (이것도 나중에 dcSbc처리되면 그 정보로 대체)
        if(this.data.pgsStCd === '03') {
          if(!this.data.dcSbc) {
            const [resA, errA] = await this.$https.post('/customer-info/v2/customer-info/hds/employeeDcRate', {csmrMgmtNo : this.data.customerManagementNumber}, null, 'gateway')
          
            if(!errA) {
              if(resA.data) this.data.dcRate = ((resA.data.dcRate && resA.data.dcRate > 0) ? resA.data.dcRate : '0')
            } else {
              console.error('employeeDcRate Error {} ', errA)
            }
          } 
        }

        // 1-2. 직원인증 서류정보 호출
        this.$refs.employeeInfo.getInfoData(this.data)

        if(this.data.managerId && this.data.managerId === this.userInfo.eeno) { // 사용자 사번과 처리자가 같을 경우
          this.activeFlag = true
        }

        // 2. 구매가능일 조회
        this.getBuyCanDtime()

      } else {
        console.error(err1)
      }
    },
    employeeAuthCancel() {
      if(!this.data.alreadyAuthCompleteFlag && this.data.wExsfCtfnOftLast === this.data.wExsfCtfnOft) {
        this.alertMessage = '인증 완료건이 아닙니다. 완료 건만 취소가 가능합니다.'
        this.alertMessagePop = true
        return
      }
      /* 직원인증 취소처리 confirm 창 */
      if(this.data.pgsStCd === '03') this.employeeAuthCancelPopFlag = true
    },
    async employeeAuthCancelSave() {

      if(!this.workAssignNumber) {
        this.alertMessage = '업무를 먼저 검색해주세요.'
        this.alertMessagePop = true
        return
      }
      const body = {
        customerManagementNumber: this.data.customerManagementNumber,
        wExsfCtfnOftLast: this.data.wExsfCtfnOftLast,
        managerId: this.data.managerId
      };
      const [res,err] = await this.$https.post('/v2/exclusive/employeeAuth/cancel', body) // API-WX-전담컨설턴트-142 (임직원 인증 취소)
     
      if(!err) {
        console.log(res)
        this.alertMessage = '직원인증 정보를 취소처리 했습니다.'
        this.alertMessagePop = true
      } else {
      // ETC_A_035
        this.alertMessage = err.rspMessage ? err.rspMessage : '직원인증 정보 취소처리를 실패했습니다.'
        this.alertMessagePop = true
      }
      this.searchWork(this.workAssignNumber)
    },
    saveCheck() {
      if(this.data.alreadyAuthCompleteFlag) {
        // 진행상태 완료(03), 실패(04) 일경우 메모 수정을 위해서 변경처리함.
      	if(this.data.pgsStCd === '03' || this.data.pgsStCd === '04') {
            this.save()
      	} else {
            this.alertMessage = '이미 완료된 인증 건 입니다.'
            this.alertMessagePop = true
      	}
      	return
      }
      
      /* 진행상태 완료/실패 상태 저장 시 confirm 창 */
      if(this.data.pgsStCd === '03') this.employeeAuthCompletePopFlag = true
      else if(this.data.pgsStCd === '04') this.employeeAuthFailPopFlag = true
      else this.save()
    },
    async save() {

      // EmployeeAuthInfo 에서 setting 한 documentList, data 가져오기
      await this.$refs.employeeInfo.setDocumentList()

      if(!this.workAssignNumber) {
        this.alertMessage = '업무를 먼저 검색해주세요.'
        this.alertMessagePop = true
        return
      }

      if(!this.data.xprDt) {
        this.alertMessage = '인증 만료일은 필수 입력사항 입니다.'
        this.alertMessagePop = true
        return
      }

      let completedValidation = true

      if(this.data.pgsStCd === '03') {
        // 노란우산 회원인증은 체크X
        if(!this.data.firmCd && this.data.wExsfCtfnCndSn !== '31') {
          this.alertMessage = '업체를 선택해주세요.'
          this.alertMessagePop = true
          return
        }

        if(!this.data.wExsfNo && this.data.wExsfCtfnCndSn !== '31') {
          this.alertMessage = '사번은 필수 입력사항 입니다.'
          this.alertMessagePop = true
          return
        }

        // 국판 넘기기용 (생년월일 형식)
        this.data.birthDay = moment(this.data.tymd).format('YYMMDD')
      }

      if(!completedValidation) return

      // EmployeeAuthInfo에서  이런 형식으로 데이터 넘겨오면 됌


      // 소속 선택에 따라 추가된 필요한 기본/추가 서류가 있으면 insert 및 고객에게 알림전송 필요(팝업에서 설정)
      // const paperReviewData = this.paperReviewData.filter((items) => { // 변경된 사항만 저장
      //   return items.isEdit === true
      // })

      let documentList = []

      if(this.documentList) {

        let docValidation = true

        // 그냥 대입했더니 documentList도 같이 바뀌어서 리턴으로 새로 할당
        let paramDocumentList = this.documentList.map((items) => { return items })

        paramDocumentList.map((items) => {
          // 만약 완료 처리일시 모든 서류심사 결과가 완료일때 가능하다
          if(this.data.pgsStCd === '03') {
            if(!items.workProcessDetailResultCode || !['40', '50'].includes(items.workProcessDetailResultCode)) {
              /* ETC_A_030 */
              this.alertMessage = '서류 심사를 완료해주세요.'
              this.alertMessagePop = true
              docValidation = false
            }
          }

          // 처리결과는 필수
          if(!items.workProcessDetailResultCode ) {
            /* ETC_A_030 */
            this.alertMessage = '처리결과를 선택해주세요.'
            this.alertMessagePop = true
            docValidation = false
          }

          // 추가행 + 파일 등록건
          if(items.isAdd && items.isAdd === true) {
            //  추가서류의 경우 진행사항 메모는 필수입력사항 
            if(!items.ppExamSbc) {
              /* ETC_A_008 */
              this.alertMessage = '진행 상황 메모를 입력해주세요.'
              this.alertMessagePop = true
              docValidation = false
            }
          }

          // 재심사/완료 상태 메모 필수입력
          if(['40', '50'].includes(items.workProcessDetailResultCode)) {
            if(!items.ppExamSbc) {
              /* ETC_A_008 */
              this.alertMessage = '진행 상황 메모를 입력해주세요.' 
              this.alertMessagePop = true
              docValidation = false
            }
          }
        })

        // 소속에 따라 추가된 서류를 documentList에 추가. 추가요청으로 전송된다.
        this.paperReviewData.map((items) => {

          // [#9044/20213.10.07/A936506_추가서류 요청 시에도 진행상태 완료처리가 가능하여 막기 기능 추가]
          if(items && this.data.pgsStCd === '03') {
            this.alertMessage = '추가 서류 심사를 완료해주세요.'
            this.alertMessagePop = true
            docValidation = false
            return
          } else {
            if(items.isAdd && items.isAdd === true) {
              paramDocumentList.push({
                ...items,
                workAssignNumber: this.data.workAssignNumber,
                customerManagementNumber: this.data.customerManagementNumber,
                isEdit: true
              })
            }
          }
        })

        if(!docValidation) { return }
        
        paramDocumentList.map((items) => {
          items.workAssignNumber = this.data.workAssignNumber
          items.customerManagementNumber = this.data.customerManagementNumber
          items.wExsfCtfnOft  = this.data.wExsfCtfnOft
          items.contractNumber = this.data.contractNumber
          items.managerId = this.data.managerId
        })

        let bResult = false
        paramDocumentList.some((items) => {
          if(!items.neceDocTargNo || !items.neceDocNo) {
            bResult = true
            return true
          }
        })

        if(bResult) {
          /* ETC_A_070 */
          this.alertMessage = '추가서류의 구분과 소분류 항목을 확인해주세요.'
          this.alertMessagePop = true
          return false
        }
        

        documentList = paramDocumentList.filter((items) => { // 변경된 사항만 저장
          return items.isEdit === true
        })
      }

      const data = {
        ...this.data,
        documentList, // 서류심사목록
        xprDt: moment(this.data.xprDt).format('YYYYMMDD')
      }

      const [res,err] = await this.$https.post('/v2/exclusive/employeeAuth/process', data) // API-WX-0?? (임직원 인증 정보 저장)
     
      if(!err) {
        console.log(res)
        // screenUseTypeCode (01:열람,02:수정,03:삭제,04:인쇄,05:입력,06:업로드,07:다운로드)
        this.$store.dispatch('commonSupportLog', { vm: this, params: { screenUseTypeCode: '02', useInfo: JSON.stringify(data) } })
        this.alertMessage = '직원인증 정보를 저장했습니다.'
        this.alertMessagePop = true
      } else {
      // ETC_A_035
        this.alertMessage = err.rspMessage ? err.rspMessage : '직원인증 정보 저장에 실패했습니다.'
        this.alertMessagePop = true
      }
      this.getData(this.workAssignNumber, this.wExsfCtfnOft)

      //re-rendering
      this.componentKey += 1;
    },
    settingDocumentList(paramDocumentList, paramData) {
      // employeeAuthInfo.vue의 documentList
      this.documentList = paramDocumentList.documentList
      this.paperReviewData = paramDocumentList.paperReviewData
      const data = {
        ...this.data,
        paramData
      }

      this.data = {}
      this.data = data
      
    },
    searchWork(value) {
      if(!this.isValidAuthBtn('authSelect')) { // 권한없을경우 동작 x
        return
      }

      if(!value) {
        this.alertMessage = '업무일련번호를 입력해주세요.'
        this.alertMessagePop = true
        return
      } else {
        value = value.trim() // 공백 제거
      }

      this.workAssignNumber = value
      this.getData(value)
    },
    initRuleFormPop() { // 문자 초기화 버튼
      Object.assign(this.$data.ruleFormpopup, this.$options.data().ruleFormpopup)
    },
    async sendSms() {
      let customersInfo = []
      // const contractorInfo = this.contractData && this.contractData.contractorInfo
      // const targetContractorInfo = contractorInfo && contractorInfo.filter((items) => {
      //   return this.contractorNames.includes(items.customerName)
      // })

      customersInfo.push({
        sendChannelCode: 'M', // 발송경로 구분 코드 - 업무담당자
        customerMgmtNo: this.data.customerManagementNumber || '', // 고객관리번호
        customerUniqueNo: this.userInfo.eeno || '', // 고객고유번호
        messageTitle: this.ruleFormpopup.title, // 제목
        messageContents: this.ruleFormpopup.text, // 내용
        receiverTel: this.data.hpTn.replace(/-/gi, ''), // 수신자전화번호
        receiverName: this.data.wExsfNm, // 수신자명
        // [#9993/2021.11.24/A936505] 업무할당번호가 없어 임직원 문자 이력 정상 조회가 불가능하여 추가
        workAssignNumber : this.data.workAssignNumber
      })

      const [result1, result2] = await Promise.all(
        customersInfo.map((items) => {
          return this.$https.post('/v2/exclusive/common/sms-send', items) // API-E-공통서비스-023 (문자 보내기)
        })
      )

      // 1명의 계약자에게만 발송하는 경우
      if (!result2) {
        const [res1, err1] = result1
        if (!err1) {
          if(res1.rspStatus && res1.rspStatus.rspCode === '0000') {
            this.popVisibleSMS = false // 팝업 닫기
            this.alertMessage = '문자가 전송되었습니다.'
            this.alertMessagePop = true
          }
        }
      }

      // 주계약자 및 공동명의자 모두 발송하는 경우
      if (result1 && result2) {
        const [res1, err1] = result1
        const [res2, err2] = result2

        // 모두 전송되었을 경우
        if (!err1 && !err2) {
          if(res1.rspStatus && res1.rspStatus.rspCode === '0000' &&
            res2.rspStatus && res2.rspStatus.rspCode === '0000') {
            this.popVisibleSMS = false // 팝업 닫기
            this.alertMessage = '문자가 전송되었습니다.'
            this.alertMessagePop = true
          }
        }
      }
      this.popVisibleSMS = false // 팝업 닫기
    },
    openPopSms() { // 문자보내기 팝업 노출
      let hpTn = '', wExsfNm = ''

      if (this.data && this.data.customerManagementNumber) {
        ({ hpTn, wExsfNm } = this.data)
      }

      if (!hpTn || !wExsfNm) { // 고객정보가 없을 경우
        this.alertMessage = '고객 데이터가 없습니다.'
        this.alertMessagePop = true
      } else {
        this.popVisibleSMS = true
        Object.assign(this.ruleFormpopup, this.$options.data().ruleFormpopup)
      }
    },
    oneClickDisable(event, clickEvent, ...args) {
      if(event.target.disabled === true){
        retrun
      }

      event.target.disabled = true

      try {
        clickEvent(...args)
      } catch {}
      setTimeout(() => {
        event.target.disabled = false
      }, 2000)
    }
  },
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
.btn-md{
  min-width: 40px;
  height: 40px;
}
.append-box {
  .el-input, .el-select {
    margin:2px 0;
  }
}
</style>