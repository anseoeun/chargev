<template>
  <section>
    <div id="release">
      <div class="btn-wrap">
        <div class="side">
          <el-button type="primary" @click="resetSearchCond">
            초기화
          </el-button>
        </div>
        <div class="main">
          <el-button
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            @click="onSearch(1)"
          >
            조회
          </el-button>
          <el-button
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            class="excel"
            @click="downloadExcel"
          >
            Excel 다운로드
          </el-button>
        </div>
      </div>
      <div class="board-wrap">
        <el-form
          ref="ruleForm"
          :model="ruleForm"
          class="detail-form table-wrap"
        >
          <el-row>
            <el-col :span="24">
              <el-form-item
                label="구분"
                prop="searchDateType"
                required
                align=""
              >
                <el-select v-model="ruleForm.searchDateType">
                  <el-option
                    v-for="{ value, label } in commonCodes.U019 &&
                      commonCodes.U019.slice(1, commonCodes.U019.length)"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
                <el-date-picker
                  v-model="ruleForm.searchFromDt"
                  type="date"
                  :clearable="false"
                  style="margin-left: 10px;"
                />
                <span class="ex-txt" style="margin:0 10px;">~</span>
                <el-date-picker
                  v-model="ruleForm.searchEndDt"
                  type="date"
                  :clearable="false"
                />
                <el-radio-group
                  v-model="searchDtRadio"
                  class="tabBtn-case01"
                  @change="onChangeSearchDtRadio"
                >
                  <el-radio-button label="lastDay">
                    전일
                  </el-radio-button>
                  <el-radio-button label="today">
                    오늘
                  </el-radio-button>
                  <el-radio-button label="day7">
                    7일
                  </el-radio-button>
                  <el-radio-button label="day30">
                    30일
                  </el-radio-button>
                  <el-radio-button label="month3">
                    3개월
                  </el-radio-button>
                  <el-radio-button label="month6">
                    6개월
                  </el-radio-button>
                  <el-radio-button label="month12">
                    1년
                  </el-radio-button>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="온라인진행상태" prop="onlineStatus">
                <el-select
                  v-model="ruleForm.onlineStatus"
                  multiple
                  collapse-tags
                  placeholder="전체"
                  style="max-width: 180px;"
                  @change="onChangeMultiSelect($event, 'online')"
                >
                  <!-- commonCodes.T010 -->
                  <el-option
                    v-for="item in onlineProgressCodes"
                    :key="item"
                    :value="item"
                    :label="item"
                  />
                </el-select>
                <el-checkbox
                  v-model="onlineSelectedVal"
                  style="margin-left: 8px;"
                  @change="selectedAll($event, 'online')"
                >
                  전체
                </el-checkbox>
                <el-checkbox
                  v-if="!isDeliveryCenterInventoryConfirmComplete"
                  v-model="deliveryCenterInventoryConfirmCompleteVal"
                  style="margin-left: 2px;"
                >
                  생산완료
                </el-checkbox>
                <el-checkbox
                  v-if="!isNonPayment"
                  v-model="nonPaymentVal"
                  style="margin-left: 2px;"
                >
                  미입금제외
                </el-checkbox>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="국판 진행상태" prop="legacyStatus">
                <el-select
                  v-model="ruleForm.legacyStatus"
                  multiple
                  collapse-tags
                  placeholder="전체"
                  @change="onChangeMultiSelect($event, 'legacy')"
                >
                  <el-option
                    v-for="{ value, label } in LegacyCommonCodes.C013 &&
                      LegacyCommonCodes.C013.slice(1)"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
                <el-checkbox
                  v-model="legacySelectedVal"
                  style="margin-left: 8px;"
                  @change="selectedAll($event, 'legacy')"
                >
                  전체
                </el-checkbox>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="계약담당자" prop="consultantId">
                <el-select
                  v-model="ruleForm.consultantId"
                  placeholder="전체"
                  multiple
                  collapse-tags
                  @change="onChangeMultiSelect($event, 'consultant')"
                >
                  <el-option
                    v-for="{ sysUserNo, sysUserNm } in consultants &&
                      consultants.slice(1)"
                    :key="sysUserNo"
                    :value="sysUserNo"
                    :label="sysUserNm"
                  />
                </el-select>
                <el-checkbox
                  v-model="consultantSelectedVal"
                  style="margin-left: 8px;"
                  @change="selectedAll($event, 'consultant')"
                >
                  전체
                </el-checkbox>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="고객구분" prop="customerTypeCode">
                <el-select
                  v-model="ruleForm.customerTypeCode"
                  placeholder="전체"
                >
                  <el-option
                    v-for="{ value, label } in customerTypeCodes"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="회원ID" prop="contractEmployeeName">
                <el-input
                  v-model="ruleForm.contractEmployeeName"
                  @keyup.native.enter="onSearch(1)"
                  @blur="ruleForm.contractEmployeeName = $event.target.value"
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item
                label="고객관리번호"
                prop="customerManagementNumber"
              >
                <el-input
                  v-model="ruleForm.customerManagementNumber"
                  @keyup.native.enter="onSearch(1)"
                  @blur="ruleForm.customerManagementNumber = $event.target.value
                  "
                />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="계약번호" prop="contractId">
                <el-input
                  v-model="ruleForm.contractId"
                  @keydown.native.tab="onAddZero(ruleForm.contractId)"
                  @keyup.native.enter="onSearch(1)"
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="계약자">
                <el-select
                  v-model="ruleForm.searchType"
                  placeholder="이름"
                  style="width:100px"
                >
                  <el-option
                    v-for="{ value, label } in searchType"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
                <el-input
                  v-model="ruleForm.searchValue"
                  @keyup.native.enter="onSearch(1)"
                  @blur="ruleForm.searchValue = $event.target.value"
                  style="margin-left:8px; width:250px"
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="취소사유" prop="contractCancleCode">
                <el-select
                  v-model="ruleForm.contractCancleCode"
                  placeholder="전체"
                >
                  <el-option
                    v-for="{ value, label } in commonCodes.T048 &&
                      commonCodes.T048"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="할부진행상태">
                <el-select
                  v-model="ruleForm.pgsStCd"
                  placeholder="전체"
                  style="width:140px"
                >
                  <el-option
                    v-for="{ value, label } in pgsType"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <!-- <el-row>
            <el-col :span="8">
              <el-form-item label="차종" prop="carTypeCode">
                <el-select
                  v-model="ruleForm.carTypeCode"
                  placeholder="전체"
                  @change="onChangeTypeCars"
                >
                  <el-option
                    v-for="{ carTypeCode, carTypeName } in carTypes"
                    :key="carTypeCode"
                    :value="carTypeCode"
                    :label="carTypeName"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="16">
              <el-form-item label="차명" prop="carCode">
                <el-select v-model="ruleForm.carCode" placeholder="전체">
                  <el-option
                    v-for="{ repnCarCode, repnCarName } in selTypeCars"
                    :key="repnCarCode"
                    :value="repnCarCode"
                    :label="repnCarName"
                  />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row> -->
        </el-form>
      </div>
      <article class="article">
        <div class="article-title title01">
          <!-- ###### [#10062/2021.11.26/A936505] 전체선택 추가 Start ###### -->
          <!-- TODO: 다중선택으로 변경시 주석해제 -->
          <el-checkbox
            v-model="checked"
            label="전체선택"
            @change="toggleSelectionAll"
          />
          <!-- ###### [#10062/2021.11.26/A936505] 전체선택 추가 Start END ###### -->
          <el-button
            v-if="isValidAuthBtn('authExclusive')"
            type="primary"
            @click="changeReleaseDate"
          >
            출고예정일 변경
          </el-button>

          <el-button
            v-if="isValidAuthBtn('authExclusive')"
            type="primary"
            @click="changePaymentDate"
          >
            결제기한일 연기
          </el-button>
          <el-button
            v-if="isValidAuthBtn('authExclusive')"
            type="primary"
            @click="changePaymentRequest"
          >
            빠른 결제요청
          </el-button>
        </div>
        <div>
            <!-- 전체선택 시 선택된 해당 페이지(1페이지) or 전체 페이지 ? 헷갈리는 사람 있따하여 주석추가 -->
          <span> * 전체 선택 시 선택된 현재 페이지의 계약만 해당됩니다. </span>
        </div>
        <el-table
          :data="tableData"
          style="width: 100%"
          empty-text="조회된 조회결과가 존재하지 않습니다."
          max-height="1136"
          @sort-change="sortChange"
        >
          <el-table-column
            label="선택"
            prop="isSelected"
            align="center"
            width="50"
            fixed
          >
            <template slot-scope="scope">
              <!-- <el-checkbox
                v-model="scope.row.isSelected"
                @change="onChange($event, scope.row)"
                @click.native.stop
              /> -->
              <el-checkbox v-model="scope.row.isSelected" @click.native.stop />
            </template>
          </el-table-column>
          <el-table-column
            prop="no"
            label="NO."
            align="center"
            width="50"
            fixed
          />
          <el-table-column
            label="계약번호"
            prop="contractNumber"
            width="150"
            align="center"
            sortable="custom"
            fixed
          >
            <template slot-scope="props">
              <a
                class="link"
                href="/#/wp/contract/customer/release-detail"
                target="_blank"
                @click="
                  $utils.setLocalStorage({
                    contractNumber: props.row.contractNumber
                  })
                "
              >
                {{ props.row.contractNumber | capitalize }}
              </a>
            </template>
          </el-table-column>
          <el-table-column label="진행상태" width="300" fixed>
            <el-table-column
              label="온라인"
              prop="onlineStatusName"
              width="200"
              align="center"
              sortable="custom"
              fixed
            >
              <!-- <template slot-scope="props">
                <span
                  v-if="
                    props.row.deliveryCenterInventoryConfirmCompleteYn &&
                      props.row.deliveryCenterInventoryConfirmCompleteYn ===
                        'N' &&
                      props.row.onlineStatusCode &&
                      props.row.onlineStatusCode === '0093'
                  "
                  >생산완료</span
                >
                <span v-else>{{ props.row.onlineStatusName }}</span>
              </template> -->
            </el-table-column>
            <el-table-column
              label="국판"
              prop="legacyStatusName"
              width="100"
              align="center"
              sortable="custom"
              fixed
            />
          </el-table-column>
          <el-table-column label="계약정보" width="1000">
            <el-table-column
              label="무통장입금여부"
              prop="depositYn"
              width="100"
              align="center"
            />
            <el-table-column label="유형" width="120" align="center"
              >개인/개인사업자
            </el-table-column>
            <el-table-column
              label="고객구분"
              prop="customerTypeName"
              width="100"
              align="center"
              sortable="custom"
            />
            <el-table-column
              prop="loginId"
              label="회원ID"
              align="center"
              width="200"
            />
            <el-table-column
              label="이름"
              prop="contractorName"
              width="120"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="휴대전화"
              prop="customerMobile"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="이메일"
              prop="customerEamil"
              width="200"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="사업자번호"
              prop="companyNumber"
              width="180"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="취소사유"
              prop="contractCancleName"
              width="300"
              align="center"
              sortable="custom"
            />
          </el-table-column>
          <el-table-column label="차량정보" width="450">
            <el-table-column
              label="재고구분"
              prop="stockType"
              width="100"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="판매코드"
              prop="carSaleCode"
              width="150"
              align="center"
              sortable="custom"
            >
              <template slot-scope="props">
                <el-tooltip placement="bottom" effect="light">
                  <div slot="content">
                    <el-row>
                      <el-col :span="6">
                        차종
                      </el-col>
                      <el-col :span="18">
                        {{ props.row.saleModelName }}
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="6">
                        옵션
                      </el-col>
                      <el-col :span="18">
                        {{ props.row.optionName }}
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="6">
                        외, 내장 칼라
                      </el-col>
                      <el-col :span="18">
                        {{
                          `외장(${props.row.exteriorColorName ||
                            ""}), 내장(${props.row.interiorColorName || ""})`
                        }}
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="6">
                        TUIX
                      </el-col>
                      <el-col :span="18">
                        {{ props.row.tuixName }}
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="6">
                        가격
                      </el-col>
                      <el-col :span="18">
                        {{
                          props.row.carPrice &&
                            props.row.carPrice.toLocaleString() + "원"
                        }}
                      </el-col>
                    </el-row>
                  </div>
                  <el-button type="text">
                    {{ props.row.carSaleCode }}
                  </el-button>
                </el-tooltip>
              </template>
            </el-table-column>
            <el-table-column
              label="칼라"
              prop="carColor"
              width="100"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="TUIX"
              prop="csptCode"
              width="100"
              align="center"
              sortable="custom"
            />
          </el-table-column>

          <el-table-column
            label="출고센터"
            prop="deliveryCenterCode"
            width="100"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="인수유형"
            prop="acquisitionTypeCode"
            width="100"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="탁송지"
            prop="deliveryPlace"
            width="200"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="계약시작일"
            prop="contractDate"
            width="100"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="계약완료일"
            prop="contractCompletionDate"
            width="100"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="배정 요청일"
            prop="assignRequestDate"
            width="100"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="배정일"
            prop="assignDate"
            width="100"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="결제기한일"
            prop="payExpireDate"
            width="150"
            align="center"
          />
          <el-table-column
            label="결제시작일"
            prop="payStartDate"
            width="150"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="결제완료일"
            prop="payEndDate"
            width="150"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="출고일/출고예정일"
            prop="releaseOrExpectDate"
            width="150"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="제작증 발급일"
            prop="craftCertificateDate"
            width="100"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="해약/매취일"
            prop="cancelDate"
            width="100"
            align="center"
            sortable="custom"
          />

          <el-table-column label="결제 정보" width="1600">
            <el-table-column
              label="차량가격"
              prop="carPrice"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="계약금"
              prop="contractPrice"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="할인액"
              prop="discountPrice"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="포인트"
              prop="usePoint"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="감면액"
              prop="taxReduction"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="탁송료"
              prop="deliveryPrice"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="의무보험료"
              prop="insurancePayment"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="할부유형"
              prop="installmentType"
              width="100"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="할부금"
              prop="installment"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="할부진행상태"
              prop="pgsStCd"
              width="120"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="PV진행일자"
              prop="pvDate"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="카드 결제액"
              prop="cardPayment"
              width="150"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="현금 입금액"
              prop="cashPayment"
              width="150"
              align="center"
              sortable="custom"
            />
          </el-table-column>
          <el-table-column label="업무담당자" width="400">
            <el-table-column
              label="사번"
              prop="consultantId"
              width="100"
              align="center"
              sortable="custom"
            />
            <el-table-column
              label="성명"
              prop="consultantName"
              width="80"
              align="center"
              sortable="custom"
            />
          </el-table-column>
        </el-table>
        <div class="btn-wrap">
          <div class="side"></div>
          <div class="pagination">
            <v-pagination
              v-if="tableData.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch"
            />
          </div>
          <div class="main"></div>
        </div>
      </article>

      <!-- 조회결과없음 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="alertNoData"
        :width="pupWidth"
      >
        <!-- Message -->
        조회 결과가 없습니다.

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button type="primary" @click="alertNoData = false">
            확인
          </el-button>
        </template>
      </el-dialog>

      <!-- 출고예정일 변경 팝업 -->
      <el-dialog title="출고예정일 변경" :visible.sync="popReleaseDate">
        <!-- Popup Contents -->
        <div class="board-wrap changeDate">
          <el-form ref="ruleFormpopup" class="detail-form">
            <el-row>
              <el-col :span="24">
                <el-form-item label="변경 후">
                  <el-date-picker
                    v-model="dateAfter"
                    type="date"
                    :clearable="false"
                  />
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
          <article class="article">
            <h-table
              :table-type="'DefultTable'"
              :table-header="popupTableHeader"
              :table-datas="multipleSelection"
            />
          </article>
        </div>
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button type="info" @click="popReleaseDate = false">
            취소
          </el-button>
          <el-button type="primary" @click="saveReleaseDate">
            저장
          </el-button>
        </template>
      </el-dialog>

      <!-- 결제기한일 연기 팝업 -->
      <el-dialog title="결제기한일 연기" :visible.sync="popPaymentDate">
        <!-- Popup Contents -->
        <div class="board-wrap changeDate">
          <el-form ref="ruleFormpopup" class="detail-form">
            <el-row>
              <el-col :span="32">
                <el-form-item label="결제시작일">
                  <el-date-picker
                    v-model="paymentAfter"
                    type="datetime"
                    @change="changePayAfterDate"
                    :clearable="false"
                  />
                  <!--  ############################# W Project - <2022-03-25> - <A934118> - START ###################################### -->
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <el-checkbox
                    v-model="deliveryDueDateChangYn"
                    class="private"
                    :label="true"
                    >출고 예정일 변경 포함
                  </el-checkbox>
                  <!--  ############################# W Project - <2022-03-25> - <A934118> - END ###################################### -->
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
          <article class="article">
            <h-table
              :table-type="'DefultTable'"
              :table-header="popupPaymentTableHeader"
              :table-datas="multipleSelection"
            />
          </article>
        </div>
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button type="info" @click="popPaymentDate = false">
            취소
          </el-button>
          <el-button type="primary" @click="oneClickDisable($event, onSavePaymentDate)">
            저장
          </el-button>
        </template>
      </el-dialog>

      <loading
        :pop-visible.sync="popVisibleLoading"
        @close="popVisibleLoading = false"
      />
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
    <pay-request-popup
      ref="payReqPop"
      :pop-payment-datas.sync="multipleSelection"
      @callPaymentRequest="onSavePaymentRequest"
    />
  </section>
</template>

<script>
import { mapState } from "vuex";
import moment from "moment";
import HTable from "~/components/common/HTable.vue";
import Loading from "~/components/popup/Loading.vue";
import PopMessage from "~/components/popup/PopMessage.vue";
import PayRequestPopup from "~/components/popup/PayRequestPopup.vue";

export default {
  name: "Release",
  layout: "default",
  components: {
    HTable,
    Loading,
    PopMessage,
    PayRequestPopup
  },
  data() {
    return {
      alertMessage: "",
      alertMessagePop: false,
      popVisiblePayment: false,
      onlineSelectedVal: false,
      legacySelectedVal: false,
      consultantSelectedVal: false,
      deliveryCenterInventoryConfirmCompleteVal: false,
      nonPaymentVal: false,
      isDeliveryCenterInventoryConfirmComplete: true,
      isNonPayment: true,
      pupWidth: "550px",
      popVisibleLoading: false,
      singleSelRow: null,
      tableData: [],
      multipleSelection: [],
      /* ############################# W Project - <2022-03-25> - <A934118> - START ###################################### */
      deliveryDueDateChangYn: false, // 출고예정일 포함 변경 여부
      /* ############################# W Project - <2022-03-25> - <A934118> - END ###################################### */
      popReleaseDate: false,
      popPaymentDate: false,
      alertNoData: false,
      // alertContinueChange: false,
      checked: false,
      searchDtRadio: "today",
      ruleForm: {
        searchDateType: "10",
        searchFromDt: moment(),
        searchEndDt: moment(),
        searchType: "contractorName",
        searchValue: "",
        onlineStatus: [],
        legacyStatus: [],
        consultantId: [],
        contractId: "",
        contractEmployeeName: "",
        contractEmployeeId: "",
        carTypeCode: "all", // 차종
        carCode: "all", // 차명
        customerTypeCode: "all", //고객구분
        contractCancleCode: "all", //취소사유
        contractorName: "", //계약자명
        businessNumber: "", //사업자번호
        customerMobile: "", //휴대전화
        customerEamil: "", //이메일
        companyNumber: "", //사업자번호
        customerManagementNumber: "", //고객관리번호
        deliveryCenterInventoryConfirmCompleteVal: "N",
        nonPaymentVal: "N",
        pgsStCd: "",
      },
      code: [{ value: "all", label: "전체" }],
      onlineProgressCodes: {},
      selTypeCars: [{ repnCarCode: "all", repnCarName: "전체" }],
      searchType: [
        { value: "contractorName", label: "이름" },
        { value: "customerMobile", label: "휴대전화" },
        { value: "customerEamil", label: "이메일" },
        { value: "companyNumber", label: "사업자번호" }
      ],
      pgsType: [
        { value: "", label: "전체" },
        { value: "0", label: "한도심사" },
        { value: "1", label: "PV대기" },
        { value: "2", label: "PV진행중" },
        { value: "3", label: "PV완료(가승인완료)" },
        { value: "4", label: "확정진행중" },
        { value: "5", label: "대출확정" },
        { value: "9", label: "기타(취소)" }
      ],
      dateAfter: moment(),
      paymentAfter: moment(),
      popupTableHeader: [
        {
          label: "계약번호",
          prop: "contractNumber",
          align: "center"
        },
        {
          label: "변경 전",
          prop: "releaseExpectDate",
          align: "center"
        }
      ],
      popupPaymentTableHeader: [
        {
          label: "계약번호",
          prop: "contractNumber",
          align: "center"
        },
        {
          label: "결제시작일",
          prop: "payStartDate",
          align: "center"
        },
        {
          label: "결제기한일",
          prop: "payAfterDate",
          align: "center"
        }
      ],
      commonCodes: {},
      LegacyCommonCodes: {},
      pageInfo: {
        // paging info
        page: 1,
        size: 20,
        total: 0
      },
      sortInfo: {
        order: "",
        prop: ""
      }
    };
  },
  computed: {
    ...mapState({
      userInfo: state => state.userInfo
    }),
    carTypes: function() {
      const carTypes = this.$store.state.carTypes;
      if (carTypes && carTypes.length > 0) {
        carTypes.shift();
        carTypes.unshift({ carTypeCode: "all", carTypeName: "전체" });
      }
      return carTypes;
    },
    // allTypeCars: function() {
    //   const allTypeCars = this.$store.state.allTypeCars['all']
    //   if(allTypeCars && allTypeCars.length > 0) {
    //     allTypeCars.unshift({ 'carCode': 'all', 'carName': '전체' })
    //   }
    //   return allTypeCars
    // },
    consultants: function() {
      const consultants = this.$store.state.authConsultants.slice();
      if (consultants && consultants.length > 0) {
        consultants.unshift({
          useAuthId: "",
          sysUserNo: "",
          sysUserNm: "전체",
          opsNm: ""
        });
      }
      return consultants;
    },
    customerTypeCodes: function() {
      const customerTypeCodes = this.$store.state.commonCodesCustomerType;
      if (customerTypeCodes && customerTypeCodes.length > 0) {
        customerTypeCodes.shift();
        customerTypeCodes.unshift({ value: "all", label: "전체" });
      }
      return customerTypeCodes;
    }
  },
  async created() {
    await this.loadCommonCode();
  },
  mounted() {
    this.$store.dispatch("loadAuthConsultants", { vm: this });
    this.$store.dispatch("loadAllTypeCars", { vm: this });
    this.$store.dispatch("loadCommonCodesCustomerType", {
      vm: this,
      customerType: "customer"
    });

    if (
      this.userInfo.exclusiveUseAuthGroupIds.includes("WT001") &&
      !this.userInfo.exclusiveUseAuthGroupIds.includes("WT002")
    ) {
      // 일반 업무담당자 or 조회권한만 있는 업무담당자일 경우에만 default 로그인 사용자
      this.ruleForm.consultantId = [this.userInfo.eeno];
    }
  },
  methods: {
    sortChange(props) {
      const { prop, order } = props;

      let convertOrder = "";

      if (order === "descending") {
        convertOrder = "desc";
      } else if (order === "ascending") {
        convertOrder = "asc";
      }

      this.sortInfo = { prop, order: convertOrder };
      this.getData();
    },
    stringToDateChange(date) {
      const endYY = date.substring(0, 4)
      const endMM = date.substring(4, 6)
      const endDD = date.substring(6, 8)
      const endHour = date.substring(8, 10)
      const endMin = date.substring(10, 12)
      const endSec = date.substring(10, 12)
      const endDate = `${endYY}-${endMM}-${endDD} ${endHour}:${endMin}:${endSec}`
      return endDate
    },
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null;
      switch (systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {
          vm: this,
          codeTypeCode: codeType
        })
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {
          vm: this,
          codeTypeCode: codeType
        })
        break
      case 'W':
        res = this.$store.dispatch('loadCommonCodesW', {
          vm: this,
          codeTypeCode: codeType
        })
        break
      }
      return res
    },
    async loadCommonCode() {
      const [ccU019, ccT010, ccC013, ccT045, ccT048] = await Promise.all([
        this.fetchCommonCodeData("E", "U019"), // 구분
        this.fetchCommonCodeData("W", "T010"), // 임직원몰 진행상태
        this.fetchCommonCodeData("C", "C013"), // 레거시 진행상태
        this.fetchCommonCodeData("E", "T045"), // 취소사유
        this.fetchCommonCodeData("E", "T048"), // 취소사유
      ]);
      this.commonCodes = { ...ccU019, ...ccT010, ...ccT045, ...ccT048 };
      this.LegacyCommonCodes = { ...ccC013 };
      this.initRuleFormStatus();

      this.onlineProgressCodes = this.commonCodes.T010.slice(1)
        .map(el => {
          return el.label.replace(/\s/gi, '')
        })
        .reduce((unique, item) => {
          return unique.includes(item) ? unique : [...unique, item];
        }, []);
    },
    isValidAuthBtn(authId) {
      // 버튼별 권한 체크
      let bResult = false; // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || [];
      if (currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some(items => {
          if (items.btnId === authId) {
            bResult = true;
            return true;
          }
        });
      }
      return bResult;
    },
    onAddZero(contractNumber) {
      let resultString = "";
      if (contractNumber.length > 6) {
        const frontString = contractNumber.substring(0, 7);
        const backString = contractNumber.substring(7);

        resultString = resultString.concat(frontString);
        resultString = resultString.concat(
          backString.length >= 6
            ? backString
            : Array.from({ length: 6 - backString.length }, () => 0).join("") +
                backString
        );
      }

      if (!resultString) {
        resultString = contractNumber;
      }
      this.ruleForm.contractId = resultString;
    },
    resetSearchCond() {
      Object.assign(this.ruleForm, this.$options.data().ruleForm);
      this.searchDtRadio = "today";
    },
    onSearch(page) {
      if (!this.isValidAuthBtn("authSelect")) {
        // 권한없을경우 동작 x
        return;
      }

      this.$data.pageInfo.page = page;
      this.getData();
    },
    initRuleFormStatus() {
      if (
        this.ruleForm.legacyStatus &&
        this.ruleForm.legacyStatus.length === 0
      ) {
        // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false, "legacy");
      }
      if (
        this.ruleForm.onlineStatus &&
        this.ruleForm.onlineStatus.length === 0
      ) {
        // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false, "online");
      }
      if (
        this.ruleForm.consultantId &&
        this.ruleForm.consultantId.length === 0
      ) {
        // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false, "consultant");
      }

      if (this.ruleForm.searchType === "contractorName") {
        // 이름 검색일 경우 값 세팅
        this.ruleForm.contractorName = this.ruleForm.searchValue;
      } else {
        this.ruleForm.contractorName = "";
      }
      if (this.ruleForm.searchType === "businessNumber") {
        // 사업자번호 검색일 경우 값 세팅
        this.ruleForm.businessNumber = this.ruleForm.searchValue;
      } else {
        this.ruleForm.businessNumber = "";
      }
      if (this.ruleForm.searchType === "customerMobile") {
        // 휴대전화 검색일 경우 값 세팅
        this.ruleForm.customerMobile = this.ruleForm.searchValue.replace(/-/gi, '')
      } else {
        this.ruleForm.customerMobile = "";
      }
      if (this.ruleForm.searchType === "customerEamil") {
        // 이메일 검색일 경우 값 세팅
        this.ruleForm.customerEamil = this.ruleForm.searchValue;
      } else {
        this.ruleForm.customerEamil = "";
      }
      if (this.ruleForm.searchType === "companyNumber") {
        // 사업자번호 검색일 경우 값 세팅
        this.ruleForm.companyNumber = this.ruleForm.searchValue;
      } else {
        this.ruleForm.companyNumber = "";
      }
      if (this.deliveryCenterInventoryConfirmCompleteVal) {
        this.ruleForm.deliveryCenterInventoryConfirmCompleteVal = "Y";
      } else {
        this.ruleForm.deliveryCenterInventoryConfirmCompleteVal = "N";
      }
      if (this.nonPaymentVal) {
        this.ruleForm.nonPaymentVal = "Y";
      } else {
        this.ruleForm.nonPaymentVal = "N";
      }
    },
    selectedAll(e, type) {
      if (type === "online") {
        //온라인진행상태  체크박스 초기화////////////////////////////
        this.deliveryCenterInventoryConfirmCompleteVal = false
        this.nonPaymentVal = false
        this.ruleForm.deliveryCenterInventoryConfirmCompleteVal = 'N'
        this.ruleForm.nonPaymentVal = 'N'
        this.isDeliveryCenterInventoryConfirmComplete = true
        this.isNonPayment = true
        ///////////////////////////////////////////////////////////
        
        if (e) {
          this.ruleForm.onlineStatus =
            this.onlineProgressCodes.map(items => {
              return items;
            }) || [];
        } else {
          this.ruleForm.onlineStatus = [];
        }
      } else if (type === "legacy") {
        if (e) {
          this.ruleForm.legacyStatus =
            this.LegacyCommonCodes.C013.slice(1).map(items => {
              return items.value;
            }) || [];
        } else {
          this.ruleForm.legacyStatus = [];
        }
      } else if (type === "consultant") {
        if (e) {
          this.ruleForm.consultantId =
            this.consultants.slice(1).map(items => {
              return items.sysUserNo;
            }) || [];
        } else {
          this.ruleForm.consultantId = [];
        }
      }
    },
    onChangeMultiSelect(data, type) {
      if (type === "online") {
        //온라인진행상태  체크박스 초기화////////////////////////////
        this.deliveryCenterInventoryConfirmCompleteVal = false
        this.nonPaymentVal = false
        this.ruleForm.deliveryCenterInventoryConfirmCompleteVal = 'N'
        this.ruleForm.nonPaymentVal = 'N'
        ///////////////////////////////////////////////////////////

        if (data.length === this.commonCodes.T010.slice(1).length) {
          this.onlineSelectedVal = true;
        } else {
          this.onlineSelectedVal = false;
        }

        const selOnlineStatus =
          data.length === 1 && data.includes("생산완료or결제대기");
        if (selOnlineStatus) {
          this.isDeliveryCenterInventoryConfirmComplete = false;
        } else {
          this.isDeliveryCenterInventoryConfirmComplete = true;
        }

        const selOnlineStatusPayment =
        data.length === 1 && data.includes("결제완료");
        if (selOnlineStatusPayment) {
          this.isNonPayment = false;
        } else {
          this.isNonPayment = true;
        }
      } else if (type === "legacy") {
        if (data.length === this.LegacyCommonCodes.C013.slice(1).length) {
          this.legacySelectedVal = true;
        } else {
          this.legacySelectedVal = false;
        }
      } else if (type === "consultant") {
        if (data.length === this.consultants.slice(1).length) {
          this.consultantSelectedVal = true;
        } else {
          this.consultantSelectedVal = false;
        }
      }
    },
    toggleSelectionAll() {
      if(this.checked) {
        this.tableData.map((items) => { items.isSelected = true })
      }
      else {
        this.tableData.map((items) => { items.isSelected = false })
      }
    },
    async getData() {
      //날짜 포맷 API형식에 맞추기
      const searchFromDt = moment(this.ruleForm.searchFromDt).format(
        "YYYYMMDD"
      );
      const searchEndDt = moment(this.ruleForm.searchEndDt).format("YYYYMMDD");
      if (!this.ruleForm.searchFromDt || !this.ruleForm.searchEndDt) {
        this.alertMessage = "날짜는 필수입력사항입니다.";
        this.alertMessagePop = true;
        return false;
      }
      if (searchEndDt - searchFromDt > 10000) {
        this.alertMessage = "최대 조회 가능기간은 1년입니다.";
        this.alertMessagePop = true;
        return false;
      }

      this.initRuleFormStatus();

      const { page, size } = this.$data.pageInfo;

      const params = {
        ...this.ruleForm,
        carCode: this.ruleForm.carCode !== "all" ? this.ruleForm.carCode : "",
        carTypeCode:
          this.ruleForm.carTypeCode !== "all" ? this.ruleForm.carTypeCode : "",
        // legacyStatus: this.ruleForm.legacyStatus !== 'all' ? this.ruleForm.legacyStatus : '',
        // onlineStatus: this.ruleForm.onlineStatus !== 'all' ? this.ruleForm.onlineStatus : '',
        customerTypeCode:
          this.ruleForm.customerTypeCode !== "all"
            ? this.ruleForm.customerTypeCode
            : "",
        contractCancleCode:
          this.ruleForm.contractCancleCode !== "all"
            ? this.ruleForm.contractCancleCode
            : "",
        searchFromDt,
        searchEndDt,
        pageNo: page,
        pageSize: size,
        sortingId: this.sortInfo.prop,
        sortingType: this.sortInfo.order
      };
      this.popVisibleLoading = true;
      // API-E-업무담당자-010 (계약출고현황)
      const [res, err] = await this.$https.post(
        "/v2/exclusive/contract",
        params
      );
      if (!err) {
        if (!res.data || !res.data.list || res.data.list.length === 0) {
          this.tableData = [];
        } else {
          this.tableData = res.data.list.map((el, idx) => {
            return {
              ...el,
              no: res.data.total - res.data.endRow + res.data.list.length - idx,
              isSelected: false,
              carPrice: el.carPrice && (el.carPrice * 1).toLocaleString(),
              contractPrice:
                el.contractPrice && (el.contractPrice * 1).toLocaleString(),
              discountPrice:
                el.discountPrice && (el.discountPrice * 1).toLocaleString(),
              usePoint: el.usePoint && (el.usePoint * 1).toLocaleString(),
              taxReduction:
                el.taxReduction && (el.taxReduction * 1).toLocaleString(),
              deliveryPrice:
                el.deliveryPrice && (el.deliveryPrice * 1).toLocaleString(),
              insurancePayment:
                el.insurancePayment &&
                (el.insurancePayment * 1).toLocaleString(),
              cashPayment:
                el.cashPayment && (el.cashPayment * 1).toLocaleString(),
              installment:
                el.installment && (el.installment * 1).toLocaleString(),
              cardPayment:
                el.cardPayment && (el.cardPayment * 1).toLocaleString(),
              depositAmount:
                el.depositAmount && (el.depositAmount * 1).toLocaleString(),
              releaseDate: el.releaseDate
                ? moment(el.releaseDate).format("YYYY-MM-DD")
                : el.releaseExpectedDate &&
                  moment(el.releaseExpectedDate).format("YYYY-MM-DD"),
              contractDate:
                el.contractDate && moment(el.contractDate).format("YYYY-MM-DD"),
              contractCompletionDate:
                el.contractCompletionDate &&
                moment(el.contractCompletionDate).format("YYYY-MM-DD"),
              assignRequestDate:
                el.assignRequestDate &&
                moment(el.assignRequestDate).format("YYYY-MM-DD"),
              assignDate:
                el.assignDate && moment(el.assignDate).format("YYYY-MM-DD"),
              craftCertificateDate:
                el.craftCertificateDate &&
                moment(el.craftCertificateDate).format("YYYY-MM-DD"),
              cancelDate:
                el.cancelDate && moment(el.cancelDate).format("YYYY-MM-DD"),
              carSaleCode: el.carSaleCode || "코드없음"
            };
          });

          this.$data.pageInfo = {
            ...this.$data.pageInfo,
            total: res.data.total
          };

          console.log("/v2/exclusive/contract", this.tableData);
        }
        this.popVisibleLoading = false;
      } else {
        this.popVisibleLoading = false;
        console.error(err);
      }
    },
    async downloadExcel() {
      this.initRuleFormStatus();

      const params = {
        ...this.ruleForm,
        carCode: this.ruleForm.carCode !== "all" ? this.ruleForm.carCode : "",
        carTypeCode:
          this.ruleForm.carTypeCode !== "all" ? this.ruleForm.carTypeCode : "",
        // legacyStatus: this.ruleForm.legacyStatus !== 'all' ? this.ruleForm.legacyStatus : '',
        onlineStatus:
          this.ruleForm.onlineStatus !== "all"
            ? this.ruleForm.onlineStatus
            : "",
        customerTypeCode:
          this.ruleForm.customerTypeCode !== "all"
            ? this.ruleForm.customerTypeCode
            : "",
        contractCancleCode:
          this.ruleForm.contractCancleCode !== "all"
            ? this.ruleForm.contractCancleCode
            : "",
        searchFromDt: moment(this.ruleForm.searchFromDt).format("YYYYMMDD"),
        searchEndDt: moment(this.ruleForm.searchEndDt).format("YYYYMMDD")
      };

      // API-E-업무담당자-011 (계약출고현황 목록 엑셀저장)
      const [res, err] = await this.$https.post(
        "/v2/exclusive/contract-excel",
        params,
        null,
        null,
        { responseType: "blob" }
      );
      if (!err) {
        const blob = new Blob([res], { type: res.Type });
        const nowDate = moment().format("YYYYMMDD_HHmm");
        if (window.navigator.msSaveOrOpenBlob) {
          // IE11
          window.navigator.msSaveOrOpenBlob(
            blob,
            "계약출고현황목록_" + nowDate + ".xlsx"
          );
        } else {
          // IE11 외 브라우저
          const blobURL = window.URL.createObjectURL(blob);
          const tempLink = document.createElement("a");

          tempLink.href = blobURL;

          tempLink.setAttribute(
            "download",
            "대고객계약출고현황목록_" + nowDate + ".xlsx"
          );
          document.body.appendChild(tempLink);
          tempLink.click();
          document.body.removeChild(tempLink);
          window.URL.revokeObjectURL(blobURL);
        }
        // screenUseTypeCode (01:열람,02:수정,03:삭제,04:인쇄,05:입력,06:업로드,07:다운로드)
        this.$store.dispatch('commonSupportLog', { vm: this, params: { screenUseTypeCode: '07', fileName: '계약출고현황목록_' + nowDate + '.xlsx', fileSize: blob.size, useInfo: JSON.stringify(params) } })
      } else {
        console.error(err);
        this.tableData = null;
      }
    },
    onChangeSearchDtRadio(val) {
      if (val === "lastDay") {
        this.ruleForm.searchFromDt = moment().subtract("days", 1);
        this.ruleForm.searchEndDt = moment().subtract("days", 1);
      } else if (val === "today") {
        this.ruleForm.searchFromDt = moment();
        this.ruleForm.searchEndDt = moment();
      } else if (val === "day7") {
        this.ruleForm.searchFromDt = moment().subtract("days", 7);
        this.ruleForm.searchEndDt = moment();
      } else if (val === "day30") {
        this.ruleForm.searchFromDt = moment().subtract("days", 30);
        this.ruleForm.searchEndDt = moment();
      } else if (val === "month3") {
        this.ruleForm.searchFromDt = moment().subtract("months", 3);
        this.ruleForm.searchEndDt = moment();
      } else if (val === "month6") {
        this.ruleForm.searchFromDt = moment().subtract("months", 6);
        this.ruleForm.searchEndDt = moment();
      } else if (val === "month12") {
        this.ruleForm.searchFromDt = moment().subtract("months", 12);
        this.ruleForm.searchEndDt = moment();
      }
    },
    /* onChange(val, row) {
      this.tableData
        .filter(items => {
          return items.no !== row.no;
        })
        .map(items => {
          items.isSelected = false;
        });
    },*/
    changeReleaseDate() {
      let selectionItems = this.tableData.filter(items => {
        return items.isSelected === true;
      });

      if (selectionItems.length === 0) {
        this.alertMessage = "계약을 먼저 선택해주세요.";
        this.alertMessagePop = true;
      } else {
        
        this.multipleSelection = selectionItems.filter(items => {
          return items.releaseOrExpectDate;
        });

        /* this.multipleSelection = selectionItems.filter(items => {
          return Number(items.legacyStatusCode) < 40;
        });
 */
        /* ############################# W Project - <2022-03-25> - <A934118> - START ###################################### */
        this.multipleSelection = selectionItems.filter(items => {
          return items.legacyStatusName === "배정"; // 출고예정일 동시 변경시 국판상태명 배정만 처리
        });
        /* ############################# W Project - <2022-03-25> - <A934118> - END ###################################### */

        if (this.multipleSelection.length === 0) {
          this.alertMessage = "배정 상태에서 출고예정일 변경이 가능합니다.";
          this.alertMessagePop = true;
        } else {
          this.popReleaseDate = true;
        }
      }
    },
    async changePaymentDate() {
      let selectionItems = this.tableData.filter(items => {
        return items.isSelected === true;
      });

      if (selectionItems.length === 0) {
        this.alertMessage = "계약을 먼저 선택해주세요.";
        this.alertMessagePop = true;
      } else {


        this.multipleSelection = selectionItems.filter(items => {
          return items.payExpireDate;
        });

        /* ############################# W Project - <2022-03-25> - <A934118> - START ###################################### */
        /* 2022-03-25 : #12165 [시스템 안정화][구매지원시스템] 결제기한일 에 출고예정일 연기 기능 포함 필요
         결제기한일 : 결제대기 상태에서만 변경 */
        this.multipleSelection = selectionItems.filter(items => {
          return items.onlineStatusCode === "0093"; // 결제대기만 변경
        });

        let paymentAfterInput = moment().format("YYYYMMDDHHMMss")

        for(let i=0; i< this.multipleSelection.length; i++){
          console.log("legacyStatusName ===> " + this.multipleSelection[i].legacyStatusName)
          let paymentLimitDate = ""
          const postParam = {
              saleContractNo : this.multipleSelection[i].contractNumber,
              paymentStartDate : paymentAfterInput
            }

            const [res, err] = await this.$https.post("/v2/exclusive/work/payment-time-limit/info", postParam)

            if (!err) {
              if (res.rspStatus && res.rspStatus.rspCode === '0000') {
                paymentLimitDate = res.data.paymentLimitDate
                console.log("res.data.paymentLimitDate ===> " + paymentLimitDate)
              }
            } else {
              console.log("error ===> ")
              this.alertMessage = err.rspMessage;
              this.alertMessagePop = true;
              console.error(err);
            }
            if(this.multipleSelection[i].legacyStatusName === "배정"){
              if(paymentLimitDate !== null){
                this.multipleSelection[i].payAfterDate = this.stringToDateChange(paymentLimitDate)
              }
            } else {
                this.multipleSelection[i].payAfterDate = "배정 상태 아님"
            }
        }
        /* ############################# W Project - <2022-03-25> - <A934118> - END ###################################### */

        if (this.multipleSelection.length === 0) {
          this.alertMessage = "결제대기 상태에서만 변경이 가능합니다.";
          this.alertMessagePop = true;
        } else {
          this.popPaymentDate = true;
        }
      }
    },
    changePaymentRequest() {
      let selectionItems = this.tableData.filter(items => {
        return items.isSelected === true;
      });

      if (selectionItems.length === 0) {
        this.alertMessage = "계약을 먼저 선택해주세요.";
        this.alertMessagePop = true;
      } else {
        
        this.multipleSelection = selectionItems.filter(items => {
          return (
            items.releaseOrExpectDate &&
            !items.payExpireDate
          );
        });

        /* this.multipleSelection = selectionItems.filter(items => {
          return (
            items.deliveryCenterInventoryConfirmCompleteYn === "N" &&
            items.onlineStatusCode === "0093"
          );
        }); */

        if (this.multipleSelection.length === 0) {
          this.alertMessage = "생산완료 상태에서만 변경이 가능합니다.";
          this.alertMessagePop = true;
        } else {
          this.$refs.payReqPop.openPop();
        }
      }
    },
    async saveReleaseDate() {
      const body = this.multipleSelection.map(el => {
        return {
          contractNumber: el.contractNumber,
          deliveryExpectedDate: moment(this.dateAfter).format("YYYYMMDD")
        };
      });

      if (body.length === 0) {
        this.alertMessage = "변경 할 목록이 없습니다.";
        this.alertMessagePop = true;
      } else {
        console.log(body);
        let obj = { result: false, resultList: [], errContract: [], err: {} };

        for (const item of body) {
          const [res, err] = await this.$https.postNoErrMsg(
            "/purchase/v2/purchase/contract/due-date",
            item,
            null,
            "gateway"
          );

          if (!err) {
            /* console.log(res);
              this.alertMessage = "변경되었습니다.";
              this.alertMessagePop = true;
              // this.alertContinueChange = false
              this.popReleaseDate = false; */
            /*   this.multipleSelection.map(el => {
                el.releaseExpectDate = moment(this.dateAfter).format("YYYY-MM-DD");
              }); */

            obj.result = true;
            obj.resultList.push(item);
          } else {
            console.log("error : " + item.contractNumber);
            obj.errContract.push(item.contractNumber);
            obj.err = err;
          }
        }

        if (obj.result) {
          this.alertMessage = "변경되었습니다.";
          this.alertMessagePop = true;
          // this.alertContinueChange = false
          this.popReleaseDate = false;

          this.multipleSelection.map(el => {
            el.releaseExpectDate = moment(this.dateAfter).format("YYYY-MM-DD");
          });
        } else {
          this.alertMessage = obj.err.rspMessage;
          this.alertMessagePop = true;
          console.error(obj.err);
        }
      }
    },
    async onSavePaymentDate() {
      this.popVisibleLoading = true
      const body = this.multipleSelection.map(el => {
        return {
          saleCnttNo: el.contractNumber,
          vbgStlStrtDtm: moment(this.paymentAfter).format("YYYYMMDDHHMMss")
          //data: el
        };
      });

      // 결제기한일 체크
      let inputDate = moment(this.paymentAfter).format("YYYYMMDDHHMMss")
      let nowDate = moment().format("YYYYMMDDHHMMss")
      console.log("결제기한일 ==> " + inputDate);
      console.log("현재일시   ==> " + nowDate);
      // if (inputDate < nowDate) {
      //     this.popVisibleLoading = false;
      //     this.alertMessage = "결제기한일은 현재시간 이후 일시를 입력하셔야 합니다.";
      //     this.alertMessagePop = true;
      //     return false;
      // }

      if (body.length === 0) {
        this.alertMessage = "변경 할 목록이 없습니다.";
        this.alertMessagePop = true;
      } else {
        console.log(body);
        let obj = { result: false, resultList: [], errContract: [], err: {} };

        for (const item of body) {
          const [res, err] = await this.$https.postNoErrMsg(
            "/payment/v2/payment/payment-start-date",
            item,
            null,
            "gateway"
          ); // TODO: 다중선택으로 변경시 body[0] => body로 변경
          if (!err) {
            /* console.log(res);
            this.alertMessage = "변경되었습니다.";
            this.alertMessagePop = true;
            this.popPaymentDate = false;

            this.multipleSelection.map(el => {
              el.payStartDate = moment(this.paymentAfter).format(
                "YYYY-MM-DD HH:mm"
              );
            }); */
            //receiverTel: data.customerMobile,
            /* this.$utils.sendMessageAll(this, {
              messageTemplateId: "wp_1201001",
              messageParams: {
                cnttNo: item.saleCnttNo,
                mdlNm: data.saleModelName,
                date: moment(this.dateAfter).format("YYYY년 MM월 DD일")
              },
              sendChannelCode: "003",
              saleContractNo: item.saleCnttNo,
              customerMgmtNo: data.customerManagementNo,
              customerUniqueNo: data.employeeId,
              receiverName: data.contractorName,
              receiverTel: data.customerMobile,
              fileGroupSerialNo: ""
            }); */
            obj.result = true;
            obj.resultList.push(item);
          } else {
            //console.error(err);

            console.log("error : " + item.contractNumber);
            obj.errContract.push(item.contractNumber);
            obj.err = err;
          }
        }

        /* ############################# W Project - <2022-03-25> - <A934118> - START ###################################### */
        // 출고 예정일 변경 포함  기능 추가
        if(this.deliveryDueDateChangYn) {
          const bodyDlv = this.multipleSelection.map(el => {
            console.log("el.legacyStatusName ====> " + el.legacyStatusName)
            return {
              contractNumber: el.contractNumber,
              deliveryExpectedDate: moment(el.payAfterDate).format("YYYYMMDD"),
              legacyStatusName: el.legacyStatusName
              //data: el
            };
          });
          if (bodyDlv.length !== 0) {
            for (const item of bodyDlv) {
              if(item.legacyStatusName === "배정"){ 
                const [res, err] = await this.$https.postNoErrMsg(
                  "/purchase/v2/purchase/contract/due-date",
                  item,
                  null,
                  "gateway"
                );
              }
            }
          }
        }
        /* ############################# W Project - <2022-03-25> - <A934118> - END ###################################### */
        this.popVisibleLoading = false

        if (obj.result) {
          this.alertMessage = "변경되었습니다.";
          this.alertMessagePop = true;
          // this.alertContinueChange = false
          this.popReleaseDate = false;

          this.multipleSelection.map(el => {
            el.payStartDate = moment(this.paymentAfter).format(
              "YYYY-MM-DD HH:mm"
            );
          });
        } else {
          this.alertMessage = obj.err.rspMessage;
          this.alertMessagePop = true;
          console.error(obj.err);
        }
      }
    },
    async changePayAfterDate() {
      let paymentAfterInput = moment(this.paymentAfter).format("YYYYMMDDHHMMss")
      let paymentLimitDateYn = false

      for(let i=0; i< this.multipleSelection.length; i++){
         let paymentLimitDate = ""
         const postParam = {
            saleContractNo : this.multipleSelection[i].contractNumber,
            paymentStartDate : paymentAfterInput
          }

          const [res, err] = await this.$https.post("/v2/exclusive/work/payment-time-limit/info", postParam)

          if (!err) {
            if (res.rspStatus && res.rspStatus.rspCode === '0000') {
              console.log("res.data.paymentLimitDate ===> " + res.data.paymentLimitDate)
              paymentLimitDate = res.data.paymentLimitDate
            }
          } else {
            console.log("error ===> ")
            this.alertMessage = err.rspMessage;
            this.alertMessagePop = true;
            console.error(err);
          }
          if(this.multipleSelection[i].legacyStatusName === "배정"){
            if(paymentLimitDate !== null){
              this.multipleSelection[i].payAfterDate = this.stringToDateChange(paymentLimitDate)
            }
          } else {
              this.multipleSelection[i].payAfterDate = "배정 상태 아님"
          }           
      }

      const body = this.multipleSelection.map(el => {
        return {
          contractNumber: el.contractNumber,
          payStartDate: el.payStartDate,
          payAfterDate: el.payAfterDate,
          legacyStatusName : el.legacyStatusName
        };
      });

      this.multipleSelection = body
    },
    async onSavePaymentRequest() {
      // 빠른결제요청 상태 변경
      const body = {
        contractNoList: this.multipleSelection.map(el => {
          return el.contractNumber;
        })
      };

      if (body.length === 0) {
        this.alertMessage = "변경 할 목록이 없습니다.";
        this.alertMessagePop = true;
      } else {
        console.log(body);
        const [res, err] = await this.$https.post(
          "/purchase/v2/purchase/contract/quickPayment/request",
          body,
          null,
          "gateway"
        ); // TODO: 다중선택으로 변경시 body[0] => body로 변경
        if (!err) {
          console.log(res);
          if (res.data.resultYn === "Y") {
            this.alertMessage = "변경되었습니다.";
            this.alertMessagePop = true;
            this.popPaymentDate = false;

            this.multipleSelection.map(el => {
              el.payStartDate = moment(this.paymentAfter).format(
                "YYYY-MM-DD HH:mm"
              );
            });
          } else {
            this.alertMessage = res.data.resultMessage;
            this.alertMessagePop = true;
            this.popPaymentDate = false;
          }
        } else {
          console.error(err);
        }

        this.$refs.payReqPop.closePop();
      }
    },
    async onChangeTypeCars(carTypeCode) {
      // 차종별 해당 차명 목록 추출
      this.ruleForm.carCode = "all";
      const [res, err] = await this.$https.get(
        "/v2/exclusive/contract/repncarCode",
        { carTypeCode }
      );
      if (err) {
        console.log("err", err);
        return;
      }

      this.selTypeCars = res.data.map(items => {
        return {
          repnCarName: items.repnCarName,
          repnCarCode: items.repnCarCode
        };
      });
      this.selTypeCars.unshift({ repnCarName: "전체", repnCarCode: "all" });
      // res.data && res.data.map((items) => { return { label: items.codeName, value: items.code } })
    },
    oneClickDisable(event, clickEvent, ...args) {
      if(event.target.disabled === true){
        retrun
      }

      event.target.disabled = true

      try {
        clickEvent(...args)
      } catch {}
      setTimeout(() => {
        event.target.disabled = false
      }, 2000)
    }    
  }
};
</script>

<style lang="scss" scoped>
@import "~/assets/style/pages/release.scss";
</style>
