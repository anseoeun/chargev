<template>
  <section>
    <div id="release-detail">
      <div class="article-title">
        <h-search
          v-model="contractNumber"
          :title="'계약번호'"
          :on-click="searchContract"
          :active-button="isValidAuthBtn('authSelect')"
          @enter="searchContract"
          @keydown.native.tab="onAddZero(contractNumber)"
        />
        <div class="btn-group">
          <div>
            <!-- <el-button
              v-if="
                isValidAuthBtn('authExclusive') &&
                  (isAuth || userInfo.eeno === info.consultantId) &&
                  (info.legacyStatusCode === '20' ||
                    info.legacyStatusCode === '30')
              "
              type="primary"
              :disabled="
                !contractNumber ||
                  (info.contractCarTypeCode === '20' ||
                    info.contractCarTypeCode === '30' ||
                    info.contractCarTypeCode === '40')
              "
              @click="onSavePaymentRequest()"
            >
              빠른 결제요청
            </el-button> -->
            <el-button
              @click="popVisibleCancelCarAllocation = true"
              v-if="
                isValidAuthBtn('authExclusive') &&
                  (isAuth || userInfo.eeno === info.consultantId) &&
                  //2022-02-24 배정취소 버튼 노출기준을 대고객 노출기준하고 동일하게 적용함. A934118
                  //releaseCancleChack &&
                  (info.legacyStatusCode === '20' ||
                    info.legacyStatusCode === '30') &&
                  contractData.specialOrderYn === 'N' &&
                  contractData.contractCarTypeCode === '50'
              "
              type="primary"
              :disabled="
                !contractNumber || !activeFlag ||
                  (contractData.contractCarTypeCode === '20' ||
                    contractData.contractCarTypeCode === '30' ||
                    contractData.contractCarTypeCode === '40')
              "
            >
              배정취소
            </el-button>
            <el-button
              v-if="
                isValidAuthBtn('authExclusive') &&
                  (isAuth || userInfo.eeno === info.consultantId) &&
                  info.legacyStatusCode === '10' &&
                  (info.onlineStatusCode === '0999')
              "
              type="primary"
              :disabled="!contractNumber || !activeFlag"
              @click="alertVisibleReassignment = true"
            >
              재배정
            </el-button>
            <!-- <el-button
              v-if="
                isValidAuthBtn('authExclusive') &&
                  (isAuth || userInfo.eeno === info.consultantId)
              "
              type="primary"
              :disabled="!contractNumber || info.legacyStatusCode === '90'"
            >
              전담DC품의
            </el-button> -->
            <el-button
              v-if="
                isValidAuthBtn('authExclusive') &&
                  (isAuth || userInfo.eeno === info.consultantId)
              "
              type="primary"
              :disabled="
                !contractNumber || !activeFlag ||
                  (info.onlineStatusCode !== '0330' &&
                    info.onlineStatusCode !== '0320')
              "
              @click="popShow.reservedCenterPop = true"
            >
              방문예약
            </el-button>
            <el-button
              v-if="
                isValidAuthBtn('authExclusive') &&
                  (isAuth || userInfo.eeno === info.consultantId)
              "
              type="primary"
              :disabled="!contractNumber || !activeFlag"
              @click="openPopSms()"
            >
              문자보내기
            </el-button>
            <el-button
              v-if="isValidAuthBtn('authSelect')"
              type="primary"
              :disabled="!contractNumber || !activeFlag"
              @click="estimationView"
            >
              견적보기
            </el-button>
            <el-button
              v-if="
                isValidAuthBtn('authExclusive') &&
                  (isAuth || userInfo.eeno === info.consultantId) &&
                  showBtnCarMakeCertification
              "
              type="primary"
              :disabled="
                !contractNumber || !activeFlag ||
                  (info.onlineStatusCode !== '0600' &&
                    info.onlineStatusCode !== '0610' &&
                    info.onlineStatusCode !== '0710' &&
                    info.onlineStatusCode !== '0800' &&
                    info.onlineStatusCode !== '0810')
              "
              @click="oneClickDisable($event, issueCarCertification)"
            >
              제작증 발급
            </el-button>
          </div>
          <div>
            <el-button
              type="primary"
              :disabled="
                !contractNumber || !activeFlag || info.applyDcYn !== 'Y'
              "
              @click="oneClickDisable($event, applyExrsDcStatus)"
            >
              전담DC 적용
            </el-button>
            <el-button
              v-if="
                isValidAuthBtn('authExclusive') &&
                  (isAuth || userInfo.eeno === info.consultantId)
              "
              type="primary"
              :disabled="
                !contractNumber ||!activeFlag ||
                  (info.onlineStatusCode !== '9109' &&
                    info.onlineStatusCode !== '9125' &&
                    info.onlineStatusCode !== '9126' &&
                    info.onlineStatusCode !== '9131')
              "
              @click="checkPaymentInitPop = true"
            >
              결제 초기화
            </el-button>
            <!-- 출고센터도착 상태 추가 시 수정필요 -->
            <el-button
              v-if="
                isValidAuthBtn('authExclusive') &&
                  (isAuth || userInfo.eeno === info.consultantId)
              "
              type="primary"
              :disabled="
                !contractNumber || !activeFlag ||
                  info.legacyStatusCode === '71' ||
                  info.legacyStatusCode === '91' ||
                  (info.legacyStatusCode === '70' &&
                    info.onlineStatusCode !== '0099'&&
                    info.onlineStatusCode !== '0035'&&
                    info.onlineStatusCode !== '0036') ||
                  (info.legacyStatusCode === '90' &&
                    info.onlineStatusCode !== '0099'&&
                    info.onlineStatusCode !== '0035'&&
                    info.onlineStatusCode !== '0036')||
                    info.onlineStatusCode === '0110'||
                    info.onlineStatusCode === '0120'||
                    info.onlineStatusCode === '0130'||
                    info.onlineStatusCode === '0200'||
                    info.onlineStatusCode === '9108'||
                    info.onlineStatusCode === '9109'||
                    info.onlineStatusCode === '9131'
              "
              @click="alertVisibleCancelPayAsk = true"
            >
              해약
            </el-button>
            <el-button
              v-if="
                isValidAuthBtn('authPayment') &&
                  (isAuth || userInfo.eeno === info.consultantId)
              "
              type="primary"
              :disabled="!info.contractNumber || !activeFlag || info.legacyStatusCode === '90'"
              @click="popVisibleActivatePay = true"
            >
              결제항목 활성화
            </el-button>
            <el-button
              v-if="
                isValidAuthBtn('authExclusive') &&
                  (isAuth || userInfo.eeno === info.consultantId)
              "
              type="primary"
              :disabled="!contractNumber || !activeFlag || info.legacyStatusCode === '90'"
              @click="popVisibleRequestPaper = true"
            >
              서류요청
            </el-button>
          </div>
        </div>
      </div>

      <h-relese-info
        :info="info"
        :active-user-flag.sync="activeFlag"
        @alertMsg="
          msg => {
            alertMessage = msg;
            alertMessagePop = true;
          }
        "
      />

      <div class="box" v-if="info.contractPersonalCorporationCode === '3'">
        <h-title title="구매차량목록" />
        <el-table
          :data="purchaseCarList"
          class="box"
          :row-class-name="tableRowClassName"
        >
          <el-table-column
            prop="no"
            label="NO."
            width="60"
            align="center"
          ></el-table-column>
          <el-table-column
            prop="contractNumber"
            label="계약번호"
            width="200"
            align="center"
          ></el-table-column>
          <el-table-column
            prop="contractCarTypeName"
            label="차량유형"
            width="150"
            align="center"
          ></el-table-column>
          <el-table-column
            prop="carSpec"
            label="판매 SPEC"
            width="300"
            align="center"
          ></el-table-column>
          <el-table-column
            prop="taxationSectionalName"
            label="과세 구분"
            width="120"
            align="center"
          ></el-table-column>
          <el-table-column
            prop="taxationTypeName"
            label="면세 유형"
            width="120"
            align="center"
          ></el-table-column>
          <el-table-column
            prop="onlineStatusName"
            label="온라인 진행상태"
            width="200"
            align="center"
          ></el-table-column>
          <el-table-column label="서류심사 상태" width="200" align="center">
            <template slot-scope="scope">
              {{ scope.row.workProcessResultName || "-" }}
            </template>
          </el-table-column>
          <el-table-column
            prop="legacyStatusName"
            label="판매 진행상태"
            width="200"
            align="center"
          ></el-table-column>
          <!-- <el-table-column label="결제 진행상태" width="200" align="center">
            <template slot-scope="scope">
              {{ scope.row.paymentStateName || "-" }}
            </template>
          </el-table-column>          
          <el-table-column label="출고증 발급요청" width="200" align="center">
            <template slot-scope="scope">
              {{ scope.row.qSignYn }}
              <el-button
                v-if="
                  isValidAuthBtn('authExclusive') &&
                    (activeFlag || isAuth) &&
                    scope.row.qSignYn !== 'Y'
                "
                type="info"
                class="btn-qsign"
                @click="updateContractAssignPopup(scope.row.contractNumber)"
              >
                결제승인
              </el-button>
            </template>
          </el-table-column>
          <el-table-column
            prop="taxBillYn"
            label="세금 계산서"
            width="200"
            align="center"
          ></el-table-column> -->
          <el-table-column
            prop="contractCompleteDate"
            label="계약완료일"
            width="160"
            align="center"
          ></el-table-column>
          <el-table-column
            prop="paymentCompleteDate"
            label="결제완료일"
            width="160"
            align="center"
          ></el-table-column>
          <el-table-column
            prop="AcquisitionDate"
            label="인도확정일"
            width="160"
            align="center"
          ></el-table-column>
          <el-table-column
            prop="delveryDate"
            label="출고일"
            width="160"
            align="center"
          ></el-table-column>
          <el-table-column
            prop="certificateIssueDate"
            label="제작증발급일"
            width="160"
            align="center"
          ></el-table-column>
        </el-table>
      </div>

      <div class="article">
        <el-tabs
          v-model="activeName"
          type="card"
          stretch
          @tab-click="handleTabClick"
        >
          <el-tab-pane label="계약정보" name="first">
            <contract-info
              ref="contractInfo"
              :contract-number.sync="contractNumber"
              :contract-data.sync="contractData"
              :contract-info-data.sync="info"
              :user-info-data.sync="userInfo"
              :common-codes.sync="commonCodes"
              :active-user-flag.sync="activeFlag"
              @refresh="onRefresh($event, 'contract')"
            />
          </el-tab-pane>
          <el-tab-pane label="차량정보" name="second">
            <car-info
              ref="CarInfo"
              :contract-info-data.sync="info"
              :contract-number.sync="contractNumber"
              :active-user-flag.sync="activeFlag"
              @data="getCarProductionNumber"
              @searchContract="searchContract"
            />

            <!-- <car-info
              :car-info-data.sync="carInfoData"
              :choice-option-names.sync="choiceOptionNames"
              :tuix-option-names.sync="tuixOptionNames"
            /> -->
          </el-tab-pane>
          <el-tab-pane label="결제정보" name="third">
             <pay-info
              ref="payInfo" 
              :contract-number.sync="contractNumber" 
              :user-info-data.sync="userInfo" 
              :contract-data.sync="contractData" 
              :contract-info-data.sync="info" 
              :common-codes.sync="commonCodes" 
              :active-user-flag.sync="activeFlag" 
              @searchContractAssignChange="searchContractAssignChange(contractNumber)"          
              @refresh="onRefresh($event, 'pay')" 
            />
          </el-tab-pane>
          <el-tab-pane label="출고정보" name="fourth">
            <release-info
              ref="releaseInfo"
              :contract-info-data.sync="info"
              :contract-data.sync="contractData"
              :active-user-flag.sync="activeFlag"
              @refresh="onRefresh($event, 'release')"
            />
          </el-tab-pane>
          <el-tab-pane label="상태이력" name="fifth">
            <status-history
              ref="StatusHistory"
              :contract-number.sync="contractNumber"
              :active-user-flag.sync="activeFlag"
            />
            <!-- 상태이력 화면 컴포넌트화로 인한 주석처리 <A936507> -->
            <!-- <status-history
              ref="StatusHistory"
              :data.sync="statusTabData"
              :contract-number.sync="contractNumber"
            /> -->
          </el-tab-pane>
          <el-tab-pane label="문자이력" name="sixth">
            <sms-history
              ref="SmsHistory"
              :contract-number.sync="contractNumber"
              :active-user-flag.sync="activeFlag"
            />
            <!-- <sms-history
              :data.sync="messageTabData"
              @refresh="onRefresh($event, 'sms')"
            /> -->
          </el-tab-pane>
        </el-tabs>
      </div>

      <loading
        :pop-visible.sync="popVisibleLoading"
        @close="popVisibleLoading = false"
      />

      <!-- 조회결과없음 팝업 -->
      <el-dialog custom-class="message" :visible.sync="alertNoData">
        <!-- Message -->
        조회 결과가 없습니다.

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button type="info" @click="alertNoData = false">
            확인
          </el-button>
        </template>
      </el-dialog>

      <!-- 해약 팝업 -->
      <el-dialog title="해약처리" :visible.sync="alertVisibleCancelPayAsk">
        <!-- Popup Contents -->
        <div class="board-wrap">
          <table class="tbl-detail">
            <colgroup>
              <col style="width:20%;" />
              <col style="width:40%;" />
              <col style="width:40%;" />
            </colgroup>
            <thead>
              <tr>
                <th>구분</th>
                <th>변경 전</th>
                <th>변경 후</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th>온라인 계약상태</th>
                <td align="center">{{ info.onlineStatusName }}</td>
                <td align="center" v-if="Number(info.legacyStatusCode) < 60">
                  <template
                    v-if="
                      info.onlineStatusCode === '0035' ||
                        info.onlineStatusCode === '0036' ||
                        info.onlineStatusCode === '0099'
                    "
                  >
                    {{
                      payDetail.paymentCompletePriceTotal -
                        payDetail.refundCompletePriceTotal >
                      0
                        ? "-"
                        : "계약취소(환불완료)"
                    }}
                  </template>
                  <template v-else>
                    {{
                      payDetail.paymentCompletePriceTotal -
                        payDetail.refundCompletePriceTotal >
                      0
                        ? "계약취소(환불대기)"
                        : "계약취소(환불완료)"
                    }}
                  </template>
                </td>
                <td align="center" v-if="!(Number(info.legacyStatusCode) < 60)">
                  <template v-if="Number(info.legacyStatusCode) < 70">
                    -
                  </template>
                  <template v-else>
                    {{
                      payDetail.paymentCompletePriceTotal -
                        payDetail.refundCompletePriceTotal >
                      0
                        ? "-"
                        : "계약취소(환불완료)"
                    }}
                  </template>
                </td>
              </tr>
              <tr>
                <th>국판 계약상태</th>
                <td align="center">{{ info.legacyStatusName }}</td>
                <td align="center" v-if="Number(info.legacyStatusCode) < 60">
                  <template
                    v-if="
                      info.onlineStatusCode === '0035' ||
                        info.onlineStatusCode === '0036' ||
                        info.onlineStatusCode === '0099'
                    "
                  >
                    {{
                      payDetail.paymentCompletePriceTotal -
                        payDetail.refundCompletePriceTotal >
                      0
                        ? "-"
                        : "해약"
                    }}
                  </template>
                  <template v-else>
                    해약
                  </template>
                </td>
                <td align="center" v-if="!(Number(info.legacyStatusCode) < 60)">
                  <template v-if="Number(info.legacyStatusCode) < 70">
                    -
                  </template>
                  <template v-else>
                    {{
                      payDetail.paymentCompletePriceTotal -
                        payDetail.refundCompletePriceTotal >
                      0
                        ? "-"
                        : "매출취소"
                    }}
                  </template>
                </td>
              </tr>
              <tr>
                <th>처리자</th>
                <td colspan="2" align="center">{{ info.consultantName }}</td>
              </tr>
              <tr v-if="contractData.specialOrderYn === 'Y'">
                <th>위약금처리</th>
                <td align="center">
                  <el-radio
                    v-model="contractData.penaltyYn"
                    label="Y"
                    :disabled="
                      (info.onlineStatusCode === '0035' ||
                        info.onlineStatusCode === '0036' ||
                        info.onlineStatusCode === '0099') &&
                        payDetail.paymentCompletePriceTotal -
                          payDetail.refundCompletePriceTotal <=
                          0
                    "
                    >예</el-radio
                  >
                  <el-radio
                    v-model="contractData.penaltyYn"
                    label="N"
                    :disabled="
                      (info.onlineStatusCode === '0035' ||
                        info.onlineStatusCode === '0036' ||
                        info.onlineStatusCode === '0099') &&
                        payDetail.paymentCompletePriceTotal -
                          payDetail.refundCompletePriceTotal <=
                          0
                    "
                    >아니오</el-radio
                  >
                </td>
                <td align="center">
                  {{
                    contractData.contractPrice && contractData.contractPrice > 0
                      ? contractData.contractPrice.toLocaleString() + "원"
                      : ""
                  }}
                </td>
              </tr>
              <!-- <tr>
                <th>왕복배송비 부과</th>
                <td align="center">
                  <el-radio v-model="rdo2" :label="1">예</el-radio>
                  <el-radio v-model="rdo2" :label="2">아니오</el-radio>
                </td>
                <td align="center">30,000원</td>
              </tr> -->
              <tr>
                <th>해약사유</th>
                <td colspan="2">
                  <el-select
                    v-model="contractData.returnRefundCode"
                    placeholder="해약사유"
                    :disabled="
                      (info.onlineStatusCode === '0035' ||
                        info.onlineStatusCode === '0036' ||
                        info.onlineStatusCode === '0099') &&
                        contractData.returnRefundCode &&
                        payDetail.paymentCompletePriceTotal -
                          payDetail.refundCompletePriceTotal <=
                          0
                    "
                    ><!-- .slice(1, commonCodes.T045.length) -->
                    <el-option
                      v-for="{ value, label } in this.cancelReasonList &&
                        this.cancelReasonList.slice(1, this.cancelReasonList.length)"
                      :key="value"
                      :value="value"
                      :label="label"
                    />
                  </el-select>
                  <el-input
                    :disabled="
                      !contractData.returnRefundCode ||
                        (contractData.returnRefundCode &&
                          contractData.returnRefundCode.trim() !== 'Z') ||
                        (payDetail.paymentCompletePriceTotal -
                          payDetail.refundCompletePriceTotal <=
                          0 && info.legacyStatusCode === '90')
                    "
                    v-model="contractData.returnRefundMemo"
                    placeholder="기타: 직접입력"
                  ></el-input>
                </td>
              </tr>
            </tbody>
          </table>
          <ul class="note">
            <li>
              ※ 위약금 또는 왕복배송비 부과 시 해당 금액을 제외하고 환불처리가
              가능합니다. (또는 추가 결제 필요)
            </li>
            <li>
              ※ 해약처리 시 계약상태가 '변경 후' 상태로 변경되며, 결제금액이
              없는 경우 즉시 해약처리가 완료됩니다.
            </li>
            <li>
              ※ '계약취소(환불대기)' 상태에서 다시 한번 위약금 처리여부 및
              해약사유를 입력하실 수 있으며, 해약완료 시 선택한 값으로 최종
              적용됩니다.
            </li>
          </ul>
        </div>
        <!-- Popup Footer -->
        <template slot="footer">
          <div>
            <el-button type="info" @click="alertVisibleCancelPayAsk = false"
              >취소</el-button
            >
            <el-button type="primary" @click="oneClickDisable($event, saveRefundReason)">확인</el-button>
          </div>
        </template>
      </el-dialog>
      <!-- <el-dialog
        :center="false"
        custom-class="message cancellation"
        :visible.sync="alertVisibleCancelPayAsk"
        width="550px"
      > -->
      <!-- Message -->
      <!-- <i class="el-icon-info"></i>
        <p>
          해약처리를 진행하시겠습니까? <br />
          아래 3단계를 진행해주세요. <br />
          <br />
        </p>
        <p style="text-align: left">
          ① 해약버튼 클릭 -> 결제취소(환불대기) 상태 변경됨 <br />
          ② 결제취소 처리 -> 할부,카드,포인트 취소 <br />
          ③ 해약버튼 클릭 -> 해약처리 완료 <br />
        </p> -->
      <!-- Popup Footer -->
      <!-- <template slot="footer">
          <el-button type="info" @click="alertVisibleCancelPayAsk = false">
            아니요
          </el-button>
          <el-button type="primary" @click="canclePay">
            예
          </el-button>
        </template>
      </el-dialog> -->

      <!-- 결제 초기화 팝업 -->
      <el-dialog custom-class="message" :visible.sync="checkPaymentInitPop">
        <!-- Message -->
        결제 초기화를 진행하시겠습니까?

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button type="info" @click="checkPaymentInitPop = false">
            아니요
          </el-button>
          <el-button type="primary" @click="oneClickDisable($event, doPaymentInit)">
            예
          </el-button>
        </template>
      </el-dialog>

      <!-- 해약 진행 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="alertVisibleCancelPayConfirm"
      >
        <!-- Message -->
        결제 해약을 진행하시겠습니까?

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button type="info" @click="alertVisibleCancelPayConfirm = false">
            아니요
          </el-button>
          <el-button
            type="primary"
            @click="alertVisibleCancelPayConfirm = false"
          >
            예
          </el-button>
        </template>
      </el-dialog>

      <!-- 결제항목 활성화 -->
      <el-dialog
        title="결제항목 활성화"
        :visible.sync="popVisibleActivatePay"
        @close="closeActivatePayPop"
      >
        <div class="btn-wrap" style="margin: 0px;">
          <div class="side"></div>
          <div class="main">
            <el-button type="primary" @click="oneClickDisable($event, activationSend)">
              전송
            </el-button>
            <el-button
              type="primary"
              class="btn-s"
              icon="el-icon-plus"
              @click="onActRowAdd"
            />
          </div>
        </div>
        <div class="board-wrap" style="padding-top: 10px;">
          <el-table :data="activationlist">
            <el-table-column prop="rowNum" label="NO." align="center">
              <template slot-scope="props">
                <el-button
                  type="primary"
                  class="btn-s"
                  icon="el-icon-minus"
                  @click="onActRowDelete(props.row.rowNum)"
                />
              </template>
            </el-table-column>

            <el-table-column prop="addStlRqTypeCd" label="항목" align="center">
              <template slot-scope="props">
                <el-select
                  v-model="props.row.addStlRqTypeCd"
                  placeholder="결제항목"
                >
                  <el-option
                    v-for="{ value, label } in commonCodes.T023 &&
                      commonCodes.T023.slice(1, commonCodes.T023.length)"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
              </template>
            </el-table-column>
            <el-table-column prop="stlRqAmt" label="결제대상금액">
              <template slot-scope="props">
                <el-input v-model="props.row.stlRqAmt" />
              </template>
            </el-table-column>
            <el-table-column prop="date" label="요청일시" align="center">
              <template slot-scope="props">
                <span>{{ props.row.date }}</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <!-- Popup Footer -->
        <!-- <template slot="footer">
          <el-button
            type="primary"
            @click="popVisibleActivatePay = false"
          >
            전송
          </el-button>
        </template> -->
      </el-dialog>

      <!-- 추가서류요청 -->
      <el-dialog
        title="추가서류요청"
        :visible.sync="popVisibleRequestPaper"
        width="1300px"
        @close="closeRequestPop"
      >
        <div class="board-wrap" style="padding-top: 10px;">
          <div class="transformBox">
            <div class="left">
              <div class="article-title">
                <div>
                  <h2 class="fl">서류목록</h2>
                  <!-- [#10339/2021.12.16/A936506] 서류 loading이 안되는 이슈가 있어 if조건 추가 -->
                  <el-select
                    v-if="documentTypeList"
                    v-model="documentType"
                    placeholder="선택"
                    @change="onChangeDocumentType"
                  >
                    <el-option
                      v-for="{ value, label } in documentTypeList &&
                        documentTypeList.slice(1, documentTypeList.length)"
                      :key="value"
                      :value="value"
                      :label="label"
                    />
                  </el-select>
                  <!--  <select>
                    <option>111</option>
                    <option>222</option>
                  </select> -->
                </div>
              </div>
              <div class="transformContentWrap">
                <div class="transformContent" style="height: 370px" v-if="documentTargets.length > 0">
                  <p
                    v-for="items in documentTargets"
                    :key="items.neceDocTargNo"
                    :title="items.neceDocTargNm"
                    class="p-chk"
                    @click="getDocList($event, items)"
                  >
                    {{ items.neceDocTargNm }}
                  </p>
                  <!-- 선택 되었을때  -->
                  <!-- class="p-chk is-chlick" class에 is-chlic 추가 해주세요. -->
                </div>
                <div v-else class="transformContent" style="height: 370px">
                  <p
                  >서류목록이 없습니다.
                  </p>
                  <!-- 선택 되었을때  -->
                  <!-- class="p-chk is-chlick" class에 is-chlic 추가 해주세요. -->
                </div>
                <div
                  v-if="documentList.length > 0"
                  class="transformContent"
                  style="height: 370px"
                >
                  <el-checkbox
                    v-for="({ neceDocNo, neceDocNm }, idx) in documentList"
                    :key="neceDocNo"
                    v-model="checkedDocList[idx]"
                    :value="neceDocNo"
                    :label="neceDocNm"
                  />
                </div>
                <div v-else class="transformContent" style="height: 370px">
                  <p class="p-chk">
                    서류목록이 없습니다.
                  </p>
                </div>
              </div>
            </div>
            <div class="btn-wrap">
              <div class="btns">
                <div>
                  <el-button type="primary" @click="addDocList">
                    추가
                  </el-button>
                </div>
                <div></div>
                <el-button type="info" @click="delDocList">
                  삭제
                </el-button>
              </div>
            </div>
            <div class="right">
              <h-title :title="'요청서류'" />

              <el-table
                :data="requestDocList"
                max-height="150px"
                @select="selRequestDocList"
                @select-all="selRequestDocList"
              >
                <el-table-column label="선택" type="selection" width="80px" />
                <el-table-column
                  label="구분"
                  prop="neceDocTargNm"
                  align="center"
                />
                <el-table-column
                  label="서류이름"
                  prop="neceDocNm"
                  align="center"
                />
              </el-table>
              <h-title :title="'고객알림'" />
              <el-input v-model="needPapersSubject" type="textarea" />
            </div>
          </div>
        </div>
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button type="primary" @click="oneClickDisable($event, docSend)">
            고객전송
          </el-button>
        </template>
      </el-dialog>

      <!-- 문자보내기 팝업 -->
      <el-dialog
        title="문자보내기"
        :visible.sync="popVisibleSMS"
        width="1100px"
      >
        <!-- Popup Contents -->
        <div class="board-wrap sandmessage">
          <h-title :title="'수신자 정보'" />
          <el-form ref="contractData" :model="contractData" class="detail-form">
            <el-row>
              <el-col :span="9">
                <el-form-item label="수신자명">
                  <!-- {{ contractData.contractorInfo && contractData.contractorInfo.length > 0 ? contractData.contractorInfo[0].customerName : '' }} -->
                  <el-select
                    v-model="contractorNames"
                    multiple
                    placeholder="수신자명"
                  >
                    <el-option
                      v-for="item in contractData.contractorInfo"
                      :key="item.customerName"
                      :label="item.customerName"
                      :value="item.customerName"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="15">
                <el-form-item label="휴대전화번호">
                  <!-- {{ contractData.contractorInfo && contractData.contractorInfo.length > 0 ? contractData.contractorInfo[0].customerMobile : '' }} -->
                  {{ contractorHpTns() }}
                </el-form-item>
              </el-col>
              <!-- <el-col :span="7">
                <el-form-item label="발송일시" />
              </el-col> -->
            </el-row>
          </el-form>
          <h-title :title="'발신내용'" />
          <el-form
            ref="ruleFormpopup"
            :model="ruleFormpopup"
            class="detail-form"
          >
            <el-row>
              <el-col :span="24">
                <el-form-item label="제목">
                  <el-input
                    v-model="ruleFormpopup.title"
                    class="mms-title"
                    @blur="ruleFormpopup.title = $event.target.value"
                  />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item label="내용">
                  <el-input
                    v-model="ruleFormpopup.text"
                    type="textarea"
                    @blur="ruleFormpopup.text = $event.target.value"
                  />
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button type="info" @click="initRuleFormPop">
            초기화
          </el-button>
          <el-button type="primary" @click="oneClickDisable($event, sendSms)">
            전송
          </el-button>
        </template>
      </el-dialog>

      <el-dialog custom-class="message" :visible.sync="updateContractAssignPop">
        <!-- Message -->
        출고증발급요청을 진행하시겠습니까?

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button type="info" @click="updateContractAssignPop = false">
            아니요
          </el-button>
          <el-button type="primary" @click="updateContractAssign">
            예
          </el-button>
        </template>
      </el-dialog>
      <!-- message Popup -->
      <pop-message
        :pop-visible.sync="alertMessagePop"
        :pop-message.sync="alertMessage"
        @confirm="alertMessagePop = false"
        @close="alertMessagePop = false"
      />

      <!-- 방문예약하기 팝업 -->
      <reserved-center-popup
        :pop-show.sync="popShow"
        :contract-number="contractNumber"
        :info="info"
        @alertMsg="
          msg => {
            alertMessage = msg;
            alertMessagePop = true;
          }
        "
      />
      <!-- //방문예약하기 팝업 -->

      <!-- 주소검색 팝업 -->
      <address-search-popup
        :pop-visible-address.sync="popVisibleAddress"
        @alertMsg="
          msg => {
            alertMessage = msg;
            alertMessagePop = true;
          }
        "
      />
      <!-- //주소검색 팝업 -->

      <!-- 비영리법인 법인번호 팝업 -->
      <business-number-check-popup
        :pop-visible-corp-number.sync="popVisibleCorpNumber"
        @setData="setCorpNumber($event)"
      />
      <!-- //비영리법인 법인번호 팝업 -->

      <!-- 재배정 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="alertVisibleReassignment"
      >
        <!-- Message -->
        다시 배정(또는 배정요청) 상태로 변경하시겠습니까?

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button type="info" @click="alertVisibleReassignment = false">
            취소
          </el-button>
          <el-button type="primary" @click="oneClickDisable($event, onReassignment)">
            확인
          </el-button>
        </template>
      </el-dialog>

      <!-- 배정취소 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="popVisibleCancelCarAllocation"
      >
        <!-- Message -->
        배정(요청) 취소 상태로 변경하시겠습니까?

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button type="info" @click="popVisibleCancelCarAllocation = false">
            취소
          </el-button>
          <el-button type="primary" @click="oneClickDisable($event, onCancelCarAllocation)">
            확인
          </el-button>
        </template>
      </el-dialog>
    </div>
  </section>
</template>

<script>
import HSearch from "~/components/common/HSearch.vue";
import HReleseInfo from "~/components/common/HReleseInfo.vue";
import HTitle from "~/components/common/HTitle.vue";
import ContractInfo from "~/components/tab/ContractInfo.vue";
import CarInfo from "~/components/tab/CarInfo.vue";
import PayInfo from "~/components/tab/PayInfo.vue";
import ReleaseInfo from "~/components/tab/ReleaseInfo.vue";
import StatusHistory from "~/components/tab/StatusHistory.vue";
import SmsHistory from "~/components/tab/SmsHistory.vue";
import Loading from "~/components/popup/Loading.vue";
import PopMessage from "~/components/popup/PopMessage.vue";
import ReservedCenterPopup from "~/components/popup/ReservedCenterPopup";
import AddressSearchPopup from "~/components/popup/AddressSearchPopup";
import BusinessNumberCheckPopup from "~/components/popup/BusinessNumberCheckPopup";
import { mapState, mapGetters } from "vuex";
import moment from "moment";

export default {
  name: "ReleaseDetail",
  layout: "default",
  components: {
    HSearch,
    HReleseInfo,
    HTitle,
    ContractInfo,
    CarInfo,
    PayInfo,
    ReleaseInfo,
    StatusHistory,
    SmsHistory,
    Loading,
    PopMessage,
    ReservedCenterPopup,
    AddressSearchPopup,
    BusinessNumberCheckPopup
  },
  data() {
    return {
      alertMessage: "",
      alertMessagePop: false,
      isAuth: process.env.VUE_APP_AUTH === "true", // 권한 패스용
      popVisibleLoading: false,
      activeFlag: false, // 탭에서 조건별 활성화되어야 하는 버튼 제어 플래그
      alertNoData: false,
      checkPaymentInitPop: false,
      alertVisibleCancelPayAsk: false,
      alertVisibleCancelPayConfirm: false,
      alertVisibleReassignment: false,
      updateContractAssignPop: false,
      popShow: {
        reservedCenterPop: false
      },
      popVisibleAddress: {
        addressPop: false,
        addrIndex: null
      },
      popVisibleCorpNumber: {
        visible: false
      },
      popVisibleSMS: false,
      popVisibleEstimation: false,
      popVisibleActivatePay: false,
      popVisibleRequestPaper: false,
      popVisibleCancelCarAllocation: false,
      agreePop: false,
      active: [],
      activeName: "first",
      popactiveName: "pop-first",
      popactiveName1: "pop-first",
      ruleFormpopup: {
        title: "",
        text: ""
      },
      documentList: [], // 서류목록
      checkedDocList: [], // 서류목록 체크 여부
      requestDocList: [], // 요청서류목록
      selNeceDocInfo: {
        // 선택한 서류대상 정보
        neceDocTargNo: "", // 필요서류대상번호
        neceDocTargNm: "" // 필요서류대상명
      },
      selRequestDoc: [], // 선택한 요청 서류목록
      needPapersSubject: "", // 추가요청내용
      activationlist: [], // 결제기능 활성화 목록
      addKeyActPayIdx: 0, // 결제항목 활성화 목록 인덱스
      info: {},
      contractData: {},
      statusDateData: {},
      paperReviewData: [],
      carProductionNumber: "",
      //carInfoData: {},
      //choiceOptionNames: '',
      //tuixOptionNames: '',
      payInfoData: {},
      payAmountList: [],
      payDetail: {},
      releaseInfoData: {},
      releaseCenterData: {},
      releaseTakeoverData: {},
      releaseConsignData: {},
      releaseRegistAgencyData: {},
      // 상태이력 화면 컴포넌트화로 인한 주석처리 <A936507>
      //statusTabData: {sale: [], sales: [], payment:[], consultant:[], papers:[], electron: [], point: [], apiLog : []},
      //messageTabData: [],
      isCertificationRequestValidDate: false, // 제작증발급 요청일시 유효성 여부(true: 발급가능, false: 발급불가능)
      contractNumber: null, // 계약번호
      commonCodes: {},
      contractorNames: [], // 선택한 계약자명
      purchaseCarList: [], // 구매차량목록 조회
      addrIndex: null,
      refundFrom: {},
      documentType: "",
      documentTargets : [],
      documentTypeList: [],
      searchClick : false,
      releaseCancleChack : true,
      cancelReasonList : []     
    };
  },
  computed: {
    ...mapState({
     /*  documentTargets: state =>
        state.documentTargets.filter(items => {
          return items.neceDocTargNm !== "전체";
        }),  */// 전체 항목 제외
      customerTypeCodes: state => state.commonCodesCustomerType.slice(1)
    }),
    ...mapGetters(["userInfo"])
  },
  watch: {
    contractData: function() {
      this.activeName = 'first'
    },
    info: function() {
      let onlineStatusCodeList = this.info.onlineStatusCodeList.split(",");
      let legacyStatusCodeList = this.info.legacyStatusCodeList.split(",");
      
      onlineStatusCodeList &&
            onlineStatusCodeList.map((el) => {
        if(['0110', '0120', '0130', '0200', '9108', '9109', '9121', '9122', '9123', '9124', '9125', '9126', '9131'].includes(el)){
          this.releaseCancleChack = false;
        }
      });

      if(this.releaseCancleChack){
        legacyStatusCodeList &&
            legacyStatusCodeList.map((el) => {
          if(!['10', '20', '30'].includes(el)){
            this.releaseCancleChack = false;
          }
        });
      }
    }
  },
  async created() {
    await this.loadCommonCode();
    /* [#10339/2021.12.16/A936506] 해약 서류 loading이 안되는 이슈가 있어 순서 변경 */
    this.cancelReasonValid()

    this.$EventBus.$on("searchAddressPopOpen", index => {
      this.searchAddressPopOpen(index);
    });

    this.$EventBus.$on("addDocumentPopOpen", this.addDocumentPopOpen);
  },
  mounted() {
    this.$store.dispatch("loadDocumentTargets", { vm: this });
    this.$store.dispatch("loadCommonCodesCustomerType", {
      vm: this,
      customerType: "customer"
    });

    this.contractNumber = localStorage.getItem("contractNumber") || ""; // 새창으로 넘어오는 경우

    if (this.$route.params.contractNumber) {
      // route 이동으로 넘어오는 경우 * params이 있을 경우에만 셋팅
      this.contractNumber = this.$route.params.contractNumber;
    }

    if (this.contractNumber) {
      this.getInfoData();
      this.getContractTabData(); //first tab
    }

    localStorage.removeItem("contractNumber");
  },
  methods: {
    fetchCommonCodeData(systemType = "", codeType = "") {
      let res = null;
      switch (systemType) {
      case "E":
        res = this.$store.dispatch("loadCommonCodesE", {
          vm: this,
          codeTypeCode: codeType
        });
        break;
      case "C":
        res = this.$store.dispatch("loadLegacyCommonCodesC", {
          vm: this,
          codeTypeCode: codeType
        });
        break;
      }
      return res;
    },
    async loadCommonCode() {
      /* [#10339/2021.12.16/A936506] 미사용 코드가 섞여있어 정상적으로 조회하지 못하여 수정 */
      //const [ccT023, ccT045, ccT072, ccC609, ccT046, ccT048] = await Promise.all([
      const [ccT023, ccT045, ccT072, ccT046, ccT048] = await Promise.all([
        this.fetchCommonCodeData("E", "T023"), // 결제항목
        this.fetchCommonCodeData("E", "T045"), // 반품 및 환불사유
        this.fetchCommonCodeData("E", "T072"), // 반품 및 환불사유
        this.fetchCommonCodeData("E", "P037"), // 은행코드
        this.fetchCommonCodeData("E", "T048") // 취소사유 2021-11-29
      ])

      this.commonCodes = { ...ccT023, ...ccT045, ...ccT072, ...ccT046, ...ccT048 }
      this.documentTypeList = this.commonCodes.T072;
      //this.cancelReasonList = this.commonCodes.T048 // cancelReasonValid 메소드에서 대입하고 있어 의미없으므로 삭제
    },
    cancelReasonValid(){

      console.log("cancelReasonValid1 >>" + JSON.stringify(this.cancelReasonList));
      // 2021-11-29 레드마인 9321 - 해약 로직 변경으로, 해약사유 공통코드 변경 
      console.log("this.info.legacyStatusCode >>"+this.info.legacyStatusCode)


      let cancelRsnList = this.commonCodes.T048;

      console.log("this.commonCodes.T048 >>" + JSON.stringify(this.commonCodes.T048));
      console.log("cancelReasonValid2 >>" + JSON.stringify(cancelRsnList));
      if(this.info.legacyStatusCode === "10" || this.info.legacyStatusCode === "20"){        
        cancelRsnList = cancelRsnList.filter(items => {                
          return items.value !== "F"  ;                                  
        })
                       

      }else if(this.info.legacyStatusCode === "40" || this.info.legacyStatusCode === "60") {        
       cancelRsnList =  cancelRsnList.filter(items => {        
          return items.value !== "F"  ;                                  
        })
              
      }
      console.log("cancelRsnList >>" + JSON.stringify(cancelRsnList));
      this.cancelReasonList = cancelRsnList;
      console.log("cancelReasonValid3 >>" + JSON.stringify(this.cancelReasonList));
    },
    isValidAuthBtn(authId) {
      // 버튼별 권한 체크
      let bResult = false; // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || [];
      if (currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some(items => {
          if (items.btnId === authId) {
            bResult = true;
            return true;
          }
        });
      }
      return bResult;
    },
    onAddZero(contractNumber) {
      let resultString = "";
      if (contractNumber.length > 6) {
        const frontString = contractNumber.substring(0, 7);
        const backString = contractNumber.substring(7);

        resultString = resultString.concat(frontString);
        resultString = resultString.concat(
          backString.length >= 6
            ? backString
            : Array.from({ length: 6 - backString.length }, () => 0).join("") +
                backString
        );
      }

      if (!resultString) {
        resultString = contractNumber;
      }
      this.contractNumber = resultString;
    },
    estimationView() {
      // 견적보기
      let preffixUrl = 'http://10.7.137.110/dev/casper'
      if (['stg', 'dev', 'prod'].includes(process.env.VUE_APP_PROFILE)) {
        preffixUrl = process.env.VUE_APP_BASEURL_FRONT
      }

      if (this.contractData && this.contractData.estimationUrl) {
        window.open(
          preffixUrl +
            "/estimation/detail?fromExclusive=Y&estimationUrl=" +
            this.contractData.estimationUrl
        );
      } else {
        this.alertMessage = "해당 계약 건은 견적이력이 없습니다.";
        this.alertMessagePop = true;

        return false;
      }
    },
    async getInfoData() {
      this.popVisibleLoading = true;

      // API-E-업무담당자-013 (계약출고상세조회)
      const [res, err] = await this.$https.post(
        "/v2/exclusive/contract-detail",
        { contractNumber: this.contractNumber }
      );
      if (!err) {
        if (!res.data) {
          // 상세보기 - 조회 결과 없음 팝업 노출
          const beforeContractNumber = this.contractNumber;
          const beforeActiveName = this.activeName;
          Object.assign(this.$data, this.$options.data());
          this.contractNumber = beforeContractNumber; // 이전 계약번호 유지
          this.activeName = beforeActiveName; // 이전 탭 상태 유지
          this.alertNoData = true;
          return;
        }

        // screenUseTypeCode (01:열람,02:수정,03:삭제,04:인쇄,05:입력,06:업로드,07:다운로드)
        this.$store.dispatch('commonSupportLog', { vm: this, params: { screenUseTypeCode: '01', useInfo: JSON.stringify(res.data) } })
        this.info = res.data;
        if (
          this.info.consultantId &&
          this.info.consultantId === this.userInfo.eeno
        ) {
          // 사용자 사번과 계약건의 업무담당자이 같을 경우
          this.activeFlag = true;
        }

        if (this.userInfo.exclusiveUseAuthGroupIds.includes("WT004")) {
          // 법인 관리자 권한일 경우
          this.activeFlag = true;
        }
        
        
        // 대고객 계약일 경우 대고객 계약출고상세로 이동
        if (this.info.contractPersonalCorporationCode !== "3") {
          this.$utils.setLocalStorage({
            contractNumber: this.contractNumber
          });
          this.$router.push("/wp/contract/customer/release-detail");
          return;
        }

        this.info.customerTypeCodes = this.customerTypeCodes;


        this.getCarTabData();
        this.getPurchaseCarList();
        this.getPayInfoData();
        this.popVisibleLoading = false;
      } else {
        this.popVisibleLoading = false;
        console.error(err);
      }

      this.cancelReasonValid();
    },
    async getPayInfoData() {
      // API-E-업무담당자-022 (결제내역 상세조회)
      // if(Object.keys(this.payDetail).length===0) {
      const [res3, err3] = await this.$https.post(
        "/v2/exclusive/work/payment-details",
        { contractNumber: this.contractNumber }
      );
      if (!err3) {
        console.log("/work/payment/", res3.data);
        this.payDetail = res3.data;
      } else {
        console.error(err3);
      }
    },
    async getPurchaseCarList() {
      // API-E-업무담당자-017 (구매차량목록조회)
      const [res, err] = await this.$https.get(
        "/v2/exclusive/work/contract/purchaseCar/" +
          this.info.groupContractNumber
      );

      if (!err) {
        if (!res.data || res.data.length === 0) {
          this.purchaseCarList = [];
        } else {
          this.purchaseCarList = res.data.map((el, idx) => {
            return {
              ...el,
              no: idx + 1,
              carSpec:
                (el.saleModelCode || "") +
                " " +
                (el.optionMixCode || "") +
                " " +
                (el.exteriorColorCode || "") +
                " " +
                (el.interiorColorCode || "") +
                " " +
                (el.tuixMixCode || "")
            };
          });
          let possibleYn = 'Y'
          this.purchaseCarList.map(el => {
            if(el.onlineStatusCode !== '0999' || el.legacyStatusCode !== '10'){
              possibleYn = 'N'
            } 
          })
          this.info.possibleChangeCar = possibleYn
        }

        console.log(this.purchaseCarList);
        this.popVisibleLoading = false;
      } else {
        this.popVisibleLoading = false;
        console.error(err);
      }
    },
    searchContract(value) {
      this.popShow.reservedCenterPop = false;
      if (!this.isValidAuthBtn("authSelect")) {
        // 권한없을경우 동작 x
        return;
      }

      if (!value) {
        this.alertMessage = "계약번호를 입력해주세요.";
        this.alertMessagePop = true;
        return;
      } else {
        value = value.trim(); // 공백 제거
      }

      this.contractNumber = value;
      this.getInfoData();
      this.getContractTabData()
      //this.handleTabClick({ name: this.activeName });
    },
    handleTabClick(tab) {
      if (tab.name === "first") this.getContractTabData();
      else if (tab.name === "second") this.getCarTabData();
      else if (tab.name === "third") this.getPaymentTabData();
      else if (tab.name === "fourth") this.getReleaseTabData();
      else if (tab.name === "fifth") this.getStatusTabData();
      else if (tab.name === "sixth") this.getMessageTabData();
    },
    async getContractTabData() {
      if (!this.contractNumber) return;

      //계약자 정보 + 서비스가입 + 계약금 결제
      // API-E-업무담당자-014 (계약정보조회)
      // if(Object.keys(this.contractData).length===0) {
      const [res1, err1] = await this.$https.post(
        "/v2/exclusive/work/contract",
        { contractNumber: this.contractNumber }
      );
      if (!err1) {
        console.log("/work/contract/", res1.data);
        if (!res1.data) {
          return;
        }
        this.contractData = res1.data;

        const contractorInfo =
          this.contractData && this.contractData.contractorInfo;
        this.contractorNames =
          contractorInfo && contractorInfo.length
            ? contractorInfo.map(items => {
                return items.customerName;
              })
            : [];

        this.$refs.contractInfo.getAllData();
      } else {
        console.error(err1);
      }
    },
    async getCarTabData() {
      if (!this.contractNumber) return;

      this.$refs.CarInfo.getCarInfoData();

      // API-E-업무담당자-019 (차량정보 조회)
      // if(Object.keys(this.carInfoData).length===0) {
      // const [res1, err1] = await this.$https.post('/v2/exclusive/work/car', { contractNumber: this.contractNumber })
      // if(!err1) {
      //   console.log('/work/car/', res1.data)
      //   if(res1.data) {
      //     this.carInfoData = res1.data
      //     let choiceOptionNameAry = [], tuixOptionNameArr = [], tuixOptionTotalPrice = 0

      //     this.carInfoData.choiceOptionInfo && this.carInfoData.choiceOptionInfo.map(el => {
      //       choiceOptionNameAry.push(el.carOptionName)
      //       if(el.carOptionDeailName !== null) {
      //         el.carOptionDeailNameAry = el.carOptionDeailName.split('+')
      //       }
      //     })
      //     this.choiceOptionNames = choiceOptionNameAry.join(', ')

      //     this.carInfoData.tuixOptionInfo && this.carInfoData.tuixOptionInfo.map(el => {
      //       tuixOptionTotalPrice += el.carOptionPrice
      //       tuixOptionNameArr.push(el.carOptionName)
      //       if(el.carOptionDeailName !== null) {
      //         el.carOptionDeailNameAry = el.carOptionDeailName.split('+')
      //       }
      //     })
      //     this.tuixOptionNames = tuixOptionNameArr.join(', ')
      //     this.carInfoData = { ...this.carInfoData, tuixOptionTotalPrice: tuixOptionTotalPrice }

      //     console.log(this.carInfoData)
      //   }
      // } else {
      //   console.error(err1)
      // }
      // }
    },
    getCarProductionNumber(pdNumber) {
      this.carProductionNumber = pdNumber;
    },
    async getPaymentTabData() {
      if (!this.contractNumber) return;
      this.$refs.payInfo.getAllData();
    },
    async getReleaseTabData() {
      if (!this.contractNumber) return;
      this.$refs.releaseInfo.getAllData();
      //출고정보
      // if(Object.keys(this.releaseInfoData).length===0) {
      /* const [res1, err1] = await this.$https.get(
        "/v2/exclusive/work/delivery/" + this.contractNumber
      );
      if (!err1) {
        console.log("/work/delivery/", res1.data);
        this.releaseInfoData = res1.data;
      } else {
        console.error(err1);
      } */
      // }

      //출고센터진행정보
      // if(Object.keys(this.releaseCenterData).length===0) {
      /* const [res2, err2] = await this.$https.get(
        "/v2/exclusive/work/delivery-state/" + this.contractNumber
      );
      if (!err2) {
        console.log("/work/delivery-state/", res2.data);
        this.releaseCenterData = res2.data;
      } else {
        console.error(err2);
      } */
      // }

      // API-E-업무담당자-032 (인수정보 조회)
      // if(Object.keys(this.releaseTakeoverData).length===0) {
      /* const [res3, err3] = await this.$https.post(
        "/v2/exclusive/work/take-over",
        { contractNumber: this.contractNumber }
      );
      if (!err3) {
        console.log("/work/take-over/", res3.data);
        this.releaseTakeoverData = res3.data;
      } else {
        console.error(err3);
      } */
      // }

      //탁송정보
      // if(Object.keys(this.releaseConsignData).length===0) {
      /* const [res4, err4] = await this.$https.get(
        "/v2/exclusive/work/consign/" + this.contractNumber
      );
      if (!err4) {
        console.log("/work/consign/", res4.data);
        this.releaseConsignData = res4.data;
      } else {
        console.error(err4);
      } */
      // }

      //등록대행정보 조회 (API-E-전담컨설턴트-034)
      // if(Object.keys(this.releaseRegistAgencyData) && Object.keys(this.releaseRegistAgencyData).length===0) {
      /* const [res5, err5] = await this.$https.get(
        "/v2/exclusive/work/regist-agency/" + this.contractNumber
      );
      if (!err5) {
        this.releaseRegistAgencyData = res5.data;
      } else {
        console.error(err5);
      } */
      // }
    },
    async getStatusTabData() {
      if (!this.contractNumber) return;

      //전담DC 품의 이력 조회
      this.$refs.StatusHistory.getDcHistory();
	  
      //API-WE-업무담당자-035 (판매처리이력 조회)
      this.$refs.StatusHistory.getSaleHistory();

      //API-WE-업무담당자-036 (매출변경이력 조회)
      this.$refs.StatusHistory.getSalesHistory();

      //API-WE-업무담당자-037 (결제변경이력 조회)
      this.$refs.StatusHistory.getPaymentHistory();

      // API-WE-업무담당자-129 (포인트신청이력 조회)
      this.$refs.StatusHistory.getPointHistory();

      //API-WE-업무담당자-038 (업무담당자처리이력 조회)
      this.$refs.StatusHistory.getConsultantHistory();

      //API-WE-업무담당자-040 (서류심사이력 조회)
      this.$refs.StatusHistory.getPaperHistory();

      //API-WE-업무담당자-041 (전자서명이력 조회)
      this.$refs.StatusHistory.getSignHistory();

      //API-WE-업무담당자-133 (국판 호출 로그 이력 조회)
      this.$refs.StatusHistory.getApiHistory();

      //API-WE-업무담당자-147 (계약 변경 이력 조회)
      this.$refs.StatusHistory.getChangeHistory();

      // 상태이력 화면 컴포넌트화로 인한 주석처리 <A936507>
      //API-E-업무담당자-035 (판매처리이력 조회)
      // if(this.statusTabData.sale.length===0) {
      // const [res1, err1] = await this.$https.post('/v2/exclusive/work/history/sale', { contractNumber: this.contractNumber })
      // if(!err1) {
      //   console.log('/work/history/sale/', res1.data)
      //   this.statusTabData.sale = res1.data.map((el) => {
      //     return {
      //       ...el,
      //       deliveryPrearrangedDate: el.deliveryPrearrangedDate ? moment(el.deliveryPrearrangedDate).format('YYYY-MM-DD') : '',          }
      //   })
      // } else {
      //   console.error(err1)
      // }
      // }

      //API-E-업무담당자-036 (매출변경이력 조회)
      // if(this.statusTabData.sales.length===0) {
      // const [res2, err2] = await this.$https.get('/v2/exclusive/work/history/sales/' + this.contractNumber)
      // if(!err2) {
      //   console.log('/work/history/sales/', res2.data)
      //   this.statusTabData.sales = res2.data.map((el) => {
      //     return {
      //       ...el,
      //       carPrice: el.carPrice && (el.carPrice*1).toLocaleString()+' 원',
      //       discountPrice: el.discountPrice && (el.discountPrice*1).toLocaleString()+' 원',
      //       usePoint: el.usePoint && (el.usePoint*1).toLocaleString(),
      //       salePrice: el.salePrice && (el.salePrice*1).toLocaleString()+' 원',
      //       contractPrice: el.contractPrice && (el.contractPrice*1).toLocaleString()+' 원',
      //       installmentPrincipal: el.installmentPrincipal && (el.installmentPrincipal*1).toLocaleString()+' 원',
      //       cardPaymentPrice: el.cardPaymentPrice && (el.cardPaymentPrice*1).toLocaleString()+' 원',
      //       tax: el.tax && (el.tax*1).toLocaleString()+' 원',
      //     }
      //   })
      // } else {
      //   console.error(err2)
      // }
      // }

      //API-E-업무담당자-037 (결제변경이력 조회)
      // if(this.statusTabData.payment.length===0) {
      // const [res3, err3] = await this.$https.post('/v2/exclusive/work/history/payment', { contractNumber: this.contractNumber })
      // if(!err3) {
      //   console.log('/work/history/payment/', res3.data)
      //   this.statusTabData.payment = res3.data.map((el) => {
      //     return {
      //       ...el,
      //       paymentPrice: el.paymentPrice ? (el.paymentPrice*1).toLocaleString()+'원' : '',
      //       paymentContents: el.paymentTypeCode !== '30' ? el.paymentContents : (el.virtualAccount ? el.paymentContents + '\n - 계좌번호: ' + el.virtualAccount : el.paymentContents),
      //       refundPrice: el.refundPrice ? (el.refundPrice*1).toLocaleString()+'원' : ''
      //     }
      //   })
      // } else {
      //   console.error(err3)
      // }

      // API-E-업무담당자-129 (포인트신청이력 조회)
      // const [res4, err4] = await this.$https.post('/v2/exclusive/work/history/point', { contractNumber: this.contractNumber })
      // if(!err4) {
      //   console.log('/work/history/point/', res4.data)
      //   this.statusTabData.point = res4.data.map((items, idx) => {
      //     return {
      //       ...items,
      //       no: idx + 1,
      //       pointUsePrice: items.pointUsePrice.toLocaleString() + '원', // 포인트 사용금액
      //       partnerAssignmentPrice: items.partnerAssignmentPrice.toLocaleString() + '원', // 제휴사분담금액
      //       companyAssignmentPrice: items.companyAssignmentPrice.toLocaleString() + '원' // 당사분담금액
      //     }
      //   })
      // } else {
      //   console.error(err4)
      // }

      //API-E-업무담당자-038 (업무담당자처리이력 조회)
      // if(this.statusTabData.consultant.length===0) {
      // const [res5, err5] = await this.$https.get('/v2/exclusive/work/history/consultant/'+this.contractNumber)
      // if(!err5) {
      //   console.log('/work/history/consultant/', res5.data)
      //   this.statusTabData.consultant = res5.data
      // } else {
      //   console.error(err5)
      // }
      // }

      //API-E-업무담당자-040 (서류심사이력 조회)
      // if(this.statusTabData.papers.length===0) {
      // const [res6, err6] = await this.$https.get('/v2/exclusive/work/history/papers/'+this.contractNumber)
      // if(!err6) {
      //   console.log('/work/history/papers/', res6.data)
      //   this.statusTabData.papers = res6.data.map((el, idx) => {
      //     return {
      //       ...el,
      //       no : idx+1,
      //       papersNameListStr : el.papersNameList.join(', ')
      //     }
      //   })
      // } else {
      //   console.error(err6)
      // }
      // }

      //API-E-업무담당자-041 (전자서명이력 조회)
      // if(this.statusTabData.electron.length===0) {
      // const [res7, err7] = await this.$https.get('/v2/exclusive/work/history/electron/'+this.contractNumber)
      // if(!err7) {
      //   console.log('/work/history/electron/', res7.data)
      //   this.statusTabData.electron = res7.data
      // } else {
      //   console.error(err7)
      // }
      // }

      //API-E-업무담당자-133 (국판 호출 로그 이력 조회)
      // if(this.statusTabData.apiLog.length===0) {
      // const [res8, err8] = await this.$https.get('/v2/exclusive/work/history/apilog/'+this.contractNumber)
      // if(!err8) {
      //   // console.log('/work/history/apilog/', res8.data)
      //   this.statusTabData.apiLog = res8.data && res8.data.map((el, idx) => {
      //     return {
      //       ...el,
      //       no : res8.data.length - idx,
      //       siteConnectTime: el.siteConnectTime? el.siteConnectTime.split('.')[0]:null
      //     }
      //   })

      //   console.log('/work/history/apilog/', this.statusTabData.apiLog)
      // } else {
      //   console.error(err8)
      // }
      // }
    },
    async getMessageTabData() {
      if (!this.contractNumber) return;

      this.$refs.SmsHistory.getSmsHistoryData();

      //API-E-업무담당자-042 (문자발송목록 조회)
      // if(this.messageTabData.length===0) {
      // const [res, err] = await this.$https.post('/v2/exclusive/work/history/sms', { contractNumber: this.contractNumber, pageNo : '1', pageSize: '100' })
      // if(!err) {
      //   console.log('/work/history/sms/', res.data)
      //   this.messageTabData = res.data.list && res.data.list.map((el, idx) => {
      //     return {
      //       ...el,
      //       no : idx+1,
      //     }
      //   })
      // } else {
      //   console.error(err)
      // }
      // }
    },
    closeActivatePayPop() {
      // 결제항목 활성화 팝업 닫을시 데이터 초기화
      this.activationlist = []; // init
    },
    closeRequestPop() {
      // 추가서류요청 팝업 닫을시 데이터 초기화
      (this.selRequestDoc = []),
        (this.documentList = []),
        (this.requestDocList = []),
        (this.checkedDocList = []),
        (this.needPapersSubject = ""); // init
    },
    onActRowAdd() {
      // 결제기능 활성화 목록 추가
      // addStlRqScnCd 추가결제요청구분코드(T019 - 01: 추가결제, 02: 결제취소)
      const { contractNumber: saleCnttNo, employeeId: rqEeno } = this.info; // 판매계약번호, 요청사원번호
      this.activationlist.push({
        rowNum: this.addKeyActPayIdx++,
        saleCnttNo,
        rqEeno,
        addStlRqScnCd: "01",
        date: moment().format("YYYY-MM-DD HH:mm")
      }); // addRow
    },
    onActRowDelete(key) {
      const idx = this.activationlist.findIndex(item => item.rowNum === key);
      if (idx > -1) this.activationlist.splice(idx, 1); // 일치하는 row 삭제
    },
    async activationSend() {
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      // 결제항목 활성화
      let sucCnt = 0; // 활성화 카운팅
      this.activationlist.map(async items => {
        const params = { ...items, rltdStlNos: items.rowNum };
        console.log(params);
        if (params.addStlRqTypeCd && params.stlRqAmt) {
          // 추가한 결제항목 활성화 목록중에서 항목, 결제대상금액을 입력한 row만 활성화 처리
          const [res, err] = await this.$https.get(
            "payment/v2/payment/provision/activation",
            params,
            null,
            "gateway"
          ); // API-E-결제서비스-019 (결제항목 활성화 처리)
          /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
          this.popVisibleLoading = false
          /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
          if (!err) {
            console.log(res);
            sucCnt++;
            if (this.activationlist.length === sucCnt) {
              this.popVisibleActivatePay = false;
              this.alertMessage =
                "고객님, 추가 결제 안내가 전송되었습니다.\n마이페이지에서 확인요청 드립니다.";
              this.alertMessagePop = true;
            }
          } else {
            console.error(err);
          }
        }
      });
    },
    async getDocList($event, items) {
      // 서류 심사 목록
      // class all delete and self add
      Array.from($event.target.parentElement.children).map(items => {
        items.classList.remove("is-chlick");
      });
      $event.target.classList.add("is-chlick");

      const { neceDocTargNo = "", neceDocTargNm = "" } = items;
      if (!neceDocTargNo) {
        this.alertMessage = "서류목록을 확인해주세요.";
        this.alertMessagePop = true;
        return false;
      }
      const [res, err] = await this.$https.get(
        "/v2/exclusive/contract/papers",
        { neceDocTargNo: neceDocTargNo }
      ); //API-E-업무담당자-047 (필요서류목록 조회)
      if (!err) {
        console.log(res);
        this.documentList = res.data;

        this.checkedDocList = []; // init list
        this.documentList.map((items, idx) => {
          // init checkYN
          items.neceDocTargNo = neceDocTargNo;
          items.neceDocTargNm = neceDocTargNm;
          this.checkedDocList[idx] = false;
        });

        this.selNeceDocInfo = items; // 선택한 필요서류대상
      }
    },
    addDocList() {
      // 추가서류요청 팝업 - 추가 버튼
      let addList = this.documentList.filter((items, idx) => {
        //items.
        return this.checkedDocList[idx] ? items : null;
      });
      if (addList.length > 0) {
        // 체크한 서류 목록이 있을 경우

        this.requestDocList.map(items => {
          addList.map((items2, idx) => {
            // 요청 서류 중복 제거
            // 필요서류대상번호, 필요서류번호가 모두 일치할 경우 추가하려는 서류목록에서 삭제
            if (
              items.neceDocTargNo === items2.neceDocTargNo &&
              items.neceDocNo === items2.neceDocNo
            ) {
              addList.splice(idx, 1);
            }
          });
        });

        if (addList.length > 0) {
          // 서류 중복 데이터 제거 후 남은 서류 목록이 있는지 다시 확인
          this.selRequestDoc = []; // 요청 서류 목록이 변경되므로 기존 선택되어있던 목록도 초기화
          this.requestDocList = [...this.requestDocList, ...addList];
        } else {
          this.alertMessage = "요청서류에 등록되어 있습니다.";
          this.alertMessagePop = true;
        }
      } else {
        this.alertMessage = "서류목록을 선택해주세요.";
        this.alertMessagePop = true;
        return false;
      }
    },
    delDocList() {
      // 추가서류요청 팝업 - 삭제 버튼
      if (this.selRequestDoc.length > 0) {
        // 삭제하려는 서류 목록이 있을경우
        this.selRequestDoc.map(items => {
          this.requestDocList.map((items2, idx) => {
            // 요청 서류 제거
            // 필요서류대상번호, 필요서류번호가 모두 일치할 경우 추가하려는 서류목록에서 삭제
            if (
              items.neceDocTargNo === items2.neceDocTargNo &&
              items.neceDocNo === items2.neceDocNo
            ) {
              this.requestDocList.splice(idx, 1);
            }
          });
        });
      }
    },
    selRequestDocList(data) {
      // 요청서류 - 선택한 서류 목록
      this.selRequestDoc = data;
    },
    async docSend() {
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      // 추가서류요청 팝업 - 고객전송 버튼
      const { eeno: customerNumber } = this.userInfo; // 세션사원번호
      const { contractNumber: saleContractNumber } = this.info; // 계약번호
      const needPapersSubject = this.needPapersSubject; // 추가요청내용
      const contractInfo = this.contractData.contractorInfo.filter(items => {
        return items.contractorTypeCode === "01";
      }); // 주계약자 정보

      const {
        customerManagementNumber: customerManageNumber
      } = contractInfo[0];

      const paramList = this.requestDocList.map(items => {
        const {
          neceDocTargNo: needPapersSubjectNumber = '',
          neceDocNo: needPapersNumber = '', neceDocNm: needPapersSubjectName = '' 
        } = items
        return {
          needPapersSubjectNumber,
          needPapersNumber,
          customerNumber,
          needPapersSubject,
          saleContractNumber,
          customerManageNumber,
          needPapersSubjectName
        }
      })

      if (paramList.length > 0) {
        console.log(paramList);
        const [res, err] = await this.$https.post(
          "/v2/exclusive/contract/addition-papers",
          paramList
        ); // API-E-업무담당자-048 (추가서류요청 저장)
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
        this.popVisibleLoading = false
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
        if (!err) {
          console.log(res);
          this.alertMessage = "서류가 추가되었습니다.";
          this.alertMessagePop = true;
          this.getStatusTabData();
        } else {
          console.error(err);
        }

        this.popVisibleRequestPaper = false; // 팝업 닫기
      } else {
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
        this.popVisibleLoading = false
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */        
        this.alertMessage = "서류를 추가해주세요.";
        this.alertMessagePop = true;
      }
    },
    initRuleFormPop() {
      // 초기화 버튼
      Object.assign(
        this.$data.ruleFormpopup,
        this.$options.data().ruleFormpopup
      );
    },
    async saveRefundReason() {
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      // 해약 팝업 - 계약취소
      const contractNumber = this.contractNumber;

      if (!this.contractData.returnRefundCode || this.contractData.returnRefundCode === "") {
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
        this.popVisibleLoading = false
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */        
        this.alertMessage = "해약사유를 선택 해주세요.";
        this.alertMessagePop = true;
        return;
      }
      
      if (this.contractData.returnRefundCode !== "Z") {
        this.contractData.returnRefundMemo = "";
      }

      if (
        this.contractData.returnRefundCode === "Z" &&
        this.contractData.returnRefundMemo === ""
      ) {
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
        this.popVisibleLoading = false
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */        
        this.alertMessage = "기타 사유를 입력해주세요.";
        this.alertMessagePop = true;
        return;
      }

      const body = {
        contractNumber: contractNumber,
        penaltyYn: this.contractData.penaltyYn,
        returnRefundCode: this.contractData.returnRefundCode,
        returnRefundMemo: this.contractData.returnRefundMemo
      };
      const [res, err] = await this.$https.post(
        "/v2/exclusive/contract/cancel",
        body
      ); // API-E-업무담당자-126 (차량계약 상태변경 - 계약취소(고객), 계약취소(환불대기))
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
      if (!err) {
        this.alertVisibleCancelPayAsk = false;
        if (res.rspStatus && res.rspStatus.rspCode !== "0000") {
          this.alertMessage =
            res.data.rspMessage ||
            "시스템 오류 입니다.\n관리자에게 문의하세요.";
          this.alertMessagePop = true;
        } else {
          this.alertMessage = "해약처리 되었습니다.";
          this.alertMessagePop = true;
          this.getInfoData(); // refresh
          this.getContractTabData(); // 계약정보 탭 refresh
          this.getPaymentTabData(); // 결제정보 탭 refresh
          this.getStatusTabData(); // 상태이력 탭 refresh
        }
      } else {
        this.alertMessage =
          err.rspMessage || "시스템 오류 입니다.\n관리자에게 문의하세요.";
        if (
          res &&
          res.rspStatus &&
          (res.rspStatus.rspCode === "EXP.1000" ||
            res.rspStatus.rspCode === "1000")
        ) {
          this.alertMessagePop = true;
        }
      }
      this.alertVisibleCancelPayAsk = false;
      // this.alertVisibleCancelPayConfirm = true
    },
    async canclePay() {
      // 해약 팝업 - 계약취소
      const contractNumber = this.contractNumber;
      const body = { contractNumber };
      const [res, err] = await this.$https.post(
        "/v2/exclusive/contract/cancel",
        body
      ); // API-E-업무담당자-126 (차량계약 상태변경 - 계약취소(고객), 계약취소(환불대기))

      if (!err) {
        if (res.rspStatus && res.rspStatus.rspCode === "0000") {
          this.alertMessage =
            res.data.resultMessage ||
            "시스템 오류 입니다.\n관리자에게 문의하세요.";
          this.alertMessagePop = true;
        }
        this.getInfoData(); // refresh
        this.getContractTabData(); // 계약정보 탭 refresh
        this.getStatusTabData(); // 상태이력 탭 refresh
      } else {
        this.alertMessage =
          err.rspMessage || "시스템 오류 입니다.\n관리자에게 문의하세요.";
        if (
          res &&
          res.rspStatus &&
          (res.rspStatus.rspCode === "EXP.1000" ||
            res.rspStatus.rspCode === "1000")
        ) {
          this.alertMessagePop = true;
        }
      }
      this.alertVisibleCancelPayAsk = false;
      // this.alertVisibleCancelPayConfirm = true
    },
    async sendSms() {
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      let customersInfo = [];
      const contractorInfo =
        this.contractData && this.contractData.contractorInfo;
      const targetContractorInfo =
        contractorInfo &&
        contractorInfo.filter(items => {
          return this.contractorNames.includes(items.customerName);
        });

      targetContractorInfo.map(items => {
        customersInfo.push({
          sendChannelCode: "M", // 발송경로 구분 코드 - 업무담당자
          saleContractNo: this.contractNumber || "", // 판매계약번호
          customerMgmtNo: items.customerManagementNumber || "", // 고객관리번호
          customerUniqueNo: this.userInfo.eeno || "", // 고객고유번호
          messageTitle: this.ruleFormpopup.title, // 제목
          messageContents: this.ruleFormpopup.text, // 내용
          receiverTel: items.customerMobile, // 수신자전화번호
          receiverName: items.customerName // 수신자명
        });
      });

      const [result1, result2] = await Promise.all(
        customersInfo.map(items => {
          return this.$https.post("/v2/exclusive/common/sms-send", items); // API-E-공통서비스-023 (문자 보내기)
        })
      );

      // 1명의 계약자에게만 발송하는 경우
      if (!result2) {
        const [res1, err1] = result1;
        if (!err1) {
          if (res1.rspStatus && res1.rspStatus.rspCode === "0000") {
            /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
              this.popVisibleLoading = false
            /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */            
            // this.popVisible05 = false // 팝업 닫기
            this.alertMessage = "문자가 전송되었습니다.";
            this.alertMessagePop = true;
          }
        }
      }

      // 주계약자 및 공동명의자 모두 발송하는 경우
      if (result1 && result2) {
        const [res1, err1] = result1;
        const [res2, err2] = result2;

        // 모두 전송되었을 경우
        if (!err1 && !err2) {
          /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
            this.popVisibleLoading = false
          /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */          
          if (
            res1.rspStatus &&
            res1.rspStatus.rspCode === "0000" &&
            res2.rspStatus &&
            res2.rspStatus.rspCode === "0000"
          ) {
            // this.popVisible05 = false // 팝업 닫기
            this.alertMessage = "문자가 전송되었습니다.";
            this.alertMessagePop = true;
          }
        }
      }
      this.getMessageTabData(); // reload
      this.popVisibleSMS = false; // 팝업 닫기
    },
    openPopSms() {
      // 문자보내기 팝업 노출
      // ※ 출고일 장기 경과 데이터 이관으로 고객정보 부재가 발생하는 케이스가 생김.
      // 고객 데이터에 따른 안내팝업 처리
      // 고객관리번호는 필수값이 아니라 체크안함. 고객정보의 수신자 전화번호와 수신자명은 필수값 임으로 체크
      let customerMobile = "",
        customerName = "";

      if (this.contractData && this.contractData.contractorInfo[0]) {
        ({
          customerMobile,
          customerName
        } = this.contractData.contractorInfo[0]);
      }

      if (!customerMobile || !customerName) {
        // 고객정보가 없을 경우
        this.alertMessage =
          "출고일 장기 경과건으로 고객 데이터가 없습니다.\n데이터 복원후 진행해주세요.";
        this.alertMessagePop = true;
      } else {
        this.popVisibleSMS = true;
        Object.assign(this.ruleFormpopup, this.$options.data().ruleFormpopup);
      }
    },
    onRefresh(flag, tab) {
      if (flag) {
        switch (tab) {
          case "contract":
            this.getInfoData();
            this.getContractTabData();
            break;
          case "car":
            this.getCarTabData();
            break;
          case "pay":
            this.getPaymentTabData(); // 결제정보탭 reload
            break;
          case "release":
            this.getReleaseTabData();
            break;
          case "status":
            this.getStatusTabData();
            break;
          case "sms":
            this.getMessageTabData();
            break;
        }
      }
    },
    showBtnCarMakeCertification() {
      const { carMakeCertificateIssueYn } = this.contractData; // 계약정보
      const { makeDocumentIssueDate } = this.info; // 상태별일자 정보
      const isCertificationRequestValidDate = moment().isSameOrBefore(
        moment(makeDocumentIssueDate, "YYYYMMDD").add(14, "days")
      ); // 제작증 발급 요청일시에 대한 발급가능 여부에 대한 유효성 여부

      //자동차제작증 재출력 / 자동차제작증 발급
      const flag =
        carMakeCertificateIssueYn === "Y"
          ? isCertificationRequestValidDate
          : true;

      // 0600: 차량 인수 완료 (직접인수), 0610: 차량 인수 완료(배달탁송), 0710: 차량 구매 완료, 0800: 차량 구매 완료(미신고) , 0810: 차량 구매 완료(미신고)
      const statusCheck = ["0600", "0610", "0710", "0800", "0810"].includes(
        this.onlineContractState
      );
      //
      return statusCheck && flag;
    },
    async setCorpNumber(data) {
      console.log("============", data);

      if(data){
        const contractNumber = this.contractNumber;
        const body = {
          saleCnttNo : contractNumber,
          corpRgstNo : data.textNum
          };
        const [res, err] = await this.$https.post(
          "/v2/exclusive/contract/saveNonProfitCorporateRegistNo",
          body
        ); // API-WP_IF_국내판매_011 비영리법인 사업자번호 저장
        if (!err) {
          let canOpenOZReport = await this.createCertification(false, data);
          if(canOpenOZReport){
            this.callOZreport();
          }
        }else{
         /* this.alertMessage =
            "사업자번호, 주민번호 저장시 오류가 발생했습니다.";
          this.alertMessagePop = true; */
        }
      }
      
      this.popVisibleCorpNumber.visible = false;
      
    },
    async issueCarCertification() {
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      // 제작증 발급 action
      //자동차제작증 발급
      if (this.$mq === "mobile") {
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
        this.popVisibleLoading = false
        /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */        
        this.alertMessage = "제작증은 PC에서만 출력 가능합니다.";
        this.alertMessagePop = true;
        return;
      }

      this.getContractTabData().then(async () => {
        // 재조회 후 호출
        let canOpenOZReport = false; // ozReport open YN
        const carProductionNumber = this.carProductionNumber; // 차량정보
        //const { carProductionNumber } = this.carInfoData
        const { carMakeCertificateIssueYn } = this.contractData; // 계약정보
        const { contractNumber } = this.info; // 계약출고상세 정보
        const { makeDocumentIssueDate } = this.info; // 상태별일자 정보

        this.isCertificationRequestValidDate = moment().isSameOrBefore(
          moment(makeDocumentIssueDate, "YYYYMMDD HH:mm").add(14, "days")
        ); // 제작증 발급 요청일시에 대한 발급가능 여부에 대한 유효성 여부
        if (carMakeCertificateIssueYn !== "Y") {
          // 최초 발급하는 경우
          const params = { contractNumber, carProductionNumber };
          //API-E-구매서비스-047 (자동차제작증 발급 사전체크)
          let [res, err] = await this.$https.get(
            "/purchase/v2/purchase/proof-document/car-document/check",
            params,
            null,
            "gateway"
          );
          console.log(res);
          /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
          this.popVisibleLoading = false
          /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */          
          if (!err) {
            if (res.data && res.data.checkValue === "00000") {
              // 비영리법인일 경우 법인번호 혹은 주민번호 받는 로직 추가 필요

              if (this.contractData.nonProfitCorporateYn === "Y") {
                this.popVisibleCorpNumber.visible = true;
              } else {
                canOpenOZReport = await this.createCertification(canOpenOZReport, null);
              }
            } else {
              this.alertMessage = `지금은 제작증 발급이 불가능합니다.(${res.data &&
                res.data.checkValue})`;
              this.alertMessagePop = true;
            }
          }
        } else if (
          carMakeCertificateIssueYn === "Y" &&
          this.isCertificationRequestValidDate
        ) {
          /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
          this.popVisibleLoading = false
          /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */          
          canOpenOZReport = true; //발급일로부터 14일이내 재출력 가능
        } else {
          /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
          this.popVisibleLoading = false
          /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */          
          this.alertMessage =
            "발급 가능일이 경과되었습니다.\n(차량제작증발급일 + 14Day (최초발급일 포함 15일))";
          this.alertMessagePop = true;
        }

        //오즈레포트 호출
        if (canOpenOZReport) {
          this.callOZreport();
        }
      });

      // this.$nuxt.$loading.finish()
    },
    async createCertification(canOpenOZReport, data) {
      const contractNumber = this.contractNumber;

      // 발급 가능할경우
      const params2 = {
        ...data,
        contractNumber,
        issueBranchNumber: contractNumber.substring(0, 3)
      };
      //API-E-구매서비스-017 (자동차 제작증 발급)
      const [res2, err2] = await this.$https.get(
        "/purchase/v2/purchase/proof-document/car-document/issue",
        params2,
        null,
        "gateway"
      );

      if (!err2) {
        if (res2.data.resultValue === "COMPLETE") {
          // const params3 = { contractNumber }
          // //API-E-구매서비스-068 (수입인지 발행 조회)
          // // eslint-disable-next-line no-unused-vars
          // const [res3, err3] = await this.$https.get('/purchase/v2/purchase/proof-document/revenue-stamp/issue', params3, null, 'gateway')
          //
          // if (!err3) {
          canOpenOZReport = true;
          // } else {
          //   this.alertMessage = '수입인지가 발행되지 않았습니다.'
          //   this.alertMessagePop = true
          // }
          return canOpenOZReport;
        } else {
          this.alertMessage = `제작증 발급이 거부되었습니다.${
            res2.rspStatus ? "(" + res2.rspStatus.rspCode + ")" : ""
          }`;
          this.alertMessagePop = true;
        }
      }
    },
    async callOZreport() {
       const contractNumber = this.contractNumber;
      
        // API-E-구매서비스-005(자동차 제작증 정보 조회)
        const params = { contractNumber };
        const params2 = { saleCnttNo: contractNumber };
        const [resR1, errR1] = await this.$https.get(
          "/purchase/v2/purchase/proof-document/car-document",
          params,
          null,
          "gateway"
        );
        if (!errR1) {
          if (
            resR1 &&
            resR1.data &&
            resR1.data.salecnttno &&
            resR1.data.salecnttno.length > 0
          ) {
            // eslint-disable-next-line no-unused-vars
            Object.entries(resR1.data).forEach(([k, v]) => {
              if (v === null) resR1.data.k = "";
            });
            sessionStorage.setItem(
              "formDataCarCertificate",
              JSON.stringify(resR1)
            );
          } else {
            sessionStorage.removeItem("formDataCarCertificate");
          }
        } else {
          sessionStorage.removeItem("formDataCarCertificate");
        }
        // API-E-구매서비스-020(저공해차 증명서 조회)
        const [resR2, errR2] = await this.$https.get(
          "/purchase/v2/purchase/proof-document/low-pollution-car",
          params2,
          null,
          "gateway"
        );
        if (!errR2) {
          if (
            resR2 &&
            resR2.data &&
            resR2.data.carDesignation &&
            resR2.data.carDesignation.length > 0
          ) {
            // eslint-disable-next-line no-unused-vars
            Object.entries(resR2.data).forEach(([k, v]) => {
              if (v === null) resR2.data.k = "";
            });
            sessionStorage.setItem(
              "formDataLowPollutionCar",
              JSON.stringify(resR2)
            );
          } else {
            sessionStorage.removeItem("formDataLowPollutionCar");
          }
        } else {
          sessionStorage.removeItem("formDataLowPollutionCar");
        }
        // API-E-구매서비스-027(영수증 정보 조회)
        // const [resR3, errR3] = await this.$https.get(
        //   "/purchase/v2/purchase/proof-document/car/receipts-voucher",
        //   params2,
        //   null,
        //   "gateway"
        // );
        // if (!errR3) {
        //   if (
        //     resR3 &&
        //     resR3.data &&
        //     resR3.data.taxinvoiceNumber &&
        //     resR3.data.taxinvoiceNumber.length > 0
        //   ) {
        //     // eslint-disable-next-line no-unused-vars
        //     Object.entries(resR3.data).forEach(([k, v]) => {
        //       if (v === null) resR3.data.k = "";
        //     });
        //     sessionStorage.setItem(
        //       "formDataCarReceiptsVoucher",
        //       JSON.stringify(resR3)
        //     );
        //   } else {
        //     sessionStorage.removeItem("formDataCarReceiptsVoucher");
        //   }
        // } else {
        //   sessionStorage.removeItem("formDataCarReceiptsVoucher");
        // }
        // setTimeout(() => {
        //   const win = window.open(
        //     "/report/carProductionCertificate/index.html",
        //     "_blank"
        //   );
        //   win.focus();
        // }, 200);

        //2021-12-20 #10363 법인 > 세금계산서                            
        const [resR3, errR3] = await this.$https.get(
          "/purchase/v2/purchase/proof-document/tax-invoice/document",
          params3,
          null,
          "gateway"
        );
        if (!errR3) {
          if (
            resR3 &&
            resR3.data 
          ) {
            // eslint-disable-next-line no-unused-vars
            Object.entries(resR3.data).forEach(([k, v]) => {
              if (v === null) resR3.data.k = "";
            });
            sessionStorage.setItem(
              "formDataTaxInvoice",
              JSON.stringify(resR3)
            );
            console.log("resR3 >>" + JSON.stringify(resR3));
          } else {
            sessionStorage.removeItem("formDataTaxInvoice");
          }
        } else {
          sessionStorage.removeItem("formDataTaxInvoice");
        }

        setTimeout(() => {
          const win = window.open(
            "/report/carProductionCertificate/index.html",
            "_blank"
          );
          win.focus();
        }, 200);

        setTimeout(() => {
          const win = window.open(
            "/report/taxInvoice/index.html",
            "_blank"
          );
          win.focus();
        }, 200);

        

        //API-E-구매서비스-096 (차량 구매 완료 처리) - 양지수
        // 자동차제작증 발급 완료 -> 자동차 구매 완료 (상태코드 UPDATE!)
        const [resR4, errR4] = await this.$https.post(
          "/purchase/v2/purchase/proof-document/car-document/complete",
          params,
          null,
          "gateway"
        );
    },
	
    async applyExrsDcStatus() {
      if (!this.contractNumber) return

      //결제 실패 상태시, 블루선포인트 적용 or 현대캐피탈 할부 계약인 경우
      if(this.info.onlineStatusCode ==='9131' 
            && (this.info.blueMembersPrePointApplyYn ==='Y' 
                  || (this.payDetail.paymentInfo && this.payDetail.paymentInfo.findIndex((ele) => ele.paymentTypeCode === '10' && ele.paymentStateCode ==='13') > -1))
      ){
        this.alertMessage = '현대캐피탈 할부 및 블루멤버스 선포인트가 적용된 계약은 전담DC 적용이 불가능합니다.'
        this.alertMessagePop = true
        return 
      }
      
      this.popVisibleLoading = true
      const [res, err] = await this.$https.post(
        "/v2/exclusive/contract/applyDcStatus/" + this.contractNumber
      );
      if (!err) {
        if (res.data === 1) {
          //성공
          this.alertMessage = "전담DC품의 이력을 조회했습니다.";
          this.alertMessagePop = true;

          this.$refs.StatusHistory.getDcHistory();
        } else {
          //실패
          this.alertMessage =
            "현재 해당 계약에 승인된 전담DC 품의 이력이 없습니다.";
          this.alertMessagePop = true;
        }
      } else {
        console.error("/contract/applyDcStatus ERROR ::: " + err);
      }
      this.popVisibleLoading = false;
    },
	
    async doPaymentInit() {
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      const [res, err] = await this.$https.post(
        "purchase/v2/purchase/contract/contract-info/payment-init/" +
          this.contractNumber,
        null,
        null,
        "gateway"
      );
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
      if (!err) {
        console.log(res);
        if (res.rspStatus && res.rspStatus.rspCode === "0000") {
          this.alertMessage = "결제 초기화되었습니다.";
          this.alertMessagePop = true;
          this.getInfoData();
        }
      } else {
        console.error(err);
      }
      this.checkPaymentInitPop = false;
    },
    contractorHpTns() {
      const contractorInfo =
        this.contractData && this.contractData.contractorInfo;
      const targetContractorInfo =
        contractorInfo &&
        contractorInfo.filter(items => {
          return this.contractorNames.includes(items.customerName);
        });
      return (
        targetContractorInfo &&
        targetContractorInfo
          .map(items => {
            return (
              items.customerMobile +
              (items.contractorTypeName
                ? "(" + items.contractorTypeName + ")"
                : "")
            );
          })
          .join(", ")
      );
    },
    tableRowClassName({ row, rowIndex }) {
      if (row.contractNumber === this.contractNumber) {
        return "warning-row";
      }
      return "";
    },
    searchAddressPopOpen(index) {
      this.popVisibleAddress.addressPop = true;
      this.popVisibleAddress.addrIndex = index;
    },
    addDocumentPopOpen() {
      this.popVisibleRequestPaper = true;
    },
    async onReassignment() {
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      // 재배정
      const body = {
        contractNumber: this.contractNumber,
        contractCarTypeCode: this.contractData.contractCarTypeCode,
        productionCarNumber: ""
      };

      console.log(body);
      const [res, err] = await this.$https.get(
        "/purchase/v2/purchase/contract/reassignment/request",
        body,
        null,
        "gateway"
      ); // TODO: 다중선택으로 변경시 body[0] => body로 변경
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      if (!err) {
        this.alertVisibleReassignment = false;
        console.log(res);
        if (res.data.assignmentRequestResultCode !== "10") {
          this.alertMessage = "재배정 요청을 성공했습니다.";
          this.alertMessagePop = true;
          this.onRefresh(true, "contract");
        } else {
          this.alertMessage = "재배정 요청에 실패했습니다.";
          this.alertMessagePop = true;
        }
      } else {
        console.error(err);
      }
    },
    async onCancelCarAllocation() {
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = true
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      // 배정취소
      const body = {
        contractNumber: this.contractNumber
      };

      console.log(body);
      const [res, err] = await this.$https.get(
        "/purchase/v2/purchase/contract/cancelCarAllocation",
        body,
        null,
        "gateway"
      ); // TODO: 다중선택으로 변경시 body[0] => body로 변경
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
      this.popVisibleLoading = false
      /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */      
      if (!err) {
        console.log(res);
        this.popVisibleCancelCarAllocation = false;
        if (res.data.result === "취소성공") {
          this.alertMessage = "배정(요청) 취소에 성공했습니다.";
          this.alertMessagePop = true;
          this.getInfoData();
          this.getContractTabData();
        } else {
          this.alertMessage =
            "배정(요청) 취소에 실패했습니다. " + res.data.result;
          this.alertMessagePop = true;
        }
      } else {
        this.popVisibleCancelCarAllocation = false;
        this.alertMessage = "배정(요청) 취소에 실패했습니다. ";
        this.alertMessagePop = true;
        console.error(err);
      }
    },
    async onSavePaymentRequest() {
      // 빠른결제요청 상태 변경
      const body = {
        contractNoList: [this.contractNumber]
      };

      if (body.length === 0) {
        this.alertMessage = "변경 할 목록이 없습니다.";
        this.alertMessagePop = true;
      } else {
        console.log(body);
        const [res, err] = await this.$https.post(
          "/purchase/v2/purchase/contract/quickPayment/request",
          body,
          null,
          "gateway"
        ); // TODO: 다중선택으로 변경시 body[0] => body로 변경
        if (!err) {
          console.log(res);
          if (res.data.resultYn === "Y") {
            this.alertMessage = "변경되었습니다.";
            this.alertMessagePop = true;
            this.onRefresh(true, "contract");
          } else {
            this.alertMessage = res.data.resultMessage;
            this.alertMessagePop = true;
          }
        } else {
          console.error(err);
        }
      }
    },
    async onChangeDocumentType(data) {
      const [res, err] = await this.$https.get(
        "/v2/exclusive/mypage/document/target/" + data
      );
      if (!err) {
        console.log(res);
        this.documentTargets = res.data;
      } else {
        console.error(err);
      }
    },
    async updateContractAssignPopup(val){
      const [res1, err1] = await this.$https.post(
        "/v2/exclusive/work/payment",
        { contractNumber: val }
      );
      if (!err1) {
        console.log("/work/payment/", res1.data);
        this.payInfoData = res1.data;
        this.payInfoData.contractNumber = val;
        this.updateContractAssignPop = true
      } else {
        console.error(err1);
      }
    },
    async updateContractAssign() {

      
      console.log(moment().isAfter(this.payInfoData.afterApproveDate));

      if (this.isEmployee) {
        if (!this.payInfoData.afterApproveDate) {
          this.alertMessage = "현재 직원 재인증을 진행중입니다.";
          this.alertMessagePop = true;
          return;
        }

        if (
          this.payInfoData.afterApproveDate &&
          moment().isAfter(this.payInfoData.afterApproveDate)
        ) {
          this.alertMessage = "직원 2차 인증이 필요합니다.";
          this.alertMessagePop = true;
          return;
        }
      }

      const [res, err] = await this.$https.post(
        "purchase/v2/purchase/contract/contract-info/assign/" +
          this.payInfoData.contractNumber,
        null,
        null,
        "gateway"
      );

      if (!err) {
        console.log(res);
        if (res.rspStatus && res.rspStatus.rspCode === "0000") {
          this.alertMessage = "변경되었습니다.";
          this.alertMessagePop = true;
          this.$emit("refresh", true);
        }
      } else {
        console.error(err);
      }
      this.updateContractAssignPop = false;
    },
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - START ######## */
    oneClickDisable(event, clickEvent, ...args) {
      if(event.target.disabled === true){
        retrun
      }

      event.target.disabled = true

      try {
        clickEvent(...args)
      } catch {}
      setTimeout(() => {
        event.target.disabled = false
      }, 2000)
    },
    /* ######## W Project #11149 - <2022-04-15> - <A934118> - END ######## */
    /* ######## W Project #12159 - <2022-04-25> - <A934118> - START ######## */    
    async searchContractAssignChange(value) {
      this.popShow.reservedCenterPop = false
      if(!this.isValidAuthBtn('authSelect')) { // 권한없을경우 동작 x
        return
      }

      if(!value) {
        this.alertMessage = '계약번호를 입력해주세요.'
        this.alertMessagePop = true
        return
      } else {
        value = value.trim() // 공백 제거
      }

      this.contractNumber = value;
      await this.getInfoData();
      this.getPaymentTabData();
    },
    /* ######## W Project #12159 - <2022-04-25> - <A934118> - END ######## */  

  }
};
</script>
<style lang="scss">
.warning-row {
  background-color: #aed0fa;
}
</style>
<style lang="scss" scoped>
/deep/.el-icon-info {
  font-size: 34px;
  color: #002b5e;
  padding-bottom: 10px;
}

@import "~/assets/style/pages/detail.scss";
</style>
