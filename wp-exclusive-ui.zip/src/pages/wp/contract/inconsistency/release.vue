<template>
  <section>
    <div id="release">
      <div class="btn-wrap">
        <div class="side">
          <el-button type="primary" @click="resetSearchCond">
            초기화
          </el-button>
        </div>
        <div class="main">
          <el-button
            type="primary"
            @click="onSearch(1)"
          >
            조회
          </el-button>
          <el-button
            type="primary"
            class="excel"
            @click="downloadExcel"
          >
            Excel 다운로드
          </el-button>
        </div>
      </div>
      <div class="board-wrap">
        <el-form
          ref="ruleForm"
          :model="ruleForm"
          class="detail-form table-wrap"
        >
          <el-row>
            <el-col :span="24">
              <el-form-item
                label="계약일"
                required
                align=""
              >
                <el-date-picker
                  v-model="ruleForm.searchFromDt"
                  type="date"
                  :clearable="false"
                  style="margin-left: 10px"
                />
                <span class="ex-txt" style="margin:0 10px">~</span>
                <el-date-picker
                  v-model="ruleForm.searchEndDt"
                  type="date"
                  :clearable="false"
                />
                <el-radio-group
                  v-model="searchDtRadio"
                  class="tabBtn-case01"
                  @change="onChangeSearchDtRadio"
                >
                  <el-radio-button label="lastDay">
                    전일
                  </el-radio-button>
                  <el-radio-button label="today">
                    오늘
                  </el-radio-button>
                  <el-radio-button label="day7">
                    7일
                  </el-radio-button>
                  <el-radio-button label="day30">
                    30일
                  </el-radio-button>
                  <el-radio-button label="month3">
                    3개월
                  </el-radio-button>
                  <el-radio-button label="month6">
                    6개월
                  </el-radio-button>
                  <el-radio-button label="month12">
                    1년
                  </el-radio-button>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="진행상태(온라인)" prop="onlineStatus">
                <el-select
                  v-model="ruleForm.onlineStatus"
                  multiple
                  collapse-tags
                  placeholder="전체"
                  style="max-width: 180px"
                  @change="onChangeMultiSelect($event, 'online')"
                >
                  <el-option
                    v-for="{ value, label } in LegacyCommonCodes.C013 &&
                      LegacyCommonCodes.C013.slice(1)"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
                <el-checkbox
                  v-model="onlineSelectedVal"
                  style="margin-left: 8px"
                  @change="selectedAll($event, 'online')"
                >
                  전체
                </el-checkbox>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="진행상태(국판)" prop="legacyStatus">
                <el-select
                  v-model="ruleForm.legacyStatus"
                  multiple
                  collapse-tags
                  placeholder="전체"
                  @change="onChangeMultiSelect($event, 'legacy')"
                >
                  <el-option
                    v-for="{ value, label } in LegacyCommonCodes.C013 &&
                      LegacyCommonCodes.C013.slice(1)"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
                <el-checkbox
                  v-model="legacySelectedVal"
                  style="margin-left: 8px"
                  @change="selectedAll($event, 'legacy')"
                >
                  전체
                </el-checkbox>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="계약담당자" prop="consultantId">
                <el-select
                  v-model="ruleForm.consultantId"
                  placeholder="전체"
                  multiple
                  collapse-tags
                  @change="onChangeMultiSelect($event, 'consultant')"
                >
                  <el-option
                    v-for="{ sysUserNo, sysUserNm } in consultants &&
                      consultants.slice(1)"
                    :key="sysUserNo"
                    :value="sysUserNo"
                    :label="sysUserNm"
                  />
                </el-select>
                <el-checkbox
                  v-model="consultantSelectedVal"
                  style="margin-left: 8px"
                  @change="selectedAll($event, 'consultant')"
                >
                  전체
                </el-checkbox>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="계약번호" prop="saleCnttNo">
                <el-input
                  v-model="ruleForm.saleCnttNo"
                  @keyup.native.enter="onSearch(1)"
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="주계약자">
                <el-input
                  v-model="ruleForm.contractorName"
                  @keyup.native.enter="onSearch(1)"
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="불일치 내용" prop="diffContent">
                <el-select
                  v-model="ruleForm.diffContent"
                  placeholder="전체"
                  collapse-tags
                >
                  <el-option
                    v-for="{ codeName, codeValue } in diffCodes"
                    :key="codeValue"
                    :value="codeValue"
                    :label="codeName"
                  />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <article class="article">
        <el-table
          :data="tableData"
          style="width: 100%"
          empty-text="조회된 조회결과가 존재하지 않습니다."
          max-height="1136"
          @sort-change="sortChange"
        >
          <el-table-column
            prop="no"
            label="NO."
            align="center"
            width="50"
            fixed
          />
          <el-table-column
            label="불일치"
            prop="content"
            width="200"
            align="center"
            fixed
          />
          <el-table-column
            label="계약번호"
            prop="saleCnttNo"
            width="150"
            align="center"
            sortable="custom"
            fixed
          >
            <template slot-scope="props">
              <a
                v-if="props.row.psnCorpCd === '1' || props.row.psnCordCpd === '2'"
                class="link"
                href="/#/wp/contract/customer/release-detail"
                target="_blank"
                @click="
                  $utils.setLocalStorage({
                    contractNumber: props.row.saleCnttNo
                  })
                "
              >
                {{ props.row.saleCnttNo | capitalize }}
              </a>
              <a
                v-else
                class="link"
                href="/#/wp/contract/corporation/release-detail"
                target="_blank"
                @click="
                  $utils.setLocalStorage({
                    contractNumber: props.row.saleCnttNo
                  })
                "
              >
                {{ props.row.saleCnttNo | capitalize }}
              </a>
            </template>
          </el-table-column>
          <el-table-column
            label="계약일"
            prop="contractDate"
            width="150"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="성명"
            prop="contractorNm"
            width="100"
            align="center"
            sortable="custom"
          />
          <el-table-column
            label="담당자"
            prop="employeeNm"
            width="100"
            align="center"
            sortable="custom"
          />
          <el-table-column label="진행상태" width="200">
            <el-table-column
              label="온라인"
              prop="onlineStatusNm"
              width="100"
              align="center"
              sortable="custom"
              fixed
            />
            <el-table-column
              label="국판"
              prop="legacyStatusNm"
              width="100"
              align="center"
              sortable="custom"
              fixed
            />
          </el-table-column>
          <el-table-column label="판매코드" width="400">
            <el-table-column
              label="온라인"
              prop="onlineSaleCd"
              width="250"
              align="center"
              sortable="custom"
              fixed
            />
            <el-table-column
              label="국판"
              prop="legacySaleCd"
              width="250"
              align="center"
              sortable="custom"
              fixed
            />
          </el-table-column>
          <el-table-column label="고객구분" width="200">
            <el-table-column
              label="온라인"
              prop="onlineCustTypeCd"
              width="100"
              align="center"
              sortable="custom"
              fixed
            />
            <el-table-column
              label="국판"
              prop="legacyCustTypeCd"
              width="100"
              align="center"
              sortable="custom"
              fixed
            />
          </el-table-column>
          <el-table-column label="출고센터" width="200">
            <el-table-column
              label="온라인"
              prop="onlineDeliveryCenterCd"
              width="100"
              align="center"
              sortable="custom"
              fixed
            />
            <el-table-column
              label="국판"
              prop="legacyDeliveryCenterCd"
              width="100"
              align="center"
              sortable="custom"
              fixed
            />
          </el-table-column>
          <el-table-column label="탁송지역코드" width="200">
            <el-table-column
              label="온라인"
              prop="onlineDeliveryPlaceCd"
              width="100"
              align="center"
              sortable="custom"
              fixed
            />
            <el-table-column
              label="국판"
              prop="legacyDeliveryPlaceCd"
              width="100"
              align="center"
              sortable="custom"
              fixed
            />
          </el-table-column>
        </el-table>
        <div class="btn-wrap">
          <div class="side"></div>
          <div class="pagination">
            <v-pagination
              v-if="tableData.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch"
            />
          </div>
          <div class="main"></div>
        </div>
      </article>

      <!-- 조회결과없음 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="alertNoData"
        :width="pupWidth"
      >
        <!-- Message -->
        조회 결과가 없습니다.

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button type="primary" @click="alertNoData = false">
            확인
          </el-button>
        </template>
      </el-dialog>

      <loading
        :pop-visible.sync="popVisibleLoading"
        @close="popVisibleLoading = false"
      />
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import { mapState } from "vuex"
import HTable from "~/components/common/HTable.vue"
import Loading from "~/components/popup/Loading.vue"
import moment from "moment"
import PopMessage from "~/components/popup/PopMessage.vue"

export default {
  name: "Release",
  layout: "default",
  components: {
    HTable,
    Loading,
    PopMessage
  },
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      tableData : [],
      pageInfo: {
        // paging info
        page: 1,
        size: 20,
        total: 0
      },
      popVisibleLoading: false,
      pupWidth: '550px',
      alertNoData: false,
      searchDtRadio: 'today',
      ruleForm: {
        searchFromDt: moment(),
        searchEndDt: moment(),
        onlineStatus: [],
        legacyStatus: [],
        consultantId: [],
        saleCnttNo: '',
        contractorName: '',
        diffContent:'',
      },
      LegacyCommonCodes: {},
      diffCodes:[
        {codeName: '전체', codeValue: ''},
        {codeName: '진행상태', codeValue: '01'},
        {codeName: '판매코드', codeValue: '02'},
        {codeName: '고객구분', codeValue: '03'},
        {codeName: '출고센터', codeValue: '04'},
        {codeName: '탁송지역코드', codeValue: '05'}
      ],
      onlineSelectedVal: false,
      legacySelectedVal: false,
      consultantSelectedVal: false,
      diffCodesSelectedVal: false,
      sortInfo: {
        order: "",
        prop: ""
      },
    }
  },
  computed: {
    ...mapState({
      userInfo: state => state.userInfo
    }),
    consultants: function() {
      const consultants = this.$store.state.authConsultants.slice()
      if (consultants && consultants.length > 0) {
        consultants.unshift({
          useAuthId: "",
          sysUserNo: "",
          sysUserNm: "전체",
          opsNm: ""
        })
      }
      return consultants
    },
  },
  async created() {
    await this.loadCommonCode()
  },
  mounted() {

    this.$store.dispatch("loadAuthConsultants", { vm: this })
    this.$store.dispatch("loadAllTypeCars", { vm: this })
    this.$store.dispatch("loadCommonCodesCustomerType", {
      vm: this,
      customerType: "customer"
    })

    this.onSearch(1)
  },
  methods: {
    async loadCommonCode() {
      const [ccU019, ccT010, ccC013, ccT045, ccT048] = await Promise.all([
        this.fetchCommonCodeData("E", "U019"), // 구분
        this.fetchCommonCodeData("W", "T010"), // 온라인몰 진행상태
        this.fetchCommonCodeData("C", "C013"), // 레거시 진행상태
        this.fetchCommonCodeData("E", "T045"), // 취소사유
        this.fetchCommonCodeData("E", "T048"), // 취소사유
      ])
      this.commonCodes = { ...ccU019, ...ccT010, ...ccT045, ...ccT048 }
      this.LegacyCommonCodes = { ...ccC013 }
      this.initRuleFormStatus()
    },
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null;
      switch (systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {
          vm: this,
          codeTypeCode: codeType
        })
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {
          vm: this,
          codeTypeCode: codeType
        })
        break
      case 'W':
        res = this.$store.dispatch('loadCommonCodesW', {
          vm: this,
          codeTypeCode: codeType
        })
        break
      }
      return res
    },
    initRuleFormStatus() {
      if (
        this.ruleForm.legacyStatus &&
        this.ruleForm.legacyStatus.length === 0
      ) {
        // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false, "legacy")
      }
      if (
        this.ruleForm.onlineStatus &&
        this.ruleForm.onlineStatus.length === 0
      ) {
        // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false, "online")
      }
      if (
        this.ruleForm.consultantId &&
        this.ruleForm.consultantId.length === 0
      ) {
        // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false, "consultant")
      }
    },
    sortChange(props) {
      const { prop, order } = props

      let convertOrder = ""

      if (order === "descending") {
        convertOrder = "desc"
      } else if (order === "ascending") {
        convertOrder = "asc"
      }

      this.sortInfo = { prop, order: convertOrder }
      this.getData()
    },
    async getData() {

      //날짜 포맷 API형식에 맞추기
      const searchFromDt = moment(this.ruleForm.searchFromDt).format(
        "YYYYMMDD"
      )
      const searchEndDt = moment(this.ruleForm.searchEndDt).format("YYYYMMDD")
      if (!this.ruleForm.searchFromDt || !this.ruleForm.searchEndDt) {
        this.alertMessage = "날짜는 필수입력사항입니다."
        this.alertMessagePop = true
        return false
      }
      if (searchEndDt - searchFromDt > 10000) {
        this.alertMessage = "최대 조회 가능기간은 1년입니다.";
        this.alertMessagePop = true
        return false
      }

      const param = {
        ...this.ruleForm,
        pageNo : this.pageInfo.page,
        pageSize : this.pageInfo.size ,
        searchFromDt,
        searchEndDt,
        sortingId: this.sortInfo.prop,
        sortingType: this.sortInfo.order
      }
      
      this.popVisibleLoading = true

      const [res, err] = await this.$https.post(
        "/v2/exclusive/onlineAndLegacyDifference",
        param
      )

      this.popVisibleLoading = false

      if(!err){

        if (!res.data || !res.data.list || res.data.list.length === 0) {
          this.tableData = []
        } else {
          this.tableData = res.data.list.map((el, idx) => {
            return {
              ...el,
              no: res.data.total - res.data.endRow + res.data.list.length - idx,
            }
          })

          this.pageInfo = {
            ...this.pageInfo,
            total: res.data.total
          }
        }
        
      }else{
        console.error(err)
      }

    },
    onSearch(page) {
      this.pageInfo.page = page
      this.getData()
    },
    resetSearchCond() {
      Object.assign(this.ruleForm, this.$options.data().ruleForm)
      this.searchDtRadio = "today"
    },
    onChangeSearchDtRadio(val) {
      if (val === "lastDay") {
        this.ruleForm.searchFromDt = moment().subtract("days", 1)
        this.ruleForm.searchEndDt = moment().subtract("days", 1)
      } else if (val === "today") {
        this.ruleForm.searchFromDt = moment()
        this.ruleForm.searchEndDt = moment()
      } else if (val === "day7") {
        this.ruleForm.searchFromDt = moment().subtract("days", 7)
        this.ruleForm.searchEndDt = moment()
      } else if (val === "day30") {
        this.ruleForm.searchFromDt = moment().subtract("days", 30)
        this.ruleForm.searchEndDt = moment()
      } else if (val === "month3") {
        this.ruleForm.searchFromDt = moment().subtract("months", 3)
        this.ruleForm.searchEndDt = moment()
      } else if (val === "month6") {
        this.ruleForm.searchFromDt = moment().subtract("months", 6)
        this.ruleForm.searchEndDt = moment()
      } else if (val === "month12") {
        this.ruleForm.searchFromDt = moment().subtract("months", 12)
        this.ruleForm.searchEndDt = moment()
      }
    },
    selectedAll(e, type) {
      if (type === "online") {
        if (e) {
          this.ruleForm.onlineStatus =
            this.LegacyCommonCodes.C013.slice(1).map(items => {
              return items.value
            }) || []
        } else {
          this.ruleForm.onlineStatus = []
        }
      } else if (type === "legacy") {
        if (e) {
          this.ruleForm.legacyStatus =
            this.LegacyCommonCodes.C013.slice(1).map(items => {
              return items.value
            }) || []
        } else {
          this.ruleForm.legacyStatus = []
        }
      } else if (type === "consultant") {
        if (e) {
          this.ruleForm.consultantId =
            this.consultants.slice(1).map(items => {
              return items.sysUserNo
            }) || []
        } else {
          this.ruleForm.consultantId = []
        }
      }
    },
    onChangeMultiSelect(data, type) {
      if (type === "online") {

        if (data.length === this.LegacyCommonCodes.C013.slice(1).length) {
          this.onlineSelectedVal = true;
        } else {
          this.onlineSelectedVal = false;
        }

      } else if (type === "legacy") {

        if (data.length === this.LegacyCommonCodes.C013.slice(1).length) {
          this.legacySelectedVal = true;
        } else {
          this.legacySelectedVal = false;
        }

      } else if (type === "consultant") {

        if (data.length === this.consultants.slice(1).length) {
          this.consultantSelectedVal = true;
        } else {
          this.consultantSelectedVal = false;
        }

      }
    },
    async downloadExcel() {

      //날짜 포맷 API형식에 맞추기
      const searchFromDt = moment(this.ruleForm.searchFromDt).format(
        "YYYYMMDD"
      )
      const searchEndDt = moment(this.ruleForm.searchEndDt).format("YYYYMMDD")
      if (!this.ruleForm.searchFromDt || !this.ruleForm.searchEndDt) {
        this.alertMessage = "날짜는 필수입력사항입니다."
        this.alertMessagePop = true
        return false
      }
      if (searchEndDt - searchFromDt > 10000) {
        this.alertMessage = "최대 조회 가능기간은 1년입니다.";
        this.alertMessagePop = true
        return false
      }

      const params = {
        ...this.ruleForm,
        searchFromDt,
        searchEndDt,
        sortingId: this.sortInfo.prop,
        sortingType: this.sortInfo.order
      }

      // API-E-업무담당자-011 (계약출고현황 목록 엑셀저장)
      const [res, err] = await this.$https.post(
        '/v2/exclusive/onlineAndLegacyDifference-excel',
        params,
        null,
        null,
        { responseType: 'blob' }
      )
      if (!err) {
        const blob = new Blob([res], { type: res.Type })
        const nowDate = moment().format('YYYYMMDD_HHmm')
        if (window.navigator.msSaveOrOpenBlob) {
          // IE11
          window.navigator.msSaveOrOpenBlob(
            blob,
            '국판 온판 불일치 목록_' + nowDate + '.xlsx'
          )
        } else {
          // IE11 외 브라우저
          const blobURL = window.URL.createObjectURL(blob)
          const tempLink = document.createElement('a')

          tempLink.href = blobURL

          tempLink.setAttribute(
            'download',
            '국판 온판 불일치 목록_' + nowDate + '.xlsx'
          )
          document.body.appendChild(tempLink)
          tempLink.click()
          document.body.removeChild(tempLink)
          window.URL.revokeObjectURL(blobURL)
        }
        // screenUseTypeCode (01:열람,02:수정,03:삭제,04:인쇄,05:입력,06:업로드,07:다운로드)
        this.$store.dispatch('commonSupportLog', { vm: this, params: { screenUseTypeCode: '07', useInfo: JSON.stringify(params), fileName: '마이페이지 수신업무목록_' + nowDate + '.xlsx', fileSize: blob.size } })
      } else {
        console.error(err)
        this.tableData = null
      }
    },
  }
}
</script>

<style lang="scss" scoped>
@import "~/assets/style/pages/release.scss"
</style>
