<template>
  <section>
    <div id="reception">
      <div class="btn-wrap">
        <div class="side">
          <el-button
            type="primary"
            @click="resetSearchCond"
          >
            초기화
          </el-button>
        </div>

        <div
          class="main"
          style="width: 300px;"
        >
          <el-button
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            @click="onSearch(1)"
          >
            조회
          </el-button>
          <el-button
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            class="excel"
            @click="downloadExcel"
          >
            EXCEL 다운로드
          </el-button>
        </div>
      </div>
      <el-form
        ref="ruleForm"
        :model="ruleForm"
        class="detail-form detail-box"
      >
        <el-row>
          <el-col :span="24">
            <el-form-item
              label="기간"
              required
            >
              <el-date-picker
                v-model="ruleForm.searchFromDt"
                type="date"
                :clearable="false"
              />
              <span class="ex-txt">~</span>
              <el-date-picker
                v-model="ruleForm.searchEndDt"
                type="date"
                :clearable="false"
              />
              <el-radio-group
                v-model="searchDtRadio"
                class="tabBtn-case01"
                @change="onChangeSearchDtRadio"
              >
                <el-radio-button label="lastDay">
                  전일
                </el-radio-button>
                <el-radio-button label="today">
                  오늘
                </el-radio-button>
                <el-radio-button label="day7">
                  7일
                </el-radio-button>
                <el-radio-button label="day30">
                  30일
                </el-radio-button>
                <el-radio-button label="month3">
                  3개월
                </el-radio-button>
                <el-radio-button label="month6">
                  6개월
                </el-radio-button>
                <el-radio-button label="day365">
                  1년
                </el-radio-button>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item
              label="온라인 진행상태"
            >
              <el-select
                v-model="ruleForm.onlineStatus"
                multiple
                collapse-tags
                placeholder="전체"
                @change="onChangeMultiSelect($event,'online')"
              >
                <!-- commonCodes.T010 -->
                <el-option
                  v-for="item in onlineProgressCodes"
                  :key="item"
                  :value="item"
                  :label="item"
                />
              </el-select>
              <el-checkbox
                v-model="onlineSelectedVal"
                style="margin-left: 8px;"
                @change="selectedAll($event,'online')"
              >
                전체
              </el-checkbox>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item
              label="국판 진행상태"
            >
              <el-select
                v-model="ruleForm.legacyStatus"
                multiple
                collapse-tags
                style="max-width: 160px;"
                placeholder="전체"
                @change="onChangeMultiSelect($event, 'legacy')"
              >
                <el-option
                  v-for="{ value, label } in LegacyCommonCodes.C013 && LegacyCommonCodes.C013.slice(1)"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
              <el-checkbox
                v-model="legacySelectedVal"
                style="margin-left: 8px;"
                @change="selectedAll($event,'legacy')"
              >
                전체
              </el-checkbox>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item
              label="계약 담당자"
            >
              <el-select
                v-model="ruleForm.consultantId"
                placeholder="전체"
                multiple
                collapse-tags
                @change="onChangeMultiSelect($event,'authConsultant')"
              >
                <el-option
                  v-for="{ sysUserNo, sysUserNm } in authConsultants && authConsultants.slice(1)"
                  :key="sysUserNo"
                  :value="sysUserNo"
                  :label="sysUserNm"
                />
              </el-select>
              <el-checkbox
                v-model="consultantSelectedVal"
                style="margin-left: 8px;"
                @change="selectedAll($event,'authConsultant')"
              >
                전체
              </el-checkbox>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item
              label="업무유형"
              prop="workType"
            >
              <el-select
                v-model="ruleForm.workType"
              >
                <el-option
                  v-for="{ value, label } in commonCodes.U022"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item
              label="업무 진행상태"
            >
              <el-select
                v-model="ruleForm.workStatus"
                multiple
                collapse-tags
                placeholder="전체"
                @change="onChangeMultiSelect($event, 'work')"
              >
                <el-option
                  v-for="{ value, label } in commonCodes.U011 && commonCodes.U011.slice(1)"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
              <el-checkbox
                v-model="workSelectedVal"
                style="margin-left: 8px;"
                @change="selectedAll($event,'work')"
              >
                전체
              </el-checkbox>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item
              label="업무 처리자"
            >
              <el-select
                v-model="ruleForm.managerId"
                placeholder="전체"
              >
                <el-option
                  v-for="{ sysUserNo, sysUserNm } in authConsultants"
                  :key="sysUserNo"
                  :value="sysUserNo"
                  :label="sysUserNm"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item
              label="고객구분"
            >
              <el-select
                v-model="ruleForm.customerTypeCd"
                placeholder="전체"
                collapse-tags
              >
                <el-option
                  v-for="(item) in customerCodes"
                  :key="item.codeName"
                  :value="item.code"
                  :label="item.codeName"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item
              label="계약번호"
              prop="contractId"
            >
              <el-input
                v-model="ruleForm.contractId"
                @keydown.native.tab="onAddZero(ruleForm.contractId)"
                @keyup.native.enter="onSearch(1)"
              />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item
              label="고객정보"
            >
              <el-select
                v-model="ruleForm.customerInfoKey"
                placeholder="전체"
              >
                <el-option
                  v-for="(item) in customerInfo"
                  :key="item.name"
                  :value="item.value"
                  :label="item.name"
                />
              </el-select>
              <el-input
                v-model="ruleForm.customerInfoValue"
                @blur="ruleForm.customerInfoValue = $event.target.value"
                @keyup.native.enter="onSearch(1)"
              />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-form
        ref="ruleForm"
        :model="ruleForm"
        class="detail-form detail01"
        style="margin-top:10px;"
      >
        <el-form-item label="">
          <el-col
            :span="4"
            class="header"
          >
            집계데이터 조회
          </el-col>
          <el-col :span="5">
            대상리스트<span><span>{{ countData.totalCount || 0 }}</span>건</span>
          </el-col>
          <el-col :span="5">
            접수<span><span>{{ countData.received || 0 }}</span>건</span>
          </el-col>
          <el-col :span="5">
            진행중<span><span>{{ countData.proceeding || 0 }}</span>건</span>
          </el-col>
          <el-col :span="5">
            종결<span><span>{{ countData.closed || 0 }}</span>건</span>
          </el-col>
        </el-form-item>
      </el-form>
      <div class="btn-wrap">
        <div class="side">
          <el-checkbox
            v-model="checked"
            label="전체선택"
            @change="toggleSelectionAll"
          />
        </div>

        <div
          class="side"
        >
          <!-- <el-button
            v-if="isValidAuthBtn('authExclusive')"
            type="primary"
            @click="changeReadStatus"
          >
            읽음처리
          </el-button> -->
          <el-button
            v-if="isValidAuthBtn('authManage')"
            type="primary"
            @click="openConsultantPopup"
          >
            처리자 변경
          </el-button>
        </div>
      </div>

      <el-table
        ref="multipleTable"
        :data="tableData"
        max-height="450"
        empty-text="조회된 조회결과가 없습니다."
        :row-class-name="tableRowClassName"
        @sort-change="sortChange"
      >
        <el-table-column
          label="선택"
          prop="isSelected"
          align="center"
          width="50"
        >
          <template slot-scope="scope">
            <el-checkbox
              v-model="scope.row.isSelected"
              @change="onChange($event, scope.row)"
              @click.native.stop
            />
          </template>
        </el-table-column>
        <el-table-column
            prop="no"
            label="NO."
            align="center"
            width="50"
        />
        <el-table-column
          label="업무 일련번호"
          prop="workSerialNumber"
          align="center"
          width="120"
          sortable="custom"
        >
          <template slot-scope="props">
            <a
              class="link"
              href="/#/wp/mypage-reception/customer/process"
              target="_blank"
              @click="$utils.setLocalStorage({ workSerialNumber: props.row.workSerialNumber })"
            >
              {{ props.row.workSerialNumber }}
            </a>
          </template>
        </el-table-column>
        <el-table-column label="진행 정보">
          <el-table-column
            label="유형"
            prop="progressType"
            align="center"
            width="90"
            sortable="custom"
          />
          <el-table-column
            label="처리결과"
            prop="progressResult"
            align="center"
            width="90"
            sortable="custom"
          />
          <el-table-column
            label="국판 진행상태"
            prop="legacyStatusName"
            align="center"
            width="130"
            sortable="custom"
          />
          <el-table-column
            label="온라인 진행상태"
            prop="onlineStatusName"
            align="center"
            width="170"
            sortable="custom"
          />
        </el-table-column>
        <el-table-column label="계약자 정보">
          <el-table-column
            label="회원ID"
            prop="custId"
            align="center"
            width="100"
            sortable="custom"
          />
          <el-table-column
            label="이름"
            prop="contractorName"
            align="center"
            width="100"
            sortable="custom"
          />
          <el-table-column
            label="휴대전화"
            prop="custPhone"
            align="center"
            width="100"
            sortable="custom"
          />
          <el-table-column
            label="이메일"
            prop="custEmail"
            align="center"
            width="100"
            sortable="custom"
          />
          <el-table-column
            label="사업자번호"
            prop="companyNo"
            align="center"
            width="100"
            sortable="custom"
          />
        </el-table-column>
        <el-table-column label="계약정보">
          <el-table-column
            label="유형"
            prop="typeCd"
            align="center"
            width="120"
            sortable="custom"
          />
          <el-table-column
            label="고객구분"
            prop="customerType"
            align="center"
            width="120"
            sortable="custom"
          />
          <el-table-column
            label="계약번호"
            prop="contractNumber"
            align="center"
            width="130"
            sortable="custom"
          />
          <el-table-column
            label="재고구분"
            prop="stockType"
            align="center"
            width="100"
            sortable="custom"
          />
          <el-table-column
            label="계약일시"
            prop="contractDate"
            align="center"
            width="150"
            sortable="custom"
          />
          <el-table-column
            label="배정일시"
            prop="assignDate"
            align="center"
            width="150"
            sortable="custom"
          />
          <el-table-column
            label="출고일/출고예정일"
            prop="releaseOrExpectDate"
            align="center"
            width="150"
            sortable="custom"
          />
          <el-table-column
            label="제작증 발급일"
            prop="prdCertificationIssueDate"
            align="center"
            width="150"
            sortable="custom"
          />
        </el-table-column>
        <el-table-column label="결제정보">
          <el-table-column
            label="결제시작 일시"
            prop="payStartDate"
            align="center"
            width="150"
            sortable="custom"
          />
          <el-table-column
            label="결제기한"
            prop="payExpireDate"
            align="center"
            width="150"
          />
          <el-table-column
            label="업무기한"
            prop="releaseDate"
            align="center"
            width="150"
          />
        </el-table-column>
        <el-table-column label="처리상세 결과">
          <el-table-column
            label="첨부파일"
            prop="attcFilNm"
            align="center"
            width="100"
          >
            <template slot-scope="scope">
              <i class="file_img"></i>{{ scope.row.attcFilYn }}<br />
            </template>
          </el-table-column>
        </el-table-column>
        <el-table-column label="담당자">
          <el-table-column
            label="계약 담당자"
            prop="consultantName"
            align="center"
            width="100"
            sortable="custom"
          />
          <el-table-column
            label="업무 처리자"
            prop="managerName"
            align="center"
            width="100"
            sortable="custom"
          />
        </el-table-column>
        <el-table-column
          label="생성일시"
          prop="regDate"
          align="center"
          width="150"
          sortable="custom"
        />
      </el-table>
      <div class="btn-wrap">
        <div class="side"></div>
        <div class="pagination">
          <v-pagination
            v-if="tableData.length"
            :page.sync="pageInfo.page"
            :size="pageInfo.size"
            :total="pageInfo.total"
            @page-change="onSearch"
          />
        </div>
        <div class="main"></div>
      </div>
      <!-- 초기화 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="alertNoData"
      >
        <!-- Message -->
        조회 결과가 없습니다.

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="primary"
            @click="alertNoData = false"
          >
            확인
          </el-button>
        </template>
      </el-dialog>
      <!-- 업무담당자 변경 팝업 -->
      <el-dialog
        title="업무담당자 변경"
        :visible.sync="consultantPop"
        @open="consutantPopupOpened"
      >
        <!-- Message -->
        <el-form
          :inline="true"
          class="detail-form"
        >
          <el-row>
            <el-col :span="24">
              <el-form-item label="컨시어지">
                <el-select
                  v-model="selConsultant"
                  placeholder="컨시어지 선택"
                >
                  <el-option
                    v-for="{ sysUserNo, sysUserNm } in authConsultants && authConsultants.slice(1)"
                    :key="sysUserNo"
                    :value="sysUserNo"
                    :label="sysUserNm"
                  />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="primary"
            @click="changeConsultant"
          >
            변경
          </el-button>
        </template>
      </el-dialog>
      <loading
        :pop-visible.sync="popVisibleLoading"
        @close="popVisibleLoading = false"
      />
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import { mapState } from 'vuex'
import moment from 'moment'
import Loading from '~/components/popup/Loading.vue'
import PopMessage from '~/components/popup/PopMessage.vue'

export default {
  name: 'Reception',
  layout: 'default',
  components:{
    Loading,
    PopMessage
  },
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      workSelectedVal: false,
      legacySelectedVal: false,
      onlineSelectedVal: false,
      consultantSelectedVal: false,
      popVisibleLoading: false,
      selConsultant: null,
      multipleSelection: [],
      alertNoData: false,
      consultantPop: false,
      checked: false,
      searchDtRadio: 'today',
      onlineProgressCodes: {},
      ruleForm:{
        searchFromDt: moment(),
        searchEndDt: moment(),
        workType: 'all',
        workStatus: ['10','20'], // 업무진행상태(종결제외: 접수,진행중)
        onlineStatus: [],
        legacyStatus: [],
        consultantId: [],//TODO : 관리자 아닌 경우, 로그인한 사용자로 default
        managerId: '',
        contractId: '',
        customerInfoKey: '',
        customerInfoValue: '',
        customerTypeCd: '',
        customerTypeCdAll: [],
      },
      customerInfo:[{name: '회원ID', value : 'customerId'},
        {name: '이름', value : 'customerName'},
        {name: '휴대전화', value : 'customerPhone'},
        {name: '이메일', value : 'customerEmail'},
        {name: '사업자번호', value : 'customerCompanyNo'}],
      countData: {
        totalCount: 0,
        received: 0,
        proceeding: 0,
        closed: 0
      },
      code: [
        { value: 'all',  label: '전체' }
      ],
      tableData: [],
      commonCodes: {},
      LegacyCommonCodes: {},
      customerCodes:{},
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      },
      sortInfo: {
        order: '',
        prop: ''
      },
    }
  },
  computed: {
    ...mapState(['authConsultants', 'userInfo']),
    authConsultants: function() {
      const authConsultants = this.$store.state.authConsultants.slice()
      if(authConsultants && authConsultants.length > 0) {
        authConsultants.unshift( { 'useAuthId': '', 'sysUserNo': '', 'sysUserNm': '전체', 'opsNm': '' } )
      }
      return authConsultants
    }
  },
  mounted() {
    this.$store.dispatch('loadAuthConsultants', {vm: this})

    if(this.$store.state.userInfo.exclusiveUseAuthGroupIds.indexOf('WT001') !== -1){
      this.ruleForm.managerId = this.$store.state.userInfo.eeno
    }
  },
  async created() {
    await this.loadCommonCode()
  },
  methods: {
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null
      switch(systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {vm: this, codeTypeCode: codeType})
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {vm: this, codeTypeCode: codeType})
        break
      case 'W':
        res = this.$store.dispatch('loadCommonCodesW', {
          vm: this,
          codeTypeCode: codeType
        })
        break
      }
      return res
    },
    async loadCommonCode() {
      const [ccU022, ccU011, ccT010, ccC013] = await Promise.all([
        this.fetchCommonCodeData('E', 'U022'), // 업무 유형
        this.fetchCommonCodeData('E', 'U011'), // 업무 진행상태
        /* [#9951/2021.12.02] 온라인 진행상태 코드 systemTypeCode W로 전체 변경 적용 */
        this.fetchCommonCodeData('W', 'T010'), // 임직원몰 진행상태

        this.fetchCommonCodeData('C', 'C013'), // 레거시 진행상태
      ])

      this.commonCodes = { ...ccU022, ...ccU011, ...ccT010 }
      this.LegacyCommonCodes = { ...ccC013 }

      this.initRuleFormStatus()

      //T010 중복제거
      this.onlineProgressCodes = this.commonCodes.T010.slice(1)
        .map(el => {
          return el.label.replace(/\s/gi, '')
        })
        .reduce((unique, item) => {
          return unique.includes(item) ? unique : [...unique, item]
        }, [])

      //고객 구분 코드 GET
      const customerTypeParam = { customerType : 'customer' }
      const[res] = await this.$https.get('/v2/exclusive/common/customerTypeCode', customerTypeParam)
      this.customerCodes = res.data

      //대고객용 코드
      for(let data of res.data){
        if(data.code.indexOf('A') === 0){
          this.ruleForm.customerTypeCdAll.push(data.code)
        }
      }

      //나머지 대고객 개인 사업자 코드
      const etcCd = ['BA1', 'BL1']
      for(let dataEtc of etcCd){
        this.ruleForm.customerTypeCdAll.push(dataEtc)
      }

    },
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    onAddZero(contractNumber) {
      let resultString = ''
      if(contractNumber.length > 6) {
        const frontString = contractNumber.substring(0,7)
        const backString = contractNumber.substring(7)

        resultString = resultString.concat(frontString)
        resultString = resultString.concat(backString.length >= 6 ? backString : Array.from({length: 6 - backString.length}, () => 0).join('') + backString)
      }

      if(!resultString) { resultString = contractNumber }
      this.ruleForm.contractId = resultString
    },
    resetSearchCond() {
      Object.assign(this.ruleForm, this.$options.data().ruleForm)
      this.searchDtRadio = 'today'
    },
    onSearch(page) {
      if(!this.isValidAuthBtn('authSelect')) { // 권한없을경우 동작 x
        return
      }

      this.$data.pageInfo.page = page
      this.getData()
    },
    initRuleFormStatus() {
      if(this.ruleForm.workStatus && this.ruleForm.workStatus.length === 0) { // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false, 'work')
      }
      if(this.ruleForm.legacyStatus && this.ruleForm.legacyStatus.length === 0) { // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false, 'legacy')
      }
      if(this.ruleForm.onlineStatus && this.ruleForm.onlineStatus.length === 0) { // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false,'online')
      }
      if(this.ruleForm.consultantId && this.ruleForm.consultantId.length === 0) { // 모든 선택란을 해제했을 경우, 전체 셋팅으로 변경
        this.selectedAll(false,'authConsultant')
      }
    },
    selectedAll(e,type) {
      if(type==='work'){
        if(e) {
          this.ruleForm.workStatus = this.commonCodes.U011.slice(1).map((items) => {
            return items.value
          }) || []
        } else {
          this.ruleForm.workStatus = []
        }
      }else if(type==='legacy'){
        if(e) {
          this.ruleForm.legacyStatus = this.LegacyCommonCodes.C013.slice(1).map((items) => {
            return items.value
          }) || []
        } else {
          this.ruleForm.legacyStatus = []
        }
      }else if(type==='online') {
        if (e) {
          this.ruleForm.onlineStatus = this.commonCodes.T010.slice(1).map((items) => {
            return items.value
          }) || []
        } else {
          this.ruleForm.onlineStatus = []
        }
      }else if(type==='authConsultant'){
        if(e) {
          this.ruleForm.consultantId = this.consultants.slice(1).map((items) => {
            return items.sysUserNo
          }) || []
        } else {
          this.ruleForm.consultantId = []
        }
      }

    },
    onChangeMultiSelect(data, type) {
      if(type === 'legacy') { // 레거시 진행상태
        if(data.length === this.LegacyCommonCodes.C013.slice(1).length) {
          this.legacySelectedVal = true
        } else {
          this.legacySelectedVal = false
        }
      } else if(type === 'work') { //업무 진행상태
        if(data.length === this.commonCodes.U011.slice(1).length) {
          this.workSelectedVal = true
        } else {
          this.workSelectedVal = false
        }
      } else if(type==='online'){
        if(data.length === this.commonCodes.T010.slice(1).length) {
          this.onlineSelectedVal = true
        } else {
          this.onlineSelectedVal = false
        }
      }else if(type==='consultant') {
        if (data.length === this.consultants.slice(1).length) {
          this.consultantSelectedVal = true
        } else {
          this.consultantSelectedVal = false
        }
      }else if(type==='authConsultant') {
        if (data.length === this.authConsultants.slice(1).length) {
          this.consultantSelectedVal = true
        } else {
          this.consultantSelectedVal = false
        }
      }
    },
    async getData() {
      if(!this.ruleForm.searchFromDt || !this.ruleForm.searchEndDt) {
        this.alertMessage = '날짜는 필수입력사항입니다.'
        this.alertMessagePop = true
        return false
      }

      if(moment(this.ruleForm.searchFromDt).diff(moment(this.ruleForm.searchEndDt)) > 0) {
        this.alertMessage = '시작일은 종료일보다 클수 없습니다.'
        this.alertMessagePop = true
        return false
      }

      this.initRuleFormStatus()

      const { page: pageNo, size: pageSize } = this.$data.pageInfo

      //휴대전화 치환
      if(this.ruleForm.customerInfoKey === 'customerPhone'){
        this.ruleForm.customerInfoValue = this.ruleForm.customerInfoValue.replace(/-/gi, '')
      }

      const params = {
        ...this.ruleForm,
        workType: this.ruleForm.workType !== 'all' ? this.ruleForm.workType : '',
        // workStatus: this.ruleForm.workStatus!=='all' ? this.ruleForm.workStatus : '',
        // legacyStatus: this.ruleForm.legacyStatus!=='all' ? this.ruleForm.legacyStatus : '',
        // onlineStatus: this.ruleForm.onlineStatus!=='all' ? this.ruleForm.onlineStatus : '',
        cnTypeCd: this.$store.state.userInfo.exclusiveUseAuthGroupId,
        mypageTypeCd: 'customer',
        searchFromDt: moment(this.ruleForm.searchFromDt).format('YYYYMMDD'),
        searchEndDt: moment(this.ruleForm.searchEndDt).format('YYYYMMDD'),
        pageNo,
        pageSize,
        sortingId: this.sortInfo.prop,
        sortingType: this.sortInfo.order
      }
      
      this.popVisibleLoading = true
      
      const [res,err] = await this.$https.post('/v2/exclusive/mypage-customer-list', params)

      if(!err) {
        if(!res.data || res.data.length===0) {
          this.tableData = []
        } else {
          this.tableData = res.data.list.map((el, idx) => {
            return {
              ...el,
              no : idx+1,
              isSelected: false,
              releaseDate: el.releaseDate ? moment(el.releaseDate).format('YYYY-MM-DD') : '',
              bold: el.noticeConfirmYn !== 'Y' ? 'bold' : ''
            }
          })
        }

        this.$data.pageInfo = {
          ...this.$data.pageInfo,
          total: res.data.total
        }
        console.log('/mypage', this.tableData)
        this.popVisibleLoading = false
      } else {
        console.error(err)
        this.tableData = []
        this.popVisibleLoading = false
      }

      const [res2,err2] = await this.$https.get('/v2/exclusive/mypage-count', params)
      if(!err2) {
        if(!res2.data) {
          Object.assign(this.$data.countData, this.$options.data().countData)
          return
        }
        this.countData = res2.data
        console.log('/mypage-count', this.countData)
      } else {
        console.error(err2)
      }
    },
    async downloadExcel() {

      this.initRuleFormStatus()

      const params = {
        ...this.ruleForm,
        workType: this.ruleForm.workType !== 'all' ? this.ruleForm.workType : '',
        // workStatus: this.ruleForm.workStatus!=='all' ? this.ruleForm.workStatus : '',
        // legacyStatus: this.ruleForm.legacyStatus!=='all' ? this.ruleForm.legacyStatus : '',
        // onlineStatus: this.ruleForm.onlineStatus!=='all' ? this.ruleForm.onlineStatus : '',
        searchFromDt: moment(this.ruleForm.searchFromDt).format('YYYYMMDD'),
        searchEndDt: moment(this.ruleForm.searchEndDt).format('YYYYMMDD')
      }

      const [res,err] = await this.$https.post('/v2/exclusive/mypage-excel-customer', params, null, null, { responseType: 'blob' })
      if(!err) {
        const blob = new Blob([res], {type : res.Type })
        const nowDate = moment().format('YYYYMMDD_HHmm')
        if(window.navigator.msSaveOrOpenBlob) {
          // IE11
          window.navigator.msSaveOrOpenBlob(blob, '마이페이지 수신업무목록_' + nowDate + '.xlsx')
        } else {
          // IE11 외 브라우저
          const blobURL = window.URL.createObjectURL(blob)
          const tempLink = document.createElement('a')

          tempLink.href = blobURL
          tempLink.setAttribute('download', '마이페이지 수신업무목록_' + nowDate + '.xlsx')
          document.body.appendChild(tempLink)
          tempLink.click()
          document.body.removeChild(tempLink)
          window.URL.revokeObjectURL(blobURL)
        }
        // screenUseTypeCode (01:열람,02:수정,03:삭제,04:인쇄,05:입력,06:업로드,07:다운로드)
        this.$store.dispatch('commonSupportLog', { vm: this, params: { screenUseTypeCode: '07', fileName: '마이페이지 수신업무목록_' + nowDate + '.xlsx', fileSize: blob.size, useInfo: JSON.stringify(params) } })
      } else {
        console.error(err)
        this.tableData = null
      }
    },
    onChangeSearchDtRadio(val) {
      if(val==='lastDay') {
        this.ruleForm.searchFromDt = moment().subtract('days', 1)
        this.ruleForm.searchEndDt = moment().subtract('days', 1)
      } else if(val==='today') {
        this.ruleForm.searchFromDt = moment()
        this.ruleForm.searchEndDt = moment()
      } else if(val==='day7') {
        this.ruleForm.searchFromDt = moment().subtract('days', 7)
        this.ruleForm.searchEndDt = moment()
      } else if(val==='day30') {
        this.ruleForm.searchFromDt = moment().subtract('days', 30)
        this.ruleForm.searchEndDt = moment()
      } else if(val==='month3') {
        this.ruleForm.searchFromDt = moment().subtract('months', 3)
        this.ruleForm.searchEndDt = moment()
      } else if(val==='month6') {
        this.ruleForm.searchFromDt = moment().subtract('months', 6)
        this.ruleForm.searchEndDt = moment() 
      } else if(val==='day365') {
        this.ruleForm.searchFromDt = moment().subtract('days', 365)
        this.ruleForm.searchEndDt = moment()
      }
    },
    async changeReadStatus() {
      this.multipleSelection = this.tableData.filter((items) => {
        return items.isSelected === true
      })

      if(this.multipleSelection.length===0) {
        this.alertMessage = '업무를 먼저 선택해주세요.'
        this.alertMessagePop = true
      } else {
        const workAssignNumberList = this.multipleSelection.map(el => el.workSerialNumber).join(',')

        let params = new URLSearchParams()
        params.append('workAssignNumberList', workAssignNumberList)

        const [res, err] = await this.$https.put('v2/exclusive/common/work-read', params) //workAssignNumberList : 업무 ID 목록(comma-separated)
        if(!err) {
          console.log(res)
          this.alertMessage = '읽음처리 되었습니다.'
          this.alertMessagePop = true
          this.getData() //테이블 리로드
        } else {
          console.error(err)
        }
      }
    },
    openConsultantPopup() {
      this.multipleSelection = this.tableData.filter((items) => {
        return items.isSelected === true
      })

      if(this.multipleSelection.length===0) {
        this.alertMessage = '업무를 먼저 선택해주세요.'
        this.alertMessagePop = true
      } else {
        this.consultantPop = true
      }
    },
    consutantPopupOpened() {
      //컨설턴트 명단 store load
      this.$store.dispatch('loadConsultants', {vm: this})
    },
    async changeConsultant() {
      if(!this.selConsultant) {
        this.alertMessage = '컨설턴트를 선택해주세요.'
        this.alertMessagePop = true
      } else {
        const workAssignNumberList = this.multipleSelection.map(el => el.workSerialNumber).join(',')

        const [res, err] = await this.$https.post(`v2/exclusive/common/disposer?workEmployeeNumber=${this.selConsultant}&workAssignNumberList=${workAssignNumberList}`) //workEmployeeNumber : 컨설턴트 ID, workAssignNumberList[] : 업무 ID 목록(comma-separated)
        if(!err) {
          console.log(res)
          this.alertMessage = '처리자가 변경되었습니다.'
          this.alertMessagePop = true
          this.selConsultant = null
          this.consultantPop = false
          this.getData()
        } else {
          console.error(err)
        }
      }

    },
    onChange(val, row) {
      this.tableData.filter((items) => { return items.no !== row.no }).map((items) => { items.isSelected = false })
    },
    toggleSelectionAll() {
      if(this.checked) {
        this.tableData.map((items) => { items.isSelected = true })
      }
      else {
        this.tableData.map((items) => { items.isSelected = false })
      }
    },
    tableRowClassName({row}) {
      if(row.bold === 'bold') {
        return 'bold'
      }
    },
    sortChange(props) {
      const { prop, order } = props

      let convertOrder = ''

      if (order === 'descending') {
        convertOrder = 'desc'
      } else if (order === 'ascending') {
        convertOrder = 'asc'
      }

      this.sortInfo = { prop, order: convertOrder }
      this.getData()  
    },
  },

}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/reception.scss';
</style>
