<template>
  <section>
    <div id="process">
      <div class="article-title">
        <h-search
          v-model="workSerialNumber"
          :title="'업무일련번호'"
          :on-click="searchWork"
          :active-button="isValidAuthBtn('authSelect')"
          @enter="searchWork"
        />
        <div class="btn-group">
          <div>
            <el-button
              v-if="isValidAuthBtn('authMypage') && (isAuth || userInfo.eeno === data.managerId)"
              type="primary"
              :disabled="!workSerialNumber || !activeFlag"
              @click="oneClickDisable($event, save)"
            >
              저장
            </el-button>
            <el-button
              v-if="isValidAuthBtn('authMypage') && (isAuth || userInfo.eeno === data.managerId)"
              type="primary"
              :disabled="!workSerialNumber || !activeFlag"
              @click="oneClickDisable($event, saveCheck)"
            >
              문자보내기
            </el-button>
          </div>
        </div>
      </div>
      <h-mypage-info
        :info="data"
      />
      <el-form
        class="detail-form table-wrap"
      >
        <el-row>
          <el-col :span="8">
            <el-form-item label="업무 유형">
              {{ data.typeCd }}
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item
                label="업무 진행상태"
            >
              <el-select
                v-model="data.workProcessResultCode"
                placeholder="전체"
                @change="onChange($event, data.workProcessResultCode)"
              >
                <el-option
                  v-for="{ value, label } in commonCodes['U011'] && commonCodes['U011'].slice(1)"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="업무 처리자">
              {{ data.managerName }}
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="middle-add">
        <div
          class="article-title"
          style="margin: 20px 0 10px;"
        >
          <h2 class="fl">서류심사 목록</h2>
          <div class="main">
            <el-button
              v-if="isValidAuthBtn('authMypage') && (isAuth || userInfo.eeno === data.managerId)"
              :disabled="!workSerialNumber"
              type="primary"
              class="btn-md"
              icon="el-icon-plus"
              style="position: relative; width: 20px;"
              @click="addDocumentRow"
            />
          </div>
        </div>
        <el-table
          :data="documentList"
          empty-text="업무를 먼저 선택해주세요."
        >
          <el-table-column
            label="NO."
            prop="no"
            align="center"
            width="60"
          >
            <template slot-scope="props">
              <span v-if="!props.row.isAdd">{{ props.row.no }}</span>
              <el-button
                v-else
                type="info"
                icon="el-icon-minus"
                class="btn-s"
                @click="deleteDocumentRow(props.row.addRowKey)"
              />
            </template>
          </el-table-column>
          <el-table-column
            label="분류"
            prop="neceDocTypeNm"
            align="center"
            width="180"
          >
            <template slot-scope="props">
              <span
                v-if="!props.row.isAdd"
              >
                {{ props.row.neceDocTypeNm }}
              </span>
              <el-select
                v-else
                v-model="props.row.neceDocTypeCd"
                @change="onChangeDocumentType($event, props.row)"
              >
                <el-option
                v-for="{ value, label } in documentTypeList"
                :key="value"
                :value="value"
                :label="label"
                />
              </el-select>
            </template>
          </el-table-column>
          <el-table-column
            label="용도"
            prop="neceDocTargNm"
            align="center"
            width="180"
          >
            <template slot-scope="props">
              <span
                v-if="!props.row.isAdd"
              >
                {{ props.row.neceDocTargNm }}
              </span>
              <el-select
                v-else
                v-model="props.row.neceDocTargNo"
                @change="changeDocCtgList($event, props.row)"
              >
                <el-option
                  v-for="{ neceDocTargNo, neceDocTargNm } in documentTargets && documentTargets.slice(1, documentTargets.length)"
                  :key="neceDocTargNo"
                  :value="neceDocTargNo"
                  :label="neceDocTargNm"
                />
              </el-select>
            </template>
          </el-table-column>
          <el-table-column
            label="서류"
            prop="neceDocNm"
            align="center"
            width="230"
          >
            <template slot-scope="props">
              <span v-if="!props.row.isAdd">{{ props.row.neceDocNm }}</span>
              <el-select
                v-else
                v-model="props.row.neceDocNo"
                @change="changeDocSubCtgList($event, props.row)"
              >
                <el-option
                  v-for="{ neceDocNo, neceDocNm } in neceDocSubCategoryList[''+props.row.addRowKey]"
                  :key="neceDocNo"
                  :value="neceDocNo"
                  :label="neceDocNm"
                />
              </el-select>
            </template>
          </el-table-column>
          <el-table-column
            label="스크래핑 결과"
            prop="scrapingCompleteYn"
            align="center"
            width="100"
          >
            <template slot-scope="scope">
              <span v-if="scope.row.scrapingCompleteYn">
                {{ scope.row.scrapingCompleteYn }}
              </span>
              <span v-else>
                -
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="추가서류여부"
            prop="additionPapersYn"
            align="center"
            width="100"
          />
          <el-table-column
            label="제출서류"
            prop="fileGroupSerialNumber"
            align="center"
            width="210"
          >
            <template slot-scope="scope">
              <span
                v-if="scope.row.fileGroupSerialNumber"
                style="cursor: pointer; color: #1a0dab;"
                @click="getFileData(scope.row)"
              >
                <i class="file_img"></i>{{ scope.row.attcFilNm }}<br />[편집]
              </span>
              <span v-else>
                -
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="요청일시"
            prop="papersRequestDate"
            align="center"
            width="150"
          >
            <template slot-scope="scope">
              <span v-if="scope.row.papersRequestDate">
                {{ scope.row.papersRequestDate }}
              </span>
              <span v-else>
                -
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="등록일시"
            prop="uploadDate"
            align="center"
            width="150"
          >
            <template slot-scope="scope">
              <span v-if="scope.row.uploadDate">
                {{ scope.row.uploadDate }}
              </span>
              <span v-else>
                -
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="처리일시"
            prop="workProcessDate"
            align="center"
            width="150"
          >
            <template slot-scope="scope">
              <span v-if="scope.row.workProcessDate">
                {{ scope.row.workProcessDate }}
              </span>
              <span v-else>
                -
              </span>
            </template>
          </el-table-column>
          <el-table-column
            label="처리결과"
            prop="workProcessDetailResultCode"
            align="center"
            width="150"
          >
            <template slot-scope="scope">
              <el-select
                v-if="!scope.row.isAdd"
                v-model="scope.row.workProcessDetailResultCode"
                :disabled="!scope.row.fileGroupSerialNumber || ['40', '50'].includes(scope.row.copyWorkProcessDetailResultCode)"
                @change="changeDocStatus($event, scope.row)"
              >
                <el-option
                  v-for="{ value, label } in commonCodes.T002 && commonCodes.T002.slice(1, commonCodes.T002.length)"
                  :key="value"
                  :value="value"
                  :label="label"
                  :disabled="isValidStatusCode(scope.row.copyWorkProcessDetailResultCode, value)"
                />
              </el-select>
              <el-select
                v-else
                v-model="scope.row.workProcessDetailResultCode"
              >
                <el-option
                  v-for="{ value, label } in commonCodes.T002 && commonCodes.T002.slice(1, 2)"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </template>
          </el-table-column>
          <el-table-column
            label="진행 상항 메모"
            prop="processedContent"
            align="center"
            width="300"
          >
            <template slot-scope="scope">
              <el-input
                v-model="scope.row.processedContent"
                :disabled="!scope.row.isAdd && !scope.row.fileGroupSerialNumber || ['40', '50'].includes(scope.row.copyWorkProcessDetailResultCode)"
                @change="changeDocContent($event, scope.row)"
                @blur="scope.row.processedContent = $event.target.value"
              />
            </template>
          </el-table-column>
        </el-table>
      </div>

      <div class="article">
        <el-tabs
          v-model="activeName"
          type="card"
          stretch
          @tab-click="handleTabClick"
        >
          <el-tab-pane label="계약정보" name="first">
            <contract-info
              ref="contractInfo"
              :contract-number.sync="contractNumber"
              :contract-data.sync="contractData"
              :contract-info-data.sync="info"
              :component-sort-list.sync="componentSortList"
              :user-info-data.sync="userInfo"
              :common-codes.sync="commonCodes"
              :active-user-flag.sync="activeFlag"
            />
          </el-tab-pane>
          <el-tab-pane label="차량정보" name="second">
            <car-info
              ref="CarInfo"
              :contract-info-data.sync="info"
              :contract-number.sync="contractNumber"
              :active-user-flag.sync="activeFlag"
              @data="getCarProductionNumber"
            />

            <!-- <car-info
              :car-info-data.sync="carInfoData"
              :choice-option-names.sync="choiceOptionNames"
              :tuix-option-names.sync="tuixOptionNames"
            /> -->
          </el-tab-pane>
          <el-tab-pane label="결제정보" name="third">
            <pay-info
              ref="payInfo"
              :contract-number.sync="contractNumber"
              :user-info-data.sync="userInfo"
              :contract-data.sync="contractData"
              :contract-info-data.sync="info"
              :active-user-flag.sync="activeFlag"
              @refresh="onRefresh($event, 'pay')"
            />
          </el-tab-pane>
          <el-tab-pane label="출고정보" name="fourth">
            <release-info
              ref="releaseInfo"
              :contract-info-data.sync="info"
              :contract-data.sync="contractData"
              :active-user-flag.sync="activeFlag"
            />
          </el-tab-pane>
          <el-tab-pane label="상태이력" name="fifth">
            <status-history
              ref="StatusHistory"
              :contract-number.sync="contractNumber"
            />
            <!-- 상태이력 화면 컴포넌트화로 인한 주석처리 <A936507> -->
            <!-- <status-history
              ref="StatusHistory"
              :data.sync="statusTabData"
              :contract-number.sync="contractNumber"
            /> -->
          </el-tab-pane>
          <el-tab-pane label="문자이력" name="sixth">
            <sms-history
              ref="SmsHistory"
              :contract-number.sync="contractNumber"
            />
            <!-- <sms-history
              :data.sync="messageTabData"
              @refresh="onRefresh($event, 'sms')"
            /> -->
          </el-tab-pane>
        </el-tabs>
      </div>
      <!-- 조회결과없음 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="alertNoData"
      >
        <!-- Message -->
        조회 결과가 없습니다.

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="info"
            @click="alertNoData = false"
          >
            확인
          </el-button>
        </template>
      </el-dialog>

      <!-- 문자보내기 팝업 -->
      <el-dialog
        title="문자보내기"
        :visible.sync="popVisibleSMS"
        width="1100px"
      >
        <!-- Popup Contents -->
        <div class="board-wrap sandmessage">
          <h-title :title="'수신자 정보'" />
          <el-form
            ref="contractData"
            :model="contractData"
            class="detail-form"
          >
            <el-row>
              <el-col :span="9">
                <el-form-item label="수신자명">
                  <!-- {{ contractData.contractorInfo && contractData.contractorInfo.length > 0 ? contractData.contractorInfo[0].customerName : '' }} -->
                  <el-select v-model="contractorNames" multiple placeholder="수신자명">
                    <el-option
                      v-for="item in contractData.contractorInfo"
                      :key="item.customerName"
                      :label="item.customerName"
                      :value="item.customerName">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="15">
                <el-form-item label="휴대전화번호">
                  <!-- {{ contractData.contractorInfo && contractData.contractorInfo.length > 0 ? contractData.contractorInfo[0].customerMobile : '' }} -->
                  {{ contractorHpTns() }}
                </el-form-item>
              </el-col>
              <!-- <el-col :span="8">
                <el-form-item label="발송일시" />
              </el-col> -->
            </el-row>
          </el-form>
          <h-title :title="'발신내용'" />
          <el-form
            ref="ruleFormpopup"
            :model="ruleFormpopup"
            class="detail-form"
          >
            <el-row>
              <el-col :span="24">
                <el-form-item label="제목">
                  <el-input
                    v-model="ruleFormpopup.title"
                    class="mms-title"
                    @blur="ruleFormpopup.title = $event.target.value"
                  />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item label="내용">
                  <el-input
                    v-model="ruleFormpopup.text"
                    type="textarea"
                    @blur="ruleFormpopup.text = $event.target.value"
                  />
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="primary"
            @click="initRuleFormPop"
          >
            초기화
          </el-button>
          <el-button
            type="primary"
            @click="sendSms"
          >
            전송
          </el-button>
        </template>
      </el-dialog>

      <!-- 제출서류 편집 S -->
      <el-dialog
        :visible.sync="imageEditorFlag"
        title="제출서류 편집"
        class="img-editor-dialog"
      >
        <div class="img-editor" :class="loadType">
            <div class="menu-wrap">
              <div class="left">
                <ul class="menu">
                  <li>
                    <div class="label">펜 색상</div>
                    <div class="label-cont">
                      <input v-model="stroke_color" type="color" placeholder="Colors" />
                    </div>
                  </li>
                  <li>
                    <div class="label">펜 굵기</div>
                    <div class="label-cont">
                        <input v-model="stroke_width" type="range" class="pen-size" min="1" max="100" />
                    </div>
                  </li>
                  <li>
                    <div class="label">펜/이동</div>
                    <div class="label-cont">
                        <div class="tog-btn">
                          <button @click="moving = false" :class="{on: moving === false}"><img src="data:image/webp;base64,UklGRgoDAABXRUJQVlA4WAoAAAAQAAAAfwAAfwAAQUxQSJ0CAAAJkEPbtqk9949t26lsVrZtpzQ6dbZt2+6czradznzvuzrn7hMjIhy4bRtJGRlrJ3Pt1fmDkrBlatisQq7sz56c3nP4tRK4pR91Z2OPMrlT5C0/YMfdUWnlVa3r47NYbiL7+HNlpFXvI3kc91H8eEtZNXBJauedZNjSTZTmJXncS/LlghiQkB9iND+WL4LkTWcRdepFdEv+rBJhz9R7nsB7+L0jm8ELEp2Qq8/1ajp1SXY1sO23KOv+Kiy2DaxfkExlOcRjK6H6ZEqpzCw27aYMoD5xASZbdDCmT9wBmx2WFdWTre3WmsNJ96Y9UI2+ADZFnTIOa4Epmrq/14NVjKE3efBEwXftARSjxbyQDbbrvAI9G+fJLqF5b1uVYPcAe8f642+/7MTyIey281A+hP04GsoHsSMvIHkGW9nDrpmG5DnsYbfd1xfpSctjD1Y1n8K6Wr+DUQjAFIaE4M7GfLIVrd7BnY37ZL3eQ02DDHEuFA6wI9gPKA2z2Ae748M3QKbhtLnzx98c+u+/+gbUxlgI9fhDON81EkTtafsu5BSGcAIilKAQq3HZdDp/4L4QjDKNPJJdu4Ftrd8xXwhm2ipN+cPZzaHII9orZYVXKLmecsB5IZysXPBdFSk74RJS9kDWctcyyj5wCCt7QRdSrq88oQos+0ITWvaGIrRMwF9wmYKv8DIJAcoYZSL+gnrmUHELMZNxCTEz4BLg0RzYhJlZMIWYGygmNEFWiyjTOJhNp/OaWJjVgXpbFY/odlu3WMCZPDQ22ExnaZJeqJl8X/dn1mn9RSvYTO4UHnT0s+UVc9GjdQq5OpiLHrFjnBs7c3TQj6Z34DO1IyA3tNc9V0dItnXiv7i1IyZTOxKO9urIymktHaFblSnVtY7YTQEAVlA4IEYAAABwBgCdASqAAIAAPnE4mkokoyKhoIgAkA4JaW7hdJAAT22IvEFRz2xF4gqOe2IvEFRz2xF4gqOe2IvEE2AA/v+VgAAAAAAA" alt=""></button>
                          <button @click="moving = true" :class="{on: moving === true}"><img src="data:image/webp;base64,UklGRnAEAABXRUJQVlA4WAoAAAAQAAAAfwAAfwAAQUxQSAMEAAANoKxt2yFJeiMj1dYJFE6gbavQ40kW2zYKo2LbdncZbds29tPe2p2IiEFE5B9//V9rFRETgG89bVBJa7ugM67m3KVrYCGAbgUFJ6hKHYf/N9m2cQ9N3w+DvrNq2w6KAj4YOyoPl9Mzsh/MypturKZmbDuYl1bcW0bLrATEKi15XkJJbhswLHbm0VHsBNPcNjlESEvAelbCBJUCaQXYj203ThWfvAlWjuyXHRWdswLWBnzBkNhcFbD6+2HpH0TWuB7Wp070vRVXkzrw2DfX/1pULbeDz55FvmdikneA1445QUVIHvDbv/keIfXmCH3OCini4CgKIR9J5uiooN56uNkGQafFDU2UOVDulT0WVWRR2T1FT2PiDul8wdfI+/zXyPvyr5EnWPnXvqFjh4WRMth1ZqfCV8vtgGvw+2BECM46N9C3jfcFT8224f+/JiwUwiz8v2+u7w0/jbdBP7ucK43ZUB10+dP3nhd3HQwT73HFPl4PvacHPvLhqIaxrHClsZJsBhg0wR/iQd4KwUowmTQ0M2qdtA4Cw8/eTMUqaTUarsYDvEmjVYsWQLwxYGi7KdbMgfAwMXGaFYUgAFNbFLGb2iI2jStVYsSw8OM8VhMTQeTcp4vZDG0HMhf+vZ6FNwl0SqsvVcX2sxeU2rYcqYslaSholbdu329uwCRQ66jdfNhM2yLQ66wuvWtiPihu8ke+ka0rSehxWTXQNBtJ0GB0pRtJF2Ay788mBL0rNXOnoN5NTjgdpk+urHcREwkixqNllXZSlKGIeff2SpkQdTgYbj+6wUaGNgFMy24vJ2MWGK+6t5SIfDBf9qogJneIkaQykZhpMRXCwkJ3XiwqWKEhL31tBfLbzIxBY9WgV92HtTmJYwS39Q4s1iZ0z+BBajhVZ2C5Ojw5wEHD3bUfHCrDvN8L62g5uIykjxpkoECIimxwfDU4/RiY3lvvnhjuJ+idWwJu3/v+7KKzlZnEV3m2zpVScPzGl9MPwLYnzDhfkPgrgFMLwfULX8v+H45CkJHg2yTXydfgXNl9ClZKfAFHj4bwmSmR9+VfIu/zXyLvc92Zk5UgW6HpKffLFkYEVQ8+5YSh8WliSnVyAsDz5qiQksBxkpjsPDkiQjrbh6OzEPLO1v24Of1CTIonpxsnN+ZD0K88+f25OF8IYb8LTBrMwZkFEPh7/4ifLDu0CkIPZ/g8Fu3fCsFHMpOHWlK3DcJXRrWfaMGm0yBQm5Iwldm62yBRm97qL0YL74PKgtA8JvOfgc75Txcy+CsMShfdW22LQZsOYtdd3iKbUseA3KojZXYTyigQXLet1mUQzgLJ+7fUNNIJZYHow2trmwB45wfZJwr+7I6LJSD8bt5lUK+R9wUYAFZQOCBGAAAAcAYAnQEqgACAAD5xOJpKJKMioaCIAJAOCWlu4XSQAE9tiLxBUc9sReIKjntiLxBUc9sReIKjntiLxBNgAP7/lYAAAAAAAA==" alt=""></button>
                        </div>
                    </div>
                  </li>
                </ul>
              </div>
              <div class="right">
                  <button class="btn-st" @click="Restore()">⮌ 실행취소</button>
              </div>
            </div>

            <div class="canvas-wrap parent">
              <canvas id="canvas" class="draggable" :class="{moving: moving === true}" style="top:0;left:0" width="0" height="0"></canvas>
            </div>

            <div v-if="loadType === 'pdf'" class="pdf-menu">
              <button class="btn-st" @click="prev()">❮ 이전</button>
              <span class="page">페이지 &nbsp;&nbsp; <span id="currentPage">{{ currentPdfImg }}</span> / <span id="totalPage">{{ totalPage }}</span></span>
              <button class="btn-st" @click="next()">다음 ❯</button>
            </div>

            <a id="imgDown" download class="hide"></a>
            <div id="pdfImg" class="hide"></div>
        </div>

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button type="info" @click="imageEditor(false)">취소</el-button>
          <el-button v-if="loadType === 'pdf'" type="primary" @click="savePdf()">저장</el-button>
          <el-button v-if="loadType === 'img'" type="primary" @click="saveImg()">저장</el-button>
        </template>
      </el-dialog>
      <!-- 제출서류 편집 E -->

      <loading
        :pop-visible.sync="popVisibleLoading"
        @close="popVisibleLoading = false"
      />
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import HSearch from '~/components/common/HSearch.vue'
import HMypageInfo from '~/components/common/HMypageInfo.vue'
import HTitle from '~/components/common/HTitle.vue'
import moment from 'moment'
import { mapState, mapGetters } from 'vuex'
import PopMessage from '~/components/popup/PopMessage.vue'

import ContractInfo from '~/components/tab/ContractInfo.vue'
import CarInfo from '~/components/tab/CarInfo.vue'
import PayInfo from '~/components/tab/PayInfo.vue'
import ReleaseInfo from '~/components/tab/ReleaseInfo.vue'
import StatusHistory from '~/components/tab/StatusHistory.vue'
import SmsHistory from '~/components/tab/SmsHistory.vue'

import Loading from "~/components/popup/Loading.vue"


import { jsPDF } from 'jspdf'
import pdfjsLib from '~/plugins/pdf'
pdfjsLib.GlobalWorkerOptions.workerSrc ='https://cdn.jsdelivr.net/npm/pdfjs-dist@2.0.943/build/pdf.worker.min.js'
let canvas
let context
let restore_array = []
let start_index= -1
let is_drawing= false

let parent
let parentRect
let draggable
let draggableRect

export default {
  name: 'Process',
  layout: 'default',
  components: {
    HSearch,
    HMypageInfo,
    HTitle,
    PopMessage, 
    ContractInfo,
    CarInfo,
    PayInfo,
    ReleaseInfo,
    StatusHistory,
    SmsHistory,
    Loading
  },

  data() {
    return {
      isAuth: process.env.VUE_APP_AUTH === 'true', // 권한 패스용
      alertMessage: '',
      alertMessagePop: false,
      activeFlag: false, // 탭에서 조건별 활성화되어야 하는 버튼 제어 플래그
      activeName: 'first',
      alertNoData: false,
      popVisibleSMS: false,
      ruleFormpopup: {
        title: '',
        text: ''
      },
      data: {},
      documentList: [],
      settingDocumentList: [],
      reviewFilter: { neceDocTargNo: 'all', neceDocNo: 'all', workProcessDetailResultCode: 'all'},
      contractNumber: null,
      contractData: {},
      signData: [],
      statusDateData: {},
      paperReviewData: [],
      carInfoData: {},
      choiceOptionNames: '',
      tuixOptionNames: '',
      payInfoData: {},
      payAmountList: [],
      payDetail: {},
      releaseInfoData: {},
      releaseCenterData: {},
      releaseTakeoverData: {},
      releaseConsignData: {},
      releaseRegistAgencyData: {},
      statusTabData: { sale: [], sales: [], payment:[], consultant:[], papers:[], electron: [], point: [], apiLog : []},
      messageTabData:[],
      contractInfo: {},

      paperTypes: [{ neceDocNo: 'all', neceDocNm: '전체' }],
      neceDocCategoryList: null, // 필수 서류 카테고리(구분) === 서류심사 목록 ===
      neceDocSubCategoryList: {}, // 필수 서류 카테고리(소분류) === 서류심사 목록 ===
      neceDocSubCategoryReview: [{ neceDocNo: 'all', neceDocNm: '전체' }], // 필수 서류 카테고리(소분류) === 서류심사 이력 ===
      workSerialNumber: null, // 업무 일련 번호
      addKeyIdx: 0,
      fileData: {},
      commonCodes: {},
      contractorNames: [],  // 선택한 계약자명
      componentSortList: [
        'paper-review-info',
        'contractor-info',
        'service-info',
        'payment-info',
        'signature-info',
        'status-info',
        'recommend-info'
      ], //계약정보탭 컴포넌트 정렬
      info: {},
      documentType: '',
      documentTargets: [{ neceDocTargNo: 'all', neceDocTargNm: '전체' }],
      documentTypeList: [],
      neceDocList:[],
      popVisibleLoading: false,

      stroke_color: 'black',
      stroke_width: '2',
      currentPdfImg: 1,
      totalPage: 0,
      loadType:'',
      moving: false,
      clientY: 0,
      clientX: 0,
      dragging: false,
      imageEditorFlag: false
    }
  },
  computed: {
    ...mapGetters(['userInfo'])
  },
  watch: {
    reviewFilter: {
      handler(obj) {
        this.changeFilter(obj)
      },
      deep: true
    }
  },
  mounted() {
    //this.$store.dispatch('loadDocumentTargets', {vm: this})

    //첫번째 정보탭 호출/////////////////////////////////////
    this.workSerialNumber = localStorage.getItem('workSerialNumber') || '' // 새창으로 넘어오는 경우

    if(this.workSerialNumber) {
      this.getData(this.workSerialNumber)
    }

    localStorage.removeItem('workSerialNumber')
    ///////////////////////////////////////////////////////
  },
  async created() {
    await this.loadCommonCode()
    this.$EventBus.$on('searchAddressPopOpen', index => {
      this.searchAddressPopOpen(index)
    })

    this.$EventBus.$on('addDocumentPopOpen', this.addDocumentPopOpen)
  },
  methods: {
    oneClickDisable(event, clickEvent, ...args) {
      if(event.target.disabled === true){
        return
      }

      event.target.disabled = true

      try {
        clickEvent(...args)
      // eslint-disable-next-line no-empty
      } catch {}
      setTimeout(() => {
        event.target.disabled = false
      }, 2000)
    },
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null
      switch(systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {vm: this, codeTypeCode: codeType})
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {vm: this, codeTypeCode: codeType})
        break
      }
      return res
    },
    async loadCommonCode() {
      const [ccT072, ccT002, ccU011] = await Promise.all([
        this.fetchCommonCodeData('E', 'T072'), //서류 최초 구분
        this.fetchCommonCodeData('E', 'T002'), // 상태
        this.fetchCommonCodeData('E', 'U011') // 업무 진행상태
      ])

      this.commonCodes = {...ccT072, ...ccT002, ...ccU011 }

      this.documentTypeList = this.commonCodes.T072
      this.documentTypeList.shift()
    },
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    changeFilter(obj) {
      const { neceDocTargNo, neceDocNo, workProcessDetailResultCode } = obj
      if(neceDocTargNo === 'all' && neceDocNo === 'all' && workProcessDetailResultCode === 'all') {
        this.documentList = this.settingDocumentList
      } else {
        this.documentList = this.settingDocumentList.filter((items) => {

          return (neceDocTargNo !== 'all' ? items.neceDocTargNo === neceDocTargNo : true) &&
                 (neceDocNo !== 'all' ? items.neceDocNo === neceDocNo : true) &&
                 (workProcessDetailResultCode !== 'all' ? items.workProcessDetailResultCode === workProcessDetailResultCode : true)
        })
      }
    },
    isValidStatusCode(originStatusCode = '', targetCode = '') {
      if(originStatusCode === '30' && ['10', '20'].includes(targetCode)) {
        return true
      } else if(originStatusCode === '20' && targetCode === '10') {
        return true
      }
      return false
    },

    // 제출서류 편집 S
    async getFileData(row) {
      this.popVisibleLoading = await true
      const { fileGroupSerialNumber: fileGroupSn = '', fileSn = ''} = row
      const [res, err] = await this.$https.get('common/v2/common/file/inquiry/' + fileGroupSn + '/' + fileSn, null, null, 'gateway')

      if(!err) {
        await this.imageEditor(true)
        // screenUseTypeCode (01:열람,02:수정,03:삭제,04:인쇄,05:입력,06:업로드,07:다운로드)
        this.$store.dispatch('commonSupportLog', { vm: this, params: { screenUseTypeCode: '07', useInfo: JSON.stringify({ workSerialNumber: this.workSerialNumber }), fileName: res.data.fileName, fileSize: res.data.fileCapa } })
        this.fileData = await res.data
        if(this.fileData.fileExtentions === 'pdf') this.loadType = await this.fileData.fileExtentions
        else this.loadType = await 'img'

        await this.loadDownloadLink()
        await this.canvasDragging()
        await this.canvasDrawing()
      }
      this.popVisibleLoading = await false
    },
    async loadDownloadLink() {
      let loadAfterPdf = ()=>{
        this.totalPage = document.querySelectorAll('#pdfImg img').length
        let src = document.querySelector('#pdfImg img').src
        this.loadImg(src)
      }

      let loadAfterImg = (src)=>{
        this.loadImg(src)
      }

      async function renderPDF(data) {
        let pdf = await pdfjsLib.getDocument({ data: data }).promise

        for (let i = 1;i <= pdf.numPages;i++) {
          let image = document.createElement('img')
          document.querySelector('#pdfImg').appendChild(image)

          let page = await pdf.getPage(i)
          let viewport = page.getViewport(2)
          canvas.height = viewport.height
          canvas.width = viewport.width

          if(parentRect.width > canvas.width) {
            draggable.style.left = parentRect.width/2 - canvas.width/2 + 'px'
          }
          if(parentRect.height > canvas.height) {
            draggable.style.top = parentRect.height/2 - canvas.height/2 + 'px'
          }

          await page.render({ canvasContext: context, viewport: viewport }).promise
          let _data = canvas.toDataURL('image/jpeg')
          image.src = _data
        }

        loadAfterPdf()
      }

      const { fileSn, fileGroupSn, fileName, fileExtentions } = await this.fileData
      const [res, err] = await this.$https.getb('common/v2/common/file/download/'+ fileGroupSn  + '/' + fileSn, null, null, 'gateway')

      if(!err) {
        const blob = await new Blob([res], {type : fileExtentions })
        let reader = new FileReader()

        reader.readAsDataURL(blob)
        if(this.loadType === 'pdf') {
          reader.onloadend = function () {
            let base64data = reader.result
            let data = atob(base64data.replace(/.*base64,/, ''))
            renderPDF(data)
          }
        } else {
          reader.onloadend = function () {
            let base64data = reader.result
            loadAfterImg(base64data)
          }
        }
      }
    },
    loadImg(src) {
      this.clear()
      let img = new Image()

      canvas.style.top=0
      canvas.style.left=0

      function loadAfter(cw, ch){
        if(parentRect.width > cw) {
          draggable.style.left = parentRect.width /2 - cw/2 + 'px'
        }

        if(parentRect.height > ch) {
          draggable.style.top = parentRect.height /2 - ch/2 + 'px'
        }
      }

      img.onload = function () {
        canvas.width = img.naturalWidth
        canvas.height = img.naturalHeight
        context.drawImage(img, 0, 0)
        restore_array.push(context.getImageData(0, 0, canvas.width, canvas.height))
        start_index += 1
        loadAfter(canvas.width, canvas.height)
      }
      img.src = src
    },
    async savePdf() {
      this.popVisibleLoading = await true
      await this.savePdfImg()
      let landscape = canvas.width > canvas.height ? 'l' : 'p'
      let per = 3.7795275591 * 1.5
      let doc = new jsPDF(landscape, 'mm', [canvas.width / per, canvas.height / per])
      let img = document.querySelectorAll('#pdfImg img')

      img.forEach(function (el, index, array) {
        doc.addImage(el.src, 'JPEG', 0, 0, canvas.width / per, canvas.height / per)
        if(index < array.length -1) doc.addPage()
      })

      let d = await doc.output('datauristring')
      let bstr = await atob(d.split(',')[1]);
      let file = await this.imageToFile(bstr)
      await this.fileModify(file)
      this.popVisibleLoading = await false
    },
    savePdfImg() {
      let d = canvas.toDataURL('image/jpeg')
      document.querySelector('#pdfImg img:nth-child(' + this.currentPdfImg + ')').src = d
    },
    async saveImg() {
      this.popVisibleLoading = await true
      let d = await canvas.toDataURL('image/jpeg')
      let bstr = await atob(d.split(',')[1]);
      let file = await this.imageToFile(bstr)
      await this.fileModify(file)
      this.popVisibleLoading = await false
    },
    imageToFile(imgsrc){
      let n = imgsrc.length;
      let u8arr = new Uint8Array(n);

      while(n--){
        u8arr[n] = imgsrc.charCodeAt(n);
      }

      let type = ''
      if(this.fileData.fileExtentions === 'pdf') type = 'application/pdf'
      else type = 'image/jpeg'

      console.log(u8arr)
      return new File([u8arr], this.fileData.fileName, {type: type})
    },
    // 파일업로드
    async fileModify(file) {
      if (file) {
        const allowedTypes = [
          'image/png',
          'image/jpg',
          'image/jpeg',
          'image/gif',
          'application/pdf'
        ] // 허용 가능한 파일
        let formData = new FormData()
        if (allowedTypes.includes(file.type)) {
          formData.append('file', file)
          formData.append('fileGroupSn', this.fileData.fileGroupSn)
          formData.append('fileSn', this.fileData.fileSn)
          formData.append('filePathName', this.fileData.filePathName)
          if(this.fileData.filePathName.indexOf('/attach-2') > -1) formData.append('privateYn', 'Y')
          else formData.append('privateYn', 'N')

          // 파일 크기 체크 (10MB)
          const size = 10485760
          if (file.size > size) {
            this.alertMessagePop = true
            this.alertMessage = '파일당 10MB 를 넘지 않아야 합니다'
            return
          }

          const [res, err] = await this.$https.postMultiPart(
            '/common/v2/common/file/upload/modify',
            formData,
            null,
            'gateway'
          ) // API-WE-공통서비스-00X_파일 수정 업로드

          if (!err) {
            await this.imageEditor(false)
            this.alertMessage = await '저장되었습니다.'
            this.alertMessagePop = await true
            /////////////////////////////
          } 

        } else {
          this.alertMessage = '허용되지 않는 확장자입니다.'
          this.alertMessagePop = true
        }
      }
    },

    async imageEditor(flag){
      this.imageEditorFlag = await flag;
      document.querySelector('.img-editor-dialog .el-dialog').style = await 'margin-top: 15vh; width:1200px !important;'

      canvas = await document.getElementById('canvas')
      context = await canvas.getContext('2d')
      context.fillStyle = await 'white'
      await context.fillRect(0, 0, canvas.width, canvas.height)

      parent = await document.querySelector('.parent')
      parentRect = await parent.getBoundingClientRect()
      draggable = await document.querySelector('.draggable')
      draggableRect = await draggable.getBoundingClientRect()

      await this.init()
    },
    init(){
      document.querySelector('.img-editor-dialog').scrollTop = 0
      document.querySelector('#pdfImg').innerHTML=''
      this.clear()
      this.currentPdfImg = 1
    },
    async canvasDrawing(){
      await canvas.addEventListener('touchmove', this.draw, false)
      await canvas.addEventListener('mousedown', this.drawStart, false)
      await canvas.addEventListener('mousemove', this.draw, false)
      await canvas.addEventListener('mouseup', this.drawStop, false)
    },
    drawStart(event) {
      if(this.moving) return
      is_drawing = true
      context.beginPath()
      context.moveTo(this.getX(event), this.getY(event))
      event.preventDefault()
    },
    draw(event) {
      if(this.moving) return
      if (is_drawing) {
        context.lineTo(this.getX(event), this.getY(event))
        context.strokeStyle = this.stroke_color
        context.lineWidth = this.stroke_width
        context.lineCap = 'round'
        context.lineJoin = 'round'
        context.stroke()
      }
      event.preventDefault()
    },

    drawStop(event) {
      if (is_drawing) {
        context.stroke()
        context.closePath()
        is_drawing = false
        start_index += 1
        restore_array.push(context.getImageData(0, 0, canvas.width, canvas.height))
      }
      event.preventDefault()
    },

    getX(event) {
      let dragLeft  =  parseInt(canvas.style.left);
      return event.pageX - draggableRect.left - dragLeft
    },

    getY(event) {
      let stTop = document.querySelector('.img-editor-dialog').scrollTop
      let dragTop  =  parseInt(canvas.style.top);
      return event.pageY - draggableRect.top - dragTop + stTop
    },

    async canvasDragging(){
      await document.addEventListener('mousedown', this.dragStart)
      await document.addEventListener('mousemove', this.drag)
      await document.addEventListener('mouseup', this.dragStop)
    },
    dragStart(e) {
      if(this.moving === false) return
      e.preventDefault()
      this.dragging = true
      this.clientY = e.clientY
      this.clientX = e.clientX
    },
    dragStop(e) {
      e.preventDefault()
      this.dragging = false
    },
    drag(e) {
      if(this.moving === false) return
      e.preventDefault()
      if(this.dragging){

        let y = parseInt(draggable.style.top) - (this.clientY - e.clientY)
        let x = parseInt(draggable.style.left) - (this.clientX - e.clientX)

        if(y <= 0 && y >= -(canvas.height - parentRect.height)) {
          draggable.style.top = parseInt(draggable.style.top) - (this.clientY - e.clientY) + 'px'
        }

        if(x <= 0 && x >= -(canvas.width - parentRect.width)) {
          draggable.style.left = parseInt(draggable.style.left) - (this.clientX - e.clientX) + 'px'
        }

        this.clientY = e.clientY
        this.clientX = e.clientX
      }
    },
    Restore() {
      if (start_index > 0) {
        start_index += -1
        restore_array.pop()
        if (event.type != 'mouseout') {
          context.putImageData(restore_array[start_index], 0, 0)
        }
      }
    },
    clear() {
      context.fillStyle = 'white'
      context.clearRect(0, 0, canvas.width, canvas.height)
      context.fillRect(0, 0, canvas.width, canvas.height)
      restore_array = []
      start_index = -1
    },
    next() {
      this.savePdfImg()
      if(this.currentPdfImg >= this.totalPage) return
      this.currentPdfImg += 1
      let src = document.querySelector('#pdfImg img:nth-child(' + this.currentPdfImg + ')').src
      this.loadImg(src)
    },
    prev() {
      this.savePdfImg()

      if(this.currentPdfImg <= 1) return
      this.currentPdfImg -= 1
      let src = document.querySelector('#pdfImg img:nth-child(' + this.currentPdfImg + ')').src
      this.loadImg(src)
    },
    change_color(element) {
      this.stroke_color = element.style.background
    },
    change_width(element) {
      this.stroke_width = element.innerHTML
    },
    // 제출서류 편집 E

    async getData(serialNumber) {
      
      if(!serialNumber) return

      const [res1,err1] = await this.$https.get('/v2/exclusive/mypage-corporation/'+serialNumber)

      if(!err1) {
        
        if(!res1.data) { // 상세보기 - 조회 결과 없음 팝업 노출
          const beforeWorkSerialNumber = this.workSerialNumber
          Object.assign(this.$data, this.$options.data())
          this.workSerialNumber = beforeWorkSerialNumber
          this.alertNoData = true
          return false
        }
        this.data = {
          ...res1.data,
          contractorId: res1.data.contractorId,
          progressResultCode: res1.data.progressResultCode || '10' // default '접수(10)'
        }
        this.contractNumber = res1.data && res1.data.contractNumber

        if(this.data.managerId && this.data.managerId === this.userInfo.eeno) { // 사용자 사번과 처리자가 같을 경우
          this.activeFlag = true
        }

        if (this.userInfo.exclusiveUseAuthGroupIds.includes('WT004')) {
          // 법인 관리자 권한일 경우
          this.activeFlag = true
        }

        const [res2,err2] = await this.$https.get('/v2/exclusive/mypage/document/'+serialNumber)
        if(!err2) {
          this.settingDocumentList = res2.data.map((el, idx) => {
            return {
              ...el,
              no : idx+1,
              copyWorkProcessDetailResultCode: el.workProcessDetailResultCode,
              isEdit: false
            }
          })
          this.documentList = this.settingDocumentList.slice()
        } else {
          console.error(err2)
        }

        //공통탭 호출
        this.getInfoData()

      } else {
        console.error(err1)
      }
    },
    searchWork(value) {
      if(!this.isValidAuthBtn('authSelect')) { // 권한없을경우 동작 x
        return
      }

      if(!value) {
        this.alertMessage = '업무일련번호를 입력해주세요.'
        this.alertMessagePop = true
        return
      } else {
        value = value.trim() // 공백 제거
      }

      this.workSerialNumber = value
      this.getData(value)
    },
    addDocumentRow() {
      this.documentList.push({isAdd: true, addRowKey: ''+this.addKeyIdx++, workProcessDetailResultCode: '10', neceDocNo: '', neceDocNm:''})
    },
    async save() {

      this.popVisibleLoading = true

      if(!this.workSerialNumber) {
        this.alertMessage = '업무를 먼저 검색해주세요.'
        this.alertMessagePop = true
        return
      }

      this.documentList.map((items) => {
        items.workAssignNumber = this.data.workAssignNumber
        items.customerManagementNumber = this.data.contractorId
        items.contractNumber = this.data.contractNumber

        const idx = this.neceDocList.findIndex(ele => ele.neceDocNo === items.neceDocNo)
        if (idx > -1) items.neceDocNm =  this.neceDocList[idx].neceDocNm
      })

      let bResult = false
      this.documentList.some((items) => {
        if(!items.neceDocTargNo || !items.neceDocNo) {
          bResult = true
          return true
        }
      })

      if(bResult) {
        this.alertMessage = '추가서류의 구분과 소분류 항목을 확인해주세요.'
        this.alertMessagePop = true
        return false
      }

      const documentList = this.documentList.filter((items) => { // 변경된 사항만 저장
        return items.isEdit === true
      })

      const data = {
        workAssignNumber: this.data.workAssignNumber || '', // 업무일련번호
        workProcessResultCode: this.data.workProcessResultCode || '', // 진행상태코드
        documentList // 서류심사목록
      }
      
      const [res,err] = await this.$https.post('/v2/exclusive/mypage', data)
      
      if(!err) {
        // screenUseTypeCode (01:열람,02:수정,03:삭제,04:인쇄,05:입력,06:업로드,07:다운로드)
        this.$store.dispatch('commonSupportLog', { vm: this, params: { screenUseTypeCode: '02', useInfo: JSON.stringify(this.info) } })
        this.alertMessage = '저장되었습니다.'
        this.alertMessagePop = true
        await this.getData(this.workSerialNumber)
        if (this.contractData && this.contractData.contractorInfo.length > 0) {
          let receiverTel = this.contractData.contractorInfo[0].customerMobile
          let customerMgmtNo = this.contractData.contractorInfo[0]
            .customerManagementNumber
          let customerUniqueNo = this.info.customerUniqueNo
          let receiverName = this.contractData.contractorInfo[0].customerName
          let messageTemplateId = ''
          let messageParams = {}
          let resultCodeFailFlag = 'N'

          //wp_1201004 결제 기한일 메세지 param 세팅////////////////
          let finalPayExpireDate = ''
          if(moment().day() === 5){
            finalPayExpireDate = moment().add('days',3).format('YYYY년 MM월 DD일')
          }else{
            finalPayExpireDate = moment().add('days',1).format('YYYY년 MM월 DD일')
          }
          ////////////////////////////////////////////////////////

          this.documentList.map(items => {
            if (items.workProcessDetailResultCode === '50') {
              messageTemplateId = 'wp_1201005'
            } else if (items.workProcessDetailResultCode === '40') {
              messageTemplateId = 'wp_1201004'
              messageParams = {
                cnttNo: this.contractNumber,
                date: finalPayExpireDate,
                submRson: items.processedContent,
                submSubjForm: items.attcFilNm
              }
              resultCodeFailFlag = 'Y'
            }
          })
          // 증빙서류 심사 실패 정보가 존재하면(증빙서류제출 안내_심사실패(재심사)) 알림을 발송함.
          if(resultCodeFailFlag === 'Y') {
            this.$utils.sendMessageAll(this, {
              messageTemplateId: messageTemplateId,
              messageParams: messageParams,
              sendChannelCode: '003',
              saleContractNo: this.contractNumber,
              customerMgmtNo: customerMgmtNo,
              customerUniqueNo: customerUniqueNo,
              receiverName: receiverName,
              receiverTel: receiverTel,
              fileGroupSerialNo: ''
            })
            // 증빙서류 심사 정보가 모두 성공이면(증빙서류제출 안내_심사승인) 알림을 발송함.
          } else if (resultCodeFailFlag === 'N' && messageTemplateId === 'wp_1201005' && data.workProcessResultCode === '30') {
            this.$utils.sendMessageAll(this, {
              messageTemplateId: messageTemplateId,
              messageParams: {},
              sendChannelCode: '003',
              saleContractNo: this.contractNumber,
              customerMgmtNo: customerMgmtNo,
              customerUniqueNo: customerUniqueNo,
              receiverName: receiverName,
              receiverTel: receiverTel,
              fileGroupSerialNo: ''
            })
          }          
        }
        this.popVisibleLoading = false
      } else {
        this.popVisibleLoading = false
        console.error(err)
      }
    },
    //서류심사 목록 - 최초 구분
    async onChangeDocumentType(data) {
      this.reviewFilter.neceDocTargNo = 'all'
      const [res, err] = await this.$https.get(
        '/v2/exclusive/mypage/document/target/' + data
      )
      if (!err) {
        this.documentTargets = res.data
      } else {
        console.error(err)
      }
    },
    //서류심사 목록 - 구분
    async changeCategory(e) {
      this.reviewFilter.neceDocNo = 'all'
      if(e && e !== 'all') { // 구분 select value중에서 전체가 아닐 경우에만
        const [res, err] = await this.$https.get('/v2/exclusive/contract/papers?neceDocTargNo='+ e)
        if(!err) {
          res.data.unshift({'neceDocNo': 'all', 'neceDocNm': '전체' })
          this.neceDocSubCategoryReview = res.data
        } else {
          console.error(err)
        }
      }else{
        //전체일경우 나머지 소분류 초기화
        this.neceDocSubCategoryReview = [{ neceDocNo: 'all', neceDocNm: '전체' }]
      }
    },
    changeSubCategory(e) {
      console.log(e)
    },
    async changeDocCtgList(e, rowData) { // 서류 심사 목록 - 구분 컬럼 변경시 이벤트
      this.documentList.some((items) => {
        if(items.addRowKey === ''+rowData.addRowKey) {
          items.neceDocNo = null
          return true
        }
      })

      if(e && e !== 'all') { // 구분 select value중에서 전체가 아닐 경우에만
        const [res, err] = await this.$https.get('/v2/exclusive/contract/papers?neceDocTargNo='+ e)
        if(!err) {
          // res.data.unshift({'neceDocNo': 'all', 'neceDocNm': '전체' })
          let obj = {}
          obj[rowData.addRowKey] = res.data
          this.neceDocSubCategoryList = { ...this.neceDocSubCategoryList, ...obj }
        } else {
          console.error(err)
        }
      }
    },
    // eslint-disable-next-line no-unused-vars
    changeDocSubCtgList(e, row) { // 서류 심사 목록 - 소분류 컬럼 변경시 이벤트
      row.isEdit = true

      const neceDocSubCategory = this.neceDocSubCategoryList[row.addRowKey].find((el) => el.neceDocNo === row.neceDocNo)
      if(neceDocSubCategory){
        this.neceDocList.push({
          neceDocNo:neceDocSubCategory.neceDocNo,
          neceDocNm: neceDocSubCategory.neceDocNm
        }) 
      }
    },
    // eslint-disable-next-line no-unused-vars
    changeDocStatus(e, row) { // 서류 심사 목록 - 상태
      row.isEdit = true
    },
    // eslint-disable-next-line no-unused-vars
    changeDocContent(e, row) { // 서류 심사 목록 - 처리내용
      row.isEdit = true
    },
    onCheck(value) {
      console.log(value)
    },
    tableRowClassName({row}) {
      if (row.background === 'red') {
        return 'warning-row'
      }
      else if (row.border === 'red') {
        return 'warning-row1'
      }
      return ''
    },

    // 서류심사 행추가로 생성된 행 삭제
    deleteDocumentRow(key) {
      const idx = this.documentList.findIndex(item => item.addRowKey === key)
      if (idx > -1) this.documentList.splice(idx, 1) // 일치하는 row 삭제
    },
    async documentTargetChanged(val, row) {
      const [res,err] = await this.$https.get('/v2/exclusive/contract/papers', { neceDocTargNo: val })
      if (!err) {
        console.log(row)
        this.paperTypes = [{'neceDocNo': 'all', 'neceDocNm': '전체'}, ...res.data]
      }
    },
    initRuleFormPop() { // 초기화 버튼
      Object.assign(this.$data.ruleFormpopup, this.$options.data().ruleFormpopup)
    },
    async sendSms() {
      let customersInfo = []
      const contractorInfo = this.contractData && this.contractData.contractorInfo
      const targetContractorInfo = contractorInfo && contractorInfo.filter((items) => {
        return this.contractorNames.includes(items.customerName)
      })

      targetContractorInfo.map((items) => {
        customersInfo.push({
          sendChannelCode: '003', // 발송경로 구분 코드 - 업무담당자
          saleContractNo: this.contractNumber || '', // 판매계약번호
          customerMgmtNo: items.customerManagementNumber || '', // 고객관리번호
          customerUniqueNo: this.userInfo.eeno || '', // 고객고유번호
          messageTitle: this.ruleFormpopup.title, // 제목
          messageContents: this.ruleFormpopup.text, // 내용
          receiverTel: items.customerMobile, // 수신자전화번호
          receiverName: items.customerName // 수신자명
        })
      })

      const [result1, result2] = await Promise.all(
        customersInfo.map((items) => {
          return this.$https.post('/v2/exclusive/common/sms-send', items)
        })
      )

      // 1명의 계약자에게만 발송하는 경우
      if (!result2) {
        const [res1, err1] = result1
        if (!err1) {
          if(res1.rspStatus && res1.rspStatus.rspCode === '0000') {
            this.popVisibleSMS = false // 팝업 닫기
            this.alertMessage = '문자가 전송되었습니다.'
            this.alertMessagePop = true
          }
        }
      }

      // 주계약자 및 공동명의자 모두 발송하는 경우
      if (result1 && result2) {
        const [res1, err1] = result1
        const [res2, err2] = result2

        // 모두 전송되었을 경우
        if (!err1 && !err2) {
          if(res1.rspStatus && res1.rspStatus.rspCode === '0000' &&
            res2.rspStatus && res2.rspStatus.rspCode === '0000') {
            this.popVisibleSMS = false // 팝업 닫기
            this.alertMessage = '문자가 전송되었습니다.'
            this.alertMessagePop = true
          }
        }
      }
      this.getMessageTabData() // reload
      this.popVisibleSMS = false // 팝업 닫기
    },
    openPopSms() { // 문자보내기 팝업 노출
    // ※ 출고일 장기 경과 데이터 이관으로 고객정보 부재가 발생하는 케이스가 생김.
    // 고객 데이터에 따른 안내팝업 처리
    // 고객관리번호는 필수값이 아니라 체크안함. 고객정보의 수신자 전화번호와 수신자명은 필수값 임으로 체크
      let customerMobile = '', customerName = ''

      if (this.contractData && this.contractData.contractorInfo[0]) {
        ({ customerMobile, customerName } = this.contractData.contractorInfo[0])
      }

      if (!customerMobile || !customerName) { // 고객정보가 없을 경우
        this.alertMessage = '출고일 장기 경과건으로 고객 데이터가 없습니다.\n데이터 복원후 진행해주세요.'
        this.alertMessagePop = true
      } else {
        this.popVisibleSMS = true
        Object.assign(this.ruleFormpopup, this.$options.data().ruleFormpopup)
      }
    },
    onRefresh(flag, tab) {
      if(flag) {
        switch(tab) {
        case 'contract':
          this.getContractTabData()
          break
        case 'car':
          this.getCarTabData()
          break
        case 'pay':
          this.getPaymentTabData()  // 결제정보탭 reload
          break
        case 'release':
          this.getReleaseTabData()
          break
        case 'status':
          this.getStatusTabData()
          break
        case 'sms':
          this.getMessageTabData()
          break
        }
      }
    },
    contractorHpTns() {
      const contractorInfo = this.contractData && this.contractData.contractorInfo
      const targetContractorInfo = contractorInfo && contractorInfo.filter((items) => {
        return this.contractorNames.includes(items.customerName)
      })
      return targetContractorInfo && targetContractorInfo.map((items) => { return items.customerMobile + (items.contractorTypeName ? ('(' + items.contractorTypeName + ')') : '') }).join(', ')
    },
    async getInfoData() {
      this.popVisibleLoading = true

      // API-E-업무담당자-013 (계약출고상세조회)
      const [res, err] = await this.$https.post(
        '/v2/exclusive/contract-detail',
        { contractNumber: this.contractNumber }
      )
      if (!err) {
        if (!res.data) {
          // 상세보기 - 조회 결과 없음 팝업 노출
          const beforeContractNumber = this.contractNumber
          const beforeActiveName = this.activeName
          Object.assign(this.$data, this.$options.data())
          this.contractNumber = beforeContractNumber // 이전 계약번호 유지
          this.activeName = beforeActiveName // 이전 탭 상태 유지
          this.alertNoData = true
          return
        }

        // screenUseTypeCode (01:열람,02:수정,03:삭제,04:인쇄,05:입력,06:업로드,07:다운로드)
        this.$store.dispatch('commonSupportLog', { vm: this, params: { screenUseTypeCode: '01', useInfo: JSON.stringify(res.data) } })
        this.info = res.data
        if (
          this.info.consultantId &&
          this.info.consultantId === this.userInfo.eeno
        ) {
          // 사용자 사번과 계약건의 업무담당자이 같을 경우
          this.activeFlag = true
        }

        this.info.customerTypeCodes = this.customerTypeCodes

        this.getContractTabData()
        
        this.popVisibleLoading = false
      } else {
        this.popVisibleLoading = false
        console.error(err)
      }
    },
    handleTabClick(tab) {
      if (tab.name === 'first') this.getContractTabData()
      else if (tab.name === 'second') this.getCarTabData()
      else if (tab.name === 'third') this.getPaymentTabData()
      else if (tab.name === 'fourth') this.getReleaseTabData()
      else if (tab.name === 'fifth') this.getStatusTabData()
      else if (tab.name === 'sixth') this.getMessageTabData()
    },
    async getContractTabData() {
      if (!this.contractNumber) return

      //계약자 정보 + 서비스가입 + 계약금 결제
      // API-E-업무담당자-014 (계약정보조회)
      // if(Object.keys(this.contractData).length===0) {
      const [res1, err1] = await this.$https.post(
        '/v2/exclusive/work/contract',
        { contractNumber: this.contractNumber }
      )
      if (!err1) {
        console.log('/work/contract/', res1.data)
        if (!res1.data) {
          return
        }
        this.contractData = res1.data

        const contractorInfo =
          this.contractData && this.contractData.contractorInfo
        this.contractorNames =
          contractorInfo && contractorInfo.length
            ? contractorInfo.map(items => {
              return items.customerName
            })
            : []

        this.$refs.contractInfo.getAllData()
      } else {
        console.error(err1)
      }
    },
    async getCarTabData() {
      if (!this.contractNumber) return

      this.$refs.CarInfo.getCarInfoData()
    },
    getCarProductionNumber(pdNumber) {
      this.carProductionNumber = pdNumber
    },
    async getPaymentTabData() {
      if (!this.contractNumber) return
      this.$refs.payInfo.getAllData()
    },
    async getReleaseTabData() {
      if (!this.contractNumber) return
      this.$refs.releaseInfo.getAllData()
    },
    async getStatusTabData() {
      if (!this.contractNumber) return

      //API-WE-업무담당자-035 (판매처리이력 조회)
      this.$refs.StatusHistory.getSaleHistory()

      //API-WE-업무담당자-036 (매출변경이력 조회)
      this.$refs.StatusHistory.getSalesHistory()

      //API-WE-업무담당자-037 (결제변경이력 조회)
      this.$refs.StatusHistory.getPaymentHistory()

      // API-WE-업무담당자-129 (포인트신청이력 조회)
      this.$refs.StatusHistory.getPointHistory()

      //API-WE-업무담당자-038 (업무담당자처리이력 조회)
      this.$refs.StatusHistory.getConsultantHistory()

      //API-WE-업무담당자-040 (서류심사이력 조회)
      this.$refs.StatusHistory.getPaperHistory()

      //API-WE-업무담당자-041 (전자서명이력 조회)
      this.$refs.StatusHistory.getSignHistory()

      //API-WE-업무담당자-133 (국판 호출 로그 이력 조회)
      this.$refs.StatusHistory.getApiHistory()

      //API-WE-업무담당자-147 (계약 변경 이력 조회)
      this.$refs.StatusHistory.getChangeHistory();

    },
    async getMessageTabData() {
      if (!this.contractNumber) return

      this.$refs.SmsHistory.getSmsHistoryData()
    },
    searchAddressPopOpen(index) {
      this.popVisibleAddress.addressPop = true
      this.popVisibleAddress.addrIndex = index
    },
    addDocumentPopOpen() {
      this.popVisibleRequestPaper = true
    }
  },
}
</script>

<style lang="scss" scoped>
.btn-md{
  min-width: 40px;
  height: 40px;
}
@import '~/assets/style/pages/detail.scss';

.img-editor-dialog .el-dialog{width:1200px !important;}
.img-editor .temp-menu button{display:inline-block;background:#eee !important;height:32px;border-radius: 2px;padding:0 10px;}
.img-editor .canvas-wrap { position: relative; overflow: hidden; height:400px; border: 1px solid black; background: #ccc; }
.img-editor .canvas-wrap  #canvas{ position:absolute;top:0;left:0; margin:0 auto; display:block;}
.img-editor .temp-menu{margin-bottom:10px;background:#eee;border:1px dashed #000;padding:10px 15px;}
.img-editor .menu-wrap{display: flex;align-items: center;margin-bottom:10px;}
.img-editor .menu-wrap .left{flex:1;}
.img-editor .menu-wrap .right{margin-left:auto;padding-left:30px;}
.img-editor .menu-wrap .menu{display:flex;width:100%;height:40px;border:1px solid #e4dcd3;align-items: stretch;}
.img-editor .menu-wrap .menu li {display:flex;width:100%;align-items: stretch;}
.img-editor .menu-wrap .menu li .label{display:flex;align-items:center;min-width: 100px; padding:0 14px; text-align:center;  color: #000; font-weight: 700; background: #e4dcd3; text-align: center;}
.img-editor .menu-wrap .menu li .label-cont{display:flex;align-items:center;flex:1; background: #fff;padding:0 14px;}
.img-editor .pen-size{appearance: auto; cursor: default; color: -internal-light-dark(rgb(16, 16, 16), rgb(255, 255, 255)); padding: initial; border: initial; margin: 2px;}
.img-editor .tog-btn{height:30px;border: 1px solid #ccc;border-radius: 3px;}
.img-editor .tog-btn button{height:100%;width:35px;border:none;display:inline-flex;background:#fff;align-items: center;justify-content: center;vertical-align: top;}
.img-editor .tog-btn button + button{border-left:1px solid #ccc;}
.img-editor .tog-btn button.on{background: #ccc;}
.img-editor .tog-btn img{width:23px;}
.img-editor .pdf-menu{text-align: center;margin-top:15px;}
.img-editor .pdf-menu .page{margin:0 30px;}
.img-editor .btn-st{height:35px;border:1px solid #ccc;padding:0 10px;text-align: center;min-width: 80px;}
.img-editor .hide{display: inline-block; position: absolute; overflow: hidden; clip: rect(0 0 0 0); height: 1px; width: 1px; margin: -1px; padding: 0; border: 0;}
</style>
