<template>
  <section>
    <!-- Moment Test -->
    <div style="margin-bottom: 50px">
      Moment (filter) : {{ new Date() | moment('YYYY-MM-DD') }}<br>
      Moment (this.$moment): {{ testDate }}<br>
    </div>

    <!-- API호출 -->
    <div style="margin-bottom: 50px">
      <el-button
        type="primary"
        @click="apiFetch"
      >
        API 호출 테스트
      </el-button>
    </div>

    <!-- 팝업 --> 
    <div style="margin-bottom: 50px">
      <el-button
        type="primary"
        @click="popVisible = true"
      >
        컨텐츠 팝업
      </el-button>
      <el-button
        type="primary"
        @click="alertVisible = true"
      >
        메세지 팝업
      </el-button>
    </div>

    <!-- 컨텐츠 팝업 -->
    <el-dialog
      title="Popup Title"
      :visible.sync="popVisible"
    >
      <!-- Popup Contents -->
      <el-form 
        :inline="true"
        :model="searchForm" 
        class="search-form"
      >
        <el-form-item>
          <el-select
            v-model="searchForm.category"
            placeholder="분류1"
          >
            <el-option
              v-for="{ value, label } in code.category"
              :key="value"
              :value="value"
              :label="label"
            />
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-select
            v-model="searchForm.category"
            placeholder="분류2"
          >
            <el-option
              v-for="{ value, label } in code.category"
              :key="value"
              :value="value"
              :label="label"
            />
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-select
            v-model="searchForm.category"
            placeholder="분류3"
          >
            <el-option
              v-for="{ value, label } in code.category"
              :key="value"
              :value="value"
              :label="label"
            />
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-input v-model="searchForm.text" />
        </el-form-item>

        <el-button
          type="primary"
          @click="onSubmit"
        >
          검색
        </el-button>
      </el-form>

      <div class="board-wrap">
        <el-table
          :data="list"
          @selection-change="onCheck"
        >
          <el-table-column
            type="selection"
            width="55"
          />
          <el-table-column 
            prop="date"
            label="Date" 
            align="center" 
          />
          <el-table-column 
            prop="name"
            label="Name" 
          />
          <el-table-column
            prop="model"
            label="Model"
          >
            <template slot-scope="props">
              <span>{{ getModelName(props.row.model) }}</span>
            </template>
          </el-table-column>

          <el-table-column
            prop="price"
            label="Price"
            align="right"
          >
            <template slot-scope="props">
              <span>{{ props.row.price | currency }}</span>
            </template>
          </el-table-column>
        </el-table>
      </div>

      <!-- Popup Footer -->
      <template slot="footer">
        <el-button
          type="info"
          @click="popVisible = false"
        >
          취소
        </el-button>
        <el-button
          type="primary"
          @click="popVisible = false"
        >
          확인
        </el-button>
      </template>
    </el-dialog>


    <!-- 메세지 팝업 -->
    <el-dialog
      custom-class="message"
      :visible.sync="alertVisible"
    >
      <!-- Message -->
      텍스트텍스트텍스트텍스트텍스트텍스트텍스트텍스트<br>
      텍스트텍스트텍스트텍스트

      <!-- Popup Footer -->
      <template slot="footer">
        <el-button
          type="info"
          @click="alertVisible = false"
        >
          취소
        </el-button>
        <el-button
          type="primary"
          @click="alertVisible = false"
        >
          확인
        </el-button>
      </template>
    </el-dialog>


    <!-- 일반 검색창 -->
    <el-form 
      :inline="true"
      :model="searchForm" 
      class="search-form"
    >
      <el-form-item label="분류">
        <el-select
          v-model="searchForm.category"
          placeholder="분류선택"
        >
          <el-option
            v-for="{ value, label } in code.category"
            :key="value"
            :value="value"
            :label="label"
          />
        </el-select>
      </el-form-item>

      <el-form-item>
        <el-input v-model="searchForm.text" />
      </el-form-item>

      <el-button
        type="primary"
        @click="onSubmit"
      >
        검색
      </el-button>
    </el-form>

    <!-- 항목 여러개 검색창 -->
    <el-form 
      :inline="true"
      :model="searchForm2" 
      class="search-form multiple"
    >
      <el-form-item label="대표차">
        <el-select
          v-model="searchForm2.carId"
          placeholder="대표차"
        >
          <el-option
            v-for="{ value, label } in code.carList"
            :key="value"
            :value="value"
            :label="label"
          />
        </el-select>
      </el-form-item>

      <el-form-item label="구분">
        <el-select
          v-model="searchForm2.partId"
          placeholder="구분"
        >
          <el-option
            v-for="{ value, label } in code.partList"
            :key="value"
            :value="value"
            :label="label"
          />
        </el-select>
      </el-form-item>

      <el-form-item label="검색">
        <el-select
          v-model="searchForm2.schId"
          placeholder="검색"
        >
          <el-option
            value="salecolor"
            label="판매모델 + 외장칼라별"
          />
          <el-option
            value="sale"
            label="판매모델"
          />
          <el-option
            value="color"
            label="외장칼라별"
          />
        </el-select>
      </el-form-item>

      <el-button
        type="primary"
        @click="onSubmit"
      >
        검색
      </el-button>
    </el-form>

    <div class="board-wrap">
      <el-table
        :data="list"
        @selection-change="onCheck"
      >
        <el-table-column
          type="selection"
          width="55"
        />
        <el-table-column
          prop="date"
          align="center"
        >
          <template slot="header">
            Date<br>
            (2줄인 경우)
          </template>
        </el-table-column>

        <el-table-column prop="name">
          <template slot="header">
            <span class="mark-require">&#42;</span> Name
          </template>
          <template slot-scope="props">
            <span v-if="!props.row.isEdit">{{ props.row.name | capitalize }}</span>
            <el-input
              v-else
              v-model="props.row.name"
            />
          </template>
        </el-table-column>

        <el-table-column
          prop="model"
          label="Model"
        >
          <template slot-scope="props">
            <span v-if="!props.row.isEdit"><router-link
              to="/"
              class="link"
            >{{ getModelName(props.row.model) }}</router-link></span>
            <el-select
              v-else
              v-model="props.row.model"
            >
              <el-option
                v-for="{ value, label } in code.carList"
                :key="value"
                :value="value"
                :label="label"
              />
            </el-select>
          </template>
        </el-table-column>

        <el-table-column
          prop="price"
          label="Price"
          align="right"
        >
          <template slot-scope="props">
            <span v-if="!props.row.isEdit">{{ props.row.price | currency }}</span>
            <el-input
              v-else
              v-model="props.row.price"
            />
          </template>
        </el-table-column>

        <el-table-column
          prop="thumbnail"
          label="Image"
          width="180"
          class-name="image"
        >
          <template slot-scope="props">
            <v-img
              :src="props.row.thumbnail"
              img-type="table"
            />
          </template>
        </el-table-column>

        <el-table-column
          prop="address"
          label="Address"
        />

        <el-table-column
          width="120"
          class-name="action"
        >
          <template slot-scope="props">
            <span v-if="!props.row.isEdit">
              <el-button
                type="text"
                @click="onEdit(props)"
              >
                수정
              </el-button>
              <el-button
                type="text"
                @click="onDelete(props)"
              >
                삭제
              </el-button>
            </span>
            <span v-else>
              <el-button
                type="text"
                @click="onSave(props)"
              >
                저장
              </el-button>
              <el-button
                type="text"
                @click="onCancel(props)"
              >
                취소
              </el-button>
            </span>
          </template>
        </el-table-column>

        <el-table-column
          class-name="action"
        >
          <template>
            <el-button type="primary">
              버튼
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="btn-wrap">
        <div class="side">
          <el-button type="info">
            삭제
          </el-button>
        </div>

        <div class="excel">
          <el-button
            type="primary"
            class="excel"
          >
            Excel 다운로드
          </el-button>
          <el-button
            type="primary"
            class="excel"
          >
            Excel 일괄 업로드
          </el-button>
          <span class="excel-file">[양식]사양패키지 관리.xlsx</span>
        </div>
        
        <div class="main">
          <el-button type="info">
            사양등록
          </el-button>
          <el-button type="primary">
            저장
          </el-button>
        </div>
      </div>

      <div class="btn-wrap">
        <div class="side">
          <el-button type="info">
            삭제
          </el-button>
        </div>

        <div class="pagination">
          <v-pagination
            :total="100"
          />
        </div>
        
        <div class="main">
          <el-button type="info">
            사양등록
          </el-button>
          <el-button type="primary">
            저장
          </el-button>
        </div>
      </div>

      <div class="pagination">
        <v-pagination
          :total="100"
        />
      </div>
    </div>
    
    <div
      class="board-wrap"
      style="padding-bottom: 50px;"
    >
      <el-table
        :data="list"
        @selection-change="onCheck"
      >
        <el-table-column
          prop="date"
          align="center"
          label="date"
        />
        <el-table-column
          prop="date"
          align="center"
        >
          <template slot="header">
            Menu
            <br>
            두줄
          </template>
          <el-table-column
            prop="address"
            align="center"
            label="address"
          />
          <el-table-column
            prop="name"
            align="center"
            label="name"
          />
          <el-table-column
            prop="model"
            align="center"
            label="model"
          />
        </el-table-column>
      </el-table>
    </div>
    
    <el-form
      ref="ruleForm"
      :model="ruleForm"
      class="detail-form"
    >
      <el-row>
        <el-col :span="12">
          <el-form-item
            label="Selectbox"
            prop="name"
            required
          >
            <el-select
              v-model="ruleForm.site"
              placeholder="구분"
            >
              <el-option
                value="o2o"
                label="홈페이지"
              />
              <el-option
                label="e2e"
                value="임직원몰"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item
            label="텍스트 + 숫자입력"
            prop="region"
          >
            <span class="static">10000 / </span>
            <el-input
              v-model="ruleForm.number"
              :controls="false"
              :min="10000"
            />
          </el-form-item>
        </el-col>
      </el-row>
      
      <el-row>
        <el-col :span="12">
          <el-form-item
            label="기준월"
            prop="delivery"
          >
            <el-date-picker
              v-model="ruleForm.month"
              type="month"
              :clearable="false"
            />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item
            label="날짜"
            prop="date1"
          >
            <el-date-picker
              v-model="ruleForm.date1"
              type="date"
              :clearable="false"
            />
            <el-button type="primary">
              내용생성
            </el-button>
          </el-form-item>
        </el-col>
      </el-row>

      <el-row>
        <el-col>
          <el-form-item
            label="Activity type"
            prop="type"
          >
            <el-checkbox-group v-model="ruleForm.type">
              <el-checkbox
                label="Online activities"
                name="type"
              />
              <el-checkbox
                label="Promotion activities"
                name="type"
              />
              <el-checkbox
                label="Offline activities"
                name="type"
              />
              <el-checkbox
                label="Simple brand exposure"
                name="type"
              />
            </el-checkbox-group>
          </el-form-item>
        </el-col>
        <el-col>
          <el-form-item
            label="Resources"
            prop="resource"
          >
            <el-radio-group v-model="ruleForm.resource">
              <el-radio label="Sponsorship" />
              <el-radio label="Venue" />
            </el-radio-group>
          </el-form-item>
        </el-col>
      </el-row>

      <el-row>
        <el-col>
          <el-form-item
            label="Activity form"
            prop="desc"
          >
            <el-input
              v-model="ruleForm.desc"
              type="textarea"
            />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>

    <article class="article">
      <div class="article-title">
        <h2>소제목 영역</h2>
      </div>
      <el-form
        ref="ruleForm"
        :model="ruleForm"
        class="detail-form"
      >
        <el-form-item label=" ">
          <el-col
            :span="12"
            class="header"
          >
            홈페이지
          </el-col>
          <el-col
            :span="12"
            class="header"
          >
            임직원몰
          </el-col>
        </el-form-item>

        <el-form-item
          label="노출대표차명"
          required
        >
          <el-col :span="12">
            <el-form-item prop="o2oCarName">
              <el-input v-model="ruleForm.o2o.carName" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item prop="e2eCarName">
              <el-input v-model="ruleForm.e2e.carName" />
            </el-form-item>
          </el-col>
        </el-form-item>
        <el-form-item
          label="구매상담가능여부"
          required
        >
          <el-col :span="12">
            <el-form-item prop="o2oConsult">
              <el-radio-group v-model="ruleForm.o2o.consult">
                <el-radio label="N" />
                <el-radio label="Y" />
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item prop="e2eConsult">
              <el-radio-group v-model="ruleForm.e2e.consult">
                <el-radio label="N" />
                <el-radio label="Y" />
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-form-item>
        <el-form-item
          label="노출기간"
          required
        >
          <el-col :span="12">
            <el-row class="daytime">
              <el-form-item prop="o2oDate1">
                <el-date-picker
                  v-model="ruleForm.o2o.date1"
                  type="date"
                  :clearable="false"
                />
              </el-form-item>
              <el-form-item prop="o2oTime1">
                <el-time-select
                  v-model="ruleForm.o2o.time1"
                  :clearable="false"
                />
              </el-form-item>
              <span class="ex-txt">~</span>
            </el-row>
            <el-row class="daytime">
              <el-form-item prop="o2oDate2">
                <el-date-picker
                  v-model="ruleForm.o2o.date2"
                  type="date"
                  :clearable="false"
                />
              </el-form-item>
              <el-form-item prop="o2oTime2">
                <el-time-select
                  v-model="ruleForm.o2o.time2"
                  :clearable="false"
                />
              </el-form-item>
            </el-row>
          </el-col>
          <el-col :span="12">
            <el-row class="daytime">
              <el-form-item prop="e2eDate1">
                <el-date-picker
                  v-model="ruleForm.e2e.date1"
                  type="date"
                  :clearable="false"
                />
              </el-form-item>
              <el-form-item prop="e2eTime1">
                <el-time-select
                  v-model="ruleForm.e2e.time1"
                  :clearable="false"
                />
              </el-form-item>
              <span class="ex-txt">~</span>
            </el-row>
            <el-row class="daytime">
              <el-form-item prop="e2eDate2">
                <el-date-picker
                  v-model="ruleForm.e2e.date2"
                  type="date"
                  :clearable="false"
                />
              </el-form-item>
              <el-form-item prop="e2eTime2">
                <el-time-select
                  v-model="ruleForm.e2e.time2"
                  :clearable="false"
                />
              </el-form-item>
            </el-row>
          </el-col>
        </el-form-item>
      </el-form>

      <div class="btn-wrap">
        <div class="side">
          <!-- <router-link
            :to="{ name: 'vehicles-car' }"
            class="el-button el-button--info"
          >
            목록
          </router-link> -->
        </div>
        <div class="main">
          <el-button type="info">
            취소
          </el-button>
          <el-button type="primary">
            등록
          </el-button>
        </div>
      </div>
    </article>
    
    <!-- tootip -->
    <div
      class="tooltip"
      style="padding-top: 50px;"
    >
      <div class="article-title">
        <h2>tooltip</h2>
      </div>
      
      <el-tooltip
        placement="bottom"
        effect="light"
      >
        <div slot="content">
          <el-row>
            <el-col :span="6">
              차종
            </el-col>
            <el-col :span="18">
              아반떼 가솔린 1.7터보 세단 4도어 DCT SPORT
            </el-col>
          </el-row>
        </div>
        <el-button>툴팁 버튼</el-button>
      </el-tooltip>
      <el-tooltip
        placement="bottom"
        effect="light"
      >
        <div slot="content">
          <div class="tootip-title">
            <h3>G80 신청</h3>
          </div>
          <el-row>
            <el-col :span="6">
              차종
            </el-col>
            <el-col :span="18">
              아반떼 가솔린 1.7터보 세단 4도어 DCT SPORT
            </el-col>
          </el-row>
        </div>
        <span>
          <router-link
            to="/"
            class="link"
          >
            툴팁 링크
          </router-link>
        </span>
      </el-tooltip>

      <el-tooltip
        placement="bottom"
        effect="light"
      >
        <div slot="content">
          <el-row>
            <el-col :span="24">
              위치 : 울산광역시 북구 양정동 700
            </el-col>
            <el-col :span="24">
              전화번호 : 052-215-2476
            </el-col>
          </el-row>
        </div>
        <span>
          <router-link
            to="/"
            class="link"
          >
            툴팁 링크
          </router-link>
        </span>
      </el-tooltip>
    </div>
   
    <div
      class="tabBtn"
      style="margin-top: 20px;"
    >
      <div class="article-title">
        <h2>탭버튼</h2>
      </div>
      <div>
        <p>case01</p>
        <el-radio-group
          v-model="tabPosition"
          style="margin-bottom: 30px;"
          class="tabBtn-case01"
        >
          <el-radio-button label="1년" />
          <el-radio-button label="3년" />
          <el-radio-button label="5년" />
          <el-radio-button label="10년" />
        </el-radio-group>
      </div>
      <div>
        <p>case02</p>
        <el-radio-group
          v-model="tabPosition"
          style="margin-bottom: 30px;"
          class="tabBtn-case02"
        >
          <el-radio-button label=" +1 일 후" />
          <el-radio-button label=" +2 일 후" />
          <el-radio-button label=" 전제" />
        </el-radio-group>
      </div>
      <div class="tab">
        <div class="article-title">
          <h2>tab</h2>
        </div>
        <el-tabs
          type="card"
          stretch
          @tab-click="handleClick"
        >
          <el-tab-pane label="계약정보">
            탭1
          </el-tab-pane>
          <el-tab-pane label="차량정보">
            탭2
          </el-tab-pane>
          <el-tab-pane label="결제정보">
            탭3
          </el-tab-pane>
          <el-tab-pane label="출고정보">
            탭4
          </el-tab-pane>
          <el-tab-pane label="상태이력">
            탭5
          </el-tab-pane>
          <el-tab-pane label="문자이력">
            탭6
          </el-tab-pane>
        </el-tabs>
      </div>
    </div>
    <p>컴포넌트화 된 테이블 입니다. </p>
    <h-table
      :table-type="'DefultTable'"
      :table-header="tableHeader"
      :table-datas="tableList1"
    >
      <template slot="table1">
        <el-button type="text">
          123
        </el-button>
      </template>
    </h-table>
    <h-table
      :table-type="'TwoHeadTable'"
      :table-header="tableHeader2"
      :table-datas="tableList2"
    />
    <h-table
      :table-type="'SumTable'"
      :table-header="tableHeader2"
      :table-datas="tableList2"
    />
    <p>컴포넌트화 된 테이블 리스트 입니다. </p>
    <h-table-list
      :list-table-type="'List'"
      :table-datas="tableDataL1"
      :table-header="tableHeaderL1"
    />
    <h-table-list
      :list-table-type="'Accordion'"
      :table-datas="tableDataL2"
      :table-header="tableHeaderL2"
    />
    <h-table-list
      :list-table-type="'ListTable'"
    />
  </section>
</template>

<script>
import HTable from '~/components/common/HTable.vue'
import HTableList from '~/components/common/HTableList.vue'

export default {
  layout: 'guide',
  components: {
    HTable,
    HTableList
  },
  data() {
    return {
      popVisible: false,
      alertVisible: false,
      testDate: '',
      tabPosition: 'left',
      activeName: 'first',
      searchForm: {
        category: null,
        text: ''
      },

      searchForm2: {
        carId: null,
        partId: null,
        schId: null
      },

      ruleForm: {
        type: [],
        o2o: {},
        e2e: {}
      },

      code: {
        category: [
          { value: 'carType1', label: '승용' },
          { value: 'carType2', label: 'SUV' }
        ],
        carList: [
          { value: 'avante', label: '아반떼' },
          { value: 'sonata', label: '쏘나타' }
        ],
        partList: [
          { value: 'sale', label: '판매' },
          { value: 'event', label: '이벤트' }
        ]
      },

      list: [
        {
          date: '2016-05-03',
          name: 'james',
          model: 'avante',
          price: 20000,
          thumbnail: '',
          address: 'No. 189, Grove St, Los Angeles'
        },
        {
          date: '2016-05-02',
          name: 'james',
          model: 'sonata',
          price: 20000,
          thumbnail: '',
          address: 'No. 189, Grove St, Los Angeles'
        },
        {
          date: '2016-05-02',
          name: 'james',
          model: 'sonata',
          price: 20000,
          thumbnail: '',
          address: 'No. 189, Grove St, Los Angeles'
        },
        {
          date: '2016-05-02',
          name: 'james',
          model: 'sonata',
          price: 20000,
          thumbnail: '',
          address: 'No. 189, Grove St, Los Angeles'
        },
        {
          date: '2016-05-02',
          name: 'james',
          model: 'sonata',
          price: 20000,
          thumbnail: '',
          address: 'No. 189, Grove St, Los Angeles'
        }
      ],

      //list Data backup
      cachedList: [],
      tableHeader:[
        {
          label: '' ,
          width: '55px',
          type: 'selection',
          prop: 'selection',
          align: 'center'
        },
        {
          label: 'part1',
          prop: 'part1',
          type: 'button',
          align: 'center'
        },
        {
          label: 'part2',
          prop: 'part2',
          align: 'center'
        },
        {
          label: 'part3',
          prop: 'part3',
          align: 'center'
        }
      ],
      tableList1: [
        {
          selection: false,
          part1: 'test1',
          part2: 'test2',
          part3: 'test3'
        },
        
      ],
      tableHeader2:[
        {
          label: '컨설턴트',
          width: '400',
          type: '',
          prop: 'col1',
          align: 'center',
          fixed: 'fixed',
          children: []
        },
        {
          label: '업무유형' ,
          width: '800',
          type: '',
          prop: '',
          align: 'center',
          fixed: 'fixed',
          children: [
            {
              label: 'OB 업무' ,
              width: '200',
              type: '',
              prop: 'col2',
              align: 'center',
            },
            {
              label: '고객센터이관' ,
              width: '200',
              type: '',
              prop: 'col3',
              align: 'center',
            },
            {
              label: '마이페이지' ,
              width: '200',
              type: '',
              prop: 'col4',
              align: 'center',
            },
            {
              label: '계' ,
              width: '200',
              type: '',
              prop: 'col5',
              align: 'center',
            }
          ]
        },
        {
          label: '처리결과',
          width: '',
          type: '',
          prop: '',
          align: 'center',
          children: [
            {
              label: '접수',
              width: '',
              type: '',
              prop: 'col2',
              align: 'center',
            },
            {
              label: '진행중',
              width: '',
              type: '',
              prop: 'col3',
              align: 'center',
            },
            {
              label: '종결',
              width: '',
              type: '',
              prop: 'col4',
              align: 'center',
            },
            {
              label: '계',
              width: '',
              type: '',
              prop: 'col5',
              align: 'center',
            }
          ]
        },
        {
          label: '계약',
          width: '',
          type: '',
          prop: 'part1',
          align: 'center',
          children: []
        },
        {
          label: '배정',
          width: '',
          type: '',
          prop: 'part1',
          align: 'center',
          children: []
        },
        {
          label: '배정요청',
          width: '',
          type: '',
          prop: 'part1',
          align: 'center',
          children: []
        },
        {
          label: '출고',
          width: '',
          type: '',
          prop: 'part1',
          align: 'center',
          children: []
        },
        {
          label: '해약',
          width: '',
          type: '',
          prop: 'part1',
          align: 'center',
          children: []
        },
        {
          label: '매출취소',
          width: '',
          type: '',
          prop: 'part1',
          align: 'center',
          children: []
        }
      ],
      tableList2: [
        {
          col1: '업무담당자A',
          col2: 50,
          col3: 30,
          col4: 10,
          col5: 90,
          part1: 'test2'
        },
        {
          col1: '업무담당자A',
          col2: 50,
          col3: 30,
          col4: 10,
          col5: 90,
          part1: 'test2'
        },
        {
          col1: '업무담당자A',
          col2: 50,
          col3: 30,
          col4: 10,
          col5: 90,
          part1: 'test3'
        },
        {
          col1: '업무담당자A',
          col2: 50,
          col3: 30,
          col4: 10,
          col5: 90,
          part1: 'test4'
        },
        {
          col1: '업무담당자A',
          col2: 50,
          col3: 30,
          col4: 10,
          col5: 90,
          part1: 'test5'
        },
        {
          col1: '업무담당자A',
          col2: 50,
          col3: 30,
          col4: 10,
          col5: 90,
          part1: 'test6'
        }
      ],
      tableHeaderL1:[
        {
          prop :'date',
          label: 'date',
         
        },
        {
          prop :'name',
          label: 'name',
        
        }
      ],
      tableDataL1:[
        {
          date: '2016-05-02',
          name: 'wangxiaohu',
          type: 'red'
        },
        {
          date: '2016-05-02',
          name: 'wangxiaohu',
          type: 'default'
        },
      ],
      tableHeaderL2:[
        {
          prop :'date',
          label: 'date'
        },
        {
          prop :'name',
          label: 'name'
        }
      ],
      tableDataL2: [
        {
          id: 1,
          date: '2016-05-02',
          name: 'wangxiaohu'
        }, 
        {
          id: 2,
          date: '2016-05-04',
          name: 'wangxiaohu'
        },
        {
          id: 3,
          date: '2016-05-01',
          name: 'wangxiaohu',
          children: [
            {
              id: 31,
              date: '2016-05-01',
              name: 'wangxiaohu'
            }, {
              id: 32,
              date: '2016-05-01',
              name: 'wangxiaohu'
            }
          ]
        }, 
        {
          id: 4,
          date: '2016-05-03',
          name: 'wangxiaohu'
        }
      ]
    }
  },
  mounted() {
    this.list = this.list.map(obj => ({ ...obj, isEdit: false }))
    this.cachedList = JSON.parse(JSON.stringify(this.list))
    this.testDate = this.$moment().format('LLL')
  },

  methods: {
    async apiFetch() {
      const [res, err] = await this.$https.get('/v1/exclusive/v1/adm/authority/user/list')
      if (err) {
        console.log(err)
      } else {
        console.log(res)
      }
    },

    getModelName(model) {
      const current = this.code.carList.find(({ value }) => value === model)
      return current ? current.label : ''
    },

    onSubmit() {
      console.log(this.searchForm)
    },

    onCheck(value) {
      console.log(value)
    },

    onEdit(props) {
      const { row } = props
      row.isEdit = true
    },

    onDelete(props) {
      const { $index } = props
      this.list.splice($index, 1)
      this.cachedList.splice($index, 1)
    },

    onSave(props) {
      const { row, $index } = props
      console.log({ ...row })
      row.isEdit = false
      this.cachedList[$index] = { ...row }
    },

    onCancel(props) {
      const { row, $index } = props
      Object.keys(row).forEach(key => {
        props.row[key] = this.cachedList[$index][key]
      })
      row.isEdit = false
    },
    handleClick() {
      console.log('클릭')
    }
  }
}
</script>
