<template>
  <section>
    <div id="songpa">
      <article class="article">
        <div class="article-title">
          <el-radio-group
            v-model="tabPosition"
            class="tabBtn-case01"
            @change="onChangeSearchDtRadio"
          >
            <el-radio-button label="1d">
              오늘
            </el-radio-button>
            <el-radio-button label="7d">
              7일
            </el-radio-button>
            <el-radio-button label="30d">
              30일
            </el-radio-button>
          </el-radio-group>
          <el-date-picker v-model="ruleForm.searchStartDate" />
          <span class="ex-txt">~</span>
          <el-date-picker v-model="ruleForm.searchEndDate" />
          <el-button
            v-if="isValidAuthBtn('authSongpa')"
            type="primary"
            style="margin-left: 10px;"
            @click="onSearch(1)"
          >
            조회
          </el-button>
          <el-button
            v-if="isValidAuthBtn('authSongpa')"
            type="primary"
            class="excel"
            @click="downloadExcel"
          >
            EXCEL 다운로드
          </el-button>
        </div>
        <el-table
          :data="purchaseList"
          style="widt: 100%"
          empty-text="조회결과가 존재하지 않습니다."
          max-height="auto"
          >
          <el-table-column
            label="신청일시"
            prop="vbgInpDtm"
            align="center"
            width="250"
          >
            <template slot-scope="props">
              {{ props.row.vbgInpDtm }}
            </template>
          </el-table-column>
          <el-table-column
            label="이름"
            prop="csmrNm"
            align="center"
            width="150"
          >
            <template slot-scope="props">
              {{ props.row.csmrNm }}
            </template>
          </el-table-column>
          <el-table-column
            label="연락처"
            prop="csmrHpTn"
            align="center"
            width="300"
          >
            <template slot-scope="props">
              {{ props.row.csmrHpTn }}
            </template>
          </el-table-column>
          <el-table-column
            label="상담차종"
            prop="repnCarn"
            align="center"
            width="230"
          >
            <template slot-scope="props">
              {{ props.row.repnCarn }}
            </template>
          </el-table-column>
          <el-table-column
            label="전달사항"
            prop="purCnsPttSbc"
            align="center"
            width="600"
          >
            <template slot-scope="props">
              {{ props.row.purCnsPttSbc }}
            </template>
          </el-table-column>
        </el-table>
        <div class="btn-wrap">
          <div class="side"></div>
          <div class="pagination">
            <v-pagination
              v-if="purchaseList.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch"
            />
          </div>
          <div class="main"></div>
        </div>
      </article>
    </div>
  </section>
</template>

<script>
import moment from 'moment'

export default {
  name: 'Songpa',
  layout: 'default',
  data() {
    return {
      ruleForm: {
        searchStartDate: moment(), // 조회시작일자
        searchEndDate: moment() // 조회종료일자
      },
      purchaseList: [], // 구매상담신청 내용
      tabPosition: '1d',
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      }
    }
  },
  methods: {
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    onSearch(page) {
      if(!this.isValidAuthBtn('authSongpa')) { // 권한없을경우 동작 x
        return
      }

      this.$data.pageInfo.page = page
      this.search()
    },
    async search() { // 조회
      if(!this.isValidAuthBtn('authSongpa')) { // 권한없을경우 동작 x
        return
      }

      const { searchStartDate, searchEndDate } = this.ruleForm

      const { page, size } = this.$data.pageInfo

      const params = {
        startDate: moment(searchStartDate).format('YYYYMMDD'),
        finDate: moment(searchEndDate).format('YYYYMMDD'),
        pageNo: page,
        pageSize: size
      }
      const [res, err] = await this.$https.get('/v1/exclusive/support/purchase', params)
      if(err) {
        return
      }
      if(res.data) {
        if(!res.data || !res.data.list || res.data.list.length===0) {
          this.purchaseList = []
        } else {
          this.purchaseList = res.data.list
          this.$data.pageInfo = {
            ...this.$data.pageInfo,
            total: res.data.total
          }
        }
      }
    },
    onChangeSearchDtRadio(val) {
      console.log(val)
      switch(val) {
      case '1d': // 오늘
        this.ruleForm.searchStartDate = moment()
        this.ruleForm.searchEndDate = moment()
        break
      case '7d': // 7일
        this.ruleForm.searchStartDate = moment().subtract('days', 7)
        this.ruleForm.searchEndDate = moment()
        break
      case '30d': // 30일
        this.ruleForm.searchStartDate = moment().subtract('days', 30)
        this.ruleForm.searchEndDate = moment()
        break
      }
    },
    async downloadExcel() {
      const params = {
        startDate: moment(this.ruleForm.searchStartDate).format('YYYYMMDD'),
        finDate: moment(this.ruleForm.searchEndDate).format('YYYYMMDD'),
      }

      const [res,err] = await this.$https.post('/v1/exclusive/support/songpa-excel', params, null, null, { responseType: 'blob' })

      if(!err) {
        const blob = new Blob([res], {type : res.Type })
        const nowDate = moment().format('YYYYMMDD_HHmmss')
        if(window.navigator.msSaveOrOpenBlob) {
          // IE11
          window.navigator.msSaveOrOpenBlob(blob, '구매상담신청현황(송파대로)_' + nowDate + '.xlsx')
        } else {
          // IE11 외 브라우저
          const blobURL = window.URL.createObjectURL(blob)
          const tempLink = document.createElement('a')

          tempLink.href = blobURL

          tempLink.setAttribute('download', '구매상담신청현황(송파대로)_' + nowDate + '.xlsx')
          document.body.appendChild(tempLink)
          tempLink.click()
          document.body.removeChild(tempLink)
          window.URL.revokeObjectURL(blobURL)
        }
      } else {
        console.error(err)
        this.tableData = null
      }
    },
  }
}
</script>

<style lang="scss" scoped>
  #songpa{
    .seach_result{
      padding-bottom: 30px;
      td{
        .cell{
          color:#00aadd;
        }
      }
    }

    .ex-txt{padding:10px;}
  }
</style>
