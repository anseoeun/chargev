<template>
  <section>
    <div id="release">
      <el-form
        class="detail-form"
        @submit.prevent.native
      >
        <el-row>
          <el-col :span="24">
            <el-form-item
              label="사번"
              :class="conpanyNum"
            >
              <el-input
                v-model="ruleForm.employeeNumber"
                class="conpanyNumInput"
                @keyup.enter.native="getOneData"
              />
              <el-button
                v-if="isValidAuthBtn('authSelect')"
                type="primary"
                @click="getOneData"
              >
                조회
              </el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <article class="article">
        <h-title :title="'조회결과'" />
        <h-table
          :table-type="'DefultTable'"
          :table-header="onerowHeader"
          :table-datas="onerowdata"
          class="seach_result"
          :height="100"
        />
        <!-- 직원계약출고 목록 테이블 -->
        <article class="article">
          <el-form
            :model="dateInfo"
            class="search-form"
          >
            <el-row>
              <el-col :span="24">
                <el-radio-group
                  v-model="searchDtRadio"
                  class="tabBtn-case01"
                  @change="onChangeSearchDtRadio"
                >
                  <el-radio-button label="1year">
                    1년
                  </el-radio-button>
                  <el-radio-button label="3years">
                    3년
                  </el-radio-button>
                  <el-radio-button label="5years">
                    5년
                  </el-radio-button>
                  <el-radio-button label="10years">
                    10년
                  </el-radio-button>
                </el-radio-group>

                <el-date-picker
                  v-model="dateInfo.regStartDate"
                  type="date"
                />
                <span class="ex-txt"> ~ </span>
                <el-date-picker
                  v-model="dateInfo.regEndDate"
                  type="date"
                />

                <el-button
                  v-if="isValidAuthBtn('authSelect')"
                  type="primary"
                  @click="onSearch(1)"
                >
                  조회
                </el-button>
              </el-col>
            </el-row>
          </el-form>
        </article>
        <el-table
          :data="contractListData"
          max-height="450"
          empty-text="조회 결과가 존재하지 않습니다."
        >
          <el-table-column
            label="구매채널"
            prop="purchaseChannel"
            align="center"
            width="120"
          />
          <el-table-column
            label="고객명"
            prop="contractorName"
            align="center"
            width="100"
          />
          <el-table-column
            label="계약번호"
            prop="contractNumber"
            align="center"
            width="150"
          >
            <template slot-scope="scope">
              <router-link
                :to="{ name: 'contract-release-detail', params: { contractNumber: scope.row.contractNumber }}"
                class="link"
              >
                {{ scope.row.contractNumber }}
              </router-link>
            </template>
          </el-table-column>
          <el-table-column
            label="레거시 진행상태"
            prop="legacyStatusName"
            align="center"
            width="120"
          />
          <el-table-column
            label="임직원몰 진행상태"
            prop="onlineStatusName"
            align="center"
          />
          <el-table-column
            label="계약일시"
            prop="contractDate"
            align="center"
            width="150"
          />
          <el-table-column
            label="출고일시"
            prop="deliveryDate"
            align="center"
            width="150"
          />
          <el-table-column
            label="구입가능일"
            prop="purchaseAvailableDate"
            align="center"
            width="150"
          />
          <el-table-column
            label="해약일"
            prop="cancelDate"
            align="center"
            width="150"
          />
          <el-table-column
            label="매출취소일"
            prop="saleCancelDate"
            align="center"
            width="150"
          />
          <el-table-column
            label="담당자"
            prop="consultantUserName"
            align="center"
            width="100"
          />
        </el-table>
        <div class="btn-wrap">
          <div class="side" />
          <div class="pagination">
            <v-pagination
              v-if="contractListData.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch"
            />
          </div>
          <div class="main" />
        </div>
      </article>
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />  
  </section>
</template>

<script>
import HTitle from '~/components/common/HTitle.vue'
import HTable from '~/components/common/HTable.vue'
import PopMessage from '~/components/popup/PopMessage.vue'
import moment from 'moment'

export default {
  name: 'Release',
  layout: 'default',
  components:{
    HTitle,
    HTable,
    PopMessage
  },
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      conpanyNum:'conpanyNum',
      searchDtRadio:'3years',
      ruleForm:{
        employeeNumber: '',
      },
      dateInfo:{
        regStartDate:moment().subtract('years',3),
        regEndDate:moment().subtract()
      },
      onerowdata:[],
      onerowHeader:[
        {
          label: '이름' ,
          type: '',
          prop: 'employeeName',
          align: 'center'
        },
        {
          label: '생년월일' ,
          type: '',
          prop: 'employeeBirthDay',
          width: 150,
          align: 'center'
        },
        {
          label: '사번' ,
          type: '',
          prop: 'employeeId',
          align: 'center'
        },
        {
          label: '소속' ,
          type: '',
          prop: 'affiliation',
          align: 'center'
        },
        {
          label: '직급' ,
          type: '',
          prop: 'position',
          align: 'center'
        },
        {
          label: '직군' ,
          type: '',
          prop: 'occupation',
          align: 'center'
        },
        {
          label: '입사일' ,
          type: '',
          prop: 'employeeDate',
          align: 'center'
        },
        {
          label: '근속DC율' ,
          type: '',
          prop: 'employeeDcRate',
          align: 'center'
        },
        {
          label: '최근구매계약번호' ,
          type: '',
          prop: 'recentContractNumber',
          align: 'center'
        },
        {
          label: '출고일' ,
          type: '',
          prop: 'deliveryDate',
          align: 'center'
        },
        {
          label: '구입가능일' ,
          type: '',
          prop: 'purchaseAvailableDate',
          align: 'center'
        }
      ],
      contractListData:[],
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      }
    }
  },
  methods:{
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    onSearch(page) {
      if(!this.isValidAuthBtn('authSelect')) { // 권한없을경우 동작 x
        return
      }

      this.$data.pageInfo.page = page
      this.getAlldata()
    },
    async getOneData(){
      if(!this.isValidAuthBtn('authSelect')) { // 권한없을경우 동작 x
        return
      }

      if(this.ruleForm.employeeNumber === ''){
        this.alertMessage = '사번을 입력해주세요.'
        this.alertMessagePop = true
      } else {
        this.ruleForm.employeeNumber = this.ruleForm.employeeNumber.trim() // 공백 제거

        const params = { ...this.ruleForm }
        // API-E-업무담당자-072 (직원상세조회)
        const [res,err] = await this.$https.post('/v1/exclusive/support/employee', params)

        if(!err) {
          if(!res.data || res.data.length===0) {
            this.onerowdata = []
            console.log('onerowdata',res.data)
          }else {
            this.onerowdata = res.data.map((el) => {
              return {
                ...el,
                employeeDate: el.employeeDate ? el.employeeDate.slice(0,4) + '-' + el .employeeDate.slice(4,6) +'-' +el.employeeDate.slice(6,8):'',
                deliveryDate: el.deliveryDate ? el.deliveryDate.slice(0,4) + '-' + el .deliveryDate.slice(4,6) +'-' +el.deliveryDate.slice(6,8):'',
              }
            })
            console.log('table: ', this.onerowdata)
          }
        }else{
          console.error(err)
          this.onerowdata = []
        }
      }
      this.getAlldata()
    },
    async getAlldata(){

      if(this.ruleForm.employeeNumber===''){
        this.alertMessage = '사번을 입력해주세요.'
        this.alertMessagePop = true
      }else if(!this.dateInfo.regStartDate||!this.dateInfo.regEndDate){
        this.alertMessage = '날짜는 필수입력 사항입니다.'
        this.alertMessagePop = true
      }
      else{

        const tempstart=moment(this.dateInfo.regStartDate)
        const tempend=moment(this.dateInfo.regEndDate)

        const daycheck = moment.duration(tempend.diff(tempstart)).asDays()

        if(daycheck<0){
          this.alertMessage = '시작 기간 및 종료 기간을 확인해주세요.'
          this.alertMessagePop = true
          return
        }

        const { page, size } = this.$data.pageInfo

        const params = {
          ...this.ruleForm,
          regStartDate: moment(this.dateInfo.regStartDate).format('YYYYMMDD'),
          regEndDate:moment(this.dateInfo.regEndDate).format('YYYYMMDD'),
          pageNo: page,
          pageSize: size
        }
        
        // API-E-업무담당자-073 (직원계약출고 목록조회)
        const [res, err] = await this.$https.post('/v1/exclusive/support/contract', params)
        console.log('params',params)

        if(!err) {
          if(!res.data.list || res.data.list.length===0) {
            this.contractListData = []
          } else {
            this.contractListData = res.data.list.map((el, idx) => {
              return {
                ...el,
                no : res.data.total - res.data.endRow + res.data.list.length - idx,
                purchaseAvailableDate:el.purchaseAvailableDate ? el.purchaseAvailableDate.slice(0,10):'',
                cancelDate:el.cancelDate ? el.cancelDate.slice(0,10):'',
                saleCancelDate:el.saleCancelDate ? el.saleCancelDate.slice(0,10):'',
              }
            })

            this.$data.pageInfo = {
              ...this.$data.pageInfo,
              total: res.data.total
            }
            console.log('table: ', this.contractListData)
          }

        } else {
          console.error(err)
          this.contractListData = []
        }

      }
    },
    onChangeSearchDtRadio(val) {
      if(val==='1year') {
        this.dateInfo.regStartDate = moment().subtract('years', 1)
        this.dateInfo.regEndDate = moment()
      } else if(val==='3years') {
        this.dateInfo.regStartDate = moment().subtract('years', 3)
        this.dateInfo.regEndDate = moment()
      } else if(val==='5years') {
        this.dateInfo.regStartDate = moment().subtract('years', 5)
        this.dateInfo.regEndDate = moment()
      } else if(val==='10years') {
        this.dateInfo.regStartDate = moment().subtract('years', 10)
        this.dateInfo.regEndDate = moment()
      }
    },
  }
}
</script>

<style lang="scss" scoped>
@import '~/assets/style/pages/support/release.scss';
</style>
