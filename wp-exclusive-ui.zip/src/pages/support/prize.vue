<template>
  <section>
    <div id="prize">
      <el-form
        ref="ruleForm"
        :model="ruleForm"
        class="detail-form"
        @submit.prevent.native
      >
        <el-row>
          <el-col :span="24">
            <el-form-item label="사번">
              <el-input
                v-model="ruleForm.employeeNumber"
                @keyup.enter.native="searchEmployee"
              />
              <el-button
                v-if="isValidAuthBtn('authSelect')"
                type="primary"
                @click="searchEmployee"
              >
                조회
              </el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <article class="article">
        <h-title :title="'조회결과'" />
        <h-table
          :table-type="'DefultTable'"
          :table-header="tableHeader"
          :table-datas.sync="employeeList"
          :handle-selection-change="handleSelectionChange"
          :handle-row-click="handleRowClick"
          :handle-current-row="handleCurrentRow"
          class="seach_result"
        />
        <div class="article-title">
          <el-radio-group
            v-model="tabPosition"
            class="tabBtn-case01"
            @change="onChangeSearchDtRadio"
          >
            <el-radio-button label="1m">
              1개월
            </el-radio-button>
            <el-radio-button label="3m">
              3개월
            </el-radio-button>
            <el-radio-button label="6m">
              6개월
            </el-radio-button>
            <el-radio-button label="12m">
              1년
            </el-radio-button>
          </el-radio-group>
          <el-date-picker v-model="ruleForm.searchStartDate" />
          <span class="ex-txt">~</span>
          <el-date-picker v-model="ruleForm.searchEndDate" />
          <el-button
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            style="margin-left: 10px;"
            @click="onSearch(1)"
          >
            조회
          </el-button>
        </div>
        <h-table
          :table-type="'DefultTable'"
          :table-header="tableHeader2"
          :table-datas.sync="promotionList"
        />
        <div class="btn-wrap">
          <div class="side" />
          <div class="pagination">
            <v-pagination
              v-if="promotionList.length"
              :page.sync="pageInfo.page"
              :size="pageInfo.size"
              :total="pageInfo.total"
              @page-change="onSearch"
            />
          </div>
          <div class="main" />
        </div>
      </article>
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import HTitle from '~/components/common/HTitle.vue'
import HTable from '~/components/common/HTable.vue'
import moment from 'moment'
import PopMessage from '~/components/popup/PopMessage.vue'

export default {
  name: 'Prize',
  layout: 'default',
  components:{
    HTitle,
    HTable,
    PopMessage
  },
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      ruleForm: {
        employeeNumber: '', // 사번(input)
        originEmployeeNumber: '', // 사번(search)
        searchStartDate: moment().subtract('months', 3), // 조회시작일자
        searchEndDate: moment() // 조회종료일자
      },
      employeeList: [], // 사번 - 검색 결과
      promotionList: [], // 판촉차 응모정보 조회
      tabPosition: '3m',
      tableHeader:[
        {
          label: '이름',
          prop: 'employeeName',
          align: 'center'
        },
        {
          label: '생년월일',
          prop: 'employeeBirthDay',
          align: 'center',
          width: '150'
        },
        {
          label: '사번',
          prop: 'employeeId',
          align: 'center'
        },
        {
          label: '부서',
          prop: 'affiliation',
          align: 'center'
        },
        {
          label: '직책',
          prop: 'position',
          align: 'center'
        },
        {
          label: '이메일',
          prop: 'employeeEmail',
          width: 300,
          align: 'center'
        },
        {
          label: '전화번호',
          prop: 'mobilePhoneNumber',
          align: 'center'
        },
        {
          label: '주소',
          prop: 'contractorAddress',
          width: 400,
          align: 'center'
        }
      ],
      tableHeader2:[
        {
          label: '이벤트명',
          prop: 'eventName',
          align: 'center',
          width: 200
        },
        {
          label: '응모기간',
          prop: 'entryPeriod',
          align: 'center',
          width: 280
        },
        {
          label: '계약/출고기간',
          prop: 'contractPossiblePeriod',
          align: 'center',
          width: 180
        },
        {
          label: '당첨발표일시',
          prop: 'winAnnouncementDate',
          align: 'center',
          width: 100
        },
        {
          label: '진행상태',
          prop: 'entryState',
          align: 'center',
          width: 80
        },
        {
          label: '순번',
          prop: 'entryOrder',
          align: 'center',
          width: 70
        },
        {
          label: '차명',
          prop: 'promotionCarName',
          align: 'center'
        },
        {
          label: '계약여부',
          prop: 'contractState',
          align: 'center',
          width: 100
        },
        {
          label: '차량위치',
          prop: 'deliveryCenterName',
          align: 'center',
          width: 100
        },
        {
          label: '생산번호',
          prop: 'carProductionNumber',
          align: 'center',
          width: 100
        }
      ],
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      }
    }
  },
  methods: {
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    async searchEmployee() { // 사번 조회
      if(!this.isValidAuthBtn('authSelect')) { // 권한없을경우 동작 x
        return
      }

      this.ruleForm.employeeNumber = this.ruleForm.employeeNumber.trim() // 공백 제거

      const { employeeNumber } = this.ruleForm

      // API-E-업무담당자-072 (직원상세조회)
      const [res, err] = await this.$https.post('/v1/exclusive/support/employee', { employeeNumber })

      if(!err) {
        this.employeeList = res.data
        this.ruleForm.originEmployeeNumber = employeeNumber
      } else {
        this.employeeList = []
        this.ruleForm.originEmployeeNumber = ''
      }

      this.onSearch(1)
    },
    onSearch(page) {
      if(!this.isValidAuthBtn('authSelect')) { // 권한없을경우 동작 x
        return
      }

      this.$data.pageInfo.page = page
      this.search()
    },
    async search() { // 조회
      if(!this.isValidAuthBtn('authSelect')) { // 권한없을경우 동작 x
        return
      }

      const { originEmployeeNumber, searchStartDate, searchEndDate } = this.ruleForm

      const { page, size } = this.$data.pageInfo

      const params = {
        employeeNumber: originEmployeeNumber,
        searchStartDate: moment(searchStartDate).format('YYYYMMDD'),
        searchEndDate: moment(searchEndDate).format('YYYYMMDD'),
        pageNo: page,
        pageSize: size
      }

      if(!originEmployeeNumber) {
        this.alertMessage = '사번을 확인해주세요.'
        this.alertMessagePop = true
        return
      }

      const [res, err] = await this.$https.get('/v1/exclusive/support/promotion', params)

      if(!err) {
        if(!res.data || !res.data.list || res.data.list.length===0) {
          this.promotionList = []
        } else {
          this.promotionList = res.data.list

          this.$data.pageInfo = {
            ...this.$data.pageInfo,
            total: res.data.total
          }
        }
      }
    },
    onChangeSearchDtRadio(val) {
      console.log(val)
      switch(val) {
      case '1m': // 1개월
        this.ruleForm.searchStartDate = moment().subtract('months', 1)
        this.ruleForm.searchEndDate = moment()
        break
      case '3m': // 3개월(default)
        this.ruleForm.searchStartDate = moment().subtract('months', 3)
        this.ruleForm.searchEndDate = moment()
        break
      case '6m': // 6개월
        this.ruleForm.searchStartDate = moment().subtract('months', 6)
        this.ruleForm.searchEndDate = moment()
        break
      case '12m': // 1년
        this.ruleForm.searchStartDate = moment().subtract('years', 1)
        this.ruleForm.searchEndDate = moment()
        break
      }
    },
    handleSelectionChange(e) { // row click
      console.log(e)
    },
    handleRowClick() {

    },
    handleCurrentRow(e) {
      console.log(e)
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~/assets/style/pages/support/prize.scss';
</style>
