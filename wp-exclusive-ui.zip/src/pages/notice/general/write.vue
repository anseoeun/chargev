<template>
  <section>
    <div id="generalWrite">
      <div class="btn-wrap">
        <div class="side">
          <el-button type="info">
            초기화
          </el-button>
        </div>
        <div
          class="main"
          style="width: 100%"
        >
          <el-button type="info">
            취소
          </el-button>
          <el-button type="primary">
            등록
          </el-button>
          <el-button type="primary">
            목록
          </el-button>
        </div>
      </div>
      <el-form
        ref="notice"
        :model="notice"
        class="detail-form"
      >
        <el-row>
          <el-col :span="24">
            <el-form-item label="제목">
              <el-input v-model="notice.title" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="우선순위">
              <el-select
                v-model="notice.rank"
                placeholder="전체"
              >
                <el-option
                  v-for="{ value, label } in code.rank"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="게시여부">
              <el-select
                v-model="notice.exposure"
                placeholder="공게"
              >
                <el-option
                  v-for="{ value, label } in code.exposure"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="등록자">
              {{ notice.name }}
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="16">
            <el-form-item label="게시 기간">
              <el-date-picker v-model="notice.postdate01" />
              <span class="ex-txt">~</span>
              <el-date-picker v-model="notice.postdate02" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="등록 일시">
              {{ notice.date }}
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="내용">
              <div>
                <el-input
                  v-model="notice.content"
                  type="textarea"
                />
              </div>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="첨부파일">
              <el-button
                v-model="notice.file"
                type="primary"
              >
                추가
              </el-button>
              <span
                class="ex-txt"
                style="margin-left: 10px;"
              >{{ notice.note }}</span>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
  </section>
</template>

<script>
export default {
  name:'GeneralWrite',
  layout: 'default',
  data(){
    return{
      notice:{
        title: '2019년 신차 구입 시 고객혜택 관련하여 공지합니다.',
        rank: {},
        exposure:{},
        name: '업무담당자 관리자',
        postdate01: null,
        postdate02: null,
        date: '2019-01-05 12:12',
        content: '2019년 신차 구입 시 고객혜택 관련하여 공지합니다. \n\n\n★ 전시차 할인 : 20만원, 12월 이전 전시차 40만원 + 월별 재고할인 적용되었습니다. \n★ 한정재고 할인 : (차종 별 몇% 할인) (차종 별 월별 금액할인 적용) 조건표 참조 \n★ 여기에 그룹사 할인 : 5% 추가 하시면 됩니다. \n★ 여기에 7년경과 노후차 보유 시 : 30~40만원 추가할인 됩니다. \n★ 여기에 현대카드 세이브 오토 : 20~50만원 할인 적용하면 됩니다.',
        file: null,
        note: '* 첨부파일은 7MB를 초과할 수 없습니다.'
      },
      code:{
        rank: [
          {value: 'rank01', label: '일반공지'}, 
          {value: 'rank02', label: '중요공지'}
        ],
        exposure:[
          {value: 'Y', label:'공개'},
          {value: 'N', label:'비공개'}
        ]
      }
    }
  }
}
</script>

<style lang="scss" scoped>
#generalWrite{
  .btn-wrap{
    padding-bottom: 20px;
  }
  .el-textarea__inner{
    height: 320px;
  }
}
</style>

