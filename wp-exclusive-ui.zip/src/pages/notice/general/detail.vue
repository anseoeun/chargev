<template>
  <section>
    <div id="generalDetail">
      <div class="btn-wrap">
        <div class="side" />
        <div class="main">
          <el-button type="primary">
            목록
          </el-button>
        </div>
      </div>
      <el-form
        ref="notice"
        :model="motice"
        class="detail-form"
      >
        <el-row>
          <el-col :span="24">
            <el-form-item label="제목">
              {{ notice.title }}
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="16">
            <el-form-item label="우선순위">
              {{ notice.rank }}
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="등록자">
              {{ notice.name }}
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="16">
            <el-form-item label="게시 기간">
              {{ notice.postdate }}
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="등록 일시">
              {{ notice.date }}
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="내용">
              <div style="height: 320px;">
                {{ notice.content }}
              </div>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="첨부파일">
              <i class="file_img" /> {{ notice.file }}
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
  </section>
</template>

<script>
export default {
  name:'GeneralDetail',
  layout: 'default',
  data(){
    return{
      notice:{
        title: '2019년 신차 구입 시 고객혜택 관련하여 공지합니다.',
        rank: '일반공지',
        name: '업무담당자 관리자',
        postdate: '2019-04-01 ~ 2019-04-01',
        date: '2019-01-05 12:12',
        content: '2019년 신차 구입 시 고객혜택 관련하여 공지합니다. \n★ 전시차 할인 : 20만원, 12월 이전 전시차 40만원 + 월별 재고할인 적용되었습니다. \n★ 한정재고 할인 : (차종 별 몇% 할인) (차종 별 월별 금액할인 적용) 조건표 참조 \n★ 여기에 그룹사 할인 : 5% 추가 하시면 됩니다. \n★ 여기에 7년경과 노후차 보유 시 : 30~40만원 추가할인 됩니다. \n★ 여기에 현대카드 세이브 오토 : 20~50만원 할인 적용하면 됩니다.',
        file: '신차구입고객혜택.pdf'
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~/assets/style/pages/notice.scss';
</style>

