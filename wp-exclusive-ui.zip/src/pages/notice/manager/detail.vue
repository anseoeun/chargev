<template>
  <section>
    <div id="managerDetail">
      <div class="btn-wrap">
        <div class="side"></div>
        <div
          class="main"
          style="width: 100%;"
        >
          <el-button 
            v-if="isValidAuthBtn('authManage')"
            type="info"
            @click="deleteNotice"
          >
            삭제
          </el-button>
          <el-button 
            v-if="isValidAuthBtn('authManage')"
            type="primary"
            @click="goEdit"
          >
            수정
          </el-button>
          <el-button 
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            @click="goList"
          >
            목록
          </el-button>
        </div>
      </div>
      <el-form
        ref="noticeForm"
        :model="noticeForm"
        class="detail-form"
      >
        <el-row>
          <el-col :span="24">
            <el-form-item label="제목">
              {{ noticeForm.noticeTitle }}
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="16">
            <el-form-item label="우선순위">
              {{ noticeForm.noticeGrade }}
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="등록자">
              {{ noticeForm.userName }}
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="16">
            <el-form-item label="게시 기간">
              {{ noticeForm.noticeStartDt + " ~ " + noticeForm.noticeEndtDt }}
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="등록 일시">
              {{ noticeForm.regDate }}
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="내용">
              <div style="height: 320px; white-space: pre-line;">
                <!--
                -->{{ noticeForm.noticeContents }}
                <!---->
              </div>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item 
              v-if="noticeForm.fileGroupSerialNumber" 
              label="첨부파일"
            >
              <span
                style="cursor: pointer; color: #1a0dab;"
                @click="fileDown"
              >
                <i class="file_img"></i> {{ fileData ? fileData[0].fileName : '' }}
              </span>
            </el-form-item>
            <el-form-item 
              v-else
              label="첨부파일"
            />
          </el-col>
        </el-row>
      </el-form>
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import { mapGetters } from 'vuex'
import moment from 'moment'
import PopMessage from '~/components/popup/PopMessage.vue'

export default {
  name:'ManagerDetail',
  layout: 'default',
  preserveWhitespace: false,
  components: {
    PopMessage
  },
  data(){
    return {
      alertMessage: '',
      alertMessagePop: false,
      fileData: null,
      noticeForm: {}
    }
  },
  computed: {
    ...mapGetters(['userInfo'])
  },
  mounted() {
    this.noticeSerialNumber = this.$route.params.noticeSerialNumber
    if(!this.noticeSerialNumber)
      this.noticeSerialNumber = this.$route.query.noticeSerialNumber

    this.$store.dispatch('loadUserInfo', { vm: this})
    if(this.noticeSerialNumber) {
      this.getData(this.noticeSerialNumber)
    } 
  },
  methods: {
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    goList() { // 목록
      // location.hash = '/notice/manager'
      this.$router.push('/notice/manager')
    },
    goEdit() { // 수정
      if(!this.noticeSerialNumber) return
      // location.hash = '/notice/manager/_id?noticeSerialNumber=' + this.noticeSerialNumber
      this.$router.push('/notice/manager/_id?noticeSerialNumber=' + this.noticeSerialNumber)
    },
    async getData(serialNumber) {
      if(!serialNumber) return

      const [res, err] = await this.$https.get('/v2/exclusive/notice/' + serialNumber) // API-E-업무담당자-085 (공지사항 상세 조회)
      if(!err) {
        console.log('/notice', res.data)
        this.noticeForm = {
          ...res.data,
          noticeStartDt: moment(res.data.noticeStartDt).format('YYYY-MM-DD'),
          noticeEndtDt: moment(res.data.noticeEndtDt).format('YYYY-MM-DD')
        }
        if(res.data.fileGroupSerialNumber) {
          this.getFileData(res.data.fileGroupSerialNumber)
        }
        this.$store.dispatch('loadUnConfirmInfo', {vm: this})
      } else {
        console.error(err)
      }
    },
    async deleteNotice() {
      if(!this.noticeSerialNumber) return

      const params = { 'noticeSerialNumber': this.noticeSerialNumber }
      const [res, err] = await this.$https.delete('/v1/exclusive/notice', null, params)

      if(!err) {
        console.log(res)
        this.alertMessage = '삭제되었습니다.'
        this.alertMessagePop = true
        this.$store.dispatch('loadUnConfirmInfo', {vm: this})
        this.goList()
      }
    },
    async getFileData(fileSeq) {  // 첨부파일 조회
      const [res, err] = await this.$https.get('common/v1/common/file/inquiry/no-path/' + fileSeq, null, null, 'gateway')

      if(!err) {
        this.fileData = res.data
      }
    },
    async fileDown() { // 첨부파일 다운로드
      const { fileSn, fileGroupSn, fileName, fileExtentions } = this.fileData[0]
      const [res, err] = await this.$https.getb('common/v1/common/file/download/'+ fileGroupSn  + '/' + fileSn, null, null, 'gateway')

      if(!err) {
        const blob = new Blob([res], {type : fileExtentions })
        if(window.navigator.msSaveOrOpenBlob) {
          // IE11
          window.navigator.msSaveOrOpenBlob(blob, fileName) 
        } else {            
          // IE11 외 브라우저
          const blobURL = window.URL.createObjectURL(blob)
          const tempLink = document.createElement('a')
          
          tempLink.href = blobURL        
                
          tempLink.setAttribute('download', fileName)
          document.body.appendChild(tempLink)        
          tempLink.click()
          document.body.removeChild(tempLink)        
          window.URL.revokeObjectURL(blobURL)
        }       
        console.log(res)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~/assets/style/pages/notice.scss';
</style>

