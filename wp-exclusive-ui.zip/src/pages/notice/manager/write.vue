<template>
  <section>
    <div id="managerWrite">
      <div class="btn-wrap">
        <div class="side">
          <el-button 
            type="info"
            @click="initForm"
          >
            초기화
          </el-button>
        </div>
        <div
          class="main"
          style="width: 100%"
        >
          <el-button 
            type="info"
            @click="goList"
          >
            취소
          </el-button>
          <el-button 
            v-if="isValidAuthBtn('authManage')"
            type="primary"
            @click="formSubmit"
          >
            저장
          </el-button>
          <el-button 
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            @click="goList"
          >
            목록
          </el-button>
        </div>
      </div>
      <el-form
        ref="noticeForm"
        :model="noticeForm"
        class="detail-form"
      >
        <el-row>
          <el-col :span="24">
            <el-form-item label="제목">
              <el-input v-model="noticeForm.noticeTitle" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="우선순위">
              <el-select
                v-model="noticeForm.noticeGradeCode"
                placeholder="전체"
              >
                <el-option
                  v-for="{ value, label } in code.rank"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="게시여부">
              <el-select
                v-model="noticeForm.noticeYn"
                placeholder="공개"
              >
                <el-option
                  v-for="{ value, label } in code.exposure"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="등록자">
              {{ userInfo.eeNm }}
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="16">
            <el-form-item label="게시 기간">
              <el-date-picker v-model="noticeForm.noticeStartDt" />
              <span class="ex-txt">~</span>
              <el-date-picker v-model="noticeForm.noticeEndtDt" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="등록 일시">
              {{ noticeForm.regDate }}
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="내용">
              <div>
                <el-input
                  v-model="noticeForm.noticeContents"
                  type="textarea"
                />
              </div>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="첨부파일">
              <el-upload
                ref="upload"            
                accept=".png, .jpg, .jpeg, .gif, .bmp, .doc, .docx, .ppt, .pdf, .xls, .xlsx"
                action=""
                :auto-upload="false"
                :multiple="false" 
                :limit="1"
                :on-change="handleChange"
              >
                <el-button
                  v-if="isValidAuthBtn('authManage')"
                  slot="trigger"
                  type="primary"
                >
                  추가
                </el-button>
                <span
                  class="ex-txt"
                  style="margin-left: 10px;"
                >
                  {{ noticeForm.note }}
                </span>
              </el-upload>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import { mapGetters } from 'vuex'
import moment from 'moment'
import PopMessage from '~/components/popup/PopMessage.vue'

export default {
  name:'ManagerWrite',
  layout: 'default',
  components: {
    PopMessage
  },
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      noticeForm: {
        noticeTitle: '',
        noticeContents: '',
        noticeStartDt: moment(),
        noticeEndtDt: moment(),
        noticeYn: 'Y',
        noticeGradeCode: 'B', // 일반
        noticeGrade: '',
        userId: '',
        userName: '',
        regDate: '',
        fileGroupSerialNumber: null,
        note: '* 첨부파일은 7MB를 초과할 수 없습니다.'
      },
      code:{
        rank: [
          {value: 'A', label: '중요공지'}, 
          {value: 'B', label: '일반공지'} 
        ],
        exposure:[
          {value: 'Y', label:'공개'},
          {value: 'N', label:'비공개'}
        ]
      }
    }
  },
  computed: {
    ...mapGetters(['userInfo'])
  },
  mounted() {
    this.$store.dispatch('loadUserInfo', { vm: this})
  },
  methods: {
    async handleChange(file) {
      if(file) {
        const allowedTypes = ['image/jpg', 'image/jpeg', 'image/png', 'image/gif', 'application/pdf', 'application/ppt', 'application/msword', 'application/excel'] // 허용 가능한 파일
        let formData = new FormData()
        if (allowedTypes.includes(file.raw.type)) {
          formData.append('file', file.raw)
          formData.append('fileBizTypeCode', '003')
          formData.append('privateYn', 'N')
          formData.append('customerNumber', this.userInfo.eeno)

          const [res, err] = await this.$https.postMultiPart('common/v1/common/file/upload/files', formData, null, 'gateway') // API-E-공통서비스-004_파일 업로드 
          
          if(!err) {
            this.noticeForm.fileGroupSerialNumber = res.data.fileGroupSn || ''
          }
        } else {
          this.$refs.upload.clearFiles() // 파일 초기화
          this.alertMessage = '허용되지 않는 확장자입니다.'
          this.alertMessagePop = true
        }
      }
    },
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    goList() { // 목록
      // location.hash = '/notice/manager'
      this.$router.push('/notice/manager')
    },
    initForm() { // 초기화
      Object.assign(this.$data.noticeForm, this.$options.data().noticeForm)
      this.$refs.upload.clearFiles() // 파일 초기화
    },
    async formSubmit() { // 등록
      if(!this.isValidAuthBtn('authManage')) { // 권한없을경우 동작 x
        return
      }

      if([this.noticeForm.noticeStartDt, this.noticeForm.noticeEndtDt].includes(null)) {
        this.alertMessage = '게시기간을 확인해주세요.'
        this.alertMessagePop = true
        return
      }
      
      if(moment(this.noticeForm.noticeStartDt).diff(moment(this.noticeForm.noticeEndtDt)) > 0) {
        this.alertMessage = '시작일은 종료일보다 클수 없습니다.'
        this.alertMessagePop = true
        return false
      }

      const data = {
        ...this.noticeForm,
        noticeStartDt: moment(this.noticeForm.noticeStartDt).format('YYYYMMDD'),
        noticeEndtDt: moment(this.noticeForm.noticeEndtDt).format('YYYYMMDD'),
        noticeSerialNumber: null// 공지사항 일련번호(null ==> 등록, !null ==> 수정)
      }

      const [res, err] = await this.$https.post('/v1/exclusive/notice', data) // API-E-업무담당자-086 (공지사항 정보 저장)

      if(!err) {
        console.log(res)
        this.alertMessage = '등록되었습니다.'
        this.alertMessagePop = true
        this.$store.dispatch('loadUnConfirmInfo', {vm: this})
        this.goList()
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~/assets/style/pages/notice.scss';
</style>
