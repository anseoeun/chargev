<template>
  <section>
    <div id="period">
      content
    </div>
  </section>
</template>

<script>
export default {
  name: 'Period',
  layout: 'default',
  data() {
    return {}
  }
}
</script>

