<template>
  <section>
    <div id="work-time">
      <div class="btn-wrap">
        <div class="side">
          <el-button
            type="info"
            @click="resetForm"
          >
            초기화
          </el-button>
        </div>
        <div class="main">
          <el-button
            v-if="isValidAuthBtn('authManage')"
            type="primary"
            @click="onSave"
          >
            저장
          </el-button>
        </div>
      </div>
      <el-form
        :ref="ruleForm"
        :model="ruleForm"
        class="detail-form"
      >
        <el-row>
          <el-col :span="24">
            <el-form-item label="근무시간 설정">
              <el-date-picker v-model="ruleForm.dateStart" />
              <el-time-select
                v-model="ruleForm.timeStart"
                :picker-options="{
                  start: '00:00',
                  step: '00:30',
                  end: '23:30'
                }"
              />
              <span class="ex-txt"> ~ </span>
              <el-time-select
                v-model="ruleForm.timeEnd"
                :picker-options="{
                  start: '00:00',
                  step: '00:30',
                  end: '23:30',
                  minTime: ruleForm.timeStart
                }"
              />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="board-wrap">
        <el-table
          :data="tableData"
          max-height="450"
        >
          <el-table-column
            label="NO."
            prop="no"
            align="center"
          />
          <el-table-column label="Work Time">
            <el-table-column
              label="적용일"
              prop="applicationStartDate"
              align="center"
            />
            <el-table-column
              label="시작시간"
              prop="exclusiveWorkStartTime"
              align="center"
            />
            <el-table-column
              label="종료시간"
              prop="exclusiveWorkEndTime"
              align="center"
            />
          </el-table-column>
          <el-table-column
            label="변경일시"
            prop="updDate"
            align="center"
          />
          <el-table-column
            label="변경자"
            prop="updName"
            align="center"
          />
          <el-table-column
            label="비고"
            prop="deletable"
            align="center"
          >
            <template slot-scope="scope">
              <el-button
                v-if="scope.row.deletable === true"
                type="primary"
                @click="deleteRow(scope.row)"
              >
                삭제
              </el-button>
              <span v-else>-</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />  
  </section>
</template>

<script>
import { mapGetters } from 'vuex'
import PopMessage from '~/components/popup/PopMessage.vue'

export default {
  name: 'WorkTime',
  layout: 'default',
  components: {
    PopMessage
  },
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      ruleForm:{
        dateStart:null,
        dateEnd :null,
        timeStart:null,
        timeEnd:null
      },
      tableData: []
    }
  },
  computed: {
    ...mapGetters(['userInfo'])
  },
  created() {
    this.getData()
  },
  mounted () {
    this.$store.dispatch('loadUserInfo', { vm: this})
  },
  methods: {
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    async getData() {
      const [res,err] = await this.$https.get('/v1/exclusive/setting/work-time')
      if(!err) {
        this.tableData = res.data.list && res.data.list.map((el, idx, ary) => { 
          return {
            ...el, 
            no : ary.length - idx,
            applicationStartDate : this.$moment(el.applicationStartDate).format('YYYY-MM-DD'),
            exclusiveWorkStartTime : el.exclusiveWorkStartTime && (el.exclusiveWorkStartTime.slice(0, 2) + ':' + el.exclusiveWorkStartTime.slice(2)),
            exclusiveWorkEndTime : el.exclusiveWorkEndTime && (el.exclusiveWorkEndTime.slice(0, 2) + ':' + el.exclusiveWorkEndTime.slice(2)),
            deletable: (this.$moment(el.applicationStartDate).diff(this.$moment(), 'days') > 0)
          } 
        })
        console.log('/setting/work-time', this.tableData)
      } else {
        console.error(err)
      }
    },
    resetForm() {
      Object.assign(this.ruleForm, this.$options.data().ruleForm)
    },
    async onSave() {
      if(!this.ruleForm.dateStart) {
        this.alertMessage = '날짜를 설정해주세요.'
        this.alertMessagePop = true
        return
      } else if(!this.ruleForm.timeStart || !this.ruleForm.timeEnd) {
        this.alertMessage = '시간을 설정해주세요.'
        this.alertMessagePop = true
        return
      } else if(this.ruleForm.timeStart > this.ruleForm.timeEnd) {
        this.alertMessage = '시간을 바르게 설정해주세요.'
        this.alertMessagePop = true
        return
      }

      // API-E-업무담당자-095 (업무담당자 Working Time 저장)
      const [res,err] = await this.$https.post('/v1/exclusive/setting/work-time', {  
        applicationStartDate : this.$moment(this.ruleForm.dateStart).format('YYYYMMDD'),
        applicationEndtDate : this.$moment(this.ruleForm.dateStart).format('YYYYMMDD'),
        exclusiveWorkStartTime : this.ruleForm.timeStart.split(':').join(''),
        exclusiveWorkEndTime : this.ruleForm.timeEnd.split(':').join('')
      })
      if(!err) {
        this.alertMessage = '저장되었습니다.'
        this.alertMessagePop = true
        this.getData()
        console.log('/setting/work-time', res)
      } else {
        console.error(err)
      }
    },
    async deleteRow(row) {
      if(!row.deletable) return
      console.log(row)
      const param = { workTimeSetNumber : row.workTimeSetNumber, applicationStartDate : row.applicationStartDate.split('-').join('') }
      const [res,err] = await this.$https.delete('/v1/exclusive/setting/work-time', null, param)
      if(!err) {
        this.alertMessage = '삭제되었습니다.'
        this.alertMessagePop = true
        this.getData()
        console.log('/setting/work-time', res)
      } else {
        console.error(err)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~/assets/style/pages/set/work-time.scss';
</style>