<template>
  <section>
    <div id="absence-resume">
      <div class="btn-wrap">
        <div class="side">
          <el-button
            type="info"
            @click="resetSearchCond"
          >
            초기화
          </el-button>
        </div>
        <div class="main">
          <el-button
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            @click="getData"
          >
            조회
          </el-button>
          <template
            v-if="isValidAuthBtn('authExclusive')"
          >
            <el-button
              v-if="singleSelection.length !== 0"
              type="primary"
              @click="openAbsencePop"
            >
              부재 수정
            </el-button>
            <el-button
              v-else
              type="primary"
              @click="openAbsencePop"
            >
              부재 설정
            </el-button>
          </template>
          <el-button
            v-if="isValidAuthBtn('authExclusive')"
            type="primary"
            @click="checkDelete"
          >
            삭제
          </el-button>
        </div>
      </div>
      <el-form
        :ref="ruleForm"
        :model="ruleForm"
        class="detail-form"
      >
        <el-row>
          <el-col :span="24">
            <el-form-item label="기간">
              <span class="ex-txt">시작 </span>
              <el-date-picker v-model="ruleForm.dateStart" />
              <!-- <el-time-picker
                v-model="ruleForm.timeStart"
                format="HH:mm"
              /> -->
              <span class="ex-txt">~</span>
              <span class="ex-txt">종료 </span>
              <el-date-picker v-model="ruleForm.dateEnd" />
              <!-- <el-time-picker
                v-model="ruleForm.timeEnd"
                format="HH:mm"
              /> -->
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="대상">
              <el-select
                v-model="ruleForm.consultantId"
                placeholder="업무담당자"
              >
                <el-option
                  v-for="{ sysUserNo, sysUserNm } in consultants"
                  :key="sysUserNo"
                  :value="sysUserNo"
                  :label="sysUserNm"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="board-wrap">
        <h-table
          ref="multipleTable"
          :table-type="'TwoHeadTable'"
          :table-header="tableHeader"
          :table-datas="tableData"
          :handle-change="handleChangeCheckBox"
        />
      </div>
      <!-- 부재설정 팝업 -->
      <el-dialog
        title="부재설정"
        :visible.sync="popAbsenceVisible"
        width="1000px"
      >
        <!-- Popup Contents -->
        <div class="board-wrap">
          <el-form
            :ref="ruleFormPop"
            :model="ruleFormPop"
            class="detail-form"
          >
            <el-row
              v-if="this.userInfo.exclusiveUseAuthGroupId == 'M0002'&& !this.singleSelection[0]"
            >
              <el-col :span="24">
                <el-form-item label="대상">
                  <el-select
                    v-model="ruleFormPop.consultantId"
                    placeholder="업무담당자"
                  >
                    <el-option
                      v-for="{ sysUserNo, sysUserNm } in consultants"
                      :key="sysUserNo"
                      :value="sysUserNo"
                      :label="sysUserNm"
                    />
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item label="기간 및 시간">
                  <div class="periodPop">
                    <span class="ex-txt">시작 </span>
                    <el-date-picker v-model="ruleFormPop.dateStart" />
                    <!-- <el-time-picker
                      v-model="ruleFormPop.dateStart"
                      format="HH:mm"
                    /> -->
                    <el-time-select
                      v-model="ruleFormPop.timeStart"
                      :picker-options="{
                        start: '00:00',
                        step: '00:30',
                        end: '23:30'
                      }"
                    />
                  </div>
                  <div class="periodPop">
                    <span class="ex-txt">종료 </span>
                    <el-date-picker v-model="ruleFormPop.dateEnd" />
                    <el-time-select
                      v-model="ruleFormPop.timeEnd"
                      :picker-options="{
                        start: '00:00',
                        step: '00:30',
                        end: '23:30'
                      }"
                    />
                  </div>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="info"
            @click="popAbsenceVisible = false"
          >
            취소
          </el-button>
          <el-button
            type="primary"
            @click="saveAbsence"
          >
            확인
          </el-button>
        </template>
      </el-dialog>

      <!-- 부재 삭제 확인 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="checkDeletePop"
      >
        <!-- Message -->
        해당 부재를 삭제하시겠습니까?

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="info"
            @click="checkDeletePop = false"
          >
            아니요
          </el-button>
          <el-button
            type="primary"
            @click="deleteData"
          >
            예
          </el-button>
        </template>
      </el-dialog>
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import HTable from '~/components/common/HTable.vue'
import { mapState } from 'vuex'
import moment from 'moment'
import PopMessage from '~/components/popup/PopMessage.vue'

export default {
  name: 'AbsenceResume',
  layout: 'default',
  components: {
    HTable,
    PopMessage
  },
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      checkDeletePop: false,
      singleSelection: [], // 선택된 실데이터
      popAbsenceVisible:false,
      ruleForm:{
        dateStart: moment(),
        timeStart: moment().hour(9).minute(0),
        dateEnd: moment(),
        timeEnd: moment().hour(18).minute(0),
        consultantId: '',
        consultantNm: ''
      },
      ruleFormPop:{
        dateStart: moment(),
        timeStart: '00:00',
        dateEnd: moment(),
        timeEnd: '23:30',
        consultantId: '',
        consultantNm: ''
      },
      tableHeader:[
        {
          label: '선택',
          prop: 'no',
          width: 100,
          align: 'center',
          type:'checkBox',
          children: [],
        },
        {
          label : '업무담당자',
          prop: 'exclusiveUserName',
          align: 'center',
          children: []
        },
        {
          label : '사번',
          prop: 'exclusiveUserId',
          align: 'center',
          children: []
        },
        {
          label : '부재기간',
          prop: '',
          align: 'center',
          children: [
            {
              label: '시작',
              prop: 'absenceStartDate',
              align: 'center'
            },
            {
              label: '종료',
              prop: 'absenceEndDate',
              align: 'center'
            }
          ]
        }
      ],
      tableData:[]
    }
  },
  computed: {
    ...mapState({
      userInfo: state => state.userInfo
    }),
    consultants: function() {
      const consultants = this.$store.state.consultants.slice()
      if(consultants && consultants.length > 0) {
        consultants.unshift( { 'useAuthId': '', 'sysUserNo': '', 'sysUserNm': '전체', 'opsNm': '' } )
      }
      return consultants
    }
  },
  mounted() {
    this.$store.dispatch('loadUserInfo', { vm: this})
    this.$store.dispatch('loadConsultants', {vm: this})

    // if(this.userInfo.exclusiveUseAuthGroupId === 'M0001') { // 일반 업무담당자 일경우 default(자신)
    //   this.tableHeader[0].label='No.'
    //   this.tableHeader[0].type=''
    // }
  },
  methods: {
    handleChangeCheckBox($event, row) {
      this.tableData.filter((items) => { return items.no !== row.no }).map((items) => { items.isSelected = false })
      this.singleSelection = this.tableData.filter((items) => {return items.isSelected === true})
    },
    resetSearchCond() {
      Object.assign(this.ruleForm, this.$options.data().ruleForm)
      this.singleSelection=[]
      this.tableData= []
    },
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    async getData() {
      const params = {
        pageNo: 1,
        pageSize: 999,
        absenceStartDate: moment(this.ruleForm.dateStart).format('YYYYMMDD'),
        absenceEndDate: moment(this.ruleForm.dateEnd).format('YYYYMMDD'),
        userAuthorityGroupId: this.userInfo.exclusiveUseAuthGroupId, // 시스템사용자 구분코드( M0001: 업무담당자, M0002: 업무담당자 관리자 )
        exclusiveUserId: this.ruleForm.consultantId,
        exclusiveUserName: this.ruleForm.consultantNm
      }

      const [res,err] = await this.$https.get('/v1/exclusive/setting/absence-history', params) // API-E-업무담당자-089(부재 설정 처리)
      console.log(res, err)
      if(!err) {
        if(!res.data || !res.data.list || res.data.list.length===0) {
          this.tableData = []
        } else {
          this.tableData = res.data.list.map((el, idx) => {
            return {
              ...el,
              no : idx+1,
              isSelected:false,
              absenceStartDate: el.absenceStartDate ? moment(el.absenceStartDate, 'YYYYMMDDHHmm').format('YYYY-MM-DD HH:mm') : '',
              absenceEndDate: el.absenceEndDate ? moment(el.absenceEndDate, 'YYYYMMDDHHmm').format('YYYY-MM-DD HH:mm') : ''
            }
          })
        }
        console.log('/setting/absence-history', this.tableData)
      } else {
        console.error(err)
        this.tableData = []
      }

      this.singleSelection=[]
    },
    openAbsencePop() {

      if(this.singleSelection.length === 0){
        Object.assign(this.ruleFormPop, this.$options.data().ruleFormPop)
      }else{ // 선택한 항목이 있을경우
        const { absenceStartDate, absenceEndDate } = this.singleSelection[0]

        const [dateStart, timeStart] = absenceStartDate.split(' ')
        const [dateEnd, timeEnd] = absenceEndDate.split(' ')

        this.ruleFormPop.dateStart = moment(dateStart)
        this.ruleFormPop.dateEnd = moment(dateEnd)
        this.ruleFormPop.timeStart = timeStart
        this.ruleFormPop.timeEnd = timeEnd
      }

      this.popAbsenceVisible = true
    },
    async saveAbsence() {
      // 시작 시간 ~ 종료 시간 validation
      const sDate = moment(moment(this.ruleFormPop.dateStart).format('YYYYMMDD') + this.ruleFormPop.timeStart || '00:00', 'YYYYMMDDHH:mm')
      const eDate = moment(moment(this.ruleFormPop.dateEnd).format('YYYYMMDD') + this.ruleFormPop.timeEnd || '00:00', 'YYYYMMDDHH:mm')

      const diffDate = moment.duration(eDate.diff(sDate)).asMinutes()

      if(diffDate <= 0) {
        this.alertMessage = '시작 기간 및 종료 기간을 확인해주세요.'
        this.alertMessagePop = true
        return false
      }

      const body = {
        exclusiveUserId: this.singleSelection[0] ? this.singleSelection[0].exclusiveUserId : this.ruleFormPop.consultantId , //※업무담당자사원번호 값이  NULL인 경우 등록, NOT NULL인 경우 수정
        exclusiveAbsenceNumber: this.singleSelection[0] ? this.singleSelection[0].exclusiveAbsenceNumber : '', //※업무담당자부재일련번호 값이  NULL인 경우 등록, NOT NULL인 경우 수정
        absenceStartDate: moment(this.ruleFormPop.dateStart).format('YYYYMMDD')+(this.ruleFormPop.timeStart).split(':').join(''),
        absenceEndDate: moment(this.ruleFormPop.dateEnd).format('YYYYMMDD')+(this.ruleFormPop.timeEnd).split(':').join('')
      }

        if(this.singleSelection[0] && this.userInfo.exclusiveUseAuthGroupId=='M0001' && body.exclusiveUserId!==this.userInfo.userId){
            this.alertMessage = '본인부재만 수정가능합니다.'
            this.alertMessagePop = true
            return false
        }

      const [res, err] = await this.$https.put('v1/exclusive/setting/absence', body)
      if(!err) {
        console.log(res)

        if(this.singleSelection.length===0){
          this.alertMessage = '부재설정 되었습니다.'
          this.alertMessagePop = true
        } else {
          this.alertMessage = '부재수정 되었습니다.'
          this.alertMessagePop = true
        }


        this.getData()
        this.popAbsenceVisible = false
      } else {
        this.alertMessage = err.rspMessage || '시스템 오류 입니다.\n관리자에게 문의하세요.'
        this.alertMessagePop = true
        console.error(err)
      }
    },
    checkDelete(){
      if (this.singleSelection.length === 0) {
        this.alertMessage = '삭제 대상건을 선택해주세요.'
        this.alertMessagePop = true
        return false
      }else{
        this.checkDeletePop=true
      }
    },
    async deleteData() {

      const body = {
        exclusiveUserId: this.singleSelection[0] ? this.singleSelection[0].exclusiveUserId : '' ,
        exclusiveAbsenceNumber: this.singleSelection[0] ? this.singleSelection[0].exclusiveAbsenceNumber : ''
      }

        if(this.userInfo.exclusiveUseAuthGroupId=='M0001' && body.exclusiveUserId!==this.userInfo.userId){
            this.alertMessage = '본인부재만 삭제가능합니다.'
            this.alertMessagePop = true
            return false
        }

      const [res, err] = await this.$https.delete('v1/exclusive/setting/absence', body, null)
      if(!err) {
        console.log(res)
        this.alertMessage = '부재항목이 삭제되었습니다'
        this.alertMessagePop = true

        this.getData()
        this.checkDeletePop = false
      } else {
        this.alertMessage = err.rspMessage || '시스템 오류 입니다.\n관리자에게 문의하세요.'
        this.alertMessagePop = true
        console.error(err)
      }

    }
  }
}
</script>

<style lang="scss" scoped>
@import '~/assets/style/pages/set/absence-resume.scss';
</style>

