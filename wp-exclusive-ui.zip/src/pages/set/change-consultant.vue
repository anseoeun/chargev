<template>
  <section>
    <div id="change-consultant">
      <div class="btn-wrap">
        <div class="side">
          <el-button
            type="info"
            @click="resetSearchCond"
          >
            초기화
          </el-button>
        </div>

        <div class="main">
          <el-button
            v-if="isValidAuthBtn('authSelect')"
            type="primary"
            @click="onSearch(1)"
          >
            조회
          </el-button>
          <el-button
            v-if="isValidAuthBtn('authManage')"
            type="primary"
            @click="openModifyPopup"
          >
            변경
          </el-button>
        </div>
      </div>
      <el-form
        ref="ruleForm"
        :model="ruleForm"
        class="detail-form"
      >
        <el-row>
          <el-col :span="24">
            <el-form-item
              label="기간"
              required
            >
              <el-date-picker
                v-model="ruleForm.allocationStartDate"
                type="date"
              />
              <span class="ex-txt"> ~ </span>
              <el-date-picker
                v-model="ruleForm.allocationEndDate"
                type="date"
              />
              <el-radio-group
                v-model="searchDtRadio"
                class="tabBtn-case01"
                @change="onChangeSearchDtRadio"
              >
                <el-radio-button label="lastDay">
                  전일
                </el-radio-button>
                <el-radio-button label="today">
                  오늘
                </el-radio-button>
                <el-radio-button label="day7">
                  7일
                </el-radio-button>
                <el-radio-button label="day30">
                  30일
                </el-radio-button>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="계약번호">
              <el-input
                v-model="ruleForm.saleContractNumber"
                @keydown.native.tab="onAddZero(ruleForm.saleContractNumber)"
              />
            </el-form-item>
          </el-col>
          <el-col :span="16">
            <el-form-item label="계약자명">
              <el-input
                v-model="ruleForm.contractorName"
                @blur="ruleForm.contractorName = $event.target.value"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="업무담당자">
              <el-select
                v-model="ruleForm.exclusiveId"
                placeholder="선택"
                style="width: 194px;"
              >
                <el-option
                  v-for="{ sysUserNo, sysUserNm } in consultants"
                  :key="sysUserNo"
                  :value="sysUserNo"
                  :label="sysUserNm"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="16">
            <el-form-item
              label="판매진행상태"
            >
              <el-select
                v-model="ruleForm.saleProgressState"
                placeholder="전체"
              >
                <el-option
                  v-for="{ value,label } in LegacyCommonCodes.C013"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span>{{ ruleForm.note }}</span>
      <div class="board-wrap">
        <div class="info">
          <el-form
            :model="info"
          >
            <div>
              <el-checkbox
                v-model="checked"
                label="전체선택"
                @change="toggleSelectionAll"
              />
            </div>
            <div>
              <span>변경담당자</span>
              <el-select v-model="info.afterExclusiveUserId">
                <el-option
                  v-for="{ sysUserNo, sysUserNm } in consultants"
                  :key="sysUserNo"
                  :value="sysUserNo"
                  :label="sysUserNm"
                />
              </el-select>
            </div>
            <div>
              <span>변경사유</span>
              <el-input
                v-model="info.updateReason"
                placeholder="(10자 이내)"
                @blur="info.updateReason = $event.target.value"
              />
            </div>
          </el-form>
        </div>
        <h-table
          ref="multipleSelect"
          :table-type="'DefultTable'"
          :table-header="tableHeader"
          :table-datas="tableData"
          :handle-change="handleSelect"
        />
        <div class="btn-wrap">
        <div class="side"></div>
        <div class="pagination">
          <v-pagination
            v-if="tableData.length"
            :page.sync="pageInfo.page"
            :size="pageInfo.size"
            :total="pageInfo.total"
            @page-change="onSearch"
          />
        </div>
        <div class="main"></div>
      </div>
      </div>
    </div>
    <!-- 메세지 팝업 -->
    <el-dialog
      custom-class="message"
      :visible.sync="alertVisible"
    >
      <!-- Message -->
      <p>1:1 업무담당자를 변경 하시겠습니까? </p>
      <p>변경 사유 : <span>{{ info.updateReason }}</span></p>

      <!-- Popup Footer -->
      <template slot="footer">
        <el-button
          type="info"
          @click="alertVisible = false"
        >
          취소
        </el-button>
        <el-button
          type="primary"
          @click="modifyExclusive"
        >
          확인
        </el-button>
      </template>
    </el-dialog>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import HTable from '~/components/common/HTable.vue'
import { mapState } from 'vuex'
import moment from 'moment'
import PopMessage from '~/components/popup/PopMessage.vue'

export default {
  name: 'ChangeConsultant',
  layout: 'default',
  components:{
    HTable,
    PopMessage
  },
  data() {
    return {
      alertMessage: '',
      alertMessagePop: false,
      alertVisible: false,
      tabPosition: 'left',
      searchDtRadio:'today',
      multipleSelection:[],
      checked:false,
      ruleForm:{
        allocationStartDate: moment(),
        allocationEndDate:moment(),
        saleContractNumber:'',
        contractorName:'',
        exclusiveId:'',
        saleProgressState:'all',
        note:'* 기간은 필수 기입 사항입니다. '
      },
      info:{
        afterExclusiveUserId: '',
        updateReason: ''
      },
      tableData: [],
      tableHeader:[
        {
          label : '선택',
          type: 'checkBox',
          prop: 'isSelected',
          width: '70',
          align: 'center'
        },
        {
          label : '계약번호',
          prop: 'saleContractNumber',
          align: 'center',
          width: 200
        },
        {
          label : '계약자명',
          prop: 'contractorName',
          align: 'center'
        },
        {
          label : '레거시 진행 상태',
          prop: 'saleProgressState',
          align: 'center'
        },
        {
          label : '임직원몰 진행 상태',
          prop: 'onlineProgressState',
          align: 'center'
        },

        {
          label : '업무담당자 이름',
          prop: 'exclusiveName',
          align: 'center'
        },
        {
          label : '업무담당자 사번',
          prop: 'exclusiveUserId',
          align: 'center'
        },
        {
          label:'국판 업무담당자 사번',
          prop:'legacyExclusiveUserId',
          align:'center'
        }
      ],
      LegacyCommonCodes: {},
      pageInfo: { // paging info
        page: 1,
        size: 20,
        total: 0
      }
    }
  },
  computed: {
    ...mapState(['userInfo', 'consultants'])
  },
  async created() {
    await this.loadCommonCode()
  },
  mounted(){
    this.$store.dispatch('loadConsultants', {vm: this})
    this.$store.dispatch('loadUserInfo',{vm:this})
  },
  methods: {
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null
      switch(systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {vm: this, codeTypeCode: codeType})
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {vm: this, codeTypeCode: codeType})
        break
      }
      return res
    },
    async loadCommonCode() {
      const [ccC013] = await Promise.all([
        this.fetchCommonCodeData('C', 'C013') // 판매진행상태
      ])

      this.LegacyCommonCodes = { ...ccC013 }
    },
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    onAddZero(contractNumber) {
      let resultString = ''
      if(contractNumber.length > 6) {
        const frontString = contractNumber.substring(0,7)
        const backString = contractNumber.substring(7)

        resultString = resultString.concat(frontString)
        resultString = resultString.concat(backString.length >= 6 ? backString : Array.from({length: 6 - backString.length}, () => 0).join('') + backString)
      }

      if(!resultString) { resultString = contractNumber }
      this.ruleForm.saleContractNumber = resultString
    },
    // eslint-disable-next-line no-unused-vars
    handleSelect(val, row) {
      // 단일 선택만 허용할 경우 아래 주석 해제
      // this.tableData.filter((items) => { return items.no !== row.no }).map((items) => { items.isSelected = false })
    },
    resetSearchCond() {
      Object.assign(this.ruleForm, this.$options.data().ruleForm)
      Object.assign(this.info, this.$options.data().info)
      this.searchDtRadio = 'today'
    },
    async getData() {
      const { page: pageNo, size: pageSize } = this.pageInfo
      
      // 전체선택 취소
      this.checked = false

      if(this.ruleForm.allocationStartDate!==null&&this.ruleForm.allocationEndDate!==null){
        const params = {
          ...this.ruleForm,
          allocationStartDate: moment(this.ruleForm.allocationStartDate).format('YYYYMMDD'),
          allocationEndDate: moment(this.ruleForm.allocationEndDate).format('YYYYMMDD'),
          saleProgressState: this.ruleForm.saleProgressState!=='all'?this.ruleForm.saleProgressState: '0',
          pageNo,
          pageSize
        }
        console.log('params ',params)
        const [res,err] = await this.$https.get('/v1/exclusive/setting/oneone', params)
        if(!err) {
          if(!res.data.list || res.data.list.length===0) {
            this.tableData = []
          } else {
            this.tableData = res.data.list.map((el, idx) => {
              return {
                ...el,
                no: idx+1,
                isSelected: false
              }
            })

            this.pageInfo = {
              ...this.pageInfo,
              total: res.data.total
            }

            console.log('table: ', this.tableData)
          }

        } else {
          console.error(err)
          this.tableData = []
        }

      }else{
        this.alertMessage = '기간은 필수 기입 사항입니다.'
        this.alertMessagePop = true
      }


    },
    onChangeSearchDtRadio(val) {
      if(val==='lastDay') {
        this.ruleForm.allocationStartDate = moment().subtract('days', 1)
        this.ruleForm.allocationEndDate = moment().subtract('days', 1)
      } else if(val==='today') {
        this.ruleForm.allocationStartDate = moment()
        this.ruleForm.allocationEndDate = moment()
      } else if(val==='day7') {
        this.ruleForm.allocationStartDate = moment().subtract('days', 7)
        this.ruleForm.allocationEndDate = moment()
      } else if(val==='day30') {
        this.ruleForm.allocationStartDate = moment().subtract('days', 30)
        this.ruleForm.allocationEndDate = moment()
      }
    },
    openModifyPopup(){
      this.multipleSelection = this.tableData.filter((items) => {
        return items.isSelected === true
      })

      if(this.multipleSelection.length === 0) {
        this.alertMessage = '선택된 항목이 없습니다.'
        this.alertMessagePop = true
      } else if(this.info.afterExclusiveUserId === '') {
        this.alertMessage = '변경할 업무담당자 담당자를 선택하지 않았습니다.'
        this.alertMessagePop = true
      } else {
        this.alertVisible = true
      }
    },
    async modifyExclusive(){
      // const saleContractList = this.multipleSelection.map(el=>el.saleContractNumber).join(',')

      const data = {
        ...this.info,
        saleContractList: this.multipleSelection.map(el => el.saleContractNumber),
        updateUserId: this.userInfo.eeno
      }

      console.log('parameter data: ',data)
      const [res, err] = await this.$https.put('v1/exclusive/setting/oneone', data)  // API-E-업무담당자-091 (업무담당자 1:1 정보 변경 처리)

      if(!err) {
        console.log(res)
        this.alertMessage = '업무담당자가 변경되었습니다.'
        this.alertMessagePop = true
        Object.assign(this.info, this.$options.data().info)
        this.alertVisible = false
      } else {
        console.error(err)
      }
      this.onSearch(1)
    },
    toggleSelectionAll() {
      if(this.checked) {
        this.tableData.map((items) => { items.isSelected = true })
      }
      else {
        this.tableData.map((items) => { items.isSelected = false })
      }
    },
    onSearch(page) {
      this.pageInfo.page = page
      this.getData()
    },
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/pages/set/change-consultant.scss';
</style>

