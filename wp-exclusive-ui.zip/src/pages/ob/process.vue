<template>
  <section>
    <div id="process">
      <div class="article-title">
        <h-search
          v-model="workSerialNumber"
          :title="'업무일련번호'"
          :on-click="searchWork"
          :active-button="isValidAuthBtn('authSelect')"
          @enter="searchWork"
        />
        <div class="btn-group">
          <div>
            <el-button
              v-if="isValidAuthBtn('authExclusive') && (isAuth || userInfo.eeno === data.managerId)"
              type="primary"
              :disabled="!workSerialNumber"
              @click="save"
            >
              저장
            </el-button>
            <el-button
              v-if="isValidAuthBtn('authExclusive') && (isAuth || userInfo.eeno === data.managerId)"
              type="primary"
              :disabled="!workSerialNumber"
              @click="openPopSms()"
            >
              문자보내기
            </el-button>
          </div>
        </div>
      </div>
      <el-form
        :inline="true"
        :model="data"
        class="detail-form detail-02"
      >
        <el-row>
          <el-col :span="8">
            <el-form-item label="업무유형">
              {{ data.progressType }}
            </el-form-item>
          </el-col>
          <el-col :span="16">
            <el-form-item label="처리결과">
              <el-select
                v-model="data.progressResultCode"
                placeholder="처리결과 선택"
              >
                <el-option
                  v-for="{ value, label } in commonCodes.U011"
                  :key="value"
                  :value="value"
                  :label="label"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <h-relese-info
        :info="data"
      />
      <div class="middle-add">
        <div
          class="btn-wrap"
          style="margin-bottom: 10px"
        >
          <div class="side"></div>
          <div class="main">
            <el-button
              v-if="isValidAuthBtn('authExclusive') && (isAuth || userInfo.eeno === data.managerId)"
              type="primary"
              :disabled="!workSerialNumber"
              @click="addProcessRow"
            >
              행추가
            </el-button>
          </div>
        </div>
        <el-form
          :inline="true"
          class="detail-form"
        >
          <el-row
            v-for="(item, idx) in processHistory"
            :key="`history-${idx}`"
          >
            <el-col :span="12">
              <el-form-item :label="`${idx+1}차 처리 결과 상태`">
                <el-select
                  v-model="item.workProcessResultCode"
                  placeholder="처리결과 선택"
                  @change="onChangeProcessResultCode(idx)"
                >
                  <el-option
                    v-for="{ value, label } in commonCodes.U015"
                    :key="value"
                    :value="value"
                    :label="label"
                  />
                </el-select>
                <el-input
                  v-model="item.workProcessDate"
                  disabled
                  style="width:200px; margin-left: 10px"
                />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="메모">
                <el-input
                  v-model="item.workProcessContent"
                  @change="onChangeMemo(idx)"
                />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <el-form
        :inline="true"
        class="detail-form detail-02"
      >
        <el-row>
          <el-col :span="24">
            <el-form-item label="진행 상황 메모">
              <el-input
                v-model="data.workProcessContents"
                type="textarea"
              />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-form
        :inline="true"
        class="detail-form detail-02"
      >
        <el-row>
          <el-col :span="12">
            <el-form-item label="업무담당자">
              {{ data.consultantName }}
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="처리자">
              {{ data.managerName }}
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="article">
        <el-tabs
          v-model="activeName"
          type="card"
          stretch
          @tab-click="handleTabClick"
        >
          <el-tab-pane
            label="계약정보"
            name="first"
          >
            <contract-info
              :contract-number.sync="contractNumber"
              :contract-data.sync="contractData"
              :sign-data.sync="signData"
              :status-date-data.sync="statusDateData"
              :user-info-data.sync="userInfo"
              :paper-review-data.sync="paperReviewData"
              :active-user-flag.sync="activeFlag"
            />
          </el-tab-pane>
          <el-tab-pane
            label="차량정보"
            name="second"
          >
            <car-info
              ref="CarInfo"
              :contract-number.sync="contractNumber"
              :active-user-flag.sync="activeFlag"
            />
            <!-- <car-info
              :car-info-data.sync="carInfoData"
              :choice-option-names.sync="choiceOptionNames"
              :tuix-option-names.sync="tuixOptionNames"
            /> -->
          </el-tab-pane>
          <el-tab-pane
            label="결제정보"
            name="third"
          >
            <pay-info
              :pay-info-data.sync="payInfoData"
              :pay-amount-list.sync="payAmountList"
              :pay-detail.sync="payDetail"
              :user-info-data.sync="userInfo"
              :contract-info-data.sync="contractInfo"
              :active-user-flag.sync="activeFlag"
              @refresh="onRefresh($event, 'pay')"
            />
          </el-tab-pane>
          <el-tab-pane
            label="출고정보"
            name="fourth"
          >
            <release-info
              :release-info-data.sync="releaseInfoData"
              :release-center-data.sync="releaseCenterData"
              :release-takeover-data.sync="releaseTakeoverData"
              :release-consign-data.sync="releaseConsignData"
              :contract-info-data.sync="contractInfo"
              :release-regist-agency-data.sync="releaseRegistAgencyData"
            />
          </el-tab-pane>
          <el-tab-pane
            label="상태이력"
            name="fifth"
          >
            <status-history
              ref="StatusHistory"
              :contract-number.sync="contractNumber"
            />
            <!-- 상태이력 화면 컴포넌트화로 인한 주석처리 <A936507> -->
            <!-- <status-history
              :data.sync="statusTabData"
            /> -->
          </el-tab-pane>
          <el-tab-pane
            label="문자이력"
            name="sixth"
          >
            <sms-history
              ref="SmsHistory"
              :contract-number.sync="contractNumber"
            />
            <!-- <sms-history
              :data.sync="messageTabData"
              @refresh="onRefresh($event, 'sms')"
            /> -->
          </el-tab-pane>
        </el-tabs>
      </div>

      <!-- 조회결과없음 팝업 -->
      <el-dialog
        custom-class="message"
        :visible.sync="alertNoData"
      >
        <!-- Message -->
        조회 결과가 없습니다.

        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="info"
            @click="alertNoData = false"
          >
            확인
          </el-button>
        </template>
      </el-dialog>

      <!-- 문자보내기 팝업 -->
      <el-dialog
        title="문자보내기"
        :visible.sync="popVisible05"
        width="1100px"
      >
        <!-- Popup Contents -->
        <div class="board-wrap sandmessage">
          <h-title :title="'수신자 정보'" />
          <el-form
            ref="contractData"
            :model="contractData"
            class="detail-form"
          >
            <el-row>
              <el-col :span="9">
                <el-form-item label="수신자명">
                  <!-- {{ contractData.contractorInfo && contractData.contractorInfo.length > 0 ? contractData.contractorInfo[0].customerName : '' }} -->
                  <el-select v-model="contractorNames" multiple placeholder="수신자명">
                    <el-option
                      v-for="item in contractData.contractorInfo"
                      :key="item.customerName"
                      :label="item.customerName"
                      :value="item.customerName">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="15">
                <el-form-item label="휴대전화번호">
                  <!-- {{ contractData.contractorInfo && contractData.contractorInfo.length > 0 ? contractData.contractorInfo[0].customerMobile : '' }} -->
                  {{ contractorHpTns() }}
                </el-form-item>
              </el-col>
              <!-- <el-col :span="8">
                <el-form-item label="발송일시" />
              </el-col> -->
            </el-row>
          </el-form>
          <h-title :title="'발신내용'" />
          <el-form
            ref="ruleFormpopup"
            :model="ruleFormpopup"
            class="detail-form"
          >
            <el-row>
              <el-col :span="24">
                <el-form-item label="제목">
                  <el-input
                    v-model="ruleFormpopup.title"
                    class="mms-title"
                    @blur="ruleFormpopup.title = $event.target.value"
                  />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item label="내용">
                  <el-input
                    v-model="ruleFormpopup.text"
                    type="textarea"
                    @blur="ruleFormpopup.text = $event.target.value"
                  />
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <!-- Popup Footer -->
        <template slot="footer">
          <el-button
            type="info"
            @click="initRuleFormPop"
          >
            초기화
          </el-button>
          <el-button
            type="primary"
            @click="sendSms"
          >
            전송
          </el-button>
        </template>
      </el-dialog>
    </div>
    <!-- message Popup -->
    <pop-message
      :pop-visible.sync="alertMessagePop"
      :pop-message.sync="alertMessage"
      @confirm="alertMessagePop = false"
      @close="alertMessagePop = false"
    />
  </section>
</template>

<script>
import HSearch from '~/components/common/HSearch.vue'
import HReleseInfo from '~/components/common/HReleseInfo.vue'
import HTitle from '~/components/common/HTitle.vue'
import ContractInfo from '~/components/tab/ContractInfo.vue'
import CarInfo from '~/components/tab/CarInfo.vue'
import PayInfo from '~/components/tab/PayInfo.vue'
import ReleaseInfo from '~/components/tab/ReleaseInfo.vue'
import StatusHistory from '~/components/tab/StatusHistory.vue'
import SmsHistory from '~/components/tab/SmsHistory.vue'
import { mapGetters } from 'vuex'
import moment from 'moment'
import PopMessage from '~/components/popup/PopMessage.vue'

export default {
  name: 'Process',
  layout: 'default',
  components: {
    HSearch,
    HReleseInfo,
    HTitle,
    ContractInfo,
    CarInfo,
    PayInfo,
    ReleaseInfo,
    StatusHistory,
    SmsHistory,
    PopMessage
  },

  data() {
    return {
      isAuth: process.env.VUE_APP_AUTH === 'true', // 권한 패스용
      alertMessage: '',
      alertMessagePop: false,
      activeFlag: false, // 탭에서 조건별 활성화되어야 하는 버튼 제어 플래그
      activeName: 'first',
      alertNoData: false,
      popVisible05: false,
      ruleFormpopup:{
        title: '',
        text: ''
      },
      data: {
        progressResultCode: '10' // 처리결과 코드
      },
      processHistory: [],
      workSerialNumber: null,
      contractNumber: null,
      contractData: {},
      signData: [],
      statusDateData: {},
      paperReviewData: [],
      carInfoData: {},
      //choiceOptionNames: '',
      //tuixOptionNames: '',
      payInfoData: {},
      payAmountList: [],
      payDetail: {},
      releaseInfoData: {},
      releaseCenterData: {},
      releaseTakeoverData: {},
      releaseConsignData: {},
      releaseRegistAgencyData: {},
      contractInfo: {},
      // 상태이력 화면 컴포넌트화로 인한 주석처리 <A936507>
      // statusTabData: { sale: [], sales: [], payment:[], consultant:[], papers:[], electron: [], point: [], apiLog : []},
      //messageTabData: [],
      commonCodes: {},
      contractorNames: []  // 선택한 계약자명
    }
  },
  computed: {
    ...mapGetters(['userInfo'])
  },
  async created() {
    await this.loadCommonCode()
  },
  mounted() {
    this.$store.dispatch('loadConsultants', {vm: this})

    this.workSerialNumber = sessionStorage.getItem('workSerialNumber') || '' // 새창으로 넘어오는 경우

    if(this.$route.params.workSerialNumber) { // route 이동으로 넘어오는 경우 * params이 있을 경우에만 셋팅
      this.workSerialNumber = this.$route.params.workSerialNumber
    }

    if(this.workSerialNumber) {
      this.getData(this.workSerialNumber)
    }

    sessionStorage.removeItem('workSerialNumber')
  },
  methods: {
    fetchCommonCodeData(systemType = '', codeType = '') {
      let res = null
      switch(systemType) {
      case 'E':
        res = this.$store.dispatch('loadCommonCodesE', {vm: this, codeTypeCode: codeType})
        break
      case 'C':
        res = this.$store.dispatch('loadLegacyCommonCodesC', {vm: this, codeTypeCode: codeType})
        break
      }
      return res
    },
    async loadCommonCode() {
      const [ccU011, ccU015] = await Promise.all([
        this.fetchCommonCodeData('E', 'U011'),
        this.fetchCommonCodeData('E', 'U015')
      ])

      this.commonCodes = { ...ccU011, ...ccU015 }

      const ccdKeys = Object.keys(this.commonCodes)

      if(ccdKeys.length > 0) ccdKeys.map((keys) => { this.commonCodes[keys].splice(0, 1) }) // `전체` 선택항목 제거
    },
    isValidAuthBtn(authId) { // 버튼별 권한 체크
      let bResult = false // true: 허용 , false: 비허용
      const currAuthBtnList = this.$store.state.currAuthBtnList || []
      if(currAuthBtnList && currAuthBtnList.length > 0) {
        currAuthBtnList.some((items) => {
          if(items.btnId === authId) {
            bResult = true
            return true
          }
        })
      }
      return bResult
    },
    async getData(serialNumber) {
      if(!serialNumber) return
      // API-E-업무담당자-053 (OB업무 상세조회)
      const [res1,err1] = await this.$https.post('/v2/exclusive/ob-detail', { workAssignNumber : serialNumber })

      if(!err1) {
        console.log('/ob/'+serialNumber, res1.data)
        if(!res1.data) { // 상세보기 - 조회 결과 없음 팝업 노출
          const beforeWorkSerialNumber = this.workSerialNumber
          Object.assign(this.$data, this.$options.data())
          this.workSerialNumber = beforeWorkSerialNumber
          this.alertNoData = true
          return
        }
        this.workSerialNumber = serialNumber
        this.data = {
          ...res1.data,
          progressResultCode: res1.data.progressResultCode || '10' // default '접수(10)'
        }
        this.contractNumber = res1.data && res1.data.contractNumber
        this.getContractTabData()
        this.handleTabClick({name: this.activeName})
        this.getContractInfoData()

        if(this.data.managerId && this.data.managerId === this.userInfo.eeno) { // 사용자 사번과 처리자가 같을 경우
          this.activeFlag = true
        }
      } else {
        console.error(err1)
      }

      const [res2,err2] = await this.$https.get('/v2/exclusive/ob/'+serialNumber+'/history')//API-E-업무담당자-054 (OB업무 처리정보 이력 조회)
      if(!err2) {
        console.log('/ob/'+serialNumber+'/history', res2.data)

        this.processHistory = res2.data.map((el, idx) => {
          const { workAssignNumber = '', managerId = this.data.managerId, workProcessResultCode = '', workProcessDate = '', workProcessContent = '' } = el

          return {
            workAssignNumber,
            workProcessSerialNumber: ''+(idx+1),
            managerId: managerId || this.data.managerId,
            workProcessResultCode,
            workProcessDate: workProcessDate ? moment(workProcessDate).format('YYYY-MM-DD HH:mm') : '',
            workProcessContent
          }
        })
        this.addProcessRow() // default 1개
      } else {
        console.error(err2)
      }

    },
    async getContractInfoData() {
      // API-E-업무담당자-013 (계약출고상세조회)
      const [res, err] = await this.$https.post('/v2/exclusive/contract-detail', { contractNumber: this.contractNumber })
      if(!err) {
        this.contractInfo = res.data
      } else {
        console.error(err)
      }
    },
    searchWork(value) {
      if(!this.isValidAuthBtn('authSelect')) { // 권한없을경우 동작 x
        return
      }

      if(!value) {
        this.alertMessage = '업무일련번호를 입력해주세요.'
        this.alertMessagePop = true
        return
      } else {
        value = value.trim() // 공백 제거
      }

      this.getData(value)
    },
    addProcessRow() {
      const { workSerialNumber = '', managerId = ''} = this.data
      this.processHistory.push({
        isAdd: this.processHistory.length > 1 ? true : false,
        workAssignNumber: workSerialNumber,
        workProcessSerialNumber : ''+(this.processHistory.length+1),
        managerId,
        workProcessResultCode: '',
        workProcessDate: '',
        workProcessContent: ''
      })
    },
    onChangeProcessResultCode(idx) {
      this.processHistory[idx].workProcessDate = moment().format('YYYY-MM-DD HH:mm')
      this.processHistory[idx].isAdd = true
    },
    onChangeMemo(idx){
      this.processHistory[idx].isAdd = true
    },
    async save() {
      if(!this.workSerialNumber) {
        this.alertMessage = '업무를 먼저 검색해주세요.'
        this.alertMessagePop = true
        return
      }

      const { workSerialNumber: workAssignNumber = '', progressResultCode : workProcessResultCode = '', workProcessContents : workProcessContent = '' } = this.data
      const { id = '' } = this.userInfo

      let workProcessList = this.processHistory.map(el => {
        const { managerId = '', workProcessContent = '', workProcessDate = '', workProcessResultCode = '', workProcessSerialNumber = '', workAssignNumber = '', isAdd = false } = el
        return { managerId, workProcessContent, workProcessDate, workProcessDetailResultCode: workProcessResultCode, workProcessSerialNumber, workAssignNumber, isAdd }
      })

      workProcessList = workProcessList.filter((items) => {    // 변경되거나 추가된 사항만 저장
        if(items.workProcessDetailResultCode) {
          return items.isAdd === true
        }
      })

      const body = { workAssignNumber, workProcessResultCode, workProcessContent, workProcessList, customerNumber: id }
      console.log(body)
      const [res,err] = await this.$https.post('/v2/exclusive/ob', body)//API-E-업무담당자-055 (OB업무 - 처리 내역을 저장하는 API)
      if(!err) {
        console.log('POST /ob', res.data)
        this.alertMessage = '저장되었습니다.'
        this.alertMessagePop = true
        this.getData(this.workSerialNumber)
      } else {
        console.error(err)
      }
    },
    handleTabClick(tab) {
      if(tab.name==='first') this.getContractTabData()
      else if(tab.name==='second') this.getCarTabData()
      else if(tab.name==='third') this.getPaymentTabData()
      else if(tab.name==='fourth') this.getReleaseTabData()
      else if(tab.name==='fifth') this.getStatusTabData()
      else if(tab.name==='sixth') this.getMessageTabData()
    },
    async getContractTabData() {
      if(!this.contractNumber) return
      //계약자 정보 + 서비스가입 + 계약금 결제
      // API-E-업무담당자-014 (계약정보조회)
      const [res1, err1] = await this.$https.post('/v2/exclusive/work/contract', { contractNumber: this.contractNumber })
      if(!err1) {
        console.log('/work/contract/', res1.data)
        if(!res1.data) { return }
        this.contractData = res1.data

        const contractorInfo = this.contractData && this.contractData.contractorInfo
        this.contractorNames = contractorInfo && contractorInfo.length ? contractorInfo.map((items) => { return items.customerName }) : []
      } else {
        console.error(err1)
      }

      // API-E-업무담당자-015 (전자서명목록 조회)
      const [res2, err2] = await this.$https.post('/v2/exclusive/work/electron', { contractNumber: this.contractNumber })
      if(!err2) {
        console.log('/work/electron/', res2.data)
        this.signData = res2.data
      } else {
        console.error(err2)
      }

      //상태별 일자
      const [res3, err3] = await this.$https.get('/v2/exclusive/work/state-day/'+this.contractNumber)
      if(!err3) {
        console.log('/work/state-day/', res3.data)
        this.statusDateData = res3.data
      } else {
        console.error(err3)
      }

      //서류심사 목록
      const [res4, err4] = await this.$https.get('/v2/exclusive/work/contract/papers/'+this.contractNumber)
      if(!err4) {
        console.log('/work/contract/papers/', res4.data)
        this.paperReviewData = res4.data.map((el, idx) => {
          el.no = idx+1
          return el
        })
      } else {
        console.error(err4)
      }

    },
    async getCarTabData() {
      if(!this.contractNumber) return

      this.$refs.CarInfo.getCarInfoData();

      // API-E-업무담당자-019 (차량정보 조회)
      // const [res1, err1] = await this.$https.post('/v2/exclusive/work/car', { contractNumber: this.contractNumber })
      // if(!err1) {
      //   if(res1.data) {
      //     this.carInfoData = res1.data
      //     let choiceOptionNameAry = [], tuixOptionNameArr = [], tuixOptionTotalPrice = 0

      //     this.carInfoData.choiceOptionInfo && this.carInfoData.choiceOptionInfo.map(el => {
      //       choiceOptionNameAry.push(el.carOptionName)
      //       if(el.carOptionDeailName !== null) {
      //         el.carOptionDeailNameAry = el.carOptionDeailName.split('+')
      //       }
      //     })
      //     this.choiceOptionNames = choiceOptionNameAry.join(', ')

      //     this.carInfoData.tuixOptionInfo && this.carInfoData.tuixOptionInfo.map(el => {
      //       tuixOptionTotalPrice += el.carOptionPrice
      //       tuixOptionNameArr.push(el.carOptionName)
      //       if(el.carOptionDeailName !== null) {
      //         el.carOptionDeailNameAry = el.carOptionDeailName.split('+')
      //       }
      //     })
      //     this.tuixOptionNames = tuixOptionNameArr.join(', ')
      //     this.carInfoData = { ...this.carInfoData, tuixOptionTotalPrice: tuixOptionTotalPrice }

      //     console.log(this.carInfoData)
      //   }
      // } else {
      //   console.error(err1)
      // }
    },
    async getPaymentTabData() {
      if(!this.contractNumber) return

      // API-E-업무담당자-020 (결제정보 조회)
      const [res1, err1] = await this.$https.post('/v2/exclusive/work/payment', { contractNumber: this.contractNumber })
      if(!err1) {
        console.log('/work/payment/', res1.data)
        this.payInfoData = res1.data
      } else {
        console.error(err1)
      }

      // API-E-업무담당자-021 (결제금액 조회)
      const [res2, err2] = await this.$https.post('/v2/exclusive/work/payment-amount', { contractNumber: this.contractNumber })
      if(!err2) {
        console.log('/work/payment-amount/', res2.data)
        this.payInfoData.totalPrice = 0
        let totalDiscount = 0, totalPoint = 0, totalDiscountRate = 0, totalPointRate = 0

        this.payAmountList = []
        if(res2.data) {
          this.payAmountList.push({name: '차량금액', content: '', price: (res2.data.carPrice ? res2.data.carPrice.toLocaleString() + '원' : '0원'), pointState: '', background: '', type: ''})
          this.payAmountList.push({name: '탁송료', content: '', price: (res2.data.deliveryPrice ? res2.data.deliveryPrice.toLocaleString() + '원' : '0원'), pointState: '', background: '', type: ''})
          this.payAmountList.push({name: '단기의무보험료', content: '', price: (res2.data.insurancePayment ? res2.data.insurancePayment.toLocaleString() + '원' : '0원'), pointState: '', background: '', type: ''})
          if(res2.data.greenTaxFreePrice) {
            //2020.03.03 친환경면세 => 개소세면세
            this.payAmountList.push({name: '개소세면세', content: '', price: (res2.data.greenTaxFreePrice ? res2.data.greenTaxFreePrice.toLocaleString() + '원' : '0원'), pointState: '', background: '', type: ''})
          }

          //총 할인
          res2.data.discountInfo && res2.data.discountInfo.map((el) => {
            totalDiscount += el.discountPrice
            totalDiscountRate += el.discountRate || 0
          })

          res2.data.pointInfo && res2.data.pointInfo.map((el) => { //총 포인트
            if(el.pointUseStateCode === 'S') { // 처리 완료 상태
              totalPoint += el.usePoint
            }
          })
          if(res2.data.totalTcpRate){
            totalPointRate=res2.data.totalTcpRate
          }

          //총 할인금액 % = 할인금액% + 당사분담금액 포인트%
          totalDiscountRate += totalPointRate || 0


          this.payAmountList.push({name: '총 할인금액', content: '', percent: (totalDiscountRate ? totalDiscountRate.toFixed(1) + '%' : '0%'), price: (totalDiscount.toLocaleString() + '원'), pointState: '', background: 'red', type: ''})

          res2.data.discountInfo && res2.data.discountInfo.map((el, idx, ary) => {
            this.payAmountList.push({name: (idx===0 || el.discountTypeName!==ary[idx-1].discountTypeName  ? el.discountTypeName : ''), content: el.discountContents!==null ? el.discountContents : el.discountName, percent: (el.discountRate ? el.discountRate + '%' : ''), price: (el.discountPrice ? (el.discountPrice.toLocaleString() + '원') : ''), pointState: '', background: '', type: ''})
          })

          this.payAmountList.push({name: '총 포인트 금액', content: '', percent: (totalPointRate ? totalPointRate.toFixed(1) + '%' : '0%'), price: (totalPoint.toLocaleString() + '원'), pointState: '', background: 'red', type: ''})

          res2.data.pointInfo && res2.data.pointInfo.map((el, idx) => {
            let payType = ''
            if(el.pointCode === 'HC' && el.saveAutoPointYn) {
              payType  = 'save-auto' // API-E-결제서비스-027 (세이브오토 취소 처리)
            } else if(el.pointCode === 'HC' && !el.saveAutoPointYn) {
              payType  = 'm-point' // API-E-결제서비스-025 (M포인트 취소 처리)
            } else if(el.pointCode === 'OH') {
              payType  = 'blue-point' // API-E-결제서비스-026 (블루멤버스 포인트 취소 처리)
            }

            this.payAmountList.push({name: (idx===0  ? '포인트' : ''), content: el.pointName || '', price: (el.usePoint ? (el.usePoint.toLocaleString() + '원') : ''), pointState: el.pointUseState || '', background: '', type: 'button', payType: payType, useCompleteYn: el.useCompleteYn, customerManagementNumber: el.customerManagementNumber })
          })

          this.payInfoData.totalPoint = totalPoint || 0
          this.payInfoData.totalPrice = (res2.data.carPrice || 0) + (res2.data.deliveryPrice || 0) + (res2.data.insurancePayment || 0) - totalDiscount - totalPoint
          this.payInfoData.totalPrice4Mypage = (res2.data.carPrice || 0) + (res2.data.deliveryPrice || 0) + (res2.data.insurancePayment || 0) - totalDiscount - (res2.data.greenTaxFreePrice || 0)
        }
      } else {
        console.error(err2)
      }


      // API-E-업무담당자-022 (결제내역 상세조회)
      const [res3, err3] = await this.$https.post('/v2/exclusive/work/payment-details', { contractNumber: this.contractNumber })
      if(!err3) {
        console.log('/work/payment/', res3.data)
        res3.data.installmentInfo && res3.data.installmentInfo.map(el => {
          el.advancePayment = el.advancePayment ? el.advancePayment.toLocaleString()+'원' : '-'
          el.installmentPrincipal = el.installmentPrincipal ? el.installmentPrincipal.toLocaleString()+'원' : '-'
          el.monthlyPaymentTotal = el.monthlyPaymentTotal ? el.monthlyPaymentTotal.toLocaleString()+'원' : '-'
        })
        res3.data.cardInfo && res3.data.cardInfo.map(el => {
          el.cardPaymentPrice = el.cardPaymentPrice ? el.cardPaymentPrice.toLocaleString()+'원' : '-'
        })

        res3.data.paymentInfo && res3.data.paymentInfo.map(el => {
          let payType = ''
          if(el.paymentTypeCode === '20') {
            payType  = 'card' // API-E-결제서비스-023 (카드 취소 처리)
          } else if(el.paymentTypeCode === '10') {
            payType  = 'installment' // API-E-결제서비스-024 (할부 취소 처리)
          } else if(el.paymentTypeCode === '30') {
            payType  = 'cash' // cash 현금은 별도 처리 방식
          }
          el.payType = payType
        })

        res3.data.additionPaymentInfo && res3.data.additionPaymentInfo.map(el => {
          let payType = ''
          if(el.paymentTypeCode === '20') {
            payType  = 'card' // API-E-결제서비스-023 (카드 취소 처리)
          } else if(el.paymentTypeCode === '10') {
            payType  = 'installment' // API-E-결제서비스-024 (할부 취소 처리)
          } else if(el.paymentTypeCode === '30') {
            payType  = 'cash' // cash 현금은 별도 처리 방식
          }
          el.payType = payType
        })

        this.payDetail = res3.data

        const { blueMembersRate, blueMembersPrearrangementPoint, blueMembersPoint, blueMembersContents } = res3.data
        this.payDetail.blueInfo = [ { blueMembersRate : (blueMembersRate ? Number(blueMembersRate).toFixed(1) : '-'), blueMembersPrearrangementPoint : blueMembersPrearrangementPoint ? Number(blueMembersPrearrangementPoint).toLocaleString() : '-', blueMembersPoint : blueMembersPoint ? Number(blueMembersPoint).toLocaleString() : '-', blueMembersContents } ]
      } else {
        console.error(err3)
      }
    },
    async getReleaseTabData() {
      if(!this.contractNumber) return

      //출고정보
      const [res1, err1] = await this.$https.get('/v2/exclusive/work/delivery/'+this.contractNumber)
      if(!err1) {
        console.log('/work/delivery/', res1.data)
        this.releaseInfoData = res1.data
      } else {
        console.error(err1)
      }

      //출고센터진행정보
      const [res2, err2] = await this.$https.get('/v2/exclusive/work/delivery-state/'+this.contractNumber)
      if(!err2) {
        console.log('/work/delivery-state/', res2.data)
        this.releaseCenterData = res2.data
      } else {
        console.error(err2)
      }

      // API-E-업무담당자-032 (인수정보 조회)
      const [res3, err3] = await this.$https.post('/v2/exclusive/work/take-over', { contractNumber: this.contractNumber })
      if(!err3) {
        console.log('/work/take-over/', res3.data)
        this.releaseTakeoverData = res3.data
      } else {
        console.error(err3)
      }

      //탁송정보
      const [res4, err4] = await this.$https.get('/v2/exclusive/work/consign/'+this.contractNumber)
      if(!err4) {
        console.log('/work/consign/', res4.data)
        this.releaseConsignData = res4.data
      } else {
        console.error(err4)
      }


      //등록정보
      const [res5, err5] = await this.$https.get('/v2/exclusive/work/regist-agency/'+this.contractNumber)
      if(!err5) {
        this.releaseRegistAgencyData = res5.data
      } else {
        console.error(err5)
      }

    },
    async getStatusTabData() {
      if(!this.contractNumber) return

      
      //API-WE-업무담당자-035 (판매처리이력 조회)
      this.$refs.StatusHistory.getSaleHistory();

      //API-WE-업무담당자-036 (매출변경이력 조회)
      this.$refs.StatusHistory.getSalesHistory();

      //API-WE-업무담당자-037 (결제변경이력 조회)
      this.$refs.StatusHistory.getPaymentHistory();

      // API-WE-업무담당자-129 (포인트신청이력 조회)
      this.$refs.StatusHistory.getPointHistory();

      //API-WE-업무담당자-038 (업무담당자처리이력 조회)
      this.$refs.StatusHistory.getConsultantHistory();
      
      //API-WE-업무담당자-040 (서류심사이력 조회)
      this.$refs.StatusHistory.getPaperHistory();
      
      //API-WE-업무담당자-041 (전자서명이력 조회)
      this.$refs.StatusHistory.getSignHistory();
      
      //API-WE-업무담당자-133 (국판 호출 로그 이력 조회)
      this.$refs.StatusHistory.getApiHistory();



      // 상태이력 화면 컴포넌트화로 인한 주석처리 <A936507>
      //API-E-업무담당자-035 (판매처리이력 조회)
      // const [res1, err1] = await this.$https.post('/v2/exclusive/work/history/sale', { contractNumber: this.contractNumber })
      // if(!err1) {
      //   console.log('/work/history/sale/', res1.data)
      //   this.statusTabData.sale = res1.data.map((el) => {
      //     return {
      //       ...el,
      //       deliveryPrearrangedDate: el.deliveryPrearrangedDate ? moment(el.deliveryPrearrangedDate).format('YYYY-MM-DD') : '',
      //     }
      //   })
      // } else {
      //   console.error(err1)
      // }

      //API-E-업무담당자-036 (매출변경이력 조회)
      // const [res2, err2] = await this.$https.get('/v2/exclusive/work/history/sales/' + this.contractNumber)
      // if(!err2) {
      //   console.log('/work/history/sales/', res2.data)
      //   this.statusTabData.sales = res2.data.map((el) => {
      //     return {
      //       ...el,
      //       carPrice: el.carPrice && (el.carPrice*1).toLocaleString()+' 원',
      //       discountPrice: el.discountPrice && (el.discountPrice*1).toLocaleString()+' 원',
      //       usePoint: el.usePoint && (el.usePoint*1).toLocaleString(),
      //       salePrice: el.salePrice && (el.salePrice*1).toLocaleString()+' 원',
      //       contractPrice: el.contractPrice && (el.contractPrice*1).toLocaleString()+' 원',
      //       installmentPrincipal: el.installmentPrincipal && (el.installmentPrincipal*1).toLocaleString()+' 원',
      //       cardPaymentPrice: el.cardPaymentPrice && (el.cardPaymentPrice*1).toLocaleString()+' 원',
      //       tax: el.tax && (el.tax*1).toLocaleString()+' 원',
      //     }
      //   })
      // } else {
      //   console.error(err2)
      // }

      //API-E-업무담당자-037 (결제변경이력 조회)
      // const [res3, err3] = await this.$https.post('/v2/exclusive/work/history/payment', { contractNumber: this.contractNumber })
      // if(!err3) {
      //   console.log('/work/history/payment/', res3.data)
      //   this.statusTabData.payment = res3.data.map((el) => {
      //     return {
      //       ...el,
      //       paymentPrice: el.paymentPrice ? (el.paymentPrice*1).toLocaleString()+'원' : '',
      //       paymentContents: el.paymentTypeCode !== '30' ? el.paymentContents : (el.virtualAccount ? el.paymentContents + '\n - 계좌번호: ' + el.virtualAccount : el.paymentContents),
      //       refundPrice: el.refundPrice ? (el.refundPrice*1).toLocaleString()+'원' : ''
      //     }
      //   })
      // } else {
      //   console.error(err3)
      // }

      // API-E-업무담당자-129 (포인트신청이력 조회)
      // const [res4, err4] = await this.$https.post('/v2/exclusive/work/history/point', { contractNumber: this.contractNumber })
      // if(!err4) {
      //   console.log('/work/history/point/', res4.data)
      //   this.statusTabData.point = res4.data.map((items, idx) => {
      //     return {
      //       ...items,
      //       no: idx + 1,
      //       pointUsePrice: items.pointUsePrice.toLocaleString() + '원', // 포인트 사용금액
      //       partnerAssignmentPrice: items.partnerAssignmentPrice.toLocaleString() + '원', // 제휴사분담금액
      //       companyAssignmentPrice: items.companyAssignmentPrice.toLocaleString() + '원' // 당사분담금액
      //     }
      //   })
      // } else {
      //   console.error(err4)
      // }

      //API-E-업무담당자-038 (업무담당자처리이력 조회)
      // const [res5, err5] = await this.$https.get('/v2/exclusive/work/history/consultant/'+this.contractNumber)
      // if(!err5) {
      //   console.log('/work/history/consultant/', res5.data)
      //   this.statusTabData.consultant = res5.data
      // } else {
      //   console.error(err5)
      // }

      //API-E-업무담당자-040 (서류심사이력 조회)
      // const [res6, err6] = await this.$https.get('/v2/exclusive/work/history/papers/'+this.contractNumber)
      // if(!err6) {
      //   console.log('/work/history/papers/', res6.data)
      //   this.statusTabData.papers = res6.data.map((el, idx) => {
      //     return {
      //       ...el,
      //       no : idx+1,
      //       papersNameListStr : el.papersNameList.join(', '),
      //     }
      //   })
      // } else {
      //   console.error(err6)
      // }
      //API-E-업무담당자-041 (전자서명이력 조회)
      // const [res7, err7] = await this.$https.get('/v2/exclusive/work/history/electron/'+this.contractNumber)
      // if(!err7) {
      //   console.log('/work/history/electron/', res7.data)
      //   this.statusTabData.electron = res7.data
      // } else {
      //   console.error(err7)
      // }

      //API-E-업무담당자-133 (국판 호출 로그 이력 조회)
      // if(this.statusTabData.apiLog.length===0) {
      // const [res8, err8] = await this.$https.get('/v2/exclusive/work/history/apilog/'+this.contractNumber)
      // if(!err8) {
      //   // console.log('/work/history/apilog/', res8.data)
      //   this.statusTabData.apiLog = res8.data && res8.data.map((el, idx) => {
      //     return {
      //       ...el,
      //       no : res8.data.length - idx,
      //       siteConnectTime: el.siteConnectTime? el.siteConnectTime.split('.')[0]:null
      //     }
      //   })

      //   console.log('/work/history/apilog/', this.statusTabData.apiLog)
      // } else {
      //   console.error(err8)
      // }
      // }

    },
    async getMessageTabData() {
      if(!this.contractNumber) return

      this.$refs.SmsHistory.getSmsHistoryData()

      //API-E-업무담당자-042 (문자발송목록 조회)
      // const [res, err] = await this.$https.post('/v2/exclusive/work/history/sms', { contractNumber: this.contractNumber, pageNo : '1', pageSize: '100' })
      // if(!err) {
      //   console.log('/work/history/sms/', res.data)
      //   this.messageTabData = res.data.list && res.data.list.map((el, idx) => {
      //     return {
      //       ...el,
      //       no : idx+1,
      //     }
      //   })
      // } else {
      //   console.error(err)
      // }
    },
    onCheck(value) {
      console.log(value)
    },
    initRuleFormPop() { // 초기화 버튼
      Object.assign(this.$data.ruleFormpopup, this.$options.data().ruleFormpopup)
    },
    tableRowClassName({row}) {
      if (row.background === 'red') {
        return 'warning-row'
      }
      else if (row.border === 'red') {
        return 'warning-row1'
      }
      return ''
    },
    async sendSms() {
      let customersInfo = []
      const contractorInfo = this.contractData && this.contractData.contractorInfo
      const targetContractorInfo = contractorInfo && contractorInfo.filter((items) => {
        return this.contractorNames.includes(items.customerName)
      })

      targetContractorInfo.map((items) => {
        customersInfo.push({
          sendChannelCode: '003', // 발송경로 구분 코드 - 업무담당자
          saleContractNo: this.contractNumber || '', // 판매계약번호
          customerMgmtNo: items.customerManagementNumber || '', // 고객관리번호
          customerUniqueNo: this.userInfo.eeno || '', // 고객고유번호
          messageTitle: this.ruleFormpopup.title, // 제목
          messageContents: this.ruleFormpopup.text, // 내용
          receiverTel: items.customerMobile, // 수신자전화번호
          receiverName: items.customerName // 수신자명
        })
      })

      const [result1, result2] = await Promise.all(
        customersInfo.map((items) => {
          return this.$https.post('/v2/exclusive/common/sms-send', items) // API-E-공통서비스-023 (문자 보내기)
        })
      )

      // 1명의 계약자에게만 발송하는 경우
      if (!result2) {
        const [res1, err1] = result1
        if (!err1) {
          if(res1.rspStatus && res1.rspStatus.rspCode === '0000') {
            this.popVisible05 = false // 팝업 닫기
            this.alertMessage = '문자가 전송되었습니다.'
            this.alertMessagePop = true
          }
        }
      }

      // 주계약자 및 공동명의자 모두 발송하는 경우
      if (result1 && result2) {
        const [res1, err1] = result1
        const [res2, err2] = result2

        // 모두 전송되었을 경우
        if (!err1 && !err2) {
          if(res1.rspStatus && res1.rspStatus.rspCode === '0000' &&
            res2.rspStatus && res2.rspStatus.rspCode === '0000') {
            this.popVisible05 = false // 팝업 닫기
            this.alertMessage = '문자가 전송되었습니다.'
            this.alertMessagePop = true
          }
        }
      }
      this.getMessageTabData() // reload
      this.popVisible05 = false // 팝업 닫기
    },
    openPopSms() { // 문자보내기 팝업 노출
      // ※ 출고일 장기 경과 데이터 이관으로 고객정보 부재가 발생하는 케이스가 생김.
      // 고객 데이터에 따른 안내팝업 처리
      // 고객관리번호는 필수값이 아니라 체크안함. 고객정보의 수신자 전화번호와 수신자명은 필수값 임으로 체크
      let customerMobile = '', customerName = ''

      if (this.contractData && this.contractData.contractorInfo[0]) {
        ({ customerMobile, customerName } = this.contractData.contractorInfo[0])
      }

      if (!customerMobile || !customerName) { // 고객정보가 없을 경우
        this.alertMessage = '출고일 장기 경과건으로 고객 데이터가 없습니다.\n데이터 복원후 진행해주세요.'
        this.alertMessagePop = true
      } else {
        this.popVisible05 = true
        Object.assign(this.ruleFormpopup, this.$options.data().ruleFormpopup)
      }
    },
    onRefresh(flag, tab) {
      if(flag) {
        switch(tab) {
        case 'contract':
          this.getContractTabData()
          break
        case 'car':
          this.getCarTabData()
          break
        case 'pay':
          this.getPaymentTabData()  // 결제정보탭 reload
          break
        case 'release':
          this.getReleaseTabData()
          break
        case 'status':
          this.getStatusTabData()
          break
        case 'sms':
          this.getMessageTabData()
          break
        }
      }
    },
    contractorHpTns() {
      const contractorInfo = this.contractData && this.contractData.contractorInfo
      const targetContractorInfo = contractorInfo && contractorInfo.filter((items) => {
        return this.contractorNames.includes(items.customerName)
      })
      return targetContractorInfo && targetContractorInfo.map((items) => { return items.customerMobile + (items.contractorTypeName ? ('(' + items.contractorTypeName + ')') : '') }).join(', ')
    }
  },


}
</script>

<style lang="scss" scoped>
@import '~/assets/style/pages/detail.scss';
</style>

