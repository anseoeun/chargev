<template>
  <div id="froalabox">
    <h1> Froala 에디터 테스트 페이지입니다.</h1>
    <br><br><br><br><br><br>
    <froala
      id="edit"
      v-model="content"
      :tag="'textarea'"
      :config="config"
    />
    <br><br><br><br><br>
    <hr>
    <h5>콘텐츠 출력만 할땐 아래 태그 활용하면 됩니다.</h5>
    <br>
    <hr>
    <froalaView v-model="content" />
    <hr>
  </div>
</template>

<script>
//import VueFroala from 'vue-froala-wysiwyg';

export default {
  data () {
    return {
      config: {
        events: {
          initialized: function () {
            console.log('initialized')
          },
          focus : function(e, editor) {
            console.log(editor.selection.get())
          }
        },
        placeholderText: '여기에 내용을 입력하세요',
        charCounterCount: true
      },
      content: '<h3>초기 콘텐츠는 필요시 여기에!</h3><br/><img src="http://img.sbs.co.kr/newsnet/etv/upload/2019/07/10/30000630594_700.jpg"/>'
    }
  }
}
</script>