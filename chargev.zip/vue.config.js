module.exports = {
    devServer: {
      overlay: false
    },
    runtimeCompiler: true,
};
