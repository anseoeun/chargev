<template>
    <div class="header">
        <div class="left">
            <div class="user"><Icon type="g" />이상욱</div>
        </div>
       <div class="right">
           <router-link to="/" class="btn"><Icon type="search" /></router-link>
           <router-link to="/" class="btn" :class="{on: true}"><Icon type="alarm" /></router-link>
       </div>
    </div>
</template>
