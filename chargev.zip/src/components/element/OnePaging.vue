<template>
  <div class="grident-bottom">
        <div class="custom-dotting">
            <span></span>
        </div>
   </div>
</template>
