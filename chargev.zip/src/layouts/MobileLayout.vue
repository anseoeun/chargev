<template>
    <div>
        모바일
        <slot></slot>
    </div>
</template>

<script>

export default {
    name: 'MobileLayout',
}
</script>