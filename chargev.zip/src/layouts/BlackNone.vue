<template>
    <div>
        <slot />
    </div>
</template>

<script>

export default {
    name: 'BlackNone',
    components: {
    },
}
</script>
<style>
body{background: #000 !important;}
</style>
