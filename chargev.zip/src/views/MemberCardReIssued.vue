<template>
  <div class="contents">
    <div class="support-guide-wrap">
      <div class="support-guide-header">
        <h2 class="tit-type2">멤버십카드 재발급</h2>
        <div class="header-menu">
          <div class="date">2022-02-02</div>
          <div class="right">
            <button>
              <Icon type="sns" />
            </button>
          </div>
        </div>
      </div>
      
      <!-- 멤버십카드 재발급 -->
      <div class="shadow-box">
        <h3 class="tit-type4"><span class="i-wrap"><Icon type="card" /><span>멤버십카드 재발급</span></span></h3>
        <div class="text-wrap">
            <p>차지비는 멤버십카드를 분실하신 경우에도 모바일 앱을 통해 충전이 가능합니다.</p>
            <p>멤버십카드를 분실하신 경우 아래의 버튼을 통해 멤버십카드 재발급을 진행해주세요.</p>
        </div>
        <router-link to="/" class="btn-type1 st1">멤버십카드 재발급하러가기</router-link>
      </div>
      
    </div>
  </div>
</template>

<script>
export default {
  components: {
    
  },
  data(){
    return{
     
    }
  },
   mounted(){
   
  }
}
</script>
