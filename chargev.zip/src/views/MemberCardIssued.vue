<template>
  <div class="contents">
    <div class="support-guide-wrap">
      <div class="support-guide-header">
        <h2 class="tit-type2">멤버십카드 발급</h2>
        <div class="header-menu">
          <div class="date">2022-02-02</div>
          <div class="right">
            <button>
              <Icon type="sns" />
            </button>
          </div>
        </div>
      </div>
      
      <!-- 멤버십카드 신청 -->
      <div class="shadow-box">
        <h3 class="tit-type4"><span class="i-wrap"><Icon type="card" /><span>멤버십카드 신청</span></span></h3>
        <div class="text-wrap">
            <p>차지비는 모바일카드를 통한 충전을 지원합니다. 타사업자 충전기 사용을 위해 멤버십카드가 필요하신 경우 별도로 발급이 가능합니다. <br>(유료, 6,000원)</p>
            <p>차지비 충전카드 발급을 원하실 경우 아래의 버튼을 눌러주세요.</p>
        </div>
        <router-link to="/" class="btn-type1 st1">멤버십카드 신청 하러가기</router-link>
      </div>
      
    </div>
  </div>
</template>

<script>
export default {
  components: {
    
  },
  data(){
    return{
     
    }
  },
   mounted(){
   
  }
}
</script>
