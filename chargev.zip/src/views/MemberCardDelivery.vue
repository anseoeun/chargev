<template>
  <div class="contents">
    <div class="member-card-wrap">
      <div class="member-card-header">
        <h2 class="tit-type3">멤버십 카드 신청</h2>
        <p class="text-type1">멤버십 카드 배송현황은 <br>아래와 같습니다.</p>
      </div>

      <!-- 신청정보 -->
      <div class="shadow-box">
        <h3 class="tit-type4">신청정보</h3>
        <div class="grid-list">
            <div class="row">
                <div class="tit">주소</div>
                <div class="txt">서울시 송파구 올림픽로 300 </div>
            </div>
            <div class="row">
                <div class="tit">상세주소</div>
                <div class="txt">30층, 3045호 차지비</div>
            </div>
        </div>
      </div>

      <!-- 배송정보 -->
      <div class="shadow-box">
        <h3 class="tit-type4">배송정보</h3>
        <div class="grid-list">
            <div class="row">
                <div class="tit">신청일</div>
                <div class="txt">2022-02-20</div>
            </div>
            <div class="row">
                <div class="tit">배송종류</div>
                <div class="txt">일반등기</div>
            </div>
            <div class="row">
                <div class="tit">등기번호</div>
                <div class="txt">161616161616</div>
            </div>
            <div class="row">
                <div class="tit">상태</div>
                <div class="txt">배송중</div>
            </div>
            <div class="row">
                <div class="tit">발송처</div>
                <div class="txt">송파우체국</div>
            </div>
            <div class="row">
                <div class="tit">발송일</div>
                <div class="txt">2022-02-22</div>
            </div>
        </div>
      </div>

      <!-- 결제정보 -->
      <div class="shadow-box">
        <h3 class="tit-type4">결제정보</h3>
        <div class="grid-list">
            <div class="row">
                <div class="tit">결제금액</div>
                <div class="txt">6,000원</div>
            </div>
        </div>
      </div>

    </div>
  </div>
</template>
