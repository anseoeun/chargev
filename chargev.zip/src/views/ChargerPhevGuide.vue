<template>
  <div class="contents">
    <div class="support-guide-wrap">
      <div class="support-guide-header">
        <h2 class="tit-type2">PHEV차량 충전안내</h2>
        <div class="header-menu">
          <div class="date">2022-02-02</div>
          <div class="right">
            <button>
              <Icon type="sns" />
            </button>
          </div>
        </div>
      </div>
      
      <!-- PHEV 완속 충전 -->
      <div class="shadow-box">
        <h3 class="tit-type4"><span class="i-wrap"><Icon type="true" /><span>PHEV 완속 충전</span></span></h3>
        <div class="text-wrap">
          <p>PHEV 차량은 완속 충전 방식으로 충전이 가능합니다. <br>PHEV는 평균 충전속도는 시간당 3.3kW로 평균 4시간이면 완충이 가능하기 때문에, 충전이 완료되면 다음 충전 이용 고객을 위해 반드시 차량을 이동하여 주시기 바랍니다.</p>
        </div>
      </div>
      
      <!-- PHEV 급속 충전 -->
      <div class="shadow-box">
        <h3 class="tit-type4"><span class="i-wrap"><Icon type="false" /><span>PHEV 급속 충전</span></span></h3>
        <div class="text-wrap">
          <p>PHEV 차량은 급속 충전이 불가합니다.  <br>변환 젠더 등을 이용해 급속충전기를 완속으로 이용할 경우 출력이 급격히 낮아지므로, 급속충전기 이용 및 운영 목적에 적합하지 않습니다.</p>
          <p>또한 이로 인한 이용자 간의 분쟁, 충전기 운영 방해 및 영업 손실에 해당될 수 있으므로 성숙한 충전 문화 확립을 위해 PHEV 차량은 완속충전기를 이용해주시기 바랍니다.  </p>
        </div>
      </div>
      
    </div>
  </div>
</template>

<script>
export default {
  components: {
    
  },
  data(){
    return{
     
    }
  },
   mounted(){
   
  }
}
</script>
