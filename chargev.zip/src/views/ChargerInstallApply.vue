<template>
  <div class="contents">
    <div class="support-guide-wrap">
      <div class="support-guide-header">
        <h2 class="tit-type2">충전기 설치 신청</h2>
        <div class="header-menu">
          <div class="date">2022-02-02</div>
          <div class="right">
            <button>
              <Icon type="sns" />
            </button>
          </div>
        </div>
      </div>
      
      <!-- 충전기 설치 신청 -->
      <div class="shadow-box">
        <h3 class="tit-type4"><span class="i-wrap"><Icon type="charge" /><span>충전기 설치 신청</span></span></h3>
        <div class="grid-list">
            <router-link to="/" class="row link"><div class="txt"><b>모바일카드 충전 동영상</b></div></router-link>
        </div>
        <router-link to="/" class="btn-type1 st1">충전기 설치 신청 하러가기</router-link>
      </div>
      
    </div>
  </div>
</template>

<script>
export default {
  components: {
    
  },
  data(){
    return{
     
    }
  },
   mounted(){
   
  }
}
</script>
