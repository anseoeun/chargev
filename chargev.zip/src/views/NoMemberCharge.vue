<template>
  <div class="contents">
    <div class="support-guide-wrap">
      <div class="support-guide-header">
        <h2 class="tit-type2">비회원 충전</h2>
        <div class="header-menu">
          <div class="date">2022-02-02</div>
          <div class="right">
            <button>
              <Icon type="sns" />
            </button>
          </div>
        </div>
      </div>
      
      <!-- 비회원 충전 -->
      <div class="shadow-box">
        <h3 class="tit-type4"><span class="i-wrap"><Icon type="lightning" /><span>비회원 충전</span></span></h3>
        <div class="text-wrap">
          <p>차집지는 모바일앱을 통한 비회원 결제를 지원하고 있습니다. 현장에서는 충전기 모델에 따라 후불교통카드, 삼성페이, IC카드 삽입 등으로 충전이 가능합니다. </p>
          <p>※ 차지비 회원가입 후 APP 통해 충전해보세요. 비회원 충전단가 보다 저렴한 요금으로 이용 가능합니다.</p>
          <p>비회원 충전방법은 충전기 사용방법을 통해 자세히 확인할 수 있습니다.</p>
        </div>
        <router-link to="/" class="btn-type1 st1">충전기 사용방법 확인하기</router-link>
      </div>

    </div>
  </div>
</template>

