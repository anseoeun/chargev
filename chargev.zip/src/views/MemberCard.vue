<template>
  <div class="contents">
    <div class="member-card-wrap">
      <div class="member-card-header">
        <h2 class="tit-type3">멤버십카드 관리</h2>
        <p class="text-type1">멤버십카드의 발급, 재발급, 배송현황을 <br>확인 가능합니다.</p>
      </div>
      <!-- 신청/설치 -->
      <div class="shadow-box">
        <h3 class="tit-type4">멤버십카드관리</h3>
        <div class="card-type">
          <div class="card line"><Icon type="logo" /></div>
          <div class="info"><span class="name">모바일카드</span><span class="num">1955-1231-1231-1231</span></div>
        </div>
        <router-link to="/" class="btn-type1 st1">멤버십카드 신청</router-link>
      </div>
    </div>
  </div>
</template>
