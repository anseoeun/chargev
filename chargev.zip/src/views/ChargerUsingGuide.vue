<template>
  <div class="contents">
    <div class="support-guide-wrap">
      <div class="support-guide-header">
        <h2 class="tit-type2">충전기 사용방법</h2>
        <div class="header-menu">
          <div class="date">2022-02-02</div>
          <div class="right">
            <button>
              <Icon type="sns" />
            </button>
          </div>
        </div>
      </div>
      
      <!-- 모바일카드를 통한 충전 -->
      <div class="shadow-box">
        <h3 class="tit-type4"><span class="i-wrap"><Icon type="lightning" /><span>모바일카드를 통한 충전</span></span></h3>
        <div class="grid-list">
            <router-link to="/" class="row link"><div class="txt"><b>모바일카드 충전 동영상</b></div></router-link>
        </div>
      </div>
      
      <!-- 모바일카드를 통한 충전 -->
      <div class="shadow-box">
        <h3 class="tit-type4"><span class="i-wrap"><Icon type="lightning" /><span>멤버십카드를 통한 충전</span></span></h3>
        <div class="grid-list">
            <router-link to="/" class="row link"><div class="txt"><b>모바일카드 충전 동영상</b></div></router-link>
        </div>
      </div>
      
      <!-- 비회원 충전 -->
      <div class="shadow-box">
        <h3 class="tit-type4"><span class="i-wrap"><Icon type="lightning" /><span>비회원 충전</span></span></h3>
        <div class="grid-list">
            <router-link to="/" class="row link"><div class="txt"><b>모바일카드 충전 동영상</b></div></router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {
    
  },
  data(){
    return{
     
    }
  },
   mounted(){
   
  }
}
</script>
