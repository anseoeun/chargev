<template>
  <div class="contents">
    <div class="support-guide-wrap">
      <div class="support-guide-header">
        <h2 class="tit-type2">완성차 멤버십카드</h2>
        <div class="header-menu">
          <div class="date">2022-02-02</div>
          <div class="right">
            <button>
              <Icon type="sns" />
            </button>
          </div>
        </div>
      </div>
      
      <!-- 완성차 멤버십카드 -->
      <div class="shadow-box">
        <h3 class="tit-type4"><span class="i-wrap"><Icon type="rect-car" /><span>완성차 멤버십카드</span></span></h3>
        <div class="text-wrap">
          <p>차지비와 제휴한 완성차 업체는 차량에 차지비 서비스 이용이 가능한 전용카드가 적재되어 출고됩니다.</p>
          <p>멤버십카드가 지급되는 완성차 업체는 아래와 같습니다.</p>
        </div>
      </div>
      
      <!-- 완성차 멤버십카드 미적재 -->
      <div class="shadow-box">
        <h3 class="tit-type4"><span class="i-wrap"><Icon type="rect-car-x" /><span>완성차 멤버십카드 미적재</span></span></h3>
        <div class="text-wrap">
          <p>완성차 전용 멤버십카드는 안내서와 함께 패키징이 되어있으며, 차량의 조수석, 글로브박스, 트렁크, 뒷 좌석에 있습니다.</p>
          <p>차량내에 완성차 멤버십 카드가 없을 경우 고객센터를 통해 문의주시면 절차를 통해 발급을 진행해드리도록 하겠습니다.</p>
        </div>
        <router-link to="/" class="btn-type1 st1">고객센터 문의하기</router-link>
      </div>
      
    </div>
  </div>
</template>

