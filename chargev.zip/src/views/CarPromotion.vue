<template>
  <div class="contents">
    <div class="support-guide-wrap">
      <div class="support-guide-header">
        <h2 class="tit-type2">완성차 프로모션</h2>
        <div class="header-menu">
          <div class="date">2022-02-02</div>
          <div class="right">
            <button>
              <Icon type="sns" />
            </button>
          </div>
        </div>
      </div>
      
      <!-- 완성차 충전포인트 -->
      <div class="shadow-box">
        <h3 class="tit-type4"><span class="i-wrap"><Icon type="car" /><span>완성차 충전포인트</span></span></h3>
        <div class="text-wrap">
          <p>차지비는 완성차 업체와 파트너십을 체결 후 충전이 가능한 충전 포인트를 지급해드리고 있습니다.</p>
          <p>차량 제조사별 충전포인트는 회원가입 후 대상자 확인 후에 지급되며, 차량 구매 등 대상자 확인 절차에 일정기간이 소요될 수 있습니다. 차량 제조사별 충전포인트는 회원가입이 완료된 시점으로부터 유효기간 동안 사용이 가능하며, 유효기간이 경과된 시점에는 자동 소멸됩니다.</p>
          <p>지급받은 포인트에 대한 금액 및 유효기간에 대한 내용은 내정보 -> 결제수단 관리에서 확인하실 수 있습니다.</p>
          <p>차지비와 제휴 후 프로모션이 지급된 완성차 업체는 아래와 같습니다.</p>
          <p>(아이콘)현대자동차,BMW, 벤츠, 재규어 랜드로버 , 닛산, 토요타, 르노삼성, GM, 볼보, 폴스타</p>
        </div>
      </div>
      
      <!-- 부정사용 제한 -->
      <div class="shadow-box">
        <h3 class="tit-type4"><span class="i-wrap"><Icon type="warning" /><span>부정사용 제한</span></span></h3>
        <div class="text-wrap">
          <p>아래 각 호의 행위는 부정사용행위로 간주되며, 이용약관 제 7조, 제26조에 의거하여 서비스 제재를 시행할 수 있습니다.</p>
          <p>1) 혜택 및 서비스 대상 차량 외 다른 차량에 프로모션 카드를 이용하여 충전하는 행위 2) 금전의 대가 여부와 관계없이 혜택 및 서비스를 타인에게 양도, 대여하는 행위 3) 사회통념상 상식적으로 발생할 수 없는 충전 행위 4) 혜택 및 서비스에 대한 거래 행위가 적발되었을 경우 등</p>
        </div>
      </div>
      
    </div>
  </div>
</template>

<script>
export default {
  components: {
    
  },
  data(){
    return{
     
    }
  },
   mounted(){
   
  }
}
</script>
